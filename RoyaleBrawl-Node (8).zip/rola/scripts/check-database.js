const path = require('node:path')
require('dotenv').config({ path: path.join(__dirname, '..', '.env') })
const database = require('../src/database/MongoDatabase')

async function run () {
  await database.connect(process.env.MONGODB_URI, process.env.MONGODB_DB)
  const result = await database.database.command({ ping: 1 })
  process.stdout.write(result.ok === 1 ? 'MongoDB connection successful\n' : 'MongoDB connection failed\n')
  await database.close()
}

run().catch(error => {
  console.error(error.message)
  process.exit(1)
})
