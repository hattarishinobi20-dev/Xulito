require('./src/index')
