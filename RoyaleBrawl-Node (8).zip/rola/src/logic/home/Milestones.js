const data = require('../../data/milestones.json')

class Milestones {
  encode (stream, maximumRank = 20) {
    const trophiesCount = maximumRank - 1
    const experienceCount = 499
    stream.writeVInt(trophiesCount + experienceCount)

    for (let i = 0; i < trophiesCount; i++) {
      stream.writeVInt(1)
      stream.writeVInt(i)
      stream.writeVInt(i >= 34 ? data.progressStartTrophies[33] + 50 * (i - 33) : data.progressStartTrophies[i])
      stream.writeVInt(i >= 34 ? 50 : data.progressTrophies[i])
      stream.writeVInt(0)
      stream.writeVInt(1)
      stream.writeVInt(1)
      stream.writeVInt(10)
      stream.writeVInt(5)
      stream.writeVInt(1)
    }

    for (let i = 0; i < experienceCount; i++) {
      stream.writeVInt(5)
      stream.writeVInt(i)
      stream.writeVInt(data.progressStartExp[i])
      stream.writeVInt(data.progressExp[i])
      stream.writeVInt(0)
      stream.writeVInt(1)
      stream.writeVInt(12)
      stream.writeVInt(20)
      stream.writeVInt(5)
      stream.writeVInt(1)
    }
  }
}

module.exports = new Milestones()
