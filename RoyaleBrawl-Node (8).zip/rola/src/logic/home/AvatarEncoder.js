const { writeDataReference, writeVLong } = require('./StreamHelper')

function encodeAvatar (stream, avatar) {
  writeVLong(stream, avatar.accountId)
  writeVLong(stream, avatar.accountId)
  writeVLong(stream, avatar.accountId)
  stream.writeString(avatar.name)
  stream.writeBoolean(avatar.nameSetByUser)
  stream.writeInt(-1)
  stream.writeVInt(5)
  stream.writeVInt(3 + avatar.heroes.length)
  writeDataReference(stream, 5000001)
  stream.writeVInt(avatar.gold)
  writeDataReference(stream, 5000005)
  stream.writeVInt(avatar.chips)
  writeDataReference(stream, 5000006)
  stream.writeVInt(avatar.elexir)

  for (const hero of avatar.heroes) {
    writeDataReference(stream, hero.cardId)
    stream.writeVInt(1)
  }

  stream.writeVInt(avatar.heroes.length)
  for (const hero of avatar.heroes) {
    writeDataReference(stream, hero.characterId)
    stream.writeVInt(hero.trophies)
  }

  stream.writeVInt(avatar.heroes.length)
  for (const hero of avatar.heroes) {
    writeDataReference(stream, hero.characterId)
    stream.writeVInt(hero.highestTrophies)
  }

  stream.writeVInt(0)
  stream.writeVInt(0)
  stream.writeVInt(avatar.diamonds)
  stream.writeVInt(0)
  stream.writeVInt(0)
  stream.writeVInt(0)
  stream.writeVInt(0)
  stream.writeVInt(0)
  stream.writeVInt(0)
  stream.writeVInt(0)
  stream.writeVInt(0)
  stream.writeVInt(0)
  stream.writeVInt(avatar.tutorialsCompletedCount)
}

module.exports = {
  encodeAvatar
}
