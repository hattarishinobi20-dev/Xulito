const milestones = require('./Milestones')
const { writeDataReference, writeLong } = require('./StreamHelper')

function getTrophies (avatar, field) {
  return avatar.heroes.reduce((total, hero) => total + (hero[field] || 0), 0)
}

function getUtcDayOfYear (date) {
  const start = Date.UTC(date.getUTCFullYear(), 0, 0)
  return Math.floor((date.getTime() - start) / 86400000)
}

function encodeEvent (stream, event) {
  stream.writeVInt(event.slot)
  stream.writeVInt(event.slot)
  stream.writeVInt(0)
  stream.writeVInt(Math.trunc((event.endTime.getTime() - Date.now()) / 1000))
  stream.writeVInt(10)
  stream.writeVInt(10)
  stream.writeVInt(60)
  stream.writeBoolean(true)
  stream.writeBoolean(true)
  writeDataReference(stream, event.locationId)
  stream.writeVInt(0)
  stream.writeVInt(2)
  stream.writeString('Royale Brawl v1 by PrimoDEVHacc')
}

function encodeHome (stream, account, events) {
  const now = new Date()
  const home = account.home
  const avatar = account.avatar

  stream.writeVInt(now.getUTCHours() * 3600 + now.getUTCMinutes() * 60 + now.getUTCSeconds())
  stream.writeVInt(0)
  stream.writeVInt(getTrophies(avatar, 'trophies'))
  stream.writeVInt(getTrophies(avatar, 'highestTrophies'))
  stream.writeVInt(99999)
  writeDataReference(stream, home.thumbnailId)
  stream.writeVInt(7)
  for (let i = 0; i < 7; i++) stream.writeVInt(i)
  stream.writeVInt(0)
  stream.writeVInt(0)
  stream.writeBoolean(false)
  stream.writeVInt(0)
  stream.writeVInt(home.tokenReward)
  stream.writeVInt(0)
  stream.writeBoolean(false)
  stream.writeVInt(0)
  stream.writeVInt(0)
  stream.writeBoolean(false)
  home.tokenReward = 0
  stream.writeVInt(now.getUTCFullYear() * 1000 + getUtcDayOfYear(now))
  stream.writeVInt(100)
  stream.writeVInt(10)
  stream.writeVInt(20)
  stream.writeVInt(50)
  stream.writeVInt(50)
  stream.writeVInt(1000)
  stream.writeVInt(7 * 24)
  stream.writeVInt(1)
  stream.writeVInt(2)
  stream.writeVInt(10)
  stream.writeVInt(60)
  stream.writeVInt(3)
  stream.writeVInt(10)
  stream.writeVInt(70)
  stream.writeVInt(600)
  stream.writeVInt(4)
  for (let i = 1; i <= 4; i++) {
    stream.writeVInt(i)
    stream.writeVInt(0)
  }
  stream.writeVInt(events.length)
  for (const event of events) encodeEvent(stream, event)
  stream.writeVInt(0)
  stream.writeVInt(5)
  for (let i = 1; i <= 5; i++) stream.writeVInt(i)
  milestones.encode(stream)
  writeLong(stream, home.homeId)
}

module.exports = {
  encodeEvent,
  encodeHome,
  getTrophies
}
