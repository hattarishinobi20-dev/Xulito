const GlobalId = require('../GlobalId')

function writeDataReference (stream, globalId) {
  if (!globalId || globalId <= 0) {
    stream.writeVInt(0)
    return
  }
  stream.writeVInt(GlobalId.getClassId(globalId))
  stream.writeVInt(GlobalId.getInstanceId(globalId))
}

function writeVLong (stream, value) {
  const numeric = BigInt(value)
  stream.writeVInt(Number(BigInt.asIntN(32, numeric >> 32n)))
  stream.writeVInt(Number(BigInt.asIntN(32, numeric)))
}

function writeLong (stream, value) {
  const numeric = BigInt(value)
  stream.writeInt(Number(BigInt.asIntN(32, numeric >> 32n)))
  stream.writeInt(Number(BigInt.asIntN(32, numeric)))
}

function readLong (stream) {
  const [high, low] = stream.readLong()
  return Number((BigInt(high) << 32n) | BigInt(low >>> 0))
}

function readVLong (stream) {
  const high = stream.readVInt()
  const low = stream.readVInt()
  return Number((BigInt(high) << 32n) | BigInt(low >>> 0))
}

function readDataReference (stream) {
  const classId = stream.readVInt()
  if (classId <= 0) return 0
  return GlobalId.create(classId, stream.readVInt())
}

module.exports = {
  readDataReference,
  readLong,
  readVLong,
  writeDataReference,
  writeLong,
  writeVLong
}
