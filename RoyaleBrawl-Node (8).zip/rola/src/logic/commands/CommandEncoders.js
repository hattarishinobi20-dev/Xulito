const { writeDataReference } = require('../home/StreamHelper')

function encodeBaseCommand (stream) {
  stream.writeVInt(1)
  stream.writeVInt(1)
  stream.writeVInt(0)
  stream.writeVInt(0)
}

function encodeChangeAvatarNameCommand (stream, command) {
  stream.writeString(command.name)
  stream.writeVInt(command.changeNameCost)
}

function encodeDiamondsAddedCommand (stream) {
  encodeBaseCommand(stream)
}

function encodeGatchaDrop (stream, drop) {
  if (drop.type !== 1) {
    stream.writeVInt(5)
    stream.writeVInt(6)
  } else {
    stream.writeVInt(0)
  }
  stream.writeVInt(drop.count)
  if (drop.type === 1) writeDataReference(stream, drop.dataGlobalId)
  else stream.writeVInt(0)
}

function encodeDeliveryUnit (stream, unit) {
  const drop = unit.drops[unit.drops.length - 1]
  stream.writeVInt(drop.rarity)
  encodeGatchaDrop(stream, drop)
}

function encodeGiveDeliveryItemsCommand (stream, command) {
  encodeDeliveryUnit(stream, command.deliveryUnits[command.deliveryUnits.length - 1])
  encodeBaseCommand(stream)
}

module.exports = {
  encodeBaseCommand,
  encodeChangeAvatarNameCommand,
  encodeDeliveryUnit,
  encodeDiamondsAddedCommand,
  encodeGatchaDrop,
  encodeGiveDeliveryItemsCommand
}
