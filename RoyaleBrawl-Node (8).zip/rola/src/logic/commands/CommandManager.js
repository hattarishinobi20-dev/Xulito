const { readDataReference } = require('../home/StreamHelper')

class Command {
  constructor (type) {
    this.type = type
  }

  decodeBase (stream) {
    this.tick = stream.readVInt()
    this.checksum = stream.readVInt()
    this.reserved1 = stream.readVInt()
    this.reserved2 = stream.readVInt()
  }

  execute () {
    return 0
  }
}

class GatchaCommand extends Command {
  constructor () {
    super(500)
  }

  decode (stream) {
    this.decodeBase(stream)
    this.isGold = stream.readBoolean()
  }

  execute (account) {
    if (this.isGold) {
      if (account.avatar.gold < 100) return -1
      account.avatar.gold -= 100
    } else {
      if (account.avatar.diamonds < 10) return -1
      account.avatar.diamonds -= 10
    }
    return 0
  }
}

class SetPlayerThumbnailCommand extends Command {
  constructor () {
    super(506)
  }

  decode (stream) {
    this.decodeBase(stream)
    this.classId = stream.readVInt()
    this.thumbnailInstanceId = stream.readVInt()
  }

  execute (account, context) {
    if (this.thumbnailInstanceId < 0) return 1
    if (this.thumbnailInstanceId >= context.dataTables.getTable(28).length) return 2
    account.home.thumbnailId = 28000000 + this.thumbnailInstanceId
    return 0
  }
}

class SelectSkinCommand extends Command {
  constructor () {
    super(507)
  }

  decode (stream) {
    this.decodeBase(stream)
    this.skinClassId = stream.readVInt()
    this.skinInstanceId = stream.readVInt()
  }
}

class DebugCommand extends Command {
  constructor () {
    super(1000)
  }

  decode (stream) {
    this.decodeBase(stream)
    this.debugCommand = stream.readVInt()
    this.parameter = stream.readVInt()
    this.input = stream.readString()
    this.target = readDataReference(stream)
  }
}

const commandTypes = {
  500: GatchaCommand,
  506: SetPlayerThumbnailCommand,
  507: SelectSkinCommand,
  1000: DebugCommand
}

class CommandManager {
  decode (stream) {
    const type = stream.readVInt()
    const CommandType = commandTypes[type]
    if (!CommandType) return null
    const command = new CommandType()
    command.decode(stream)
    return command
  }
}

module.exports = new CommandManager()
