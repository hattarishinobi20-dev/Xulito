const gameplay = require('../../data/gameplay.json')

class EventService {
  constructor () {
    this.events = []
    this.timer = null
  }

  start (dataTables) {
    this.dataTables = dataTables
    this.refresh()
    this.timer = setInterval(() => this.refresh(), 60 * 60 * 1000)
    this.timer.unref()
  }

  refresh () {
    const locations = this.dataTables.getTable(15)
    this.events = gameplay.slots.map(config => {
      const eligible = locations.filter(location => config.game_modes.includes(location.GameMode) && location.Name !== 'Tutorial')
      const location = eligible[Math.floor(Math.random() * eligible.length)]
      return {
        slot: config.slot,
        locationId: location.globalId,
        endTime: new Date(Date.now() + 60 * 60 * 1000)
      }
    })
  }

  getEvents () {
    return this.events.map(event => ({ ...event }))
  }

  getEvent (slot) {
    const event = this.events.find(entry => entry.slot === slot)
    return event ? { ...event } : null
  }

  stop () {
    if (this.timer) clearInterval(this.timer)
    this.timer = null
  }
}

module.exports = new EventService()
