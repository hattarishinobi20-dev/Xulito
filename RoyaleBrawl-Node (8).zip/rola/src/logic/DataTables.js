const fs = require('node:fs')
const path = require('node:path')
const { parse } = require('csv-parse/sync')
const GlobalId = require('./GlobalId')

const definitions = {
  projectiles: 6,
  alliance_badges: 8,
  locations: 15,
  characters: 16,
  area_effects: 17,
  items: 18,
  skills: 20,
  cards: 23,
  tiles: 27,
  player_thumbnails: 28,
  skins: 29
}

class DataTables {
  constructor () {
    this.tables = new Map()
  }

  load (assetsPath) {
    for (const [name, classId] of Object.entries(definitions)) {
      const content = fs.readFileSync(path.join(assetsPath, `${name}.csv`), 'utf8')
      const rows = parse(content, { bom: true, relax_column_count: true, skip_empty_lines: true })
      const columns = rows[0]
      const entries = rows.slice(2).map((row, instanceId) => {
        const entry = { classId, instanceId, globalId: GlobalId.create(classId, instanceId) }
        for (let i = 0; i < columns.length; i++) entry[columns[i]] = row[i] ?? ''
        return entry
      })
      this.tables.set(classId, entries)
    }
    return this
  }

  getByGlobalId (globalId) {
    const table = this.tables.get(GlobalId.getClassId(globalId))
    return table ? table[GlobalId.getInstanceId(globalId)] || null : null
  }

  getByName (classId, name) {
    const table = this.tables.get(classId) || []
    return table.find(entry => entry.Name === name) || null
  }

  getTable (classId) {
    return this.tables.get(classId) || []
  }
}

module.exports = new DataTables()
