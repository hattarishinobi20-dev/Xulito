const Messaging = require('../../core/Networking/Messaging')
const LogicConfig = require('../../core/Logic/Server/LogicConfig')
const LogicLaserMessageFactory = require('../../core/Protocol/LogicLaserMessageFactory')
const ClientHelloMessage = require('../../core/Protocol/Messages/Client/Auth/ClientHelloMessage')
const AuthenticationMessage = require('../protocol/messages/client/auth/AuthenticationMessage')
const clientMessages = require('../protocol/ClientMessages')

function writeMessage (message, session, doNotEncrypt) {
  const payload = LogicConfig.crypto.activate && !doNotEncrypt
    ? session.crypto.encrypt(message.id, message.stream.buffer)
    : message.stream.buffer
  const header = message.writeHeader(message.id, payload.length, message.version)
  session.write(Buffer.concat([header, payload]))
  session.log(`Packet ${message.id} (${message.constructor.name}) was sent.`)
}

function installMessaging () {
  Messaging.prototype.send = async function (doNotEncrypt) {
    if (this.id < 20000) return
    await this.encode()
    writeMessage(this, this.session, doNotEncrypt)
  }
}

function installMessageFactory () {
  LogicLaserMessageFactory.loadMessages = function () {
    this.messages = {
      10100: ClientHelloMessage,
      10101: AuthenticationMessage,
      ...clientMessages
    }
    this.messagesList = Object.keys(this.messages).map(Number)
  }
}

function installCoreAdapters () {
  installMessaging()
  installMessageFactory()
}

module.exports = installCoreAdapters
