const path = require('node:path')
require('dotenv').config({ path: path.join(__dirname, '..', '.env') })
const { database, accounts, alliances, teams } = require('./database')
const dataTables = require('./logic/DataTables')
const eventService = require('./logic/events/EventService')
const installCoreAdapters = require('./core/installCoreAdapters')
const messageRouter = require('./protocol/MessageRouter')
const udpGateway = require('./network/UdpGateway')
const battleService = require('./battle/BattleService')
const matchmaking = require('./battle/MatchmakingService')
const loadRuntimeConfig = require('./config/RuntimeConfig')
const AdminConsole = require('./admin/AdminConsole')

const adminConsole = new AdminConsole(database, matchmaking, battleService)

async function start () {
  const runtimeConfig = loadRuntimeConfig(process.env)
  await database.connect(runtimeConfig.mongodbUri, runtimeConfig.mongodbDb)
  global.repositories = { accounts, alliances, teams }
  global.messageRouter = messageRouter
  global.matchmaking = matchmaking
  global.runtimeConfig = runtimeConfig

  const LogicConfig = require('../core/Logic/Server/LogicConfig')
  const LogicVersion = require('../core/Logic/LogicVersion')
  LogicConfig.loadConfig()
  LogicConfig.serverName = 'RoyaleBrawl'
  LogicConfig.patcher.enabled = false
  LogicConfig.logger.enableAdminConsole = false
  LogicConfig.crypto.activate = true
  LogicConfig.crypto.type = 0
  LogicConfig.crypto.rc4.key = 'c2GJQU5hCjW56525cLA9MQ9JINk3zZk4nJsjYq'
  LogicConfig.crypto.rc4.nonce = 'nonce'
  LogicConfig.loadConfig = () => {}
  LogicVersion.major = 1
  LogicVersion.minor = 0
  LogicVersion.build = 1714

  dataTables.load(path.join(__dirname, '..', 'assets', 'csv_logic'))
  eventService.start(dataTables)
  udpGateway.start('0.0.0.0', runtimeConfig.udpPort)
  battleService.start()
  matchmaking.start()
  installCoreAdapters()

  process.chdir(path.join(__dirname, '..', 'core'))
  require('../core/index')
  adminConsole.start()
}

async function shutdown () {
  adminConsole.close()
  matchmaking.close()
  battleService.close()
  udpGateway.close()
  eventService.stop()
  await database.close()
  process.exit(0)
}

process.once('SIGINT', shutdown)
process.once('SIGTERM', shutdown)

start().catch(error => {
  console.error(error)
  process.exit(1)
})
