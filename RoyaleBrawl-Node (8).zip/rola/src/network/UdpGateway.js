const dgram = require('node:dgram')
const { randomBytes } = require('node:crypto')
const DataStream = require('../../core/Titan/DataStream')
const { readLong, writeLong } = require('../logic/home/StreamHelper')

class UdpGateway {
  constructor () {
    this.server = null
    this.sockets = new Map()
    this.host = '0.0.0.0'
    this.port = 9449
  }

  start (host, port) {
    if (this.server) return
    this.host = host
    this.port = port
    this.server = dgram.createSocket('udp4')
    this.server.on('message', (buffer, remote) => this.receive(buffer, remote))
    this.server.on('error', error => console.error(error))
    this.server.bind(port, host)
  }

  createSocket (tcpSession, battle, spectator = false) {
    let sessionId
    do sessionId = randomBytes(6).readUIntBE(0, 6)
    while (sessionId === 0 || this.sockets.has(sessionId))
    const socket = {
      sessionId,
      tcpSession,
      battle,
      spectator,
      remote: null
    }
    this.sockets.set(socket.sessionId, socket)
    return socket
  }

  removeSocket (sessionId) {
    this.sockets.delete(sessionId)
  }

  receive (buffer, remote) {
    try {
      if (!Buffer.isBuffer(buffer) || buffer.length < 12 || buffer.length > 65507) return
      const stream = DataStream.getByteStream(buffer)
      const sessionId = readLong(stream)
      stream.readShort()
      const socket = this.sockets.get(sessionId)
      if (!socket) return
      const type = stream.readVInt()
      const length = stream.readVInt()
      if (type !== 10555 || length < 0 || length > 8192 || stream.offset + length > buffer.length || !socket.battle) return
      if (socket.remote && (socket.remote.address !== remote.address || socket.remote.port !== remote.port)) return
      const payload = buffer.subarray(stream.offset, stream.offset + length)
      const inputs = this.decodeInputs(payload)
      if (inputs.length === 0) return
      if (!socket.remote) socket.remote = { address: remote.address, port: remote.port }
      for (const input of inputs) {
        if (socket.spectator) socket.battle.handleSpectatorInput(input, sessionId)
        else socket.battle.addInput(input, sessionId)
      }
    } catch {
      return false
    }
  }

  decodeInputs (payload) {
    try {
      if (!Buffer.isBuffer(payload) || payload.length > 8192) return []
      const stream = DataStream.getByteStream(payload)
      stream.readVInt()
      stream.readVInt()
      const count = stream.readVInt()
      if (count < 1 || count > 32) return []
      const inputs = []
      for (let i = 0; i < count; i++) {
        const input = {
          index: stream.readVInt(),
          sequence: stream.readVInt(),
          type: stream.readVInt(),
          x: stream.readVInt(),
          y: stream.readVInt()
        }
        if (!Number.isSafeInteger(input.index) || input.index < 0 || input.type < 0 || input.type > 108) return []
        if (!Number.isSafeInteger(input.x) || !Number.isSafeInteger(input.y)) return []
        inputs.push(input)
      }
      return inputs
    } catch {
      return []
    }
  }

  async sendMessage (udpSocket, message) {
    if (!udpSocket.remote || !this.server) return false
    await message.encode()
    const stream = DataStream.getByteStream()
    writeLong(stream, udpSocket.sessionId)
    stream.writeShort(0)
    stream.writeVInt(message.id)
    stream.writeVInt(message.stream.buffer.length)
    stream.writeBytesWithoutLength(message.stream.buffer)
    this.server.send(stream.buffer, udpSocket.remote.port, udpSocket.remote.address)
    return true
  }

  close () {
    if (this.server) this.server.close()
    this.server = null
    this.sockets.clear()
  }
}

module.exports = new UdpGateway()
