const database = require('../MongoDatabase')

class TeamRepository {
  get collection () {
    return database.collection('teams')
  }

  async create (team) {
    team.id = await database.nextId('teams')
    team.createdAt = new Date()
    team.updatedAt = new Date()
    await this.collection.insertOne(team)
    return team
  }

  async findById (id) {
    return this.collection.findOne({ id })
  }

  async save (team) {
    team.updatedAt = new Date()
    await this.collection.replaceOne({ id: team.id }, team, { upsert: true })
    return team
  }

  async remove (id) {
    await this.collection.deleteOne({ id })
  }
}

module.exports = new TeamRepository()
