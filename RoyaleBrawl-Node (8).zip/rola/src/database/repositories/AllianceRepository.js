const database = require('../MongoDatabase')

class AllianceRepository {
  get collection () {
    return database.collection('alliances')
  }

  async create (alliance) {
    alliance.allianceId = await database.nextId('alliances')
    alliance.trophies = alliance.trophies || 0
    alliance.members = alliance.members || []
    alliance.createdAt = new Date()
    alliance.updatedAt = new Date()
    await this.collection.insertOne(alliance)
    return alliance
  }

  async findById (allianceId) {
    return this.collection.findOne({ allianceId })
  }

  async save (alliance) {
    alliance.updatedAt = new Date()
    await this.collection.replaceOne(
      { allianceId: alliance.allianceId },
      alliance,
      { upsert: true }
    )
    return alliance
  }

  async leaderboard (limit = 200) {
    return this.collection
      .find({})
      .sort({ trophies: -1, allianceId: 1 })
      .limit(Math.min(Math.max(limit, 1), 200))
      .toArray()
  }

  async discover (limit = 20) {
    return this.collection
      .aggregate([{ $sample: { size: Math.min(Math.max(limit, 1), 100) } }])
      .toArray()
  }
}

module.exports = new AllianceRepository()
