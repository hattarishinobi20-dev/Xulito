const database = require('../MongoDatabase')
const createAccount = require('../../models/createAccount')

class AccountRepository {
  get collection () {
    return database.collection('accounts')
  }

  async create () {
    const accountId = await database.nextId('accounts')
    const account = createAccount(accountId)
    await this.collection.insertOne(account)
    return account
  }

  async findById (accountId) {
    return this.collection.findOne({ accountId })
  }

  async authenticate (accountId, passToken) {
    return this.collection.findOne({ accountId, passToken })
  }

  async save (account) {
    account.updatedAt = new Date()
    await this.collection.replaceOne(
      { accountId: account.accountId },
      account,
      { upsert: true }
    )
    return account
  }

  async leaderboard (limit = 200) {
    return this.collection
      .find({})
      .sort({ 'avatar.trophies': -1, accountId: 1 })
      .limit(Math.min(Math.max(limit, 1), 200))
      .toArray()
  }
}

module.exports = new AccountRepository()
