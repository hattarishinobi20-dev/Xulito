const database = require('./MongoDatabase')
const accounts = require('./repositories/AccountRepository')
const alliances = require('./repositories/AllianceRepository')
const teams = require('./repositories/TeamRepository')

module.exports = {
  database,
  accounts,
  alliances,
  teams
}
