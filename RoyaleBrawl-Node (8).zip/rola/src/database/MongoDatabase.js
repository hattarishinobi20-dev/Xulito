const { MongoClient } = require('mongodb')

class MongoDatabase {
  constructor () {
    this.client = null
    this.database = null
  }

  async connect (uri, databaseName) {
    if (!uri) throw new Error('MONGODB_URI is required')
    if (!databaseName) throw new Error('MONGODB_DB is required')
    this.client = new MongoClient(uri, {
      maxPoolSize: 50,
      minPoolSize: 1,
      retryReads: true,
      retryWrites: true
    })
    await this.client.connect()
    this.database = this.client.db(databaseName)
    await this.database.command({ ping: 1 })
    await this.createIndexes()
    return this.database
  }

  async createIndexes () {
    await Promise.all([
      this.database.collection('accounts').createIndexes([
        { key: { accountId: 1 }, name: 'accountId_unique', unique: true },
        { key: { passToken: 1 }, name: 'passToken_unique', unique: true },
        { key: { 'avatar.trophies': -1 }, name: 'avatar_trophies' },
        { key: { 'avatar.name': 1 }, name: 'avatar_name' }
      ]),
      this.database.collection('alliances').createIndexes([
        { key: { allianceId: 1 }, name: 'allianceId_unique', unique: true },
        { key: { trophies: -1 }, name: 'alliance_trophies' },
        { key: { name: 1 }, name: 'alliance_name' }
      ]),
      this.database.collection('teams').createIndexes([
        { key: { id: 1 }, name: 'team_id_unique', unique: true },
        { key: { 'members.accountId': 1 }, name: 'team_member_account' },
        { key: { updatedAt: 1 }, name: 'team_updated_at', expireAfterSeconds: 86400 }
      ]),
      this.database.collection('counters').createIndex({ _id: 1 }, { name: 'counter_id' })
    ])
  }

  collection (name) {
    if (!this.database) throw new Error('MongoDB is not connected')
    return this.database.collection(name)
  }

  async nextId (name) {
    const result = await this.collection('counters').findOneAndUpdate(
      { _id: name },
      { $inc: { value: 1 } },
      { upsert: true, returnDocument: 'after' }
    )
    return result.value
  }

  async close () {
    if (this.client) await this.client.close()
    this.client = null
    this.database = null
  }
}

module.exports = new MongoDatabase()
