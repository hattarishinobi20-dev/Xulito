function loadRuntimeConfig (environment) {
  const mongodbUri = environment.MONGODB_URI
  if (!mongodbUri) throw new Error('MONGODB_URI is required')
  const mongodbDb = environment.MONGODB_DB || 'royalebrawl'
  const udpPublicHost = environment.UDP_PUBLIC_HOST || '127.0.0.1'
  const udpPort = Number(environment.UDP_PORT || 9449)
  if (!Number.isInteger(udpPort) || udpPort < 1 || udpPort > 65535) throw new Error('UDP_PORT must be an integer between 1 and 65535')
  if (environment.NODE_ENV === 'production') {
    if (udpPublicHost === '127.0.0.1' || udpPublicHost === 'localhost' || udpPublicHost === '0.0.0.0' || udpPublicHost === '::1') {
      throw new Error('UDP_PUBLIC_HOST must be externally reachable in production')
    }
  }
  return {
    mongodbUri,
    mongodbDb,
    udpPublicHost,
    udpPort
  }
}

module.exports = loadRuntimeConfig
