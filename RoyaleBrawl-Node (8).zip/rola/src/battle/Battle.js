const { BattleEndMessage, VisionUpdateMessage } = require('../protocol/BattleMessages')
const udpGateway = require('../network/UdpGateway')
const GameObjectManager = require('./engine/GameObjectManager')

class Battle {
  constructor (id, location, variation) {
    this.id = id
    this.location = location
    this.variation = variation
    this.players = []
    this.playersBySessionId = new Map()
    this.spectators = new Map()
    this.inputQueue = []
    this.tick = 0
    this.gameOver = false
    this.ending = false
    this.timer = null
    this.maxTicks = variation === 6 ? 16000 : 3600
    this.gameObjectManager = null
    this.winnerTeam = -1
    this.lastError = null
    this.randomState = (id || 1) >>> 0
  }

  nextRandom (maximum) {
    if (maximum <= 0) return 0
    let value = this.randomState
    value ^= value << 13
    value ^= value >>> 17
    value ^= value << 5
    this.randomState = value >>> 0
    return this.randomState % maximum
  }

  addPlayer (player, udpSocket) {
    player.udpSessionId = udpSocket ? udpSocket.sessionId : -1
    player.lastHandledInput = 0
    player.score = player.score || 0
    player.killList = player.killList || []
    this.players.push(player)
    if (udpSocket) this.playersBySessionId.set(udpSocket.sessionId, player)
  }

  addSpectator (udpSocket) {
    this.spectators.set(udpSocket.sessionId, { socket: udpSocket, handledInputs: 0 })
  }

  removeSpectator (sessionId) {
    this.spectators.delete(sessionId)
    udpGateway.removeSocket(sessionId)
  }

  addInput (input, sessionId) {
    if (!this.playersBySessionId.has(sessionId) || this.gameOver || this.ending) return
    if (this.inputQueue.length >= 4096) this.inputQueue.splice(0, this.inputQueue.length - 2047)
    this.inputQueue.push({ ...input, sessionId })
  }

  handleSpectatorInput (input, sessionId) {
    const spectator = this.spectators.get(sessionId)
    if (spectator) spectator.handledInputs = input.index
  }

  start () {
    if (this.timer) return
    this.gameObjectManager = new GameObjectManager(this)
    this.timer = setInterval(() => this.update(), 50)
  }

  update () {
    if (this.gameOver || this.ending) return
    try {
      this.executeTick()
    } catch (error) {
      this.lastError = error
      void this.finish()
    }
  }

  executeTick () {
    while (this.inputQueue.length > 0) {
      const input = this.inputQueue.shift()
      const player = this.playersBySessionId.get(input.sessionId)
      if (player && input.index > player.lastHandledInput) {
        player.lastHandledInput = input.index
        player.lastInput = input
        if (this.gameObjectManager) this.gameObjectManager.handleInput(player, input)
      }
    }
    this.tick++
    if (this.gameObjectManager) this.gameObjectManager.update()
    this.sendVisionUpdates()
    if (this.gameObjectManager?.finished) {
      this.winnerTeam = this.gameObjectManager.winnerTeam
      void this.finish()
    } else if (this.tick >= this.maxTicks) {
      const scores = this.gameObjectManager?.teamScores || [0, 0]
      this.winnerTeam = scores[0] === scores[1] ? -1 : scores[0] > scores[1] ? 0 : 1
      void this.finish()
    }
  }

  sendVisionUpdates () {
    for (const [sessionId, player] of this.playersBySessionId) {
      const socket = udpGateway.sockets.get(sessionId)
      if (!socket || !socket.remote) continue
      const message = new VisionUpdateMessage(null, {
        tick: this.tick,
        handledInputs: player.lastHandledInput,
        visionBytes: this.gameObjectManager ? this.gameObjectManager.encode(player) : Buffer.alloc(0)
      })
      void udpGateway.sendMessage(socket, message).catch(error => {
        this.lastError = this.lastError || error
      })
    }
    for (const spectator of this.spectators.values()) {
      if (!spectator.socket.remote) continue
      const visionPlayer = this.players[0]
      const message = new VisionUpdateMessage(null, {
        tick: this.tick,
        handledInputs: spectator.handledInputs,
        visionBytes: this.gameObjectManager && visionPlayer ? this.gameObjectManager.encode(visionPlayer) : Buffer.alloc(0)
      })
      void udpGateway.sendMessage(spectator.socket, message).catch(error => {
        this.lastError = this.lastError || error
      })
    }
  }

  calculateRewards (player, result) {
    const account = player.session.account
    const hero = account.avatar.heroes.find(entry => entry.characterId === player.characterId) || account.avatar.heroes[0]
    let tokensReward = 0
    let trophiesReward = 0
    if (this.variation === 6) {
      const rank = player.battleRoyaleRank || 1
      tokensReward = Math.trunc(40 / rank)
      trophiesReward = rank > 5 ? -(rank - 5) : (5 - rank) * 2
      if (trophiesReward < 0) trophiesReward = Math.max(trophiesReward, -hero.trophies)
      if (rank === 1) account.avatar.soloWins++
    } else if (result === 0) {
      tokensReward = 20
      trophiesReward = 6 + (this.id + player.playerIndex) % 3
      account.avatar.trioWins++
    } else if (result === 1) {
      tokensReward = 10
      trophiesReward = Math.max(-2, -hero.trophies)
    } else tokensReward = 10
    account.avatar.chips += tokensReward
    account.home.tokenReward += tokensReward
    hero.trophies = Math.max(0, hero.trophies + trophiesReward)
    hero.highestTrophies = Math.max(hero.highestTrophies, hero.trophies)
    account.home.trophiesReward = Math.max(0, account.home.trophiesReward + trophiesReward)
    return { tokensReward, trophiesReward }
  }

  async finish () {
    if (this.gameOver || this.ending) return
    this.ending = true
    if (this.timer) clearInterval(this.timer)
    this.timer = null
    const realPlayers = this.players.filter(player => player.session)
    await Promise.allSettled(realPlayers.map(async player => {
      const account = player.session.account
      account.avatar.battleId = -1
      account.avatar.udpSessionId = -1
      const showdownRank = player.battleRoyaleRank || 1
      const result = this.variation === 6 ? showdownRank : this.winnerTeam === -1 ? 2 : this.winnerTeam === player.teamIndex ? 0 : 1
      const rewards = this.calculateRewards(player, result)
      await global.repositories.accounts.save(account)
      if (!player.session.destroyed) {
        await new BattleEndMessage(player.session, {
          gameMode: this.variation === 6 ? 2 : 1,
          result,
          tokensReward: rewards.tokensReward,
          trophiesReward: rewards.trophiesReward,
          players: this.players,
          ownPlayer: player,
          isPvP: true
        }).send()
      }
    }))
    for (const player of realPlayers) udpGateway.removeSocket(player.udpSessionId)
    for (const sessionId of this.spectators.keys()) udpGateway.removeSocket(sessionId)
    this.gameOver = true
    this.ending = false
  }

  stop () {
    if (this.timer) clearInterval(this.timer)
    this.timer = null
    this.gameOver = true
  }
}

module.exports = Battle
