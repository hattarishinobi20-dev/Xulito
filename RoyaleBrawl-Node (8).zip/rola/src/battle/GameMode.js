const modes = {
  CoinRush: 0,
  Campaign: 1,
  AttackDefend: 2,
  BountyHunter: 3,
  Artifact: 4,
  LaserBall: 5,
  BattleRoyale: 6
}

function getVariation (mode) {
  return modes[mode] ?? -1
}

function getPlayerCount (variation) {
  return variation === 6 ? 10 : 6
}

function hasTwoTeams (variation) {
  return variation !== 6
}

module.exports = {
  getPlayerCount,
  getVariation,
  hasTwoTeams
}
