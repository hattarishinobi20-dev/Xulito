class GameObject {
  constructor (manager, type, data, x, y, team = -1) {
    this.manager = manager
    this.type = type
    this.data = data
    this.id = 0
    this.globalId = 0
    this.index = 0
    this.x = Math.trunc(x)
    this.y = Math.trunc(y)
    this.team = team
    this.dead = false
    this.fadeCounter = 10
    this.createdTick = manager.tick
    this.radius = 50
  }

  distanceTo (object) {
    return Math.hypot(this.x - object.x, this.y - object.y)
  }

  encodeBase (stream) {
    if (this.manager.variation === 6) {
      stream.writePositiveInt(this.x, 15)
      stream.writePositiveInt(this.y, 16)
      stream.writePositiveInt(this.index, 8)
    } else {
      stream.writePositiveInt(this.x, 13)
      stream.writePositiveInt(this.y, 14)
      stream.writePositiveInt(this.index, 7)
    }
    stream.writePositiveInt(0, 12)
  }

  update () {}
}

module.exports = GameObject
