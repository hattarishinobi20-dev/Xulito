class BattleBitStream {
  constructor () {
    this.bytes = []
    this.offset = 0
    this.bitOffset = 0
  }

  writeBit (value) {
    if (this.bitOffset === 0) {
      this.bytes.push(0xff)
      this.offset++
    }
    const index = this.offset - 1
    this.bytes[index] &= ~(1 << this.bitOffset)
    this.bytes[index] |= (value & 1) << this.bitOffset
    this.bitOffset = (this.bitOffset + 1) % 8
  }

  writePositiveInt (value, bits) {
    const normalized = Number(value) >>> 0
    for (let index = 0; index < bits; index++) this.writeBit((normalized >>> index) & 1)
  }

  writeBoolean (value) {
    this.writeBit(value ? 1 : 0)
  }

  toBuffer () {
    return Buffer.from(this.bytes)
  }
}

module.exports = BattleBitStream
