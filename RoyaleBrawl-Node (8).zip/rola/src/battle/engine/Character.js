const GameObject = require('./GameObject')
const dataTables = require('../../logic/DataTables')
const { boolean, integer } = require('./DataValue')

class Character extends GameObject {
  constructor (manager, player, data, x, y) {
    super(manager, 1, data, x, y, player.teamIndex)
    this.player = player
    this.radius = integer(data.CollisionRadius, 100)
    this.maxHitpoints = Math.max(1, integer(data.Hitpoints, 1000) + Math.trunc(integer(data.Hitpoints, 1000) * 0.05) * (player.heroPowerLevel || 0))
    this.hitpoints = this.maxHitpoints
    this.normalDamage = 0
    this.destination = { x, y }
    this.angle = 0
    this.state = 0
    this.items = 0
    this.damageIndicators = []
    this.pendingDamage = 0
    this.immunityUntil = player.playerIndex >= 0 ? manager.tick + 60 : 0
    this.slowUntil = 0
    this.slowStrength = 0
    this.stunUntil = 0
    this.speedBuffUntil = 0
    this.speedBuff = 0
    this.damageBuffUntil = 0
    this.damageBuff = 0
    this.poison = null
    this.invisibleUntil = 0
    this.lastCombatTick = manager.tick
    this.lastAIAttackTick = manager.tick
    this.respawnTick = -1
    this.forcedDeathTick = -1
    this.forcedDeathSource = null
    this.skills = [dataTables.getByName(20, data.WeaponSkill), dataTables.getByName(20, data.UltimateSkill)].filter(Boolean)
    this.skillStates = new Map(this.skills.map(skill => [skill.instanceId, {
      skill,
      active: false,
      ticks: -1,
      activeTicks: Math.max(0, Math.ceil(integer(skill.ActiveTime, 50) / 50) - 1),
      x: 0,
      y: 0
    }]))
    this.spreadIndexes = new Map()
    this.ammo = 3
    this.reloadProgress = 0
    this.ultimateCharge = 0
    this.usingUltimate = false
    this.charge = null
  }

  moveTo (x, y) {
    if (this.dead || this.charge) return
    this.destination = {
      x: Math.max(0, Math.min(this.manager.map.logicWidth, Math.trunc(x))),
      y: Math.max(0, Math.min(this.manager.map.logicHeight, Math.trunc(y)))
    }
  }

  activateSkill (skillId, targetX, targetY) {
    if (this.dead) return false
    const state = this.skillStates.get(skillId)
    if (!state || state.active) return false
    const skill = state.skill
    const ultimate = skill.Name === this.data.UltimateSkill
    if (ultimate && this.ultimateCharge < 1000) return false
    if (!ultimate && this.ammo < 1) return false
    if (ultimate) {
      this.ultimateCharge = 0
      this.usingUltimate = true
    } else {
      this.ammo--
      this.usingUltimate = false
    }
    this.lastCombatTick = this.manager.tick
    this.fadeCounter = 10
    if (skill.BehaviorType === 'Blink') return this.blink(skill, targetX, targetY)
    const length = Math.max(1, Math.hypot(targetX, targetY))
    const maximum = Math.max(100, integer(skill.CastingRange, 10) * 100)
    if (length > maximum || boolean(skill.AlwaysCastAtMaxRange)) {
      targetX = targetX / length * maximum
      targetY = targetY / length * maximum
    }
    if (skill.BehaviorType === 'Charge') {
      this.normalDamage = this.absoluteDamage(integer(skill.Damage, integer(this.data.AutoAttackDamage, 200)))
      this.charge = {
        vx: targetX / Math.max(1, Math.hypot(targetX, targetY)) * integer(skill.ChargeSpeed, 1000) / 20,
        vy: targetY / Math.max(1, Math.hypot(targetX, targetY)) * integer(skill.ChargeSpeed, 1000) / 20,
        left: Math.min(maximum, Math.hypot(targetX, targetY)),
        pushback: integer(skill.ChargePushback),
        hit: new Set()
      }
      return true
    }
    state.active = true
    state.ticks = 1
    state.x = targetX
    state.y = targetY
    if (skill.BehaviorType === 'Invisibility') this.invisibleUntil = this.manager.tick + state.activeTicks
    if (skill.AreaEffectObject) this.manager.spawnAreaEffect(dataTables.getByName(17, skill.AreaEffectObject), this.x, this.y, this)
    return true
  }

  blink (skill, targetX, targetY) {
    const before = dataTables.getByName(17, skill.AreaEffectObject)
    const after = dataTables.getByName(17, skill.AreaEffectObject2)
    if (before) this.manager.spawnAreaEffect(before, this.x, this.y, this)
    const range = Math.max(100, integer(skill.CastingRange, 10) * 100)
    const length = Math.max(1, Math.hypot(targetX, targetY))
    const scale = Math.min(1, range / length)
    const destinationX = this.x + targetX * scale
    const destinationY = this.y + targetY * scale
    const valid = this.manager.findValidDestination(this.x, this.y, destinationX, destinationY, this.radius)
    this.x = valid.x
    this.y = valid.y
    this.destination = { ...valid }
    if (after) this.manager.spawnAreaEffect(after, this.x, this.y, this)
    return true
  }

  runSkillState (state) {
    if (!state.active) return
    const skill = state.skill
    if (skill.BehaviorType !== 'Attack') return
    const interval = Math.max(1, Math.ceil(integer(skill.MsBetweenAttacks, 50) / 50))
    const immediate = boolean(skill.ExecuteFirstAttackImmediately)
    if ((state.ticks === 0 && immediate) || (state.ticks > 0 && state.ticks % interval === 0)) this.fireSkill(skill, state.x, state.y)
  }

  fireSkill (skill, targetX, targetY) {
    const projectile = dataTables.getByName(6, skill.Projectile)
    const range = Math.max(100, integer(skill.CastingRange, integer(this.data.AutoAttackRange, 10)) * 100)
    const bullets = Math.max(1, integer(skill.NumBulletsInOneAttack, 1))
    const spread = integer(skill.Spread, integer(this.data.AutoAttackProjectileSpread))
    const damage = this.absoluteDamage(integer(skill.Damage, integer(this.data.AutoAttackDamage, 100)))
    this.normalDamage = damage
    const baseAngle = Math.atan2(targetY, targetX)
    const rapid = integer(skill.AttackPattern) === 6
    const rapidPattern = [0, spread / 6, -spread / 3, spread / 3]
    let rapidIndex = this.spreadIndexes.get(skill.instanceId) || 0
    for (let i = 0; i < bullets; i++) {
      let degrees = bullets === 1 ? 0 : (i / (bullets - 1) - 0.5) * spread
      if (bullets === 1 && spread !== 0 && integer(skill.AttackPattern) !== 0 && !rapid) {
        const pattern = [-0.5, -0.25, 0, 0.25, 0.5, 0.25, 0, -0.25]
        degrees = pattern[rapidIndex % pattern.length] * spread
        rapidIndex++
      }
      if (rapid) {
        degrees = rapidPattern[rapidIndex % rapidPattern.length]
        rapidIndex++
      }
      const angle = baseAngle + degrees * Math.PI / 180
      if (projectile) {
        const shot = this.manager.spawnProjectile(this, projectile, this.x, this.y, this.x + Math.cos(angle) * range, this.y + Math.sin(angle) * range, damage, range)
        if (shot) {
          shot.summonedCharacterName = skill.SummonedCharacter || ''
          shot.summonMaximum = integer(skill.MaxSpawns)
          shot.summonKey = skill.Name
        }
      } else this.melee(angle, range, damage)
    }
    this.spreadIndexes.set(skill.instanceId, rapidIndex)
    if (skill.SpawnedItem) this.manager.spawnItem(dataTables.getByName(18, skill.SpawnedItem), this.x + targetX, this.y + targetY)
  }

  absoluteDamage (damage) {
    let result = damage + Math.trunc(damage * 0.05) * ((this.player.heroPowerLevel || 0) * 2)
    if (this.manager.tick < this.damageBuffUntil) result += Math.trunc(result * this.damageBuff / 100)
    result += Math.trunc(result * this.items * 5 / 100)
    return result
  }

  applyItem (item) {
    const value = integer(item.data.Value)
    if (item.data.Name === 'Health') this.heal(value)
    else if (item.data.Name === 'Speed') {
      this.speedBuff = Math.max(this.speedBuff, value)
      this.speedBuffUntil = this.manager.tick + 100
    } else if (item.data.Name === 'Damage') {
      this.damageBuff = Math.max(this.damageBuff, value)
      this.damageBuffUntil = this.manager.tick + 100
    } else if (item.data.Name === 'BattleRoyaleBuff') {
      this.items++
      const health = Math.trunc(integer(this.data.Hitpoints, this.maxHitpoints) * 0.1)
      this.maxHitpoints += health
      this.hitpoints = Math.min(this.maxHitpoints, this.hitpoints + health)
    } else this.items += Math.max(1, value || 1)
  }

  melee (angle, range, damage) {
    for (const target of this.manager.characters()) {
      if (target.dead || target.team === this.team || this.distanceTo(target) > range + target.radius) continue
      const direction = Math.atan2(target.y - this.y, target.x - this.x)
      const delta = Math.abs(Math.atan2(Math.sin(direction - angle), Math.cos(direction - angle)))
      if (delta <= Math.PI / 3 && this.manager.map.hasLineOfSight(this.x, this.y, target.x, target.y)) target.damage(damage, this)
    }
  }

  damage (value, source) {
    if (this.dead || this.manager.tick < this.immunityUntil) return false
    const amount = Math.max(0, Math.trunc(value))
    if (this.data.Name === 'PoisonBarrel' && this.hitpoints - amount <= 0) {
      this.hitpoints = 1
      this.pendingDamage += amount
      this.lastCombatTick = this.manager.tick
      this.manager.armPoisonBarrels(source)
      return true
    }
    this.hitpoints -= amount
    this.pendingDamage += amount
    this.lastCombatTick = this.manager.tick
    if (source?.player) {
      const multiplier = integer(source.data.UltiChargeMul)
      const divisor = integer(source.data.UltiChargeDiv)
      if (divisor > 0) source.ultimateCharge = Math.min(1000, source.ultimateCharge + Math.trunc(multiplier * amount / divisor))
    }
    if (this.hitpoints <= 0) this.die(source)
    return true
  }

  heal (value) {
    if (!this.dead) this.hitpoints = Math.min(this.maxHitpoints, this.hitpoints + Math.max(0, Math.trunc(value)))
  }

  die (source) {
    this.hitpoints = 0
    this.dead = true
    this.deathTick = this.manager.tick
    this.respawnTick = -1
    this.manager.onCharacterDied(this, source)
  }

  respawn () {
    const spawn = this.manager.getSpawn(this.player)
    this.x = spawn.x
    this.y = spawn.y
    this.destination = { ...spawn }
    this.hitpoints = this.maxHitpoints
    this.dead = false
    this.immunityUntil = this.manager.tick + 60
    this.poison = null
    this.lastCombatTick = this.manager.tick
  }

  addSlow (strength, ticks) {
    this.slowStrength = Math.max(this.slowStrength, strength)
    this.slowUntil = Math.max(this.slowUntil, this.manager.tick + ticks)
  }

  addPoison (damage, source) {
    this.poison = { damage, source, nextTick: this.manager.tick + 20, endTick: this.manager.tick + 80 }
  }

  addStun (milliseconds) {
    this.stunUntil = Math.max(this.stunUntil, this.manager.tick + Math.max(1, Math.ceil(milliseconds / 50)))
    this.charge = null
  }

  push (dx, dy, strength) {
    const length = Math.max(1, Math.hypot(dx, dy))
    const destination = this.manager.findValidDestination(this.x, this.y, this.x + dx / length * strength, this.y + dy / length * strength, this.radius)
    this.x = destination.x
    this.y = destination.y
    this.destination = { ...destination }
  }

  updateNpc () {
    if (this.player.playerIndex >= 0 || this.dead) return
    if (this.data.Type === 'Minion_Dog') {
      const attractor = this.manager.objectsOfType(2)
        .filter(projectile => !projectile.dead && boolean(projectile.data.AttractsPet) && projectile.team !== this.team)
        .sort((a, b) => this.distanceTo(a) - this.distanceTo(b) || a.id - b.id)[0]
      if (attractor) {
        this.moveTo(attractor.x, attractor.y)
        return
      }
    }
    if (integer(this.data.AutoAttackDamage) <= 0) return
    const target = this.manager.characters()
      .filter(character => !character.dead && character.team !== this.team && character.player.playerIndex >= 0)
      .filter(character => this.manager.map.hasLineOfSight(this.x, this.y, character.x, character.y))
      .sort((a, b) => this.distanceTo(a) - this.distanceTo(b) || a.id - b.id)[0]
    if (!target) return
    const range = Math.max(100, integer(this.data.AutoAttackRange, 3) * 100)
    if (this.distanceTo(target) > range) {
      if (integer(this.data.Speed) > 0) this.moveTo(target.x, target.y)
      return
    }
    const interval = Math.max(1, Math.ceil(integer(this.data.AutoAttackSpeedMs, 1000) / 50))
    if (this.manager.tick - this.lastAIAttackTick < interval) return
    this.lastAIAttackTick = this.manager.tick
    const projectile = dataTables.getByName(6, this.data.AutoAttackProjectile)
    const damage = this.absoluteDamage(integer(this.data.AutoAttackDamage, 100))
    if (projectile) this.manager.spawnProjectile(this, projectile, this.x, this.y, target.x, target.y, damage, range)
    else this.melee(Math.atan2(target.y - this.y, target.x - this.x), range, damage)
  }

  update () {
    if (!this.dead && this.forcedDeathTick >= 0 && this.manager.tick >= this.forcedDeathTick) this.die(this.forcedDeathSource)
    if (this.dead) {
      if (this.respawnTick >= 0 && this.manager.tick >= this.respawnTick) this.respawn()
      return
    }
    this.updateNpc()
    if (this.manager.tick < this.invisibleUntil) this.fadeCounter = Math.max(0, this.fadeCounter - 1)
    else this.fadeCounter = Math.min(10, this.fadeCounter + 1)
    if (this.pendingDamage > 0) {
      this.damageIndicators.push(this.pendingDamage)
      this.pendingDamage = 0
    } else this.damageIndicators.length = 0
    if (this.poison && this.manager.tick >= this.poison.nextTick) {
      this.damage(this.poison.damage, this.poison.source)
      this.poison.nextTick += 20
      if (this.manager.tick >= this.poison.endTick) this.poison = null
    }
    if (this.manager.tick < this.stunUntil) return
    for (const state of this.skillStates.values()) {
      if (!state.active) continue
      if (state.ticks > 0) this.runSkillState(state)
      state.ticks++
      if (state.ticks > state.activeTicks) {
        state.active = false
        state.ticks = -1
      }
    }
    if (this.manager.tick - this.lastCombatTick >= 60 && this.hitpoints < this.maxHitpoints) {
      this.heal(Math.max(1, Math.trunc(integer(this.data.RegeneratePerSecond, this.maxHitpoints / 10) / 20)))
    }
    this.reloadProgress += 50
    const recharge = integer(this.skills[0]?.RechargeTime, 1250)
    if (this.ammo < 3 && this.reloadProgress >= recharge) {
      this.ammo++
      this.reloadProgress = 0
    }
    if (this.charge) {
      const nextX = this.x + this.charge.vx
      const nextY = this.y + this.charge.vy
      if (!this.manager.moveCharacter(this, nextX, nextY)) this.charge = null
      else {
        this.charge.left -= Math.hypot(this.charge.vx, this.charge.vy)
        for (const target of this.manager.characters()) {
          if (target.dead || target.team === this.team || this.charge.hit.has(target.id) || this.distanceTo(target) > this.radius + target.radius) continue
          this.charge.hit.add(target.id)
          target.damage(this.normalDamage || 200, this)
          if (this.charge.pushback) target.push(this.charge.vx, this.charge.vy, this.charge.pushback)
        }
        if (this.charge.left <= 0) this.charge = null
      }
      return
    }
    const movementBlockingSkill = [...this.skillStates.values()].some(state => state.active && !boolean(state.skill.CanMoveAtSameTime))
    if (movementBlockingSkill) return
    const dx = this.destination.x - this.x
    const dy = this.destination.y - this.y
    const distance = Math.hypot(dx, dy)
    if (distance < 1) return
    let speed = integer(this.data.Speed, 600)
    if (this.manager.tick < this.speedBuffUntil) speed += this.speedBuff
    else this.speedBuff = 0
    speed /= 20
    if (this.manager.tick < this.slowUntil) speed *= Math.max(0.1, 1 - this.slowStrength / 100)
    else this.slowStrength = 0
    this.angle = Math.trunc((Math.atan2(dy, dx) * 180 / Math.PI + 360) % 360)
    const step = Math.min(speed, distance)
    this.manager.moveCharacter(this, this.x + dx / distance * step, this.y + dy / distance * step)
  }

  encode (stream, own, visionTeam) {
    const hero = this.data.Type === 'Hero'
    own = own && hero
    this.encodeBase(stream)
    stream.writePositiveInt(visionTeam === this.team ? 10 : this.fadeCounter, 4)
    if (integer(this.data.AutoAttackDamage) !== 0 || integer(this.data.Speed) !== 0) {
      if (own) stream.writeBoolean(false)
      else {
        stream.writePositiveInt(this.angle, 9)
        stream.writePositiveInt(this.angle, 9)
      }
      stream.writePositiveInt(this.state, 3)
      stream.writeBoolean(this.manager.tick < this.slowUntil)
      stream.writeBoolean(false)
      stream.writeBoolean(false)
      stream.writePositiveInt(0, 6)
      stream.writeBoolean(false)
      stream.writeBoolean(this.manager.tick < this.stunUntil)
      stream.writeBoolean(false)
      stream.writeBoolean(Boolean(this.poison))
      stream.writePositiveInt(0, 7)
      stream.writePositiveInt(0, 5)
    } else stream.writePositiveInt(this.state, 3)
    const hpBits = this.manager.variation === 6 || integer(this.data.Hitpoints) > 1599 ? 13 : 11
    stream.writePositiveInt(Math.max(0, this.hitpoints), hpBits)
    stream.writePositiveInt(this.maxHitpoints, hpBits)
    if (hero) {
      stream.writePositiveInt(this.items, this.manager.variation === 3 ? 7 : 6)
      if (this.manager.variation === 5) stream.writeBoolean(this.manager.ballCarrier === this)
      stream.writePositiveInt(0, 13)
      stream.writePositiveInt(0, 11)
      stream.writeBoolean(Boolean(this.charge))
      stream.writeBoolean(this.manager.tick < this.immunityUntil)
      stream.writeBoolean(false)
      stream.writeBoolean(false)
      stream.writeBoolean(this.usingUltimate)
      stream.writeBoolean(false)
      if (this.charge) stream.writePositiveInt(0, 10)
    } else if (this.data.Type === 'Minion_Dog') stream.writePositiveInt(0, 5)
    const invisible = this.manager.tick < this.invisibleUntil
    stream.writeBoolean(invisible)
    stream.writeBoolean(invisible)
    stream.writePositiveInt(0, 9)
    if (own) {
      stream.writeBoolean(false)
      stream.writePositiveInt(0, 9)
    }
    stream.writePositiveInt(Math.min(31, this.damageIndicators.length), 5)
    for (const damage of this.damageIndicators.slice(0, 31)) {
      stream.writeBoolean(true)
      stream.writePositiveInt(Math.min(4095, damage), 12)
    }
    for (const skill of this.skills) {
      const state = this.skillStates.get(skill.instanceId)
      stream.writePositiveInt(state?.active ? state.ticks + 1 : 0, 11)
      stream.writeBoolean(false)
      stream.writePositiveInt(0, 12)
      if (integer(skill.MaxCharge) >= 1) {
        const charge = skill.Name === this.data.UltimateSkill ? this.ultimateCharge : this.ammo * 1000
        stream.writePositiveInt(Math.min(4095, charge), 12)
      }
    }
  }
}

module.exports = Character
