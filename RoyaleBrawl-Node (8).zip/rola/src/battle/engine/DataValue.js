function integer (value, fallback = 0) {
  const parsed = Number.parseInt(value, 10)
  return Number.isFinite(parsed) ? parsed : fallback
}

function boolean (value) {
  return value === true || String(value).toLowerCase() === 'true'
}

module.exports = {
  boolean,
  integer
}
