const GameObject = require('./GameObject')
const dataTables = require('../../logic/DataTables')
const { boolean, integer } = require('./DataValue')

class AreaEffect extends GameObject {
  constructor (manager, data, x, y, owner) {
    super(manager, 3, data, x, y, owner?.team ?? -1)
    this.index = owner?.index || 0
    this.owner = owner
    this.radius = integer(data.Radius, 100)
    this.damageValue = integer(data.Damage)
    this.lifeTicks = Math.max(1, Math.ceil(integer(data.TimeMs, 50) / 50))
    this.triggered = false
    this.affected = new Set()
  }

  applyToCharacters () {
    const type = this.data.Type
    for (const character of this.manager.characters()) {
      if (character.dead || this.affected.has(character.id) || this.distanceTo(character) > this.radius + character.radius) continue
      if (type === 'Hot') {
        if (character.team !== this.team || character.data.Type !== 'Hero') continue
        character.heal(Math.abs(this.damageValue || this.owner?.normalDamage || 0))
      } else {
        if (character.team === this.team) continue
        const damage = this.damageValue || this.owner?.normalDamage || 0
        character.damage(damage, this.owner)
        const pushback = integer(this.data.PushbackStrength)
        if (pushback > 0) character.push(character.x - this.x, character.y - this.y, pushback)
        const slow = integer(this.data.FreezeStrength)
        if (slow > 0) character.addSlow(slow, 20)
      }
      this.affected.add(character.id)
    }
  }

  update () {
    const elapsed = this.manager.tick - this.createdTick
    const type = this.data.Type
    if (!this.triggered) {
      this.triggered = true
      if (boolean(this.data.DestroysEnvironment)) this.manager.destroyEnvironment(this.x, this.y, this.radius)
      if (type === 'BulletExplosion' && this.owner) {
        const projectile = dataTables.getByName(6, this.data.BulletExplosionBullet)
        const count = Math.max(1, integer(this.data.CustomValue, 8))
        const distance = integer(this.data.BulletExplosionBulletDistance, 600)
        for (let i = 0; i < count; i++) {
          const angle = i * Math.PI * 2 / count
          this.manager.spawnProjectile(this.owner, projectile, this.x, this.y, this.x + Math.cos(angle) * distance, this.y + Math.sin(angle) * distance, this.owner.normalDamage, distance)
        }
      }
    }
    if (type === 'Damage') this.applyToCharacters()
    else if ((type === 'Dot' || type === 'Hot') && elapsed % 20 === 0) {
      this.affected.clear()
      this.applyToCharacters()
    }
    if (elapsed >= this.lifeTicks) this.dead = true
  }

  encode (stream) {
    this.encodeBase(stream)
    stream.writePositiveInt(10, 4)
  }
}

module.exports = AreaEffect
