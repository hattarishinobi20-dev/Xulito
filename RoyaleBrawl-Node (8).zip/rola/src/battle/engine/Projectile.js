const GameObject = require('./GameObject')
const dataTables = require('../../logic/DataTables')
const { boolean, integer } = require('./DataValue')

class Projectile extends GameObject {
  constructor (manager, owner, data, x, y, targetX, targetY, damage, range) {
    super(manager, 2, data, x, y, owner.team)
    this.owner = owner
    this.index = owner.index
    this.damage = damage
    this.radius = integer(data.Radius, 50)
    this.speed = Math.max(1, integer(data.Speed, 1000) / 20)
    this.maxDistance = Math.max(100, range)
    this.travelled = 0
    this.hit = new Set()
    this.hitTicks = new Map()
    this.chainsRemaining = integer(data.ChainsToEnemies)
    this.landed = false
    this.triggerTick = -1
    const angle = Math.atan2(targetY - y, targetX - x)
    this.vx = Math.cos(angle) * this.speed
    this.vy = Math.sin(angle) * this.speed
  }

  update () {
    if (this.dead) return
    if (this.landed) {
      if (this.manager.tick >= this.triggerTick) this.explode()
      return
    }
    const nextX = this.x + this.vx
    const nextY = this.y + this.vy
    const tile = this.manager.map.getTile(nextX, nextY)
    const blocked = !tile || (!tile.destructed && tile.blocksProjectiles && !boolean(this.data.PassesEnvironment))
    if (blocked) {
      const pierces = boolean(this.data.PiercesEnvironment) || boolean(this.data.PiercesEnvironmentLikeButter)
      if (tile?.destructible && (pierces || !boolean(this.data.IsBouncing))) this.manager.map.destruct(tile, this.manager.tick)
      if (boolean(this.data.IsBouncing) && tile) {
        const horizontalTile = this.manager.map.getTile(this.x + this.vx, this.y)
        const verticalTile = this.manager.map.getTile(this.x, this.y + this.vy)
        if (!horizontalTile || (!horizontalTile.destructed && horizontalTile.blocksProjectiles)) this.vx = -this.vx
        if (!verticalTile || (!verticalTile.destructed && verticalTile.blocksProjectiles)) this.vy = -this.vy
        if (horizontalTile && verticalTile && this.vx === 0 && this.vy === 0) this.explode()
        return
      }
      if (!pierces) {
        this.landOrExplode()
        return
      }
    }
    this.x = Math.trunc(nextX)
    this.y = Math.trunc(nextY)
    this.travelled += this.speed
    for (const character of boolean(this.data.Indirect) ? [] : this.manager.characters()) {
      const healsAllies = integer(this.data.HealOwnPercent) > 0
      const constantDamage = boolean(this.data.DamagesConstantly)
      const cooldownTicks = Math.max(1, Math.ceil(integer(this.data.SameProjectileCanNotDamageMS, 50) / 50))
      const previousHitTick = this.hitTicks.get(character.id)
      if (character.data.Type === 'LaserBall' || character.dead || (!healsAllies && character.team === this.team) || character === this.owner) continue
      if ((!constantDamage && this.hit.has(character.id)) || (previousHitTick !== undefined && this.manager.tick - previousHitTick < cooldownTicks)) continue
      if (this.distanceTo(character) > this.radius + character.radius) continue
      this.hit.add(character.id)
      this.hitTicks.set(character.id, this.manager.tick)
      const damage = this.modifiedDamage()
      const healOwn = integer(this.data.HealOwnPercent)
      if (healOwn > 0 && character.team === this.team) character.heal(Math.trunc(damage * healOwn / 100))
      else {
        character.damage(damage, this.owner)
        const lifeSteal = integer(this.data.LifeStealPercent)
        if (lifeSteal > 0) this.owner.heal(Math.trunc(damage * lifeSteal / 100))
      }
      const pushback = integer(this.data.PushbackStrength)
      if (pushback > 0) character.push(this.vx, this.vy, pushback)
      const freeze = integer(this.data.FreezeStrength)
      if (freeze > 0) character.addSlow(freeze, 20)
      const stun = integer(this.data.StunLengthMS)
      if (stun > 0) character.addStun(stun)
      const poison = integer(this.data.PoisonDamagePercent)
      if (poison > 0) character.addPoison(Math.trunc(this.damage * poison / 100), this.owner)
      if (integer(this.data.ChainsToEnemies) > 0) this.chain(character)
      if (!boolean(this.data.PiercesCharacters)) {
        this.explode()
        return
      }
    }
    if (this.travelled >= this.maxDistance) this.landOrExplode()
  }

  landOrExplode () {
    const delay = integer(this.data.TriggerWithDelayMs)
    if (delay <= 0) {
      this.explode()
      return
    }
    this.landed = true
    this.vx = 0
    this.vy = 0
    this.triggerTick = this.manager.tick + Math.max(1, Math.ceil(delay / 50))
  }

  modifiedDamage () {
    const start = integer(this.data.DamagePercentStart, 100)
    const end = integer(this.data.DamagePercentEnd, 100)
    const progress = Math.max(0, Math.min(1, this.travelled / Math.max(1, this.maxDistance)))
    const percent = start + (end - start) * progress
    return Math.max(0, Math.trunc(this.damage * percent / 100))
  }

  chain (source) {
    if (this.chainsRemaining <= 0) return
    const range = Math.max(100, integer(this.data.ChainTravelDistance, 10) * 100)
    const candidate = this.manager.characters()
      .filter(character => !character.dead && character.team !== this.team && !this.hit.has(character.id))
      .filter(character => source.distanceTo(character) <= range && this.manager.map.hasLineOfSight(source.x, source.y, character.x, character.y))
      .sort((a, b) => source.distanceTo(a) - source.distanceTo(b) || a.id - b.id)[0]
    if (!candidate) return
    const chainData = dataTables.getByName(6, this.data.ChainBullet) || this.data
    const chained = this.manager.spawnProjectile(this.owner, chainData, source.x, source.y, candidate.x, candidate.y, this.damage, range)
    if (!chained) return
    chained.hit = new Set(this.hit)
    chained.hitTicks = new Map(this.hitTicks)
    chained.chainsRemaining = this.chainsRemaining - 1
  }

  explode () {
    if (this.dead) return
    for (const area of [this.data.SpawnAreaEffectObject, this.data.SpawnAreaEffectObject2]) {
      if (area) this.manager.spawnAreaEffect(dataTables.getByName(17, area), this.x, this.y, this.owner)
    }
    const characterName = this.summonedCharacterName || this.data.SpawnCharacter
    if (characterName) this.manager.spawnSummonedCharacter(dataTables.getByName(16, characterName), this.x, this.y, this.owner, this.summonMaximum, this.summonKey)
    if (this.data.SpawnItem) this.manager.spawnItem(dataTables.getByName(18, this.data.SpawnItem), this.x, this.y)
    this.dead = true
  }

  encode (stream) {
    this.encodeBase(stream)
    const effect = this.dead ? 3 : this.travelled >= this.maxDistance ? 1 : 0
    stream.writePositiveInt(effect, 3)
    if (effect === 4 || boolean(this.data.IsBouncing)) {
      stream.writeBoolean(boolean(this.data.IsBouncing))
      stream.writePositiveInt(0, this.manager.variation === 6 ? 14 : 10)
    }
    if (integer(this.data.TriggerWithDelayMs) !== 0 || integer(this.data.PreExplosionTimeMs) !== 0) stream.writePositiveInt(0, 14)
    if (integer(this.data.PreExplosionTimeMs) !== 0) {
      stream.writePositiveInt(0, this.manager.variation === 6 ? 15 : 13)
      stream.writePositiveInt(0, this.manager.variation === 6 ? 16 : 14)
    }
    stream.writePositiveInt(0, 10)
    stream.writeBoolean(false)
  }
}

module.exports = Projectile
