const tileMaps = require('../../../assets/tilemaps.json')
const dataTables = require('../../logic/DataTables')
const { boolean, integer } = require('./DataValue')

class TileMap {
  constructor (name) {
    const source = tileMaps[name]
    if (!source) throw new Error(`Tile map not found: ${name}`)
    this.name = name
    this.width = source.WIDTH
    this.height = source.HEIGHT
    this.tiles = []
    this.spawnPoints = []
    this.team1Spawns = []
    this.team2Spawns = []
    this.lootBoxes = []
    this.poisonBarrels = []
    this.safe = null
    const tileData = dataTables.getTable(27)
    for (let y = 0; y < this.height; y++) {
      const row = []
      for (let x = 0; x < this.width; x++) {
        const code = source.Data[y * this.width + x]
        const data = tileData.find(entry => entry.TileCode && entry.TileCode[0] === code) || tileData[0]
        const tile = {
          code,
          x: TileMap.tileToLogic(x),
          y: TileMap.tileToLogic(y),
          data,
          destructed: false,
          destructedTick: -1,
          blocksMovement: boolean(data.BlocksMovement),
          blocksProjectiles: boolean(data.BlocksProjectiles),
          destructible: boolean(data.IsDestructible),
          destructibleNormal: boolean(data.IsDestructibleNormalWeapon),
          hidesHero: boolean(data.HidesHero),
          collisionMargin: integer(data.CollisionMargin)
        }
        row.push(tile)
        if (code === '1') {
          this.spawnPoints.push(tile)
          this.team1Spawns.push(tile)
        } else if (code === '2') {
          this.spawnPoints.push(tile)
          this.team2Spawns.push(tile)
        } else if (code === '4') this.lootBoxes.push(tile)
        else if (code === '5') this.poisonBarrels.push(tile)
        else if ('6789'.includes(code)) this.safe = tile
      }
      this.tiles.push(row)
    }
  }

  static logicToTile (value) {
    return Math.trunc(value / 300)
  }

  static tileToLogic (value) {
    return 300 * value + 150
  }

  get logicWidth () {
    return TileMap.tileToLogic(this.width)
  }

  get logicHeight () {
    return TileMap.tileToLogic(this.height)
  }

  get center () {
    return {
      x: TileMap.tileToLogic(Math.trunc(this.width / 2)),
      y: TileMap.tileToLogic(Math.trunc(this.height / 2))
    }
  }

  getTile (x, y, tileCoordinates = false) {
    const tileX = tileCoordinates ? x : TileMap.logicToTile(x)
    const tileY = tileCoordinates ? y : TileMap.logicToTile(y)
    return this.tiles[tileY]?.[tileX] || null
  }

  isInside (x, y) {
    return x >= 0 && y >= 0 && x <= this.logicWidth && y <= this.logicHeight
  }

  blocksMovement (x, y) {
    const tile = this.getTile(x, y)
    return !tile || (!tile.destructed && tile.blocksMovement)
  }

  destruct (tile, tick) {
    if (!tile?.destructible) return false
    tile.destructed = true
    tile.destructedTick = tick
    return true
  }

  update (tick, characters) {
    for (const row of this.tiles) {
      for (const tile of row) {
        const seconds = integer(tile.data.RespawnSeconds)
        if (!tile.destructed || seconds <= 0 || tick - tile.destructedTick < seconds * 20) continue
        const occupied = characters.some(character => !character.dead && Math.hypot(character.x - tile.x, character.y - tile.y) < character.radius + 150)
        if (occupied) continue
        tile.destructed = false
        tile.destructedTick = -1
      }
    }
  }

  hasLineOfSight (x1, y1, x2, y2) {
    const distance = Math.hypot(x2 - x1, y2 - y1)
    const steps = Math.max(1, Math.ceil(distance / 100))
    for (let i = 1; i < steps; i++) {
      const x = x1 + (x2 - x1) * i / steps
      const y = y1 + (y2 - y1) * i / steps
      const tile = this.getTile(x, y)
      if (!tile || (!tile.destructed && tile.blocksProjectiles)) return false
    }
    return true
  }
}

module.exports = TileMap
