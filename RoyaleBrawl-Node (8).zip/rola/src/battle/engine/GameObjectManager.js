const BattleBitStream = require('./BattleBitStream')
const dataTables = require('../../logic/DataTables')
const TileMap = require('./TileMap')
const Character = require('./Character')
const Projectile = require('./Projectile')
const Item = require('./Item')
const AreaEffect = require('./AreaEffect')
const { integer } = require('./DataValue')

class GameObjectManager {
  constructor (battle) {
    this.battle = battle
    this.variation = battle.variation
    const mapName = String(battle.location.AllowedMaps || 'Tutorial').split(',')[0].trim()
    this.map = new TileMap(mapName)
    this.objects = new Map()
    this.nextObjectId = 0
    this.tick = 0
    this.teamScores = [0, 0]
    this.gemSpawnTick = 100
    this.modeCountdown = 0
    this.winnerTeam = -1
    this.finished = false
    this.artifactSpawned = false
    this.ball = this.map.center
    this.ballCarrier = null
    this.ballVelocity = null
    this.characterByPlayerIndex = new Map()
    this.respawns = []
    this.spawnInitialObjects()
  }

  add (object) {
    object.id = this.nextObjectId++
    object.globalId = object.type * 1000000 + object.id
    this.objects.set(object.id, object)
    return object
  }

  removeDead () {
    for (const [id, object] of this.objects) {
      if (object.dead && this.tick > (object.deathTick ?? this.tick)) this.objects.delete(id)
    }
  }

  objectsOfType (type) {
    return [...this.objects.values()].filter(object => object.type === type)
  }

  characters () {
    return this.objectsOfType(1)
  }

  spawnPlayerCharacter (player) {
    const data = dataTables.getByGlobalId(player.characterId) || dataTables.getTable(16)[0]
    const spawn = this.getSpawn(player)
    const character = this.add(new Character(this, player, data, spawn.x, spawn.y))
    character.index = player.playerIndex + 16 * player.teamIndex
    player.ownObjectId = character.globalId
    this.characterByPlayerIndex.set(player.playerIndex, character)
    return character
  }

  spawnInitialObjects () {
    for (const player of this.battle.players) this.spawnPlayerCharacter(player)
    const crateName = this.variation === 6 ? 'LootBox' : 'ExplodingBarrel'
    const crateData = dataTables.getByName(16, crateName)
    if (crateData) {
      for (const tile of this.map.lootBoxes) {
        const crate = this.add(new Character(this, { playerIndex: -1, teamIndex: -1, heroPowerLevel: 0, bot: true }, crateData, tile.x, tile.y))
        crate.index = this.variation === 6 ? 160 : 22
      }
    }
    const poisonBarrelData = dataTables.getByName(16, 'PoisonBarrel')
    if (poisonBarrelData) {
      for (const tile of this.map.poisonBarrels) {
        const barrel = this.add(new Character(this, { playerIndex: -1, teamIndex: -1, heroPowerLevel: 0, bot: true }, poisonBarrelData, tile.x, tile.y))
        barrel.index = 22
      }
    }
    if (this.variation === 2 && this.map.safe) {
      const safeData = dataTables.getByName(16, `Safe${'6789'.indexOf(this.map.safe.code) + 1}`)
      if (safeData) {
        const safe = this.add(new Character(this, { playerIndex: -1, teamIndex: 1, heroPowerLevel: 0, bot: false }, safeData, this.map.safe.x, this.map.safe.y))
        safe.index = 22
        this.safe = safe
      }
    }
    if (this.variation === 5) {
      const ballData = dataTables.getByName(16, 'LaserBall')
      if (ballData) {
        this.ballObject = this.add(new Character(this, { playerIndex: -1, teamIndex: -1, heroPowerLevel: 0, bot: false }, ballData, this.ball.x, this.ball.y))
        this.ballObject.index = 0
      }
    }
    if ([0, 4].includes(this.variation)) this.spawnItem(dataTables.getByName(18, 'OrbSpawner'), this.map.center.x, this.map.center.y)
    if (this.variation === 3) this.spawnItem(dataTables.getByName(18, 'Money'), this.map.center.x, this.map.center.y)
  }

  getSpawn (player) {
    const teamSpawns = player.teamIndex === 0 ? this.map.team1Spawns : this.map.team2Spawns
    const options = teamSpawns.length ? teamSpawns : this.map.spawnPoints
    const tile = options[player.playerIndex % Math.max(1, options.length)]
    return tile ? { x: tile.x, y: tile.y } : this.map.center
  }

  spawnProjectile (owner, data, x, y, targetX, targetY, damage, range) {
    if (!data) return null
    return this.add(new Projectile(this, owner, data, x, y, targetX, targetY, damage, range))
  }

  spawnSummonedCharacter (data, x, y, owner, maximum = 0, summonKey = '') {
    if (!data || !owner) return null
    const existing = this.characters()
      .filter(character => character.ownerCharacter === owner && character.summonKey === summonKey && !character.dead)
      .sort((a, b) => a.createdTick - b.createdTick || a.id - b.id)
    if (maximum > 0 && existing.length >= maximum) existing[0].die(null)
    const player = { playerIndex: -1, teamIndex: owner.team, heroPowerLevel: owner.player?.heroPowerLevel || 0, bot: true }
    const character = new Character(this, player, data, x, y)
    character.index = owner.index
    character.ownerCharacter = owner
    character.summonKey = summonKey
    return this.add(character)
  }

  spawnAreaEffect (data, x, y, owner) {
    if (!data) return null
    return this.add(new AreaEffect(this, data, x, y, owner))
  }

  spawnItem (data, x, y) {
    if (!data) return null
    return this.add(new Item(this, data, x, y))
  }

  isPositionFree (x, y, radius = 0) {
    if (!this.map.isInside(x, y)) return false
    const samples = [[0, 0], [radius, 0], [-radius, 0], [0, radius], [0, -radius]]
    return samples.every(([dx, dy]) => !this.map.blocksMovement(x + dx, y + dy))
  }

  findValidDestination (startX, startY, destinationX, destinationY, radius = 0) {
    const distance = Math.hypot(destinationX - startX, destinationY - startY)
    const steps = Math.max(1, Math.ceil(distance / 50))
    let result = { x: Math.trunc(startX), y: Math.trunc(startY) }
    for (let i = 1; i <= steps; i++) {
      const x = Math.trunc(startX + (destinationX - startX) * i / steps)
      const y = Math.trunc(startY + (destinationY - startY) * i / steps)
      if (!this.isPositionFree(x, y, radius)) break
      result = { x, y }
    }
    return result
  }

  moveCharacter (character, x, y) {
    const nx = Math.trunc(x)
    const ny = Math.trunc(y)
    if (!this.isPositionFree(nx, ny, character.radius)) return false
    character.x = nx
    character.y = ny
    return true
  }

  armPoisonBarrels (source) {
    for (const character of this.characters()) {
      if (character.data.Name !== 'PoisonBarrel' || character.dead) continue
      character.forcedDeathTick = this.tick + 80
      character.forcedDeathSource = source
    }
  }

  destroyEnvironment (x, y, radius) {
    const minimumX = TileMap.logicToTile(x - radius)
    const maximumX = TileMap.logicToTile(x + radius)
    const minimumY = TileMap.logicToTile(y - radius)
    const maximumY = TileMap.logicToTile(y + radius)
    for (let ty = minimumY; ty <= maximumY; ty++) {
      for (let tx = minimumX; tx <= maximumX; tx++) {
        const tile = this.map.getTile(tx, ty, true)
        if (tile?.destructible && Math.hypot(tile.x - x, tile.y - y) <= radius + 212) this.map.destruct(tile, this.tick)
      }
    }
  }

  handleInput (player, input) {
    const character = this.characterByPlayerIndex.get(player.playerIndex)
    if (!character || character.dead) return
    if (input.type === 100) character.moveTo(input.x, input.y)
    else if (input.type === 107) character.usingUltimate = true
    else if (input.type === 108) character.usingUltimate = false
    else if (input.type >= 0 && input.type < 100) {
      if (this.variation === 5 && this.ballCarrier === character) this.throwBall(character, input.x, input.y)
      else character.activateSkill(input.type, input.x - character.x, input.y - character.y)
    }
  }

  updateBots () {
    if (this.tick % 10 !== 0) return
    for (const player of this.battle.players) {
      if (!player.bot) continue
      const character = this.characterByPlayerIndex.get(player.playerIndex)
      if (!character || character.dead) continue
      const target = this.characters()
        .filter(entry => !entry.dead && entry.player.playerIndex >= 0 && entry.team !== character.team)
        .filter(entry => this.map.hasLineOfSight(character.x, character.y, entry.x, entry.y))
        .sort((a, b) => character.distanceTo(a) - character.distanceTo(b) || a.id - b.id)[0]
      if (!target) continue
      character.moveTo(target.x, target.y)
      if (character.distanceTo(target) <= integer(character.data.AutoAttackRange, 10) * 100) {
        const weapon = character.skills[0]
        if (weapon) character.activateSkill(weapon.instanceId, target.x - character.x, target.y - character.y)
      }
    }
  }

  throwBall (character, targetX, targetY) {
    const dx = targetX - character.x
    const dy = targetY - character.y
    const length = Math.max(1, Math.hypot(dx, dy))
    const distance = Math.min(2400, length)
    this.ballCarrier = null
    this.ballVelocity = {
      vx: dx / length * 150,
      vy: dy / length * 150,
      remaining: distance,
      team: character.team
    }
    this.ball.x = character.x
    this.ball.y = character.y
  }

  resetBall () {
    this.ballCarrier = null
    this.ballVelocity = null
    this.ball = { ...this.map.center }
    if (this.ballObject) {
      this.ballObject.x = this.ball.x
      this.ballObject.y = this.ball.y
    }
  }

  updateBall () {
    if (!this.ballObject) return
    if (this.ballCarrier) {
      if (this.ballCarrier.dead) {
        this.ball.x = this.ballCarrier.x
        this.ball.y = this.ballCarrier.y
        this.ballCarrier = null
      } else {
        this.ball.x = this.ballCarrier.x
        this.ball.y = this.ballCarrier.y
      }
    } else if (this.ballVelocity) {
      const nextX = this.ball.x + this.ballVelocity.vx
      const nextY = this.ball.y + this.ballVelocity.vy
      if (!this.isPositionFree(nextX, nextY, this.ballObject.radius)) this.ballVelocity = null
      else {
        this.ball.x = Math.trunc(nextX)
        this.ball.y = Math.trunc(nextY)
        this.ballVelocity.remaining -= Math.hypot(this.ballVelocity.vx, this.ballVelocity.vy)
        this.ballVelocity.vx *= 0.94
        this.ballVelocity.vy *= 0.94
        if (this.ballVelocity.remaining <= 0 || Math.hypot(this.ballVelocity.vx, this.ballVelocity.vy) < 15) this.ballVelocity = null
      }
    } else {
      const picker = this.characters()
        .filter(character => character.player.playerIndex >= 0 && !character.dead && character.distanceTo(this.ballObject) <= 280)
        .sort((a, b) => a.distanceTo(this.ballObject) - b.distanceTo(this.ballObject) || a.id - b.id)[0]
      if (picker) this.ballCarrier = picker
    }
    this.ballObject.x = this.ball.x
    this.ballObject.y = this.ball.y
    const goalHalfWidth = 600
    const inGoalX = Math.abs(this.ball.x - this.map.center.x) <= goalHalfWidth
    if (inGoalX && this.ball.y <= 180) {
      this.teamScores[0]++
      if (this.teamScores[0] >= 2) {
        this.winnerTeam = 0
        this.finished = true
      }
      this.resetBall()
    } else if (inGoalX && this.ball.y >= this.map.logicHeight - 180) {
      this.teamScores[1]++
      if (this.teamScores[1] >= 2) {
        this.winnerTeam = 1
        this.finished = true
      }
      this.resetBall()
    }
  }

  updateMode () {
    if (this.variation === 5) this.updateBall()
    if (this.variation === 0 && this.tick >= this.gemSpawnTick) {
      if (this.objectsOfType(4).filter(item => item.data.Name === 'Point').length < 10) this.spawnItem(dataTables.getByName(18, 'Point'), this.map.center.x, this.map.center.y)
      this.gemSpawnTick = this.tick + 100
    }
    if (this.variation === 4 && this.tick >= 600 && !this.artifactSpawned) {
      this.artifactSpawned = true
      this.spawnItem(dataTables.getByName(18, 'Point'), this.map.center.x, this.map.center.y)
    }
    if ([0, 4].includes(this.variation)) {
      const required = this.variation === 0 ? 10 : 1
      const duration = this.variation === 0 ? 340 : 600
      if (this.teamScores[0] !== this.teamScores[1] && Math.max(...this.teamScores) >= required) {
        if (this.modeCountdown === 0) this.modeCountdown = this.tick + duration
        else if (this.tick > this.modeCountdown) {
          this.winnerTeam = this.teamScores[0] > this.teamScores[1] ? 0 : 1
          this.finished = true
        }
      } else this.modeCountdown = 0
    }
    if (this.variation === 3 && this.tick >= 2520) {
      this.winnerTeam = this.teamScores[0] === this.teamScores[1] ? -1 : this.teamScores[0] > this.teamScores[1] ? 0 : 1
      this.finished = true
    }
    if (this.variation === 6 && this.tick > 500) {
      const poison = 1 + Math.trunc((this.tick - 500) / 100)
      for (const character of this.characters()) {
        if (character.dead || character.player.playerIndex < 0) continue
        const tx = TileMap.logicToTile(character.x)
        const ty = TileMap.logicToTile(character.y)
        if (tx <= poison || tx >= this.map.width - 1 - poison || ty <= poison || ty >= this.map.height - 1 - poison) character.damage(100, null)
      }
    }
  }

  update () {
    this.tick = this.battle.tick
    const due = this.respawns.filter(entry => entry.tick <= this.tick)
    this.respawns = this.respawns.filter(entry => entry.tick > this.tick)
    for (const entry of due) this.spawnPlayerCharacter(entry.player)
    this.updateBots()
    this.updateMode()
    const snapshot = [...this.objects.values()].sort((a, b) => a.id - b.id)
    for (const object of snapshot) object.update()
    this.removeDead()
    this.map.update(this.tick, this.characters())
  }

  onItemPicked (item, character) {
    if (item.data.Name === 'Point' || item.data.Name === 'Money') {
      character.player.score = (character.player.score || 0) + 1
      this.teamScores[character.team] = (this.teamScores[character.team] || 0) + 1
    }
  }

  onCharacterDied (character, source) {
    if (this.ballCarrier === character) {
      this.ballCarrier = null
      this.ballVelocity = null
      this.ball.x = character.x
      this.ball.y = character.y
    }
    if (character.data.DeathAreaEffect) this.spawnAreaEffect(dataTables.getByName(17, character.data.DeathAreaEffect), character.x, character.y, source || character)
    if (character.data.Name === 'LootBox') this.spawnItem(dataTables.getByName(18, 'BattleRoyaleBuff'), character.x, character.y)
    if ([0, 4].includes(this.variation) && character.player.playerIndex >= 0) {
      this.teamScores[character.team] = Math.max(0, (this.teamScores[character.team] || 0) - (character.player.score || 0))
      character.player.score = 0
    }
    if (character === this.safe) {
      this.winnerTeam = character.team === 0 ? 1 : 0
      this.finished = true
    }
    if (source?.player?.playerIndex >= 0 && character.player.playerIndex >= 0) {
      const stars = this.variation === 3 ? character.items + 1 : 0
      source.player.killList = source.player.killList || []
      source.player.killList.push({ bountyStarsEarned: stars })
      if (source.player.killList.length > 3) source.player.killList.shift()
      if (this.variation === 3) {
        source.player.score = (source.player.score || 0) + stars
        source.items = Math.min(7, source.items + 1)
        this.teamScores[source.team] = (this.teamScores[source.team] || 0) + stars
        character.items = 0
      }
    }
    if (character.player.playerIndex >= 0 && this.variation !== 6) {
      character.player.ownObjectId = 0
      const respawnTicks = this.variation === 0 || this.variation === 2 ? 60 : this.variation === 3 ? 20 : 100
      this.respawns.push({ player: character.player, tick: this.tick + respawnTicks })
    }
    if (this.variation === 6 && character.player.playerIndex >= 0) {
      character.player.ownObjectId = 0
      this.spawnItem(dataTables.getByName(18, 'BattleRoyaleBuff'), character.x, character.y)
      const alive = this.characters().filter(entry => entry.player.playerIndex >= 0 && !entry.dead).length
      character.player.battleRoyaleRank = alive + 1
      if (alive <= 1) {
        const survivor = this.characters().find(entry => entry.player.playerIndex >= 0 && !entry.dead)
        if (survivor) survivor.player.battleRoyaleRank = 1
        this.finished = true
      }
    }
    if ([0, 4].includes(this.variation) && character.items > 0) {
      const point = dataTables.getByName(18, 'Point')
      const count = Math.min(10, character.items)
      for (let i = 0; i < count; i++) {
        const angle = i * Math.PI * 2 / count
        this.spawnItem(point, character.x + Math.cos(angle) * 120, character.y + Math.sin(angle) * 120)
      }
      character.items = 0
    }
  }

  encodeDataReference (stream, data) {
    stream.writePositiveInt(data?.classId || 0, 5)
    stream.writePositiveInt(data?.instanceId || 0, 8)
  }

  encode (player) {
    const stream = new BattleBitStream()
    stream.writePositiveInt(player.ownObjectId || 0, 21)
    stream.writePositiveInt(this.modeCountdown, 15)
    stream.writeBoolean(false)
    if (this.variation === 6) {
      stream.writePositiveInt(0, 6)
      stream.writePositiveInt(0, 7)
      stream.writePositiveInt(this.map.width - 1, 6)
      stream.writePositiveInt(this.map.height - 1, 7)
    } else {
      stream.writePositiveInt(0, 5)
      stream.writePositiveInt(0, 6)
      stream.writePositiveInt(this.map.width - 1, 5)
      stream.writePositiveInt(this.map.height - 1, 6)
    }
    for (let x = 0; x < this.map.width; x++) {
      for (let y = 0; y < this.map.height; y++) {
        const tile = this.map.getTile(x, y, true)
        if (integer(tile.data.RespawnSeconds) > 0 || tile.destructible) stream.writeBoolean(tile.destructed)
      }
    }
    for (const battlePlayer of this.battle.players) {
      const character = this.characterByPlayerIndex.get(battlePlayer.playerIndex)
      stream.writePositiveInt(0, 1)
      stream.writeBoolean((character?.ultimateCharge || 0) >= 1000)
      if (battlePlayer.playerIndex === player.playerIndex) stream.writePositiveInt(character?.ultimateCharge || 0, 10)
    }
    if (this.variation === 6) {
      const alive = this.characters().filter(character => character.player.playerIndex >= 0 && !character.dead).length
      stream.writePositiveInt(alive, 4)
    } else if (this.variation === 2) {
      const safeHealth = this.safe && !this.safe.dead ? Math.trunc(this.safe.hitpoints / this.safe.maxHitpoints * 100) : 0
      stream.writePositiveInt(this.safe?.team === 0 ? safeHealth : 0, 7)
      stream.writePositiveInt(this.safe?.team === 1 ? safeHealth : 0, 7)
    } else if (this.variation === 3) {
      stream.writePositiveInt(100, 3)
      stream.writePositiveInt(100, 3)
    }
    for (const battlePlayer of this.battle.players) {
      stream.writePositiveInt(battlePlayer.score || 0, 6)
      const kills = (battlePlayer.killList || []).slice(-3)
      stream.writePositiveInt(kills.length, 2)
      for (const kill of kills) {
        stream.writePositiveInt(1, 3)
        stream.writePositiveInt(kill.bountyStarsEarned || 0, 4)
      }
    }
    const visible = [...this.objects.values()]
      .filter(object => !object.dead || object.type === 1)
      .filter(object => object.fadeCounter > 0 || Math.trunc(object.index / 16) === player.teamIndex)
      .sort((a, b) => a.id - b.id)
      .slice(0, 127)
    stream.writePositiveInt(visible.length, 7)
    for (const object of visible) this.encodeDataReference(stream, object.data)
    for (const object of visible) {
      stream.writePositiveInt(object.type, 5)
      stream.writePositiveInt(object.id, 14)
    }
    for (const object of visible) object.encode(stream, object.globalId === player.ownObjectId, player.teamIndex)
    return stream.toBuffer()
  }
}

module.exports = GameObjectManager
