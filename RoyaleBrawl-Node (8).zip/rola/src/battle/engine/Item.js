const GameObject = require('./GameObject')
const { boolean, integer } = require('./DataValue')

class Item extends GameObject {
  constructor (manager, data, x, y) {
    super(manager, 4, data, x, y)
    this.radius = integer(data.TriggerRangeSubTiles, 3) * 100
  }

  update () {
    if (!boolean(this.data.CanBePickedUp)) return
    const target = this.manager.characters()
      .filter(character => !character.dead && this.distanceTo(character) <= this.radius + character.radius)
      .sort((a, b) => this.distanceTo(a) - this.distanceTo(b) || a.id - b.id)[0]
    if (!target) return
    target.applyItem(this)
    this.manager.onItemPicked(this, target)
    this.dead = true
  }

  encode (stream) {
    this.encodeBase(stream)
    stream.writePositiveInt(10, 4)
    if (this.data.Name === 'OrbSpawner') {
      stream.writePositiveInt(0, 14)
      stream.writePositiveInt(0, 14)
    } else if (this.data.Name === 'Mine') {
      stream.writePositiveInt(0, 11)
      stream.writePositiveInt(0, 11)
    }
  }
}

module.exports = Item
