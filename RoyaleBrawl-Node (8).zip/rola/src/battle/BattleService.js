const dataTables = require('../logic/DataTables')
const udpGateway = require('../network/UdpGateway')
const Battle = require('./Battle')
const { getPlayerCount, getVariation, hasTwoTeams } = require('./GameMode')
const { StartLoadingMessage, UdpConnectionInfoMessage } = require('../protocol/BattleMessages')

class BattleService {
  constructor () {
    this.battles = new Map()
    this.counter = 0
    this.cleanupTimer = null
  }

  start () {
    if (this.cleanupTimer) return
    this.cleanupTimer = setInterval(() => this.cleanup(), 1000)
    this.cleanupTimer.unref()
  }

  createPlayer (session, playerIndex, teamIndex, teamId = -1) {
    const account = session.account
    const hero = account.avatar.heroes.find(entry => entry.characterId === account.home.characterId) || account.avatar.heroes[0]
    return {
      accountId: account.accountId,
      playerIndex,
      teamIndex,
      teamId,
      displayData: {
        name: account.avatar.name,
        thumbnailId: account.home.thumbnailId
      },
      characterId: account.home.characterId,
      skinId: 0,
      trophies: hero.trophies,
      highestTrophies: hero.highestTrophies,
      heroPowerLevel: 0,
      session
    }
  }

  createBot (index, teamIndex, characterId) {
    const character = dataTables.getByGlobalId(characterId)
    return {
      accountId: 100000 + index,
      playerIndex: index,
      teamIndex,
      teamId: -1,
      displayData: {
        name: character ? character.Name.toUpperCase() : `Bot ${index}`,
        thumbnailId: 28000000
      },
      characterId,
      skinId: 0,
      trophies: 0,
      highestTrophies: 0,
      heroPowerLevel: 0,
      session: null,
      bot: true
    }
  }

  async createBattle (entries, event) {
    const location = dataTables.getByGlobalId(event.locationId)
    if (!location) return null
    const variation = getVariation(location.GameMode)
    const battle = new Battle(++this.counter, location, variation)
    this.battles.set(battle.id, battle)
    const playersRequired = getPlayerCount(variation)
    const teamAssignments = new Map()
    let nextTeam = 0

    for (let i = 0; i < entries.length; i++) {
      const entry = entries[i]
      let teamIndex = variation === 6 ? i : i % 2
      if (hasTwoTeams(variation) && entry.teamId > 0) {
        if (!teamAssignments.has(entry.teamId)) {
          teamAssignments.set(entry.teamId, nextTeam % 2)
          nextTeam++
        }
        teamIndex = teamAssignments.get(entry.teamId)
      }
      const player = this.createPlayer(entry.session, i, teamIndex, entry.teamId)
      const socket = udpGateway.createSocket(entry.session, battle)
      battle.addPlayer(player, socket)
      entry.session.udpSocket = socket
      entry.session.account.avatar.udpSessionId = socket.sessionId
      entry.session.account.avatar.battleId = battle.id
      entry.session.account.avatar.teamIndex = teamIndex
      entry.session.account.avatar.ownIndex = i
      await global.repositories.accounts.save(entry.session.account)
    }

    const usedByTeam = [new Set(), new Set()]
    for (let i = entries.length; i < playersRequired; i++) {
      const teamIndex = variation === 6 ? i : i % 2
      let characterInstance = battle.nextRandom(17)
      if (variation !== 6) {
        while (usedByTeam[teamIndex].has(characterInstance)) characterInstance = battle.nextRandom(17)
        usedByTeam[teamIndex].add(characterInstance)
      }
      battle.addPlayer(this.createBot(i, teamIndex, 16000000 + characterInstance), null)
    }

    for (const player of battle.players.filter(entry => entry.session)) {
      await new StartLoadingMessage(player.session, {
        players: battle.players,
        ownIndex: player.playerIndex,
        teamIndex: player.teamIndex,
        locationId: event.locationId,
        gameMode: variation === 6 ? 6 : 1
      }).send()
    }
    battle.start()
    return battle
  }

  async resume (session) {
    const battleId = session.account.avatar.battleId
    if (battleId <= 0) return false
    const battle = this.battles.get(battleId)
    if (!battle || battle.gameOver) {
      session.account.avatar.battleId = -1
      session.account.avatar.udpSessionId = -1
      await global.repositories.accounts.save(session.account)
      return false
    }
    const player = battle.players.find(entry => entry.accountId === session.account.accountId)
    if (!player) return false
    if (player.udpSessionId > 0) {
      battle.playersBySessionId.delete(player.udpSessionId)
      udpGateway.removeSocket(player.udpSessionId)
    }
    const socket = udpGateway.createSocket(session, battle)
    player.session = session
    player.udpSessionId = socket.sessionId
    battle.playersBySessionId.set(socket.sessionId, player)
    session.udpSocket = socket
    session.account.avatar.udpSessionId = socket.sessionId
    await global.repositories.accounts.save(session.account)
    await new StartLoadingMessage(session, {
      players: battle.players,
      ownIndex: player.playerIndex,
      teamIndex: player.teamIndex,
      locationId: battle.location.globalId,
      gameMode: battle.variation === 6 ? 6 : 1
    }).send()
    return true
  }

  getUdpAddress (session) {
    const configured = global.runtimeConfig?.udpPublicHost || process.env.UDP_PUBLIC_HOST || '127.0.0.1'
    if (!['127.0.0.1', 'localhost', '0.0.0.0', '::1'].includes(configured)) return configured
    const localAddress = String(session.localAddress || '').replace(/^::ffff:/, '')
    if (localAddress && localAddress !== '0.0.0.0' && localAddress !== '::') return localAddress
    return configured
  }

  async sendUdpInfo (session) {
    if (!session.udpSocket) return
    await new UdpConnectionInfoMessage(session, {
      serverPort: global.runtimeConfig?.udpPort || Number(process.env.UDP_PORT || 9449),
      serverAddress: this.getUdpAddress(session),
      sessionId: session.udpSocket.sessionId
    }).send()
  }

  async spectate (session, accountId) {
    const account = await global.repositories.accounts.findById(accountId)
    if (!account || account.avatar.battleId <= 0) return
    const battle = this.battles.get(account.avatar.battleId)
    if (!battle) return
    const socket = udpGateway.createSocket(session, battle, true)
    session.udpSocket = socket
    session.spectatedBattle = battle
    battle.addSpectator(socket)
    await new StartLoadingMessage(session, {
      players: battle.players,
      ownIndex: 0,
      teamIndex: 0,
      locationId: battle.location.globalId,
      gameMode: battle.variation === 6 ? 6 : 1
    }).send()
    await this.sendUdpInfo(session)
  }

  async stopSpectating (session) {
    if (session.spectatedBattle && session.udpSocket) {
      session.spectatedBattle.removeSpectator(session.udpSocket.sessionId)
    }
    session.spectatedBattle = null
    session.udpSocket = null
  }

  cleanup () {
    for (const [id, battle] of this.battles) {
      if (battle.gameOver) this.battles.delete(id)
    }
  }

  close () {
    if (this.cleanupTimer) clearInterval(this.cleanupTimer)
    this.cleanupTimer = null
    for (const battle of this.battles.values()) battle.stop()
    this.battles.clear()
  }
}

module.exports = new BattleService()
