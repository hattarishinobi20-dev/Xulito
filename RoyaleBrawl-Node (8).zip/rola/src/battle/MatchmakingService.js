const eventService = require('../logic/events/EventService')
const dataTables = require('../logic/DataTables')
const { getPlayerCount, getVariation } = require('./GameMode')
const battleService = require('./BattleService')
const { MatchMakingStatusMessage } = require('../protocol/ServerMessages')

class MatchmakingService {
  constructor () {
    this.slots = new Map()
    this.sessionEntries = new Map()
    this.timer = null
    this.searchTimeout = 20
    this.updating = false
  }

  start () {
    if (this.timer) return
    this.timer = setInterval(() => void this.update(), 250)
    this.timer.unref()
  }

  request (session, slot, teamId = -1) {
    this.cancel(session, false)
    const event = eventService.getEvent(slot)
    if (!event) return false
    if (!this.slots.has(slot)) {
      const location = dataTables.getByGlobalId(event.locationId)
      const variation = getVariation(location.GameMode)
      this.slots.set(slot, {
        event,
        playersRequired: getPlayerCount(variation),
        entries: [],
        secondsLeft: this.searchTimeout,
        turns: 0
      })
    }
    const entry = { session, teamId, slot }
    this.slots.get(slot).entries.push(entry)
    this.sessionEntries.set(session.id, entry)
    session.matchmakeSlot = slot
    return true
  }

  cancel (session, sendStatus = true) {
    const entry = this.sessionEntries.get(session.id)
    if (!entry) return false
    const slot = this.slots.get(entry.slot)
    if (slot) slot.entries = slot.entries.filter(item => item !== entry)
    this.sessionEntries.delete(session.id)
    session.matchmakeSlot = -1
    if (sendStatus) void new MatchMakingStatusMessage(session, { status: false }).send()
    return true
  }

  async update () {
    if (this.updating) return
    this.updating = true
    try {
      for (const slot of this.slots.values()) {
        slot.entries = slot.entries.filter(entry => entry.session && !entry.session.destroyed)
        while (slot.entries.length >= slot.playersRequired) {
          await this.startGame(slot, slot.entries.splice(0, slot.playersRequired))
        }
        if (slot.entries.length > 0) {
          slot.turns++
          if (slot.turns >= 4) {
            slot.turns = 0
            slot.secondsLeft--
          }
          if (slot.secondsLeft <= 0) {
            const entries = slot.entries.splice(0)
            slot.secondsLeft = this.searchTimeout
            await this.startGame(slot, entries)
          } else {
            for (const entry of slot.entries) {
              await new MatchMakingStatusMessage(entry.session, {
                seconds: slot.secondsLeft,
                found: slot.entries.length,
                max: slot.playersRequired,
                showTips: true,
                status: true
              }).send()
            }
          }
        } else {
          slot.turns = 0
          slot.secondsLeft = this.searchTimeout
        }
      }
    } finally {
      this.updating = false
    }
  }

  async startGame (slot, entries) {
    for (const entry of entries) {
      this.sessionEntries.delete(entry.session.id)
      entry.session.matchmakeSlot = -1
    }
    await battleService.createBattle(entries, slot.event)
  }

  close () {
    if (this.timer) clearInterval(this.timer)
    this.timer = null
    this.slots.clear()
    this.sessionEntries.clear()
  }
}

module.exports = new MatchmakingService()
