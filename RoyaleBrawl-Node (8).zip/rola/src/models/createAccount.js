const { randomBytes } = require('node:crypto')

function createAccount (accountId) {
  const passToken = randomBytes(30).toString('base64url').slice(0, 40)
  return {
    accountId,
    passToken,
    home: {
      homeId: accountId,
      thumbnailId: 28000000,
      characterId: 16000000,
      trophiesReward: 0,
      tokenReward: 0,
      trophyRoadProgress: 1,
      lastVisitHomeTime: new Date(0)
    },
    avatar: {
      accountId,
      passToken,
      name: 'Brawler',
      nameSetByUser: false,
      tutorialsCompletedCount: 2,
      gold: 100,
      diamonds: 0,
      trioWins: 0,
      soloWins: 0,
      chips: 0,
      elexir: 0,
      isDev: false,
      isPremium: false,
      allianceId: -1,
      allianceRole: 0,
      lastOnline: new Date(),
      friends: [],
      banned: false,
      playerStatus: 0,
      teamId: 0,
      battleId: -1,
      udpSessionId: -1,
      teamIndex: 0,
      ownIndex: 0,
      rollsSinceGoodDrop: 0,
      heroes: [
        {
          characterId: 16000000,
          cardId: 23000000,
          trophies: 0,
          highestTrophies: 0,
          upgrades: []
        }
      ]
    },
    createdAt: new Date(),
    updatedAt: new Date()
  }
}

module.exports = createAccount
