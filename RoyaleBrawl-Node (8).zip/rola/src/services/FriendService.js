const sessionService = require('./SessionService')
const { createFriendFromAccount } = require('../protocol/SocialEncoders')
const {
  FriendListMessage,
  FriendListUpdateMessage,
  FriendOnlineStatusEntryMessage,
  OutOfSyncMessage
} = require('../protocol/ServerMessages')

class FriendService {
  async enrich (friend) {
    const account = await global.repositories.accounts.findById(friend.accountId)
    if (!account) return friend
    const enriched = createFriendFromAccount(account, friend.friendState, friend.friendReason)
    enriched.lastOnlineSeconds = sessionService.isOnline(account.accountId)
      ? 0
      : Math.max(0, Math.trunc((Date.now() - new Date(account.avatar.lastOnline).getTime()) / 1000))
    return enriched
  }

  async list (session) {
    const friends = await Promise.all(session.account.avatar.friends.map(friend => this.enrich(friend)))
    await new FriendListMessage(session, { friends }).send()
  }

  async add (session, targetId, reason) {
    const owner = session.account
    const target = await global.repositories.accounts.findById(targetId)
    if (!target || targetId === owner.accountId) return
    const existing = owner.avatar.friends.find(friend => friend.accountId === targetId)
    if (existing) return this.accept(session, targetId)

    const targetEntry = createFriendFromAccount(owner, 3, reason)
    const ownerEntry = createFriendFromAccount(target, 2, 0)
    target.avatar.friends.push(targetEntry)
    owner.avatar.friends.push(ownerEntry)
    await Promise.all([
      global.repositories.accounts.save(owner),
      global.repositories.accounts.save(target)
    ])

    const targetSession = sessionService.get(targetId)
    if (targetSession) await new FriendListUpdateMessage(targetSession, { entry: targetEntry }).send()
    await new FriendListUpdateMessage(session, { entry: ownerEntry }).send()
  }

  async accept (session, targetId) {
    const owner = session.account
    const target = await global.repositories.accounts.findById(targetId)
    if (!target) return
    const ownerEntry = owner.avatar.friends.find(friend => friend.accountId === targetId && friend.friendState !== 4)
    const targetEntry = target.avatar.friends.find(friend => friend.accountId === owner.accountId)
    if (!ownerEntry || !targetEntry) return
    if (owner.avatar.friends.some(friend => friend !== ownerEntry && friend.accountId === targetId && friend.friendState === 4)) {
      owner.avatar.friends = owner.avatar.friends.filter(friend => friend !== ownerEntry)
      await global.repositories.accounts.save(owner)
      return new OutOfSyncMessage(session).send()
    }
    ownerEntry.friendState = 4
    ownerEntry.friendReason = 0
    targetEntry.friendState = 4
    targetEntry.friendReason = 0
    await Promise.all([
      global.repositories.accounts.save(owner),
      global.repositories.accounts.save(target)
    ])
    await new FriendListUpdateMessage(session, { entry: await this.enrich(ownerEntry) }).send()
    const targetSession = sessionService.get(targetId)
    if (targetSession) await new FriendListUpdateMessage(targetSession, { entry: await this.enrich(targetEntry) }).send()
  }

  async remove (session, targetId) {
    const owner = session.account
    const target = await global.repositories.accounts.findById(targetId)
    const ownerEntry = owner.avatar.friends.find(friend => friend.accountId === targetId)
    if (!ownerEntry || !target) return
    owner.avatar.friends = owner.avatar.friends.filter(friend => friend.accountId !== targetId)
    target.avatar.friends = target.avatar.friends.filter(friend => friend.accountId !== owner.accountId)
    await Promise.all([
      global.repositories.accounts.save(owner),
      global.repositories.accounts.save(target)
    ])
    ownerEntry.friendState = 0
    await new FriendListUpdateMessage(session, { entry: await this.enrich(ownerEntry) }).send()
    const targetSession = sessionService.get(targetId)
    if (targetSession) {
      const removed = createFriendFromAccount(owner, 0, 0)
      await new FriendListUpdateMessage(targetSession, { entry: removed }).send()
    }
  }

  async updateStatus (session, status) {
    session.account.avatar.playerStatus = status
    await global.repositories.accounts.save(session.account)
    for (const friend of session.account.avatar.friends) {
      const targetSession = sessionService.get(friend.accountId)
      if (targetSession) {
        await new FriendOnlineStatusEntryMessage(targetSession, {
          avatarId: session.account.accountId,
          playerStatus: status
        }).send()
      }
    }
  }
}

module.exports = new FriendService()
