class SessionService {
  get (accountId) {
    for (const session of global.sessions.values()) {
      if (session.account && session.account.accountId === accountId) return session
    }
    return null
  }

  isOnline (accountId) {
    return this.get(accountId) !== null
  }

  count () {
    let count = 0
    for (const session of global.sessions.values()) {
      if (session.account) count++
    }
    return count
  }
}

module.exports = new SessionService()
