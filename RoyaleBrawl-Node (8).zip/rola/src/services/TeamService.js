const eventService = require('../logic/events/EventService')
const sessionService = require('./SessionService')
const { getTrophies } = require('../logic/home/HomeEncoder')
const { createFriendFromAccount } = require('../protocol/SocialEncoders')
const {
  TeamGameStartingMessage,
  TeamInvitationMessage,
  TeamLeftMessage,
  TeamMessage,
  TeamStreamMessage
} = require('../protocol/ServerMessages')

class TeamService {
  heroForAccount (account, characterId) {
    return account.avatar.heroes.find(hero => hero.characterId === characterId) || {
      trophies: 0,
      highestTrophies: 0
    }
  }

  memberFromAccount (account, isOwner) {
    const hero = this.heroForAccount(account, account.home.characterId)
    return {
      isOwner,
      accountId: account.accountId,
      characterId: account.home.characterId,
      skinId: 0,
      heroTrophies: hero.trophies,
      heroHighestTrophies: hero.highestTrophies,
      heroLevel: 0,
      state: 0,
      isReady: false,
      displayData: {
        name: account.avatar.name,
        thumbnailId: account.home.thumbnailId
      }
    }
  }

  async broadcast (team) {
    for (const member of team.members) {
      const session = sessionService.get(member.accountId)
      if (session) await new TeamMessage(session, { team }).send()
    }
  }

  async broadcastStream (team, entry) {
    for (const member of team.members) {
      const session = sessionService.get(member.accountId)
      if (session) {
        await new TeamStreamMessage(session, {
          teamId: team.id,
          entries: [entry]
        }).send()
      }
    }
  }

  async create (session, message) {
    const firstEvent = eventService.getEvents()[0]
    const team = {
      type: message.teamType,
      locationId: firstEvent.locationId,
      eventSlot: 1,
      members: [this.memberFromAccount(session.account, true)],
      invites: [],
      joinRequests: [],
      disabledBots: [],
      entryCounter: 0,
      stream: []
    }
    await global.repositories.teams.create(team)
    session.account.avatar.teamId = team.id
    await global.repositories.accounts.save(session.account)
    await new TeamMessage(session, { team }).send()
  }

  async invite (session, targetId, slot) {
    const team = await global.repositories.teams.findById(session.account.avatar.teamId)
    const target = await global.repositories.accounts.findById(targetId)
    if (!team || !target) return
    team.invites = team.invites.filter(invite => invite.id !== targetId)
    team.invites.push({
      inviterId: session.account.accountId,
      id: targetId,
      name: target.avatar.name,
      slot
    })
    await global.repositories.teams.save(team)
    await this.broadcast(team)
    const targetSession = sessionService.get(targetId)
    if (targetSession) {
      const friendEntry = createFriendFromAccount(session.account, 0, 0)
      friendEntry.trophies = getTrophies(session.account.avatar, 'trophies')
      await new TeamInvitationMessage(targetSession, {
        unknown: 1,
        teamId: team.id,
        friendEntry
      }).send()
    }
  }

  async invitationResponse (session, message) {
    const team = await global.repositories.teams.findById(message.teamId)
    if (!team) return
    const invite = team.invites.find(entry => entry.id === session.account.accountId)
    if (!invite) return
    team.invites = team.invites.filter(entry => entry.id !== session.account.accountId)
    if (message.response === 1 && team.members.length < 3) {
      team.members.push(this.memberFromAccount(session.account, false))
      session.account.avatar.teamId = team.id
      await global.repositories.accounts.save(session.account)
    }
    await global.repositories.teams.save(team)
    await this.broadcast(team)
  }

  async leave (session) {
    const teamId = session.account.avatar.teamId
    if (teamId <= 0) return
    const team = await global.repositories.teams.findById(teamId)
    session.account.avatar.teamId = -1
    await global.repositories.accounts.save(session.account)
    await new TeamLeftMessage(session, { reason: 0 }).send()
    if (!team) return
    team.members = team.members.filter(member => member.accountId !== session.account.accountId)
    if (team.members.length === 0) {
      await global.repositories.teams.remove(team.id)
    } else {
      if (!team.members.some(member => member.isOwner)) team.members[0].isOwner = true
      await global.repositories.teams.save(team)
      await this.broadcast(team)
    }
  }

  async updateMember (session, update) {
    const team = await global.repositories.teams.findById(session.account.avatar.teamId)
    if (!team) return
    const member = team.members.find(entry => entry.accountId === session.account.accountId)
    if (!member) return
    Object.assign(member, update)
    await global.repositories.teams.save(team)
    await this.broadcast(team)
  }

  async setCharacter (session, characterId) {
    session.account.home.characterId = characterId
    const hero = this.heroForAccount(session.account, characterId)
    await global.repositories.accounts.save(session.account)
    await this.updateMember(session, {
      characterId,
      heroTrophies: hero.trophies,
      heroHighestTrophies: hero.highestTrophies
    })
  }

  async setLocation (session) {
    const team = await global.repositories.teams.findById(session.account.avatar.teamId)
    if (!team) return
    team.type = 1
    await global.repositories.teams.save(team)
    await this.broadcast(team)
  }

  async setEvent (session, slot) {
    if (slot === 2) return
    const event = eventService.getEvent(slot)
    if (!event) return
    const team = await global.repositories.teams.findById(session.account.avatar.teamId)
    if (!team) return
    team.eventSlot = slot
    team.locationId = event.locationId
    await global.repositories.teams.save(team)
    await this.broadcast(team)
  }

  async addChat (session, message, quick) {
    const team = await global.repositories.teams.findById(session.account.avatar.teamId)
    if (!team) return
    team.entryCounter++
    const entry = quick
      ? {
          type: 8,
          id: team.entryCounter,
          accountId: session.account.accountId,
          name: session.account.avatar.name,
          targetId: message.targetId,
          targetPlayerName: team.members.find(member => member.accountId === message.targetId)?.displayData.name || null,
          messageDataId: message.messageDataId,
          unknown1: message.unknown1,
          unknown2: message.unknown2
        }
      : {
          type: 2,
          id: team.entryCounter,
          accountId: session.account.accountId,
          name: session.account.avatar.name,
          message: message.message
        }
    team.stream.push(entry)
    await global.repositories.teams.save(team)
    await this.broadcastStream(team, entry)
  }

  async setReady (session, isReady) {
    await this.updateMember(session, { isReady })
    const team = await global.repositories.teams.findById(session.account.avatar.teamId)
    if (team && team.members.length > 0 && team.members.every(member => member.isReady)) {
      for (const member of team.members) {
        const memberSession = sessionService.get(member.accountId)
        if (memberSession) {
          await new TeamGameStartingMessage(memberSession, { locationId: team.locationId }).send()
          if (global.matchmaking) global.matchmaking.request(memberSession, team.eventSlot, team.id)
        }
        member.isReady = false
      }
      await global.repositories.teams.save(team)
    }
  }
}

module.exports = new TeamService()
