const dataTables = require('../logic/DataTables')

class GatchaService {
  rarityIndex (rarity) {
    return ['common', 'rare', 'epic', 'legendary'].indexOf(rarity)
  }

  randomInt (max) {
    return Math.floor(Math.random() * max)
  }

  simulate (account) {
    let drop = null
    if (this.randomInt(100) < 10) {
      for (let attempt = 0; attempt < 25; attempt++) {
        const character = dataTables.getTable(16)[this.randomInt(38)]
        if (!character || String(character.Disabled).toLowerCase() === 'true') continue
        const card = dataTables.getByName(23, `${character.Name}_unlock`)
        if (!card) continue
        const rarity = this.rarityIndex(card.Rarity)
        const existing = account.avatar.heroes.find(hero => hero.characterId === character.globalId)
        if (!existing) {
          drop = { type: 1, rarity, count: 1, dataGlobalId: character.globalId }
        } else {
          const counts = [1, 2, 10, 60]
          drop = { type: 5, rarity, count: counts[rarity], dataGlobalId: character.globalId }
        }
        break
      }
    }
    if (!drop) {
      const rarity = this.randomInt(4)
      drop = { type: 6, rarity, count: [1, 2, 5, 10][rarity], dataGlobalId: 0 }
    }
    this.apply(account, drop)
    return { type: 10, drops: [drop] }
  }

  apply (account, drop) {
    if (drop.type === 1) {
      const character = dataTables.getByGlobalId(drop.dataGlobalId)
      const card = dataTables.getByName(23, `${character.Name}_unlock`)
      account.avatar.heroes.push({
        characterId: character.globalId,
        cardId: card.globalId,
        trophies: 0,
        highestTrophies: 0,
        upgrades: []
      })
    } else if (drop.type === 6) {
      account.avatar.elexir += drop.count
    } else if (drop.type === 7) {
      account.avatar.gold += drop.count
    } else if (drop.type === 8) {
      account.avatar.diamonds += drop.count
    }
  }
}

module.exports = new GatchaService()
