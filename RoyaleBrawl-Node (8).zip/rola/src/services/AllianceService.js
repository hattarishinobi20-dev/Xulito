const dataTables = require('../logic/DataTables')
const sessionService = require('./SessionService')
const { getTrophies } = require('../logic/home/HomeEncoder')
const {
  AllianceDataMessage,
  AllianceResponseMessage,
  AllianceStreamEntryMessage,
  AllianceStreamMessage,
  JoinableAllianceListMessage,
  MyAllianceMessage
} = require('../protocol/ServerMessages')

class AllianceService {
  memberFromAccount (account) {
    return {
      accountId: account.accountId,
      trophies: getTrophies(account.avatar, 'trophies'),
      role: account.avatar.allianceRole,
      displayData: {
        name: account.avatar.name,
        thumbnailId: account.home.thumbnailId
      }
    }
  }

  onlineMembers (alliance) {
    return alliance.members.filter(member => sessionService.isOnline(member.accountId)).length
  }

  refreshTrophies (alliance) {
    alliance.trophies = alliance.members.reduce((total, member) => total + (member.trophies || 0), 0)
  }

  addStreamEntry (alliance, entry) {
    alliance.entryIdCounter = (alliance.entryIdCounter || 0) + 1
    entry.id = alliance.entryIdCounter
    entry.sendTime = new Date()
    alliance.stream = alliance.stream || []
    if (alliance.stream.length >= 200) alliance.stream.shift()
    alliance.stream.push(entry)
    return entry
  }

  async broadcast (alliance, Message, data) {
    for (const member of alliance.members) {
      const session = sessionService.get(member.accountId)
      if (session) await new Message(session, data).send()
    }
  }

  async sendMyAllianceData (session, alliance) {
    await new MyAllianceMessage(session, {
      onlineMembers: this.onlineMembers(alliance),
      role: session.account.avatar.allianceRole,
      alliance
    }).send()
    await new AllianceStreamMessage(session, { entries: alliance.stream || [] }).send()
  }

  async create (session, message) {
    const account = session.account
    if (account.avatar.allianceId >= 0) return
    const badgeCount = dataTables.getTable(8).length
    account.avatar.allianceRole = 2
    const alliance = {
      name: message.name,
      description: message.description,
      members: [],
      allianceBadgeId: message.badgeId >= 8000000 && message.badgeId < 8000000 + badgeCount ? message.badgeId : 8000000,
      requiredTrophies: message.requiredTrophies,
      type: message.allianceType || 1,
      trophies: 0,
      entryIdCounter: 0,
      stream: []
    }
    alliance.members.push(this.memberFromAccount(account))
    this.refreshTrophies(alliance)
    await global.repositories.alliances.create(alliance)
    account.avatar.allianceId = alliance.allianceId
    await global.repositories.accounts.save(account)
    await new AllianceResponseMessage(session, { responseType: 20 }).send()
    await this.sendMyAllianceData(session, alliance)
  }

  async join (session, allianceId) {
    const account = session.account
    if (account.avatar.allianceId > 0) return
    const alliance = await global.repositories.alliances.findById(allianceId)
    if (!alliance || alliance.members.length >= 100) return
    const entry = this.addStreamEntry(alliance, {
      authorId: account.accountId,
      authorName: account.avatar.name,
      authorRole: account.avatar.allianceRole,
      playerId: account.accountId,
      playerName: account.avatar.name,
      type: 4,
      event: 3
    })
    account.avatar.allianceRole = 1
    account.avatar.allianceId = alliance.allianceId
    alliance.members.push(this.memberFromAccount(account))
    this.refreshTrophies(alliance)
    await Promise.all([
      global.repositories.accounts.save(account),
      global.repositories.alliances.save(alliance)
    ])
    await this.broadcast(alliance, AllianceStreamEntryMessage, { entry })
    await new AllianceResponseMessage(session, { responseType: 40 }).send()
    await this.sendMyAllianceData(session, alliance)
  }

  async leave (session) {
    const account = session.account
    if (account.avatar.allianceId < 0 || account.avatar.allianceRole === 0) return
    const alliance = await global.repositories.alliances.findById(account.avatar.allianceId)
    if (!alliance) return
    alliance.members = alliance.members.filter(member => member.accountId !== account.accountId)
    account.avatar.allianceId = -1
    account.avatar.allianceRole = 0
    const entry = this.addStreamEntry(alliance, {
      authorId: account.accountId,
      authorName: account.avatar.name,
      authorRole: 0,
      playerId: account.accountId,
      playerName: account.avatar.name,
      type: 4,
      event: 4
    })
    this.refreshTrophies(alliance)
    await Promise.all([
      global.repositories.accounts.save(account),
      global.repositories.alliances.save(alliance)
    ])
    await this.broadcast(alliance, AllianceStreamEntryMessage, { entry })
    await new AllianceResponseMessage(session, { responseType: 80 }).send()
    await new MyAllianceMessage(session, { onlineMembers: 0, role: 0, alliance: null }).send()
  }

  async changeSettings (session, message) {
    const account = session.account
    if (account.avatar.allianceId <= 0 || account.avatar.allianceRole !== 2) return
    const alliance = await global.repositories.alliances.findById(account.avatar.allianceId)
    if (!alliance) return
    const badgeCount = dataTables.getTable(8).length
    alliance.allianceBadgeId = message.badgeId >= 8000000 && message.badgeId < 8000000 + badgeCount ? message.badgeId : 8000000
    alliance.description = message.description
    alliance.requiredTrophies = message.requiredTrophies
    await global.repositories.alliances.save(alliance)
    await new AllianceResponseMessage(session, { responseType: 10 }).send()
    await new MyAllianceMessage(session, {
      onlineMembers: this.onlineMembers(alliance),
      role: account.avatar.allianceRole,
      alliance
    }).send()
  }

  async kick (session, targetId) {
    const owner = session.account
    if (owner.avatar.allianceId <= 0) return
    const alliance = await global.repositories.alliances.findById(owner.avatar.allianceId)
    const target = await global.repositories.accounts.findById(targetId)
    if (!alliance || !target || owner.avatar.allianceRole <= target.avatar.allianceRole) return
    alliance.members = alliance.members.filter(member => member.accountId !== targetId)
    target.avatar.allianceId = -1
    target.avatar.allianceRole = 0
    const entry = this.addStreamEntry(alliance, {
      authorId: owner.accountId,
      authorName: owner.avatar.name,
      authorRole: owner.avatar.allianceRole,
      playerId: target.accountId,
      playerName: target.avatar.name,
      type: 4,
      event: 1
    })
    this.refreshTrophies(alliance)
    await Promise.all([
      global.repositories.accounts.save(target),
      global.repositories.alliances.save(alliance)
    ])
    await this.broadcast(alliance, AllianceStreamEntryMessage, { entry })
    await new AllianceResponseMessage(session, { responseType: 70 }).send()
    const targetSession = sessionService.get(targetId)
    if (targetSession) {
      await new AllianceResponseMessage(targetSession, { responseType: 100 }).send()
      await new MyAllianceMessage(targetSession, { onlineMembers: 0, role: 0, alliance: null }).send()
    }
  }

  async chat (session, content) {
    const alliance = await global.repositories.alliances.findById(session.account.avatar.allianceId)
    if (!alliance) return
    if (content.startsWith('/')) {
      const command = content.slice(1).split(' ')[0]
      const messages = {
        help: 'List of commands:\n/help - shows this message\n/status - show server status',
        status: `Server Status:\nServer Version: v1.2 (for 1.1714) (Beta)\nPlayers Online: ${sessionService.count()}\nYour id: ${session.account.accountId}`
      }
      const entry = {
        id: (alliance.entryIdCounter || 0) + 667,
        authorId: 1,
        authorName: 'Debugger',
        authorRole: 1,
        type: 2,
        sendTime: new Date(),
        message: messages[command] || `Unknown command "${command}" - type "/help" to get command list!`
      }
      await new AllianceStreamEntryMessage(session, { entry }).send()
      return
    }
    const entry = this.addStreamEntry(alliance, {
      authorId: session.account.accountId,
      authorName: session.account.avatar.name,
      authorRole: session.account.avatar.allianceRole,
      type: 2,
      message: content
    })
    await global.repositories.alliances.save(alliance)
    await this.broadcast(alliance, AllianceStreamEntryMessage, { entry })
  }

  async data (session, allianceId) {
    const alliance = await global.repositories.alliances.findById(allianceId)
    if (alliance) await new AllianceDataMessage(session, { alliance }).send()
  }

  async discover (session) {
    const alliances = await global.repositories.alliances.discover(10)
    await new JoinableAllianceListMessage(session, { alliances }).send()
  }
}

module.exports = new AllianceService()
