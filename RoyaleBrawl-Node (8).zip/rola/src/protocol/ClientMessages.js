const PiranhaMessage = require('../../core/Protocol/PiranhaMessage')
const commandManager = require('../logic/commands/CommandManager')
const { readDataReference, readLong, readVLong } = require('../logic/home/StreamHelper')

const empty = () => {}

const decoders = {
  10107: message => { message.ping = message.stream.readVInt() },
  10212: message => { message.name = message.stream.readString() },
  10501: message => { message.avatarId = readLong(message.stream) },
  10502: message => {
    message.avatarId = readLong(message.stream)
    message.reason = message.stream.readInt()
    message.reasonDetails = message.stream.readInt()
  },
  10506: message => { message.avatarId = readLong(message.stream) },
  10555: message => {
    message.stream.readVInt()
    message.stream.readVInt()
    const count = message.stream.readVInt()
    message.inputs = []
    for (let i = 0; i < count; i++) {
      message.inputs.push({
        index: message.stream.readVInt(),
        sequence: message.stream.readVInt(),
        type: message.stream.readVInt(),
        x: message.stream.readVInt(),
        y: message.stream.readVInt()
      })
    }
  },
  14102: message => {
    message.stream.readBoolean()
    message.tick = message.stream.readVInt()
    message.checksum = message.stream.readVInt()
    const count = message.stream.readVInt()
    message.commands = []
    for (let i = 0; i < count; i++) {
      const command = commandManager.decode(message.stream)
      if (!command) break
      message.commands.push(command)
    }
  },
  14103: message => {
    message.stream.readVInt()
    message.selectedCard = readDataReference(message.stream)
    message.eventSlot = message.stream.readVInt()
    message.stream.readVInt()
  },
  14104: message => { message.accountId = readLong(message.stream) },
  14113: message => { message.accountId = readLong(message.stream) },
  14166: message => { message.unknown = message.stream.readVInt() },
  14301: message => {
    message.name = message.stream.readString()
    message.description = message.stream.readString()
    message.badgeId = readDataReference(message.stream)
    message.allianceType = message.stream.readVInt()
    message.requiredTrophies = message.stream.readVInt()
  },
  14302: message => { message.allianceId = readLong(message.stream) },
  14305: message => { message.allianceId = readLong(message.stream) },
  14307: message => { message.accountId = readLong(message.stream) },
  14315: message => { message.message = message.stream.readString() },
  14316: message => {
    message.description = message.stream.readString()
    message.badgeId = readDataReference(message.stream)
    message.allianceType = message.stream.readVInt()
    message.requiredTrophies = message.stream.readVInt()
  },
  14350: message => {
    message.stream.readVInt()
    message.eventSlot = message.stream.readVInt()
    message.teamType = message.stream.readVInt()
  },
  14354: message => {
    message.stream.readVInt()
    message.characterId = readDataReference(message.stream)
  },
  14355: message => { message.isReady = message.stream.readBoolean() },
  14359: message => { message.message = message.stream.readString() },
  14361: message => { message.status = message.stream.readVInt() },
  14362: message => {
    message.stream.readVInt()
    message.eventSlot = message.stream.readVInt()
  },
  14365: message => {
    message.avatarId = readVLong(message.stream)
    message.team = message.stream.readVInt()
  },
  14366: message => { message.status = message.stream.readVInt() },
  14369: message => {
    message.messageDataId = readDataReference(message.stream)
    message.hasTarget = message.stream.readBoolean()
    message.targetId = message.hasTarget ? readLong(message.stream) : -1
    message.unknown1 = message.stream.readVInt()
    message.unknown2 = message.stream.readVInt()
    if (message.stream.offset < message.stream.buffer.length) message.unknown3 = message.stream.readVInt()
  },
  14403: message => {
    message.isRegional = message.stream.readBoolean()
    message.leaderboardType = message.stream.readVInt()
    message.targetBrawler = readDataReference(message.stream)
  },
  14479: message => {
    message.response = message.stream.readVInt()
    message.teamId = readLong(message.stream)
    message.mutePlayer = message.stream.readBoolean()
  },
  14600: message => { message.name = message.stream.readString() }
}

const names = {
  10107: 'ClientCapabilitiesMessage',
  10108: 'KeepAliveMessage',
  10177: 'ClientInfoMessage',
  10212: 'ChangeAvatarNameMessage',
  10501: 'AcceptFriendMessage',
  10502: 'AddFriendMessage',
  10504: 'AskForFriendListMessage',
  10506: 'RemoveFriendMessage',
  10555: 'ClientInputMessage',
  14101: 'GoHomeMessage',
  14102: 'EndClientTurnMessage',
  14103: 'MatchmakeRequestMessage',
  14104: 'StartSpectateMessage',
  14106: 'CancelMatchmakingMessage',
  14107: 'StopSpectateMessage',
  14109: 'GoHomeFromOfflinePractiseMessage',
  14113: 'GetPlayerProfileMessage',
  14166: 'ChronosEventSeenMessage',
  14301: 'CreateAllianceMessage',
  14302: 'AskForAllianceDataMessage',
  14303: 'AskForJoinableAllianceListMessage',
  14305: 'JoinAllianceMessage',
  14307: 'KickAllianceMemberMessage',
  14308: 'LeaveAllianceMessage',
  14315: 'ChatToAllianceStreamMessage',
  14316: 'ChangeAllianceSettingsMessage',
  14350: 'TeamCreateMessage',
  14353: 'TeamLeaveMessage',
  14354: 'TeamChangeMemberSettingsMessage',
  14355: 'TeamSetMemberReadyMessage',
  14359: 'TeamChatMessage',
  14361: 'TeamMemberStatusMessage',
  14362: 'TeamSetEventMessage',
  14363: 'TeamSetLocationMessage',
  14365: 'TeamInviteMessage',
  14366: 'PlayerStatusMessage',
  14369: 'TeamPremadeChatMessage',
  14403: 'GetLeaderboardMessage',
  14479: 'TeamInvitationResponseMessage',
  14600: 'AvatarNameCheckRequestMessage'
}

function createMessageType (id, name) {
  return {
    [name]: class extends PiranhaMessage {
      constructor (bytes, session) {
        super(session)
        this.id = id
        this.version = 0
        this.stream = this.DataStream.getByteStream(bytes)
      }

      decode () {
        return (decoders[id] || empty)(this)
      }

      async execute () {
        if (global.messageRouter) await global.messageRouter.handle(this.session, this)
      }
    }
  }[name]
}

module.exports = Object.fromEntries(
  Object.entries(names).map(([id, name]) => [Number(id), createMessageType(Number(id), name)])
)
