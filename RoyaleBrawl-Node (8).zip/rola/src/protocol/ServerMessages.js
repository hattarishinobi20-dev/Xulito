const PiranhaMessage = require('../../core/Protocol/PiranhaMessage')
const { getTrophies } = require('../logic/home/HomeEncoder')
const { writeDataReference, writeLong, writeVLong } = require('../logic/home/StreamHelper')
const {
  encodeAlliance,
  encodeAllianceHeader,
  encodeAllianceMember,
  encodeAllianceStreamEntry,
  encodeFriend,
  encodeTeam,
  encodeTeamStreamEntry
} = require('./SocialEncoders')

function createServerMessage (id, name, encoder = () => {}) {
  return {
    [name]: class extends PiranhaMessage {
      constructor (session, data = {}) {
        super(session)
        this.id = id
        this.version = 0
        Object.assign(this, data)
      }

      encode () {
        encoder(this.stream, this)
      }
    }
  }[name]
}

function encodeHero (stream, hero) {
  writeDataReference(stream, hero.characterId)
  stream.writeVInt(0)
  stream.writeVInt(hero.trophies)
  stream.writeVInt(hero.highestTrophies)
  stream.writeVInt(0)
}

const KeepAliveServerMessage = createServerMessage(20108, 'KeepAliveServerMessage')
const MatchMakingCancelledMessage = createServerMessage(20406, 'MatchMakingCancelledMessage')
const OutOfSyncMessage = createServerMessage(24104, 'OutOfSyncMessage', stream => {
  stream.writeVInt(0)
  stream.writeVInt(0)
  stream.writeVInt(0)
})
const AvailableServerCommandMessage = createServerMessage(24111, 'AvailableServerCommandMessage', (stream, message) => {
  stream.writeVInt(message.commandType)
  message.encodeCommand(stream)
})
const MatchMakingStatusMessage = createServerMessage(20405, 'MatchMakingStatusMessage', (stream, message) => {
  stream.writeInt(message.seconds || 0)
  stream.writeInt(message.found || 0)
  for (let i = 0; i < (message.found || 0); i++) {
    stream.writeString('dudka')
    stream.writeBoolean(Boolean(message.status))
    writeLong(stream, i)
  }
  stream.writeInt(message.max || 0)
})
const LeaderboardMessage = createServerMessage(24403, 'LeaderboardMessage', (stream, message) => {
  let playerIndex = 0
  stream.writeVInt(message.leaderboardType)
  stream.writeVInt(0)
  stream.writeString(message.region)

  if (message.leaderboardType === 1) {
    stream.writeVInt(message.accounts.length)
    message.accounts.forEach((account, index) => {
      if (account.accountId === message.ownAvatarId) playerIndex = index + 1
      writeVLong(stream, account.accountId)
      stream.writeVInt(1)
      stream.writeVInt(getTrophies(account.avatar, 'trophies'))
      stream.writeBoolean(true)
      stream.writeString(account.avatar.name || 'Player data is missing')
      stream.writeString(null)
      stream.writeVInt(100)
      writeDataReference(stream, account.home.thumbnailId)
      stream.writeBoolean(false)
    })
  } else if (message.leaderboardType === 2) {
    stream.writeVInt(message.alliances.length)
    for (const alliance of message.alliances) {
      writeVLong(stream, alliance.allianceId)
      stream.writeVInt(1)
      stream.writeVInt(alliance.trophies)
      stream.writeBoolean(false)
      stream.writeBoolean(true)
      stream.writeString(alliance.name)
      stream.writeVInt(alliance.members.length)
      writeDataReference(stream, alliance.allianceBadgeId)
    }
  } else {
    stream.writeVInt(0)
  }

  stream.writeVInt(0)
  stream.writeVInt(playerIndex)
  stream.writeVInt(0)
  stream.writeVInt(0)
  stream.writeString('CAT')
})
const PlayerProfileMessage = createServerMessage(24113, 'PlayerProfileMessage', (stream, message) => {
  const account = message.account
  const avatar = account.avatar
  writeVLong(stream, account.accountId)
  stream.writeString(avatar.name)
  stream.writeVInt(0)
  stream.writeVInt(avatar.heroes.length)
  for (const hero of avatar.heroes) encodeHero(stream, hero)
  const stats = [
    [1, avatar.trioWins],
    [2, 100],
    [3, getTrophies(avatar, 'trophies')],
    [4, getTrophies(avatar, 'highestTrophies')],
    [5, avatar.heroes.length],
    [7, account.home.thumbnailId],
    [8, avatar.soloWins]
  ]
  stream.writeVInt(stats.length)
  for (const [key, value] of stats) {
    stream.writeVInt(key)
    stream.writeVInt(value)
  }
  stream.writeBoolean(false)
  if (avatar.allianceRole > 0) writeDataReference(stream, 25000000 + avatar.allianceRole)
  else stream.writeVInt(0)
})

const FriendListMessage = createServerMessage(20105, 'FriendListMessage', (stream, message) => {
  stream.writeInt(0)
  stream.writeBoolean(true)
  stream.writeInt(message.friends.length)
  for (const friend of message.friends) encodeFriend(stream, friend)
})
const FriendListUpdateMessage = createServerMessage(20106, 'FriendListUpdateMessage', (stream, message) => {
  stream.writeBoolean(true)
  encodeFriend(stream, message.entry)
})
const ShutdownStartedMessage = createServerMessage(20161, 'ShutdownStartedMessage', stream => stream.writeInt(0))
const TeamMessage = createServerMessage(24124, 'TeamMessage', (stream, message) => encodeTeam(stream, message.team))
const TeamLeftMessage = createServerMessage(24125, 'TeamLeftMessage', (stream, message) => stream.writeInt(message.reason))
const TeamGameStartingMessage = createServerMessage(24130, 'TeamGameStartingMessage', (stream, message) => {
  stream.writeVInt(0)
  stream.writeVInt(0)
  writeDataReference(stream, message.locationId)
})
const TeamStreamMessage = createServerMessage(24131, 'TeamStreamMessage', (stream, message) => {
  writeVLong(stream, message.teamId)
  stream.writeVInt(message.entries.length)
  for (const entry of message.entries) encodeTeamStreamEntry(stream, entry)
})
const AllianceDataMessage = createServerMessage(24301, 'AllianceDataMessage', (stream, message) => encodeAlliance(stream, message.alliance))
const JoinableAllianceListMessage = createServerMessage(24304, 'JoinableAllianceListMessage', (stream, message) => {
  stream.writeVInt(message.alliances.length)
  for (const alliance of message.alliances) {
    encodeAllianceHeader(stream, alliance)
    stream.writeVInt(alliance.members.length)
  }
})
const AllianceMemberMessage = createServerMessage(24308, 'AllianceMemberMessage', (stream, message) => {
  writeLong(stream, message.avatarId)
  encodeAllianceMember(stream, message.entry)
})
const AllianceStreamMessage = createServerMessage(24311, 'AllianceStreamMessage', (stream, message) => {
  if (!message.entries) {
    stream.writeVInt(-1)
    return
  }
  stream.writeVInt(message.entries.length)
  for (const entry of message.entries) encodeAllianceStreamEntry(stream, entry)
})
const AllianceStreamEntryMessage = createServerMessage(24312, 'AllianceStreamEntryMessage', (stream, message) => encodeAllianceStreamEntry(stream, message.entry))
const AllianceResponseMessage = createServerMessage(24333, 'AllianceResponseMessage', (stream, message) => stream.writeVInt(message.responseType))
const MyAllianceMessage = createServerMessage(24399, 'MyAllianceMessage', (stream, message) => {
  stream.writeVInt(message.onlineMembers)
  stream.writeBoolean(Boolean(message.alliance))
  if (message.alliance) {
    writeDataReference(stream, 25000000 + message.role)
    encodeAllianceHeader(stream, message.alliance)
    stream.writeVInt(message.onlineMembers)
  }
})
const FriendOnlineStatusEntryMessage = createServerMessage(24555, 'FriendOnlineStatusEntryMessage', (stream, message) => {
  writeLong(stream, message.avatarId)
  stream.writeBoolean(message.playerStatus >= 0)
  if (message.playerStatus >= 0) {
    writeLong(stream, message.avatarId)
    stream.writeVInt(message.playerStatus)
    stream.writeVInt(0)
    stream.writeBoolean(false)
    stream.writeBoolean(false)
  }
})
const TeamInvitationMessage = createServerMessage(24589, 'TeamInvitationMessage', (stream, message) => {
  stream.writeVInt(message.unknown)
  writeLong(stream, message.teamId)
  encodeFriend(stream, message.friendEntry)
})
const DisconnectedMessage = createServerMessage(25892, 'DisconnectedMessage', (stream, message) => stream.writeInt(message.reason))

module.exports = {
  AllianceDataMessage,
  AllianceMemberMessage,
  AllianceResponseMessage,
  AllianceStreamEntryMessage,
  AllianceStreamMessage,
  AvailableServerCommandMessage,
  DisconnectedMessage,
  FriendListMessage,
  FriendListUpdateMessage,
  FriendOnlineStatusEntryMessage,
  JoinableAllianceListMessage,
  KeepAliveServerMessage,
  LeaderboardMessage,
  MatchMakingCancelledMessage,
  MatchMakingStatusMessage,
  MyAllianceMessage,
  OutOfSyncMessage,
  PlayerProfileMessage,
  ShutdownStartedMessage,
  TeamGameStartingMessage,
  TeamInvitationMessage,
  TeamLeftMessage,
  TeamMessage,
  TeamStreamMessage,
  createServerMessage
}
