const { getTrophies } = require('../logic/home/HomeEncoder')
const { writeDataReference, writeLong, writeVLong } = require('../logic/home/StreamHelper')

function writeString (stream, value) {
  if (value === '') stream.writeInt(0)
  else stream.writeString(value)
}

function encodeDisplayData (stream, displayData) {
  stream.writeString(displayData.name)
  stream.writeVInt(100)
  stream.writeVInt(displayData.thumbnailId)
  stream.writeVInt(43000000)
}

function encodeFriend (stream, friend) {
  const avatar = friend.avatar || {}
  writeLong(stream, friend.accountId)
  for (let i = 0; i < 6; i++) stream.writeString(null)
  stream.writeInt(friend.trophies ?? avatar.trophies ?? 0)
  stream.writeInt(friend.friendState)
  stream.writeInt(friend.friendReason)
  stream.writeInt(0)
  stream.writeInt(0)
  stream.writeBoolean(false)
  stream.writeString(null)
  stream.writeInt(friend.lastOnlineSeconds || 0)
  stream.writeBoolean(Boolean(friend.displayData))
  if (friend.displayData) encodeDisplayData(stream, friend.displayData)
}

function getAllianceTrophies (alliance) {
  if (typeof alliance.trophies === 'number') return alliance.trophies
  return (alliance.members || []).reduce((total, member) => total + (member.trophies || 0), 0)
}

function encodeAllianceHeader (stream, alliance) {
  writeLong(stream, alliance.allianceId)
  stream.writeString(alliance.name)
  writeDataReference(stream, alliance.allianceBadgeId)
  stream.writeVInt(alliance.type ?? 1)
  stream.writeVInt((alliance.members || []).length)
  stream.writeVInt(getAllianceTrophies(alliance))
  stream.writeVInt(alliance.requiredTrophies || 0)
  stream.writeVInt(0)
}

function encodeAllianceMember (stream, member) {
  writeLong(stream, member.accountId)
  stream.writeString(member.displayData.name)
  stream.writeVInt(member.role)
  stream.writeVInt(0)
  stream.writeVInt(member.trophies || 0)
  writeDataReference(stream, member.displayData.thumbnailId)
}

function encodeAlliance (stream, alliance) {
  encodeAllianceHeader(stream, alliance)
  writeString(stream, alliance.description || '')
  stream.writeVInt(alliance.members.length)
  for (const member of alliance.members) encodeAllianceMember(stream, member)
}

function encodeAllianceStreamEntry (stream, entry) {
  stream.writeVInt(entry.type)
  writeVLong(stream, entry.id)
  writeVLong(stream, entry.authorId)
  stream.writeString(entry.authorName)
  stream.writeVInt(entry.authorRole)
  const sendTime = new Date(entry.sendTime)
  stream.writeVInt(Math.trunc((Date.now() - sendTime.getTime()) / 1000))
  stream.writeVInt(0)
  if (entry.type === 4) {
    stream.writeVInt(entry.event)
    stream.writeVInt(1)
    writeVLong(stream, entry.playerId)
    stream.writeString(entry.playerName)
  } else {
    stream.writeString(entry.message)
  }
}

function encodeTeamMember (stream, member) {
  writeLong(stream, member.accountId)
  stream.writeString(member.displayData.name)
  stream.writeVInt(0)
  writeDataReference(stream, member.characterId)
  writeDataReference(stream, member.skinId)
  stream.writeVInt(member.heroTrophies || 0)
  stream.writeVInt(member.heroHighestTrophies || 0)
  stream.writeVInt(0)
  stream.writeVInt(member.state || 0)
  stream.writeVInt(1)
  stream.writeBoolean(Boolean(member.isReady))
  stream.writeVInt(1)
}

function encodeTeam (stream, team) {
  stream.writeVInt(team.type)
  stream.writeBoolean(team.type === 1)
  stream.writeVInt(3)
  writeLong(stream, team.id)
  stream.writeVInt(0)
  stream.writeVInt(0)
  stream.writeVInt(0)
  writeDataReference(stream, team.locationId)
  stream.writeVInt(team.members.length)
  for (const member of team.members) encodeTeamMember(stream, member)
}

function encodeTeamStreamEntry (stream, entry) {
  stream.writeVInt(entry.type)
  writeVLong(stream, entry.id)
  writeVLong(stream, entry.accountId)
  stream.writeString(entry.name)
  stream.writeVInt(0)
  stream.writeVInt(0)
  stream.writeVInt(0)
  if (entry.type === 2) {
    stream.writeString(entry.message)
  } else if (entry.type === 8) {
    writeDataReference(stream, entry.messageDataId)
    stream.writeBoolean(entry.targetId > 0)
    if (entry.targetId > 0) writeLong(stream, entry.targetId)
    stream.writeString(entry.targetPlayerName)
    stream.writeVInt(entry.unknown1 || 0)
    stream.writeVInt(entry.unknown2 || 0)
  } else if (entry.type === 77) {
    writeLong(stream, entry.teamId)
    stream.writeVInt(0)
    stream.writeVInt(0)
    stream.writeVInt(0)
  }
}

function createFriendFromAccount (account, state, reason) {
  return {
    accountId: account.accountId,
    trophies: getTrophies(account.avatar, 'trophies'),
    friendState: state,
    friendReason: reason,
    displayData: {
      name: account.avatar.name,
      thumbnailId: account.home.thumbnailId
    }
  }
}

module.exports = {
  createFriendFromAccount,
  encodeAlliance,
  encodeAllianceHeader,
  encodeAllianceMember,
  encodeAllianceStreamEntry,
  encodeDisplayData,
  encodeFriend,
  encodeTeam,
  encodeTeamMember,
  encodeTeamStreamEntry
}
