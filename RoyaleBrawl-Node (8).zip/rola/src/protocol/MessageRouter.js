const dataTables = require('../logic/DataTables')
const allianceService = require('../services/AllianceService')
const friendService = require('../services/FriendService')
const teamService = require('../services/TeamService')
const gatchaService = require('../services/GatchaService')
const battleService = require('../battle/BattleService')
const matchmaking = require('../battle/MatchmakingService')
const OwnHomeDataMessage = require('./messages/server/home/OwnHomeDataMessage')
const {
  encodeChangeAvatarNameCommand,
  encodeGiveDeliveryItemsCommand
} = require('../logic/commands/CommandEncoders')
const {
  AvailableServerCommandMessage,
  KeepAliveServerMessage,
  LeaderboardMessage,
  MyAllianceMessage,
  OutOfSyncMessage,
  PlayerProfileMessage,
  TeamMessage
} = require('./ServerMessages')

class MessageRouter {
  async handle (session, message) {
    if (message.id === 10108) return new KeepAliveServerMessage(session).send()
    if (message.id === 10107) {
      session.ping = message.ping
      return
    }
    if (!session.account) return

    switch (message.id) {
      case 10177:
        await battleService.sendUdpInfo(session)
        break
      case 10212:
      case 14600:
        await this.changeName(session, message.name)
        break
      case 10501:
        await friendService.accept(session, message.avatarId)
        break
      case 10502:
        await friendService.add(session, message.avatarId, message.reason)
        break
      case 10504:
        await friendService.list(session)
        break
      case 10506:
        await friendService.remove(session, message.avatarId)
        break
      case 14101:
      case 14109:
        await new OwnHomeDataMessage(session, session.account).send()
        break
      case 14102:
        await this.executeCommands(session, message.commands)
        break
      case 14103:
        if (dataTables.getByGlobalId(message.selectedCard)) {
          session.account.home.characterId = message.selectedCard
          await global.repositories.accounts.save(session.account)
          matchmaking.request(session, message.eventSlot)
        } else {
          await new OutOfSyncMessage(session).send()
        }
        break
      case 14104:
        await battleService.spectate(session, message.accountId)
        break
      case 14106:
        matchmaking.cancel(session)
        break
      case 14107:
        await battleService.stopSpectating(session)
        await new OwnHomeDataMessage(session, session.account).send()
        break
      case 14113:
        await this.sendProfile(session, message.accountId)
        break
      case 14301:
        await allianceService.create(session, message)
        break
      case 14302:
        await allianceService.data(session, message.allianceId)
        break
      case 14303:
        await allianceService.discover(session)
        break
      case 14305:
        await allianceService.join(session, message.allianceId)
        break
      case 14307:
        await allianceService.kick(session, message.accountId)
        break
      case 14308:
        await allianceService.leave(session)
        break
      case 14315:
        await allianceService.chat(session, message.message)
        break
      case 14316:
        await allianceService.changeSettings(session, message)
        break
      case 14350:
        await teamService.create(session, message)
        break
      case 14353:
        await teamService.leave(session)
        break
      case 14354:
        await teamService.setCharacter(session, message.characterId)
        break
      case 14355:
        await teamService.setReady(session, message.isReady)
        break
      case 14359:
        await teamService.addChat(session, message, false)
        break
      case 14361:
        await teamService.updateMember(session, { state: message.status })
        break
      case 14362:
        await teamService.setEvent(session, message.eventSlot)
        break
      case 14363:
        await teamService.setLocation(session)
        break
      case 14365:
        await teamService.invite(session, message.avatarId, message.team)
        break
      case 14366:
        await friendService.updateStatus(session, message.status)
        break
      case 14369:
        await teamService.addChat(session, message, true)
        break
      case 14403:
        await this.sendLeaderboard(session, message)
        break
      case 14479:
        await teamService.invitationResponse(session, message)
        break
    }
  }

  async resumeBattle (session) {
    return battleService.resume(session)
  }

  async onLogin (session) {
    const account = session.account
    if (account.avatar.allianceId > 0) {
      const alliance = await global.repositories.alliances.findById(account.avatar.allianceId)
      if (alliance) await allianceService.sendMyAllianceData(session, alliance)
      else {
        account.avatar.allianceId = -1
        account.avatar.allianceRole = 0
      }
    } else {
      await new MyAllianceMessage(session, { onlineMembers: 0, role: 0, alliance: null }).send()
    }

    if (account.avatar.teamId > 0) {
      const team = await global.repositories.teams.findById(account.avatar.teamId)
      if (team) await new TeamMessage(session, { team }).send()
      else account.avatar.teamId = -1
    }
    await global.repositories.accounts.save(account)
  }

  async changeName (session, name) {
    session.account.avatar.name = name
    session.account.avatar.nameSetByUser = true
    await global.repositories.accounts.save(session.account)
    await new AvailableServerCommandMessage(session, {
      commandType: 201,
      encodeCommand: stream => encodeChangeAvatarNameCommand(stream, {
        name,
        changeNameCost: 0
      })
    }).send()
  }

  async executeCommands (session, commands) {
    for (const command of commands) {
      const result = command.execute(session.account, { dataTables })
      if (result !== 0) {
        await new OutOfSyncMessage(session).send()
        return
      }
      if (command.type === 500) {
        const unit = gatchaService.simulate(session.account)
        await new AvailableServerCommandMessage(session, {
          commandType: 203,
          encodeCommand: stream => encodeGiveDeliveryItemsCommand(stream, {
            deliveryUnits: [unit]
          })
        }).send()
      }
    }
    session.account.home.lastVisitHomeTime = new Date()
    session.account.home.tokenReward = 0
    session.account.home.trophiesReward = 0
    await global.repositories.accounts.save(session.account)
  }

  async sendProfile (session, accountId) {
    const account = await global.repositories.accounts.findById(accountId)
    if (account) await new PlayerProfileMessage(session, { account }).send()
  }

  async sendLeaderboard (session, message) {
    if (message.leaderboardType === 1) {
      const accounts = await global.repositories.accounts.leaderboard()
      await new LeaderboardMessage(session, {
        leaderboardType: 1,
        accounts,
        alliances: [],
        ownAvatarId: session.account.accountId,
        region: message.isRegional ? 'RU' : null
      }).send()
    } else if (message.leaderboardType === 2) {
      const alliances = await global.repositories.alliances.leaderboard()
      await new LeaderboardMessage(session, {
        leaderboardType: 2,
        accounts: [],
        alliances,
        ownAvatarId: session.account.accountId,
        region: message.isRegional ? 'RU' : null
      }).send()
    }
  }
}

module.exports = new MessageRouter()
