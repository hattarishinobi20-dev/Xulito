const PiranhaMessage = require('../../core/Protocol/PiranhaMessage')
const milestones = require('../logic/home/Milestones')
const { writeDataReference, writeLong } = require('../logic/home/StreamHelper')

function createMessage (id, name, encoder) {
  return {
    [name]: class extends PiranhaMessage {
      constructor (session, data = {}) {
        super(session)
        this.id = id
        this.version = 0
        Object.assign(this, data)
      }

      encode () {
        encoder(this.stream, this)
      }
    }
  }[name]
}

function encodeBattlePlayer (stream, player) {
  writeLong(stream, player.accountId)
  stream.writeString(player.displayData.name)
  stream.writeVInt(player.playerIndex)
  stream.writeVInt(player.teamIndex)
  stream.writeVInt(0)
  stream.writeVInt(0)
  stream.writeInt(0)
  writeDataReference(stream, player.characterId)
  stream.writeVInt(0)
  stream.writeInt(0)
}

const StartLoadingMessage = createMessage(20559, 'StartLoadingMessage', (stream, message) => {
  stream.writeInt(message.players.length)
  stream.writeInt(message.ownIndex)
  stream.writeInt(message.teamIndex)
  stream.writeInt(message.players.length)
  for (const player of message.players) encodeBattlePlayer(stream, player)
  stream.writeInt(0)
  stream.writeVInt(message.gameMode)
  stream.writeVInt(1)
  stream.writeVInt(1)
  stream.writeBoolean(false)
  writeDataReference(stream, message.locationId)
  stream.writeBoolean(false)
})

const BattleEndMessage = createMessage(23456, 'BattleEndMessage', (stream, message) => {
  stream.writeVInt(message.gameMode)
  stream.writeVInt(0)
  stream.writeVInt(message.tokensReward)
  stream.writeVInt(0)
  stream.writeVInt(0)
  stream.writeBoolean(false)
  stream.writeVInt(message.result)
  stream.writeVInt(message.trophiesReward)
  writeDataReference(stream, message.ownPlayer.displayData.thumbnailId)
  stream.writeBoolean(false)
  stream.writeBoolean(message.isPvP)
  stream.writeVInt(50)
  stream.writeVInt(0)
  stream.writeVInt(0)
  stream.writeVInt(message.players.length)
  for (const player of message.players) {
    stream.writeStringReference(player.displayData.name)
    stream.writeBoolean(player.accountId === message.ownPlayer.accountId)
    stream.writeBoolean(player.teamIndex !== message.ownPlayer.teamIndex)
    stream.writeBoolean(false)
    writeDataReference(stream, player.characterId)
    writeDataReference(stream, player.skinId)
    stream.writeVInt(player.trophies)
  }
  stream.writeVInt(2)
  stream.writeVInt(0)
  stream.writeVInt(0)
  stream.writeVInt(8)
  stream.writeVInt(0)
  stream.writeVInt(0)
  stream.writeVInt(2)
  stream.writeVInt(1)
  stream.writeVInt(message.ownPlayer.trophies)
  stream.writeVInt(message.ownPlayer.highestTrophies)
  stream.writeVInt(5)
  stream.writeVInt(100)
  stream.writeVInt(100)
  stream.writeBoolean(true)
  milestones.encode(stream)
})

const VisionUpdateMessage = createMessage(24109, 'VisionUpdateMessage', (stream, message) => {
  stream.writeVInt(message.tick)
  stream.writeVInt(message.handledInputs)
  stream.writeVInt(1)
  stream.writeBytes(message.visionBytes)
})

const UdpConnectionInfoMessage = createMessage(24112, 'UdpConnectionInfoMessage', (stream, message) => {
  stream.writeVInt(message.serverPort)
  stream.writeString(message.serverAddress)
  stream.writeInt(10)
  writeLong(stream, message.sessionId)
  stream.writeShort(0)
  stream.writeInt(0)
})

module.exports = {
  BattleEndMessage,
  StartLoadingMessage,
  UdpConnectionInfoMessage,
  VisionUpdateMessage,
  encodeBattlePlayer
}
