const PiranhaMessage = require('../../../../../core/Protocol/PiranhaMessage')
const { readLong } = require('../../../../logic/home/StreamHelper')
const AuthenticationFailedMessage = require('../../server/auth/AuthenticationFailedMessage')
const AuthenticationOkMessage = require('../../server/auth/AuthenticationOkMessage')
const OwnHomeDataMessage = require('../../server/home/OwnHomeDataMessage')

class AuthenticationMessage extends PiranhaMessage {
  constructor (bytes, session) {
    super(session)
    this.id = 10101
    this.version = 0
    this.stream = this.DataStream.getByteStream(bytes)
    this.accountId = 0
    this.passToken = null
  }

  decode () {
    this.accountId = readLong(this.stream)
    this.passToken = this.stream.readString()
  }

  async execute () {
    let account
    if (this.accountId === 0) {
      account = await global.repositories.accounts.create()
    } else {
      account = await global.repositories.accounts.authenticate(this.accountId, this.passToken)
    }

    if (!account) {
      return new AuthenticationFailedMessage(
        this.session,
        1,
        'Your account not found.\nTry to clear app data.'
      ).send()
    }

    if (account.avatar.banned) {
      return new AuthenticationFailedMessage(this.session, 11).send()
    }

    account.home.lastVisitHomeTime = new Date()
    account.avatar.lastOnline = new Date()
    this.session.account = account
    if (!this.session.cleanupRegistered) {
      this.session.cleanupRegistered = true
      this.session.once('close', () => {
        if (global.matchmaking) global.matchmaking.cancel(this.session, false)
        if (this.session.skipAccountSave) return
        account.avatar.lastOnline = new Date()
        account.avatar.playerStatus = 0
        void global.repositories.accounts.save(account)
      })
    }
    await global.repositories.accounts.save(account)
    await new AuthenticationOkMessage(this.session, account).send()
    const resumed = global.messageRouter ? await global.messageRouter.resumeBattle(this.session) : false
    if (!resumed) {
      await new OwnHomeDataMessage(this.session, account).send()
      if (global.messageRouter) await global.messageRouter.onLogin(this.session)
    }
  }
}

module.exports = AuthenticationMessage
