const PiranhaMessage = require('../../../../../core/Protocol/PiranhaMessage')
const { writeLong } = require('../../../../logic/home/StreamHelper')

class AuthenticationOkMessage extends PiranhaMessage {
  constructor (session, account) {
    super(session)
    this.id = 20104
    this.version = 0
    this.account = account
  }

  encode () {
    writeLong(this.stream, this.account.accountId)
    writeLong(this.stream, this.account.accountId)
    this.stream.writeString(this.account.passToken)
    this.stream.writeString(null)
    this.stream.writeString(null)
    this.stream.writeInt(1)
    this.stream.writeInt(1714)
    this.stream.writeInt(0)
    this.stream.writeString('dev')
    this.stream.writeInt(0)
    this.stream.writeInt(0)
    this.stream.writeInt(0)
  }
}

module.exports = AuthenticationOkMessage
