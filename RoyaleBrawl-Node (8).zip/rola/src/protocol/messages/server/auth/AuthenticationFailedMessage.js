const PiranhaMessage = require('../../../../../core/Protocol/PiranhaMessage')

class AuthenticationFailedMessage extends PiranhaMessage {
  constructor (session, errorCode = 1, message = null) {
    super(session)
    this.id = 20103
    this.version = 0
    this.errorCode = errorCode
    this.message = message
    this.fingerprintSha = null
    this.updateUrl = null
  }

  encode () {
    this.stream.writeInt(this.errorCode)
    this.stream.writeString(this.fingerprintSha)
    this.stream.writeString(null)
    this.stream.writeString(null)
    this.stream.writeString(this.updateUrl)
    this.stream.writeString(this.message)
    this.stream.writeInt(-1)
    this.stream.writeBoolean(false)
    for (let i = 0; i < 9; i++) this.stream.writeInt(0)
  }
}

module.exports = AuthenticationFailedMessage
