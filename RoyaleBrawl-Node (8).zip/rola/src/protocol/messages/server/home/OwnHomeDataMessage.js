const PiranhaMessage = require('../../../../../core/Protocol/PiranhaMessage')
const eventService = require('../../../../logic/events/EventService')
const { encodeAvatar } = require('../../../../logic/home/AvatarEncoder')
const { encodeHome } = require('../../../../logic/home/HomeEncoder')

class OwnHomeDataMessage extends PiranhaMessage {
  constructor (session, account) {
    super(session)
    this.id = 24101
    this.version = 0
    this.account = account
  }

  encode () {
    encodeHome(this.stream, this.account, eventService.getEvents())
    encodeAvatar(this.stream, this.account.avatar)
    this.stream.writeVInt(1337)
  }
}

module.exports = OwnHomeDataMessage
