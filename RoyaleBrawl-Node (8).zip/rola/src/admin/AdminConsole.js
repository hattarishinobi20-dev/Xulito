const readline = require('node:readline')

class AdminConsole {
  constructor (database, matchmaking, battleService) {
    this.database = database
    this.matchmaking = matchmaking
    this.battleService = battleService
    this.interface = null
    this.resetting = false
  }

  start () {
    if (this.interface || !process.stdin.isTTY) return
    this.interface = readline.createInterface({ input: process.stdin, output: process.stdout })
    this.interface.setPrompt('> ')
    this.interface.on('line', input => void this.execute(input))
    this.interface.on('close', () => {
      this.interface = null
    })
    process.stdout.write('Admin commands: help, accounts, clearaccounts CONFIRM\n')
    this.interface.prompt()
  }

  async execute (input) {
    const [command = '', confirmation = ''] = input.trim().split(/\s+/)
    try {
      if (command === 'help') {
        process.stdout.write('accounts\nclearaccounts CONFIRM\n')
      } else if (command === 'accounts') {
        const count = await this.database.collection('accounts').countDocuments()
        process.stdout.write(`Saved accounts: ${count}\n`)
      } else if (command === 'clearaccounts' || command === 'limparcontas') {
        if (confirmation !== 'CONFIRM' && confirmation !== 'CONFIRMAR') {
          process.stdout.write('Use: clearaccounts CONFIRM\n')
        } else await this.clearAccounts()
      } else if (command) process.stdout.write(`Unknown command: ${command}\n`)
    } catch (error) {
      process.stderr.write(`Admin command failed: ${error.message}\n`)
    }
    if (this.interface) this.interface.prompt()
  }

  async clearAccounts () {
    if (this.resetting) return
    this.resetting = true
    this.matchmaking.close()
    this.battleService.close()
    try {
      for (const session of global.sessions?.values() || []) {
        session.skipAccountSave = true
        session.destroy()
      }
      if (global.sessions) global.sessions.clear()
      const collections = ['accounts', 'alliances', 'teams', 'counters']
      const results = await Promise.all(collections.map(name => this.database.collection(name).deleteMany({})))
      process.stdout.write(`Database cleared: ${results.map((result, index) => `${collections[index]}=${result.deletedCount}`).join(', ')}\n`)
      process.stdout.write('Clear the application data before logging in again.\n')
    } finally {
      this.battleService.start()
      this.matchmaking.start()
      this.resetting = false
    }
  }

  close () {
    if (this.interface) this.interface.close()
    this.interface = null
  }
}

module.exports = AdminConsole
