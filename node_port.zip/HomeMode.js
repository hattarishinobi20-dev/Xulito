'use strict';

const { ClientHome } = require('./ClientHome');
const { ClientAvatar } = require('./ClientAvatar');
const { EventData } = require('./EventData');

class HomeMode {
    static UNLOCKABLE_HEROES_COUNT = 38;

    constructor(home, avatar, gameListener) {
        this.GameListener = gameListener;
        this.Home = home;
        this.Avatar = avatar;
        this.CharacterChanged = null;

        home.HomeMode = this;
        avatar.HomeMode = this;
    }

    static LoadHomeState(gameListener, home, avatar, events) {
        home.Events = events;
        const homeMode = new HomeMode(home, avatar, gameListener);
        homeMode.Enter(new Date());
        return homeMode;
    }

    SimulateGatcha(unit) {
        // Simplified gatcha
    }

    Enter(dateTime) {
        this.Home.HomeVisited();
    }

    ClientTurnReceived(tick, checksum, commands) {
        for (const command of commands) {
            if (command.Execute(this) !== 0) {
                const { OutOfSyncMessage } = require('./AllMessages');
                this.GameListener.SendMessage(new OutOfSyncMessage());
            }
        }
        this.Home.Tick();
    }
}

module.exports = { HomeMode };
