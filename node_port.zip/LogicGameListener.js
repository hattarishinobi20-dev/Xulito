'use strict';

class LogicGameListener {
    constructor() {
        this.HandledInputs = 0;
    }
    SendMessage(message) { throw new Error('Abstract'); }
    SendTCPMessage(message) { throw new Error('Abstract'); }
}

module.exports = { LogicGameListener };
