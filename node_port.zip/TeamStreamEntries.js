'use strict';

class TeamStreamEntry {
    constructor() {
        this.Id = 0;
        this.AccountId = 0;
        this.Name = '';
    }

    Encode(encoder) {
        encoder.WriteVInt(this.GetStreamEntryType());
        encoder.WriteVLong(this.Id);
        encoder.WriteVLong(this.AccountId);
        encoder.WriteString(this.Name);
        encoder.WriteVInt(0);
        encoder.WriteVInt(0);
        encoder.WriteVInt(0);
    }

    GetStreamEntryType() { return 0; }
}

class ChatStreamEntry extends TeamStreamEntry {
    constructor() {
        super();
        this.Message = '';
    }

    Encode(encoder) {
        super.Encode(encoder);
        encoder.WriteString(this.Message);
    }

    GetStreamEntryType() { return 2; }
}

class TeamCreatedStreamEntry extends TeamStreamEntry {
    constructor() {
        super();
        this.TeamId = 0;
    }

    Encode(encoder) {
        super.Encode(encoder);
        encoder.WriteLong(this.TeamId);
        encoder.WriteVInt(0);
        encoder.WriteVInt(0);
        encoder.WriteVInt(0);
    }

    GetStreamEntryType() { return 77; }
}

class QuickChatStreamEntry extends TeamStreamEntry {
    constructor() {
        super();
        this.MessageDataId = 0;
        this.TargetId = -1;
        this.TargetPlayerName = '';
        this.Unknown1 = 0;
        this.Unknown2 = 0;
    }

    Encode(encoder) {
        super.Encode(encoder);
        const { ByteStreamHelper } = require('./ByteStreamHelper');
        ByteStreamHelper.WriteDataReference(encoder, this.MessageDataId);
        if (encoder.WriteBoolean(this.TargetId > 0)) {
            encoder.WriteLong(this.TargetId);
        }
        encoder.WriteString(this.TargetPlayerName);
        encoder.WriteVInt(this.Unknown1);
        encoder.WriteVInt(this.Unknown2);
    }

    GetStreamEntryType() { return 8; }
}

module.exports = { TeamStreamEntry, ChatStreamEntry, TeamCreatedStreamEntry, QuickChatStreamEntry };
