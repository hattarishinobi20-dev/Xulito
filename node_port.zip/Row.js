'use strict';

class Row {
    constructor(table) {
        this._table = table;
        this.RowStart = table.GetColumnRowCount();
        table.AddRow(this);
    }

    get Offset() {
        return this.RowStart;
    }

    LoadData(data) {
        // In Node.js, we use a property-based approach
        // The data object should have a _properties array listing its fields
        if (data._properties) {
            for (const prop of data._properties) {
                const value = this.GetValue(prop.name, 0);
                if (value !== '' && value !== undefined && value !== null) {
                    if (prop.type === 'int') {
                        data[prop.name] = parseInt(value) || 0;
                    } else if (prop.type === 'bool') {
                        data[prop.name] = value === 'true' || value === 'TRUE' || value === 'True';
                    } else {
                        data[prop.name] = value;
                    }
                }
            }
        }
    }

    GetArraySize(name) {
        const index = this._table.GetColumnIndexByName(name);
        return index !== -1 ? this._table.GetArraySizeAt(this, index) : 0;
    }

    GetName() {
        return this._table.GetValueAt(0, this.RowStart);
    }

    GetValue(name, level) {
        return this._table.GetValue(name, level + this.RowStart);
    }
}

module.exports = { Row };
