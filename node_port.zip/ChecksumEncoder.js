'use strict';

class ChecksumEncoder {
    constructor() {
        this._checksum = 0;
        this._snapshotChecksum = 0;
        this._enabled = true;
    }

    EnableCheckSum(enable) {
        if (!this._enabled || enable) {
            if (!this._enabled && enable) {
                this._checksum = this._snapshotChecksum;
            }
            this._enabled = enable;
        } else {
            this._snapshotChecksum = this._checksum;
            this._enabled = false;
        }
    }

    ResetCheckSum() {
        this._checksum = 0;
    }

    RotateRight(value, count) {
        value = value >>> 0; // ensure unsigned 32-bit
        return ((value >>> count) | (value << (32 - count))) >>> 0;
    }

    WriteBoolean(value) {
        this._checksum = ((value ? 13 : 7) + this.RotateRight(this._checksum, 31)) >>> 0;
        return value;
    }

    WriteByte(value) {
        this._checksum = (value + this.RotateRight(this._checksum, 31) + 11) >>> 0;
    }

    WriteShort(value) {
        this._checksum = (value + this.RotateRight(this._checksum, 31) + 19) >>> 0;
    }

    WriteInt(value) {
        this._checksum = (value + this.RotateRight(this._checksum, 31) + 9) >>> 0;
    }

    WriteVInt(value) {
        this._checksum = (value + this.RotateRight(this._checksum, 31) + 33) >>> 0;
    }

    WriteLong(value) {
        // LogicLong style
        if (value && typeof value === 'object' && value.Encode) {
            value.Encode(this);
        } else if (typeof value === 'bigint') {
            const high = Number(value >> 32n) | 0;
            const low = Number(value & 0xFFFFFFFFn) | 0;
            this.WriteInt(high);
            this.WriteInt(low);
        } else {
            const high = Math.floor(Number(value) / 0x100000000) | 0;
            const low = Number(value) | 0;
            this.WriteInt(high);
            this.WriteInt(low);
        }
    }

    WriteVLong(value) {
        if (typeof value === 'bigint') {
            const high = Number(value >> 32n) | 0;
            const low = Number(value & 0xFFFFFFFFn) | 0;
            this.WriteVInt(high);
            this.WriteVInt(low);
        } else {
            const high = Math.floor(Number(value) / 0x100000000) | 0;
            const low = Number(value) | 0;
            this.WriteVInt(high);
            this.WriteVInt(low);
        }
    }

    WriteBytes(value, length) {
        this._checksum = (((value !== null ? length + 28 : 27) + (this._checksum >>> 31)) | (this._checksum << (32 - 31))) >>> 0;
    }

    WriteString(value) {
        this._checksum = ((value !== null ? (value ? value.length : 0) + 28 : 27) + this.RotateRight(this._checksum, 31)) >>> 0;
    }

    WriteStringReference(value) {
        this._checksum = ((value ? value.length : 0) + this.RotateRight(this._checksum, 31) + 38) >>> 0;
    }

    HashCode() {
        return 42;
    }

    IsCheckSumEnabled() {
        return this._enabled;
    }

    IsCheckSumOnlyMode() {
        return true;
    }

    GetCheckSum() {
        return this._checksum | 0;
    }
}

module.exports = { ChecksumEncoder };
