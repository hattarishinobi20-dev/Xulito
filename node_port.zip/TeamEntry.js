'use strict';

const { LogicVector2 } = require('./LogicVector2');

class TeamMember {
    constructor() {
        this.IsOwner = false;
        this.AccountId = 0;
        this.CharacterId = 0;
        this.SkinId = 0;
        this.HeroTrophies = 0;
        this.HeroHighestTrophies = 0;
        this.HeroLevel = 0;
        this.State = 0;
        this.IsReady = false;
        this.DisplayData = null;
    }

    Encode(stream) {
        const { ByteStreamHelper } = require('./ByteStreamHelper');
        stream.WriteLong(this.AccountId);
        stream.WriteString(this.DisplayData ? this.DisplayData.Name : '');
        stream.WriteVInt(0);
        ByteStreamHelper.WriteDataReference(stream, this.CharacterId);
        ByteStreamHelper.WriteDataReference(stream, this.SkinId);
        stream.WriteVInt(this.HeroTrophies);
        stream.WriteVInt(this.HeroHighestTrophies);
        stream.WriteVInt(0);
        stream.WriteVInt(this.State);
        stream.WriteVInt(1);
        stream.WriteBoolean(this.IsReady);
        stream.WriteVInt(1);
    }
}

class TeamInviteEntry {
    constructor() {
        this.InviterId = 0;
        this.Id = 0;
        this.Name = '';
        this.Slot = 0;
    }

    Encode(stream) {
        stream.WriteLong(this.InviterId);
        stream.WriteLong(this.Id);
        stream.WriteString(this.Name);
        stream.WriteVInt(1);
        stream.WriteVInt(this.Slot);
    }
}

class TeamJoinRequest {
    Encode(stream) {
        throw new Error('Not implemented');
    }
}

class TeamEntry {
    constructor() {
        this.Id = 0;
        this.Type = 0;
        this.LocationId = 0;
        this.Members = [];
        this.Invites = [];
        this.JoinRequests = [];
        this.DisabledBots = [];
        this.EventSlot = 1;
        this.EntryCounter = 0;
        this.Stream = [];
    }

    AddStreamEntry(entry) {
        if (!entry) return;
        const { LogicServerListener } = require('./LogicServerListener');
        const { TeamStreamMessage } = require('./AllMessages');

        entry.Id = ++this.EntryCounter;
        this.Stream.push(entry);
        const message = new TeamStreamMessage();
        message.TeamId = this.Id;
        message.Entries = [entry];

        for (const member of this.Members) {
            if (LogicServerListener.Instance && LogicServerListener.Instance.IsPlayerOnline(member.AccountId)) {
                LogicServerListener.Instance.GetGameListener(member.AccountId).SendTCPMessage(message);
            }
        }
    }

    StreamUpdated() {}

    GetMember(id) {
        return this.Members.find(m => m.AccountId === id) || null;
    }

    GetInviteById(id) {
        return this.Invites.find(i => i.Id === id) || null;
    }

    IsEveryoneReady() {
        for (const member of this.Members) {
            if (!member.IsReady) return false;
        }
        return true;
    }

    TeamUpdated() {
        const { LogicServerListener } = require('./LogicServerListener');
        const { TeamMessage } = require('./AllMessages');

        const message = new TeamMessage();
        message.Team = this;

        for (const member of this.Members) {
            if (LogicServerListener.Instance && LogicServerListener.Instance.IsPlayerOnline(member.AccountId)) {
                LogicServerListener.Instance.GetGameListener(member.AccountId).SendTCPMessage(message);
            }
        }
    }

    Encode(stream) {
        const { ByteStreamHelper } = require('./ByteStreamHelper');
        stream.WriteVInt(this.Type);
        stream.WriteBoolean(this.Type === 1);
        stream.WriteVInt(3);
        stream.WriteLong(this.Id);
        stream.WriteVInt(0);
        stream.WriteVInt(0);
        stream.WriteVInt(0);
        ByteStreamHelper.WriteDataReference(stream, this.LocationId);
        stream.WriteVInt(this.Members.length);
        for (const entry of this.Members) {
            entry.Encode(stream);
        }
    }
}

module.exports = { TeamEntry, TeamMember, TeamInviteEntry, TeamJoinRequest };
