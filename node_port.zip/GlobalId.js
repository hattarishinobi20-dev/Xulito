'use strict';

class GlobalId {
    static CreateGlobalId(classId, instanceId) {
        return classId <= 0 ? 1000000 + instanceId : classId * 1000000 + instanceId;
    }

    static GetClassId(globalId) {
        return Math.floor(globalId / 1000000);
    }

    static GetInstanceId(globalId) {
        return globalId % 1000000;
    }
}

module.exports = { GlobalId };
