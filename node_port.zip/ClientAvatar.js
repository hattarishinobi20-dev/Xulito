'use strict';

const { ByteStreamHelper } = require('./ByteStreamHelper');
const { ChecksumEncoder } = require('./ChecksumEncoder');
const { GlobalId } = require('./GlobalId');
const { DataTables } = require('./DataTables');
const { DataType } = require('./DataTables');
const { Hero } = require('./Hero');

class ClientAvatar {
    constructor() {
        this.AccountId = 0;
        this.PassToken = '';
        this.Name = 'Brawler';
        this.NameSetByUser = false;
        this.Gold = 100;
        this.Diamonds = 0;
        this.Chips = 0;
        this.Elexir = 0;
        this.Heroes = [];
        this.IsDev = false;
        this.IsPremium = false;
        this.AllianceRole = 'None';
        this.AllianceId = -1;
        this.LastOnline = new Date();
        this.Friends = [];
        this.TutorialsCompletedCount = 0;
        this.PlayerStatus = 0;
        this.BattleId = -1;
        this.TeamIndex = 0;
        this.OwnIndex = 0;
        this.UdpSessionId = 0;
        this.TeamId = 0;
        this.HomeMode = null;
        this.Trophies = 0;
        this.HighestTrophies = 0;
    }

    get Trophies() {
        let total = 0;
        for (const hero of this.Heroes) {
            total += hero.Trophies;
        }
        return total;
    }

    set Trophies(v) { /* computed */ }

    get HighestTrophies() {
        let total = 0;
        for (const hero of this.Heroes) {
            total += hero.HighestTrophies;
        }
        return total;
    }

    set HighestTrophies(v) { /* computed */ }

    ResetTrophies() {
        for (const hero of this.Heroes) {
            hero.Trophies = 0;
            hero.HighestTrophies = 0;
        }
    }

    GetUnlockedHeroesCount() { return this.Heroes.length; }
    GetUnlockedHeroes() { return this.Heroes; }

    UnlockHero(characterId, cardId) {
        const heroEntry = new Hero(characterId, cardId);
        this.Heroes.push(heroEntry);
    }

    HasHero(characterId) {
        return this.Heroes.find(x => x.CharacterId === characterId) !== undefined;
    }

    GetHero(characterId) {
        return this.Heroes.find(x => x.CharacterId === characterId) || null;
    }

    UseDiamonds(count) { if (count > this.Diamonds) return false; this.Diamonds -= count; return true; }
    UseGold(count) { if (count > this.Gold) return false; this.Gold -= count; return true; }
    AddDiamonds(count) { this.Diamonds += count; }
    AddGold(count) { this.Gold += count; }
    UseChips(count) { if (count > this.Chips) return false; this.Chips -= count; return true; }
    AddChips(count) { /* this.HomeMode.Home.Chips += count; */ }
    UseElexir(count) { if (count > this.Elexir) return false; this.Elexir -= count; return true; }
    AddElexir(count) { this.Elexir += count; }

    SkipTutorial() { this.TutorialsCompletedCount = 2; }
    IsTutorialState() { return this.TutorialsCompletedCount < 2; }

    GetRequestFriendById(id) { return this.Friends.find(f => f.AccountId === id && f.FriendState !== 4) || null; }
    GetAcceptedFriendById(id) { return this.Friends.find(f => f.AccountId === id && f.FriendState === 4) || null; }
    GetFriendById(id) { return this.Friends.find(f => f.AccountId === id) || null; }

    Encode(Stream) {
        Stream.WriteVLong(this.AccountId);
        Stream.WriteVLong(this.AccountId);
        Stream.WriteVLong(this.AccountId);
        Stream.WriteString(this.Name);
        Stream.WriteBoolean(this.NameSetByUser);
        Stream.WriteInt(-1);
        Stream.WriteVInt(5);
        {
            Stream.WriteVInt(3 + this.Heroes.length);
            {
                ByteStreamHelper.WriteDataReference(Stream, 5000001);
                Stream.WriteVInt(this.Gold);
                ByteStreamHelper.WriteDataReference(Stream, 5000005);
                Stream.WriteVInt(this.Chips);
                ByteStreamHelper.WriteDataReference(Stream, 5000006);
                Stream.WriteVInt(this.Elexir);
                for (const hero of this.Heroes) {
                    ByteStreamHelper.WriteDataReference(Stream, hero.CardData);
                    Stream.WriteVInt(1);
                }
            }
            Stream.WriteVInt(this.Heroes.length);
            for (const hero of this.Heroes) {
                ByteStreamHelper.WriteDataReference(Stream, hero.CharacterData);
                Stream.WriteVInt(hero.Trophies);
            }
            Stream.WriteVInt(this.Heroes.length);
            for (const hero of this.Heroes) {
                ByteStreamHelper.WriteDataReference(Stream, hero.CharacterData);
                Stream.WriteVInt(hero.HighestTrophies);
            }
            Stream.WriteVInt(0);
            Stream.WriteVInt(0);
        }
        Stream.WriteVInt(this.Diamonds);
        Stream.WriteVInt(0); Stream.WriteVInt(0); Stream.WriteVInt(0); Stream.WriteVInt(0);
        Stream.WriteVInt(0); Stream.WriteVInt(0); Stream.WriteVInt(0); Stream.WriteVInt(0);
        Stream.WriteVInt(0);
        Stream.WriteVInt(this.TutorialsCompletedCount);
    }
}

module.exports = { ClientAvatar };
