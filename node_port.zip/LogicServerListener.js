'use strict';

class LogicServerListener {
    GetAvatar(id) { throw new Error('Abstract'); }
    GetGameListener(id) { throw new Error('Abstract'); }
    GetHomeMode(id) { throw new Error('Abstract'); }
    IsPlayerOnline(id) { throw new Error('Abstract'); }
}

LogicServerListener.Instance = null;

module.exports = { LogicServerListener };
