'use strict';

const LogicJSONNodeType = {
    ARRAY: 1,
    OBJECT: 2,
    NUMBER: 3,
    STRING: 4,
    BOOLEAN: 5,
    NULL: 6
};

class LogicJSONNode {
    GetJSONNodeType() { throw new Error('Abstract'); }
    WriteToString(builder) { throw new Error('Abstract'); }
}

class LogicJSONString extends LogicJSONNode {
    constructor(value) {
        super();
        this.m_value = value;
    }
    GetStringValue() { return this.m_value; }
    SetStringValue(value) { this.m_value = value; }
    GetJSONNodeType() { return LogicJSONNodeType.STRING; }
    WriteToString(builder) { builder.push(JSON.stringify(this.m_value)); }
}

class LogicJSONNumber extends LogicJSONNode {
    constructor(value) {
        super();
        this.m_value = value || 0;
    }
    GetIntValue() { return this.m_value; }
    SetIntValue(value) { this.m_value = value; }
    GetJSONNodeType() { return LogicJSONNodeType.NUMBER; }
    WriteToString(builder) { builder.push(String(this.m_value)); }
}

class LogicJSONBoolean extends LogicJSONNode {
    constructor(value) {
        super();
        this.m_value = value;
    }
    IsTrue() { return this.m_value; }
    GetJSONNodeType() { return LogicJSONNodeType.BOOLEAN; }
    WriteToString(builder) { builder.push(this.m_value ? 'true' : 'false'); }
}

class LogicJSONNull extends LogicJSONNode {
    GetJSONNodeType() { return LogicJSONNodeType.NULL; }
    WriteToString(builder) { builder.push('null'); }
}

class LogicJSONArray extends LogicJSONNode {
    constructor() {
        super();
        this.m_items = [];
    }

    Get(idx) { return this.m_items[idx]; }
    Add(item) { this.m_items.push(item); }

    GetJSONArray(index) {
        const node = this.m_items[index];
        if (node && node.GetJSONNodeType() === LogicJSONNodeType.ARRAY) return node;
        return null;
    }

    GetJSONBoolean(index) {
        const node = this.m_items[index];
        if (node && node.GetJSONNodeType() === LogicJSONNodeType.BOOLEAN) return node;
        return null;
    }

    GetJSONNumber(index) {
        const node = this.m_items[index];
        if (node && node.GetJSONNodeType() === LogicJSONNodeType.NUMBER) return node;
        return null;
    }

    GetJSONObject(index) {
        const node = this.m_items[index];
        if (node && node.GetJSONNodeType() === LogicJSONNodeType.OBJECT) return node;
        return null;
    }

    GetJSONString(index) {
        const node = this.m_items[index];
        if (node && node.GetJSONNodeType() === LogicJSONNodeType.STRING) return node;
        return null;
    }

    Size() { return this.m_items.length; }

    GetJSONNodeType() { return LogicJSONNodeType.ARRAY; }

    WriteToString(builder) {
        builder.push('[');
        for (let i = 0; i < this.m_items.length; i++) {
            if (i > 0) builder.push(',');
            this.m_items[i].WriteToString(builder);
        }
        builder.push(']');
    }
}

class LogicJSONObject extends LogicJSONNode {
    constructor() {
        super();
        this.m_keys = [];
        this.m_items = [];
    }

    GetJSONArray(key) {
        const idx = this.m_keys.indexOf(key);
        if (idx === -1) return null;
        const node = this.m_items[idx];
        if (node && node.GetJSONNodeType() === LogicJSONNodeType.ARRAY) return node;
        return null;
    }

    GetJSONBoolean(key) {
        const idx = this.m_keys.indexOf(key);
        if (idx === -1) return null;
        const node = this.m_items[idx];
        if (node && node.GetJSONNodeType() === LogicJSONNodeType.BOOLEAN) return node;
        return null;
    }

    GetJSONNumber(key) {
        const idx = this.m_keys.indexOf(key);
        if (idx === -1) return null;
        const node = this.m_items[idx];
        if (node && node.GetJSONNodeType() === LogicJSONNodeType.NUMBER) return node;
        return null;
    }

    GetJSONObject(key) {
        const idx = this.m_keys.indexOf(key);
        if (idx === -1) return null;
        const node = this.m_items[idx];
        if (node && node.GetJSONNodeType() === LogicJSONNodeType.OBJECT) return node;
        return null;
    }

    GetJSONString(key) {
        const idx = this.m_keys.indexOf(key);
        if (idx === -1) return null;
        const node = this.m_items[idx];
        if (node && node.GetJSONNodeType() === LogicJSONNodeType.STRING) return node;
        return null;
    }

    Put(key, item) {
        const idx = this.m_keys.indexOf(key);
        if (idx !== -1) {
            this.m_items[idx] = item;
        } else {
            this.m_items.push(item);
            this.m_keys.push(key);
        }
    }

    Remove(key) {
        const idx = this.m_keys.indexOf(key);
        if (idx !== -1) {
            this.m_keys.splice(idx, 1);
            this.m_items.splice(idx, 1);
        }
    }

    GetObjectCount() { return this.m_items.length; }

    GetJSONNodeType() { return LogicJSONNodeType.OBJECT; }

    WriteToString(builder) {
        builder.push('{');
        for (let i = 0; i < this.m_items.length; i++) {
            if (i > 0) builder.push(',');
            builder.push(JSON.stringify(this.m_keys[i]));
            builder.push(':');
            this.m_items[i].WriteToString(builder);
        }
        builder.push('}');
    }
}

class LogicJSONParser {
    static ParseObject(jsonString) {
        const parsed = JSON.parse(jsonString);
        return LogicJSONParser.ConvertToObject(parsed);
    }

    static ParseArray(jsonString) {
        const parsed = JSON.parse(jsonString);
        return LogicJSONParser.ConvertToArray(parsed);
    }

    static ConvertToObject(obj) {
        const result = new LogicJSONObject();
        for (const key of Object.keys(obj)) {
            result.Put(key, LogicJSONParser.ConvertValue(obj[key]));
        }
        return result;
    }

    static ConvertToArray(arr) {
        const result = new LogicJSONArray();
        for (const item of arr) {
            result.Add(LogicJSONParser.ConvertValue(item));
        }
        return result;
    }

    static ConvertValue(value) {
        if (value === null || value === undefined) return new LogicJSONNull();
        if (typeof value === 'boolean') return new LogicJSONBoolean(value);
        if (typeof value === 'number') return new LogicJSONNumber(value);
        if (typeof value === 'string') return new LogicJSONString(value);
        if (Array.isArray(value)) return LogicJSONParser.ConvertToArray(value);
        if (typeof value === 'object') return LogicJSONParser.ConvertToObject(value);
        return new LogicJSONNull();
    }

    static WriteString(value, builder) {
        builder.push(JSON.stringify(value));
    }
}

module.exports = {
    LogicJSONNodeType,
    LogicJSONNode,
    LogicJSONString,
    LogicJSONNumber,
    LogicJSONBoolean,
    LogicJSONNull,
    LogicJSONArray,
    LogicJSONObject,
    LogicJSONParser
};
