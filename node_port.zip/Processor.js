'use strict';

const { ByteStream } = require('./ByteStream');
const { MessageFactory } = require('./MessageFactory');
const { RC4Encrypter } = require('./RC4Encrypter');

class Processor {
    static IncomingQueue = [];
    static OutgoingQueue = [];
    static ReceiveTimer = null;
    static SendTimer = null;

    static Init() {
        Processor.IncomingQueue = [];
        Processor.OutgoingQueue = [];

        // Process incoming messages
        Processor.ReceiveTimer = setInterval(() => {
            while (Processor.IncomingQueue.length > 0) {
                const item = Processor.IncomingQueue.shift();
                try {
                    item.Connection.MessageManager.ReceiveMessage(item.Message);
                } catch (e) {}
            }
        }, 1);

        // Process outgoing messages
        Processor.SendTimer = setInterval(() => {
            while (Processor.OutgoingQueue.length > 0) {
                const item = Processor.OutgoingQueue.shift();
                item.Connection.Messaging.EncryptAndWrite(item.Message);
            }
        }, 1);
    }

    static Receive(connection, message) {
        if (!message) return false;
        if (Processor.IncomingQueue.length >= 1024) {
            console.log(`Processor: Incoming queue full. Message ${message.GetMessageType()} discarded.`);
            return false;
        }
        Processor.IncomingQueue.push({ Connection: connection, Message: message });
        return true;
    }

    static Send(connection, message) {
        if (!message) return;
        if (Processor.OutgoingQueue.length >= 1024) {
            console.log(`Processor: Outgoing queue full. Message ${message.GetMessageType()} discarded.`);
            return;
        }
        Processor.OutgoingQueue.push({ Connection: connection, Message: message });
    }
}

class Messaging {
    constructor(connection) {
        this.Connection = connection;
        this.RC4 = new RC4Encrypter();
        this.MessageFactory = MessageFactory.Instance;
    }

    Send(message) {
        Processor.Send(this.Connection, message);
    }

    EncryptAndWrite(message) {
        if (message.GetEncodingLength() === 0) message.Encode();

        const payload = Buffer.alloc(message.GetEncodingLength());
        message.GetMessageBytes().copy(payload, 0, 0, payload.length);

        const messageType = message.GetMessageType();
        const version = message.GetVersion();

        const encrypted = this.RC4.Encrypt(payload);
        const stream = Buffer.alloc(encrypted.length + 7);

        stream[0] = (messageType >> 8) & 0xFF;
        stream[1] = messageType & 0xFF;
        stream[2] = (encrypted.length >> 16) & 0xFF;
        stream[3] = (encrypted.length >> 8) & 0xFF;
        stream[4] = encrypted.length & 0xFF;
        stream[5] = (version >> 8) & 0xFF;
        stream[6] = version & 0xFF;

        encrypted.copy(stream, 7);
        this.Connection.Write(stream);
    }

    OnReceive() {
        const memory = this.Connection.Memory;
        if (memory.length < 7) return 0;

        const type = (memory[0] << 8) | memory[1];
        const length = (memory[2] << 16) | (memory[3] << 8) | memory[4];
        const version = (memory[5] << 8) | memory[6];

        if (memory.length < length + 7) return 0;

        const payload = Buffer.alloc(length);
        memory.copy(payload, 0, 7, 7 + length);

        if (this.ReadNewMessage(type, length, version, payload) !== 0) {
            return -1;
        }

        this.Connection.Memory = memory.slice(length + 7);

        if (this.Connection.Memory.length >= 7) this.OnReceive();
        return 0;
    }

    ReadNewMessage(type, length, version, payload) {
        const decrypted = this.RC4.Decrypt(payload);

        const message = this.MessageFactory.CreateMessageByType(type);
        if (message) {
            message.GetByteStream().SetByteArray(decrypted, decrypted.length);
            message.Decode();
            Processor.Receive(this.Connection, message);
        } else {
            console.log('Ignoring message of unknown type ' + type);
        }

        return 0;
    }
}

module.exports = { Processor, Messaging };
