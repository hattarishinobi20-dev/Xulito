'use strict';

const { GameMessage } = require('./GameMessage');
const {
    BattleEndMessage, ClientInputMessage, StartLoadingMessage, StartSpectateMessage, VisionUpdateMessage,
    GoHomeMessage, CancelMatchmakingMessage, MatchmakeRequestMessage, MatchMakingStatusMessage,
    MatchMakingCancelledMessage, PlayerStatusMessage, StopSpectateMessage, OutOfSyncMessage, OwnHomeDataMessage,
    ClientInfoMessage, UdpConnectionInfoMessage,
    TeamMessage, TeamCreateMessage, TeamLeaveMessage, TeamLeftMessage, TeamGameStartingMessage,
    TeamSetMemberReadyMessage, TeamSetEventMessage, TeamSetLocationMessage, TeamChangeMemberSettingsMessage,
    TeamMemberStatusMessage, TeamInviteMessage, TeamInvitationMessage, TeamInvitationResponseMessage,
    TeamChatMessage, TeamPremadeChatMessage, TeamStreamMessage
} = require('./AllMessages');

// Stub messages for types that are received but not fully implemented
class StubMessage extends GameMessage {
    constructor(type) { super(); this._type = type; }
    GetMessageType() { return this._type; }
    GetServiceNodeType() { return 0; }
}

class AuthenticationMessage extends StubMessage { constructor() { super(10101); this.AccountId = 0; this.PassToken = ''; } Decode() { this.AccountId = Number(this.Stream.ReadLong()); this.PassToken = this.Stream.ReadString(); } }
class ClientCapabilitiesMessage extends StubMessage { constructor() { super(10107); } }
class KeepAliveMessage extends StubMessage { constructor() { super(10108); } }
class ChangeAvatarNameMessage extends StubMessage { constructor() { super(10212); this.Name = ''; } Decode() { this.Name = this.Stream.ReadString(); } }
class AcceptFriendMessage extends StubMessage { constructor() { super(10501); } }
class AddFriendMessage extends StubMessage { constructor() { super(10502); } }
class AskForFriendListMessage extends StubMessage { constructor() { super(10504); } }
class RemoveFriendMessage extends StubMessage { constructor() { super(10506); } }
class EndClientTurnMessage extends StubMessage { constructor() { super(14102); } }
class GoHomeFromOfflinePractiseMessage extends StubMessage { constructor() { super(14109); } }
class GetPlayerProfileMessage extends StubMessage { constructor() { super(14113); } }
class ChronosEventSeenMessage extends StubMessage { constructor() { super(14166); } }
class CreateAllianceMessage extends StubMessage { constructor() { super(14301); } }
class AskForAllianceDataMessage extends StubMessage { constructor() { super(14302); } }
class AskForJoinableAllianceListMessage extends StubMessage { constructor() { super(14303); } }
class JoinAllianceMessage extends StubMessage { constructor() { super(14305); } }
class KickAllianceMemberMessage extends StubMessage { constructor() { super(14307); } }
class LeaveAllianceMessage extends StubMessage { constructor() { super(14308); } }
class ChatToAllianceStreamMessage extends StubMessage { constructor() { super(14315); } }
class ChangeAllianceSettingsMessage extends StubMessage { constructor() { super(14316); } }
class GetLeaderboardMessage extends StubMessage { constructor() { super(14403); } }
class AvatarNameCheckRequestMessage extends StubMessage { constructor() { super(14600); this.Name = ''; } Decode() { this.Name = this.Stream.ReadString(); } }
class KeepAliveServerMessage extends StubMessage { constructor() { super(20108); } }
class DisconnectedMessage extends StubMessage { constructor() { super(25892); this.Reason = 0; } Encode() { this.Stream.WriteInt(this.Reason); } }
class AuthenticationFailedMessage extends StubMessage { constructor() { super(20103); this.ErrorCode = 0; } Encode() { this.Stream.WriteVInt(this.ErrorCode); } }
class ShutdownStartedMessage extends StubMessage { constructor() { super(24115); } Encode() { this.Stream.WriteVInt(0); } }
class AvailableServerCommandMessage extends StubMessage { constructor() { super(24111); this.Command = null; } Encode() { if (this.Command) this.Command.Encode(this.Stream); } }
class FriendOnlineStatusEntryMessage extends StubMessage { constructor() { super(24555); this.AvatarId = 0; this.PlayerStatus = 0; } Encode() { this.Stream.WriteVLong(this.AvatarId); this.Stream.WriteVInt(this.PlayerStatus); } }

class MessageFactory {
    static Instance = null;

    constructor() {
        this.Definitions = new Map([
            [10101, AuthenticationMessage],
            [10107, ClientCapabilitiesMessage],
            [10108, KeepAliveMessage],
            [10177, ClientInfoMessage],
            [10212, ChangeAvatarNameMessage],
            [10501, AcceptFriendMessage],
            [10502, AddFriendMessage],
            [10504, AskForFriendListMessage],
            [10506, RemoveFriendMessage],
            [10555, ClientInputMessage],
            [14101, GoHomeMessage],
            [14102, EndClientTurnMessage],
            [14103, MatchmakeRequestMessage],
            [14104, StartSpectateMessage],
            [14106, CancelMatchmakingMessage],
            [14107, StopSpectateMessage],
            [14109, GoHomeFromOfflinePractiseMessage],
            [14113, GetPlayerProfileMessage],
            [14166, ChronosEventSeenMessage],
            [14301, CreateAllianceMessage],
            [14302, AskForAllianceDataMessage],
            [14303, AskForJoinableAllianceListMessage],
            [14305, JoinAllianceMessage],
            [14307, KickAllianceMemberMessage],
            [14308, LeaveAllianceMessage],
            [14315, ChatToAllianceStreamMessage],
            [14316, ChangeAllianceSettingsMessage],
            [14350, TeamCreateMessage],
            [14353, TeamLeaveMessage],
            [14354, TeamChangeMemberSettingsMessage],
            [14355, TeamSetMemberReadyMessage],
            [14359, TeamChatMessage],
            [14361, TeamMemberStatusMessage],
            [14362, TeamSetEventMessage],
            [14363, TeamSetLocationMessage],
            [14365, TeamInviteMessage],
            [14366, PlayerStatusMessage],
            [14369, TeamPremadeChatMessage],
            [14403, GetLeaderboardMessage],
            [14479, TeamInvitationResponseMessage],
            [14600, AvatarNameCheckRequestMessage]
        ]);
    }

    CreateMessageByType(type) {
        const Constructor = this.Definitions.get(type);
        if (Constructor) return new Constructor();
        return null;
    }
}

MessageFactory.Instance = new MessageFactory();

module.exports = {
    MessageFactory,
    AuthenticationMessage, ClientCapabilitiesMessage, KeepAliveMessage, KeepAliveServerMessage,
    ChangeAvatarNameMessage, AcceptFriendMessage, AddFriendMessage, AskForFriendListMessage, RemoveFriendMessage,
    EndClientTurnMessage, GoHomeFromOfflinePractiseMessage, GetPlayerProfileMessage,
    ChronosEventSeenMessage, CreateAllianceMessage, AskForAllianceDataMessage,
    AskForJoinableAllianceListMessage, JoinAllianceMessage, KickAllianceMemberMessage,
    LeaveAllianceMessage, ChatToAllianceStreamMessage, ChangeAllianceSettingsMessage,
    GetLeaderboardMessage, AvatarNameCheckRequestMessage,
    DisconnectedMessage, AuthenticationFailedMessage, ShutdownStartedMessage,
    AvailableServerCommandMessage, FriendOnlineStatusEntryMessage
};
