'use strict';

const { GameModeUtil } = require('./GameModeUtil');

class GamePlayUtil {
    static IsJumpCharge(chargeType) {
        const v1 = chargeType - 2;
        if (v1 >= 0 && v1 <= 9) return ((0x293 >> v1) & 1) !== 0;
        return false;
    }

    static GetPlayerCountWithGameModeVariation(gameMode) {
        switch (gameMode) {
            case 6: return 10;
            default: return 6;
        }
    }
}

module.exports = { GamePlayUtil };
