'use strict';

const { GlobalId } = require('./GlobalId');

class LogicData {
    constructor(row, dataTable) {
        this.Row = row;
        this.DataTable = dataTable;
        this._dataType = 0;
        this._id = 0;
    }

    LoadData(data, type, row, dataType) {
        // Get the DataType enum value from the class name
        const DataTypes = require('./DataTables.Types').DataTypes;
        const Types = require('./DataTables.Types').Types;
        
        const constructor = data.constructor;
        const dataTypeKey = Types.get(constructor);
        
        if (dataTypeKey !== undefined) {
            this._dataType = dataTypeKey;
        } else {
            this._dataType = dataType || 0;
        }
        
        this._id = GlobalId.CreateGlobalId(this._dataType, this.DataTable.Count);
        this.Row = row;
        row.LoadData(data);
    }

    GetDataType() {
        return this._dataType;
    }

    GetGlobalId() {
        return this._id;
    }

    GetInstanceId() {
        return GlobalId.GetInstanceId(this._id);
    }

    GetClassId() {
        return GlobalId.GetClassId(this._id);
    }

    GetName() {
        return this.Row.GetName();
    }
}

module.exports = { LogicData };
