'use strict';

const { GlobalId } = require('./GlobalId');

class ByteStreamHelper {
    static WriteDataReference(stream, dataOrGlobalId) {
        if (dataOrGlobalId === null || dataOrGlobalId === undefined) {
            stream.WriteVInt(0);
            return;
        }

        if (typeof dataOrGlobalId === 'number') {
            if (dataOrGlobalId <= 0) {
                stream.WriteVInt(0);
                return;
            }
            stream.WriteVInt(GlobalId.GetClassId(dataOrGlobalId));
            stream.WriteVInt(GlobalId.GetInstanceId(dataOrGlobalId));
            return;
        }

        if (typeof dataOrGlobalId === 'object' && dataOrGlobalId.GetClassId) {
            stream.WriteVInt(dataOrGlobalId.GetClassId());
            stream.WriteVInt(dataOrGlobalId.GetInstanceId());
            return;
        }

        // BitStream
        if (typeof dataOrGlobalId === 'number' && stream.WritePositiveInt) {
            stream.WritePositiveInt(GlobalId.GetClassId(dataOrGlobalId), 5);
            stream.WritePositiveInt(GlobalId.GetInstanceId(dataOrGlobalId), 8);
        }
    }

    static WriteObjectRunning(bitStream, globalId) {
        bitStream.WritePositiveInt(GlobalId.GetClassId(globalId), 5);
        bitStream.WritePositiveInt(GlobalId.GetInstanceId(globalId), 14);
    }

    static ReadDataReference(stream) {
        const classId = stream.ReadVInt();
        if (classId <= 0) return 0;
        const instanceId = stream.ReadVInt();
        return GlobalId.CreateGlobalId(classId, instanceId);
    }

    static WriteIntList(stream, list) {
        const array = Array.from(list);
        stream.WriteVInt(array.length);
        for (let i = 0; i < array.length; i++) {
            stream.WriteVInt(array[i]);
        }
    }
}

module.exports = { ByteStreamHelper };
