'use strict';

const { GameModeUtil } = require('./GameModeUtil');
const { GamePlayUtil } = require('./GamePlayUtil');
const { LogicRandom } = require('./LogicRandom');
const { LogicVector2 } = require('./LogicVector2');
const { ByteStreamHelper } = require('./ByteStreamHelper');
const { BattleEndMessage, VisionUpdateMessage } = require('./AllMessages');
const { BitStream } = require('./BitStream');

class GameObject {
    constructor(classId, instanceId) {
        this.DataId = classId * 1000000 + instanceId;
        this.Position = new LogicVector2();
        this.Z = 0;
        this.gameObjectManager = null;
    }
    Tick() {}
    Encode(bitStream, isOwnObject, visionTeam) {}
    ShouldDestruct() { return false; }
    GetObjectType() { return 0; }
    GetGlobalID() { return this.DataId; }
    GetX() { return this.Position.X; }
    GetY() { return this.Position.Y; }
    SetPosition(x, y, z) { this.Position.X = x; this.Position.Y = y; this.Z = z; }
    GetRadius() { return 100; }
    GetIndex() { return 0; }
}

class Character extends GameObject {
    static MAX_SKILL_HOLD_TICKS = 40;

    constructor(classId, instanceId) {
        super(classId, instanceId);
        this.m_index = 0;
        this.m_heroLevel = 0;
        this.m_isBot = false;
        this.m_hitpoints = 3000;
        this.m_maxHitpoints = 3000;
        this.m_immunity = null;
        this.m_skills = [];
        this.m_buffs = [];
        this.m_poison = null;
        this.m_moving = false;
        this.m_moveTarget = null;
        this.m_ticksAlive = 0;
    }

    get CharacterData() {
        const { DataTables } = require('./DataTables');
        return DataTables.Get(16).GetDataByGlobalId(this.DataId);
    }

    SetIndex(index) { this.m_index = index; }
    GetIndex() { return this.m_index; }
    SetHeroLevel(level) { this.m_heroLevel = level; }
    SetBot(isBot) { this.m_isBot = isBot; }
    SetImmunity(ticks, percent) {
        this.m_immunity = { m_ticks: ticks, m_immunityPercent: percent, Tick: function(a) { this.m_ticks -= a; return this.m_ticks < 1; } };
    }

    CauseDamage(source, damage, isPoison) {
        this.m_hitpoints -= damage;
        if (this.m_hitpoints <= 0) {
            this.m_hitpoints = 0;
            if (this.gameObjectManager) {
                this.gameObjectManager.GetBattle().PlayerDied(
                    this.gameObjectManager.GetBattle().GetPlayerWithObject(this.GetGlobalID())
                );
                this.gameObjectManager.RemoveGameObject(this);
            }
        }
    }

    GetHitpoints() { return this.m_hitpoints; }
    InterruptAllSkills() { for (const s of this.m_skills) s.Interrupt(); }
    BlockHealthRegen() {}
    GiveSpeedSlowerBuff(strength, duration) {}
    ApplyItem(item) {}

    Tick() {
        this.m_ticksAlive++;
    }

    Encode(bitStream, isOwnObject, visionTeam) {
        bitStream.WritePositiveInt(10, 4);
    }

    GetObjectType() { return 1; }
}

class Projectile extends GameObject {
    constructor(classId, instanceId) {
        super(classId, instanceId);
        this.m_source = null;
        this.m_damage = 0;
    }
    ShootProjectile(angle, source, damage, distance, isUlti) {
        this.m_source = source;
        this.m_damage = damage;
    }
    Tick() {}
    Encode(bitStream, isOwnObject, visionTeam) { bitStream.WritePositiveInt(10, 4); }
    GetObjectType() { return 2; }
}

class AreaEffect extends GameObject {
    constructor(classId, instanceId) {
        super(classId, instanceId);
        this.m_source = null;
        this.m_damage = 0;
        this.m_ticksElapsed = 0;
        this.m_alreadyDamagedList = [];
    }
    get EffectData() {
        const { DataTables } = require('./DataTables');
        return DataTables.Get(17).GetDataByGlobalId(this.DataId);
    }
    SetSource(source) { this.m_source = source; }
    SetDamage(damage) { this.m_damage = damage; }
    Tick() { this.m_ticksElapsed++; }
    Encode(bitStream, isOwnObject, visionTeam) { bitStream.WritePositiveInt(10, 4); }
    GetRadius() { const ed = this.EffectData; return ed ? ed.Radius : 100; }
    ShouldDestruct() { const ed = this.EffectData; return ed ? this.m_ticksElapsed >= ed.TimeMs / 50 : true; }
    GetObjectType() { return 3; }
}

class Item extends GameObject {
    constructor(classId, instanceId) {
        super(classId, instanceId);
        this.m_pickedUp = false;
        this.m_ticksGone = 0;
    }
    get ItemData() {
        const { DataTables } = require('./DataTables');
        return DataTables.Get(18).GetDataByGlobalId(this.DataId);
    }
    Tick() { this.m_ticksGone++; }
    PickUp(character) { this.m_pickedUp = true; }
    Encode(bitStream, isOwnObject, visionTeam) { bitStream.WritePositiveInt(10, 4); }
    GetObjectType() { return 4; }
}

class GameObjectManager {
    constructor(battle) {
        this.m_battle = battle;
        this.m_gameObjects = [];
    }
    GetBattle() { return this.m_battle; }
    AddGameObject(obj) { obj.gameObjectManager = this; this.m_gameObjects.push(obj); }
    RemoveGameObject(obj) { const idx = this.m_gameObjects.indexOf(obj); if (idx !== -1) this.m_gameObjects.splice(idx, 1); }
    GetGameObjects() { return this.m_gameObjects.slice(); }
    Tick() { for (const obj of this.m_gameObjects.slice()) { obj.Tick(); if (obj.ShouldDestruct()) this.RemoveGameObject(obj); } }
}

class TileMap {
    constructor(width, height, data) {
        this.Width = width;
        this.Height = height;
        this.Tiles = [];
        this.SpawnPoints = [];
        this.SpawnPointsTeam1 = [];
        this.SpawnPointsTeam2 = [];
        this.LootBoxes = [];

        for (let i = 0; i < height; i++) {
            this.Tiles[i] = [];
            for (let j = 0; j < width; j++) {
                const code = data[i * width + j] || '0';
                const x = TileMap.TileToLogic(j);
                const y = TileMap.TileToLogic(i);
                const tile = { Code: code, X: x, Y: y };
                this.Tiles[i][j] = tile;
                if (code === '1') { this.SpawnPoints.push(tile); this.SpawnPointsTeam1.push(tile); }
                else if (code === '2') { this.SpawnPoints.push(tile); this.SpawnPointsTeam2.push(tile); }
                else if (code === '4') { this.LootBoxes.push(tile); }
            }
        }
    }

    get LogicWidth() { return TileMap.TileToLogic(this.Width); }
    get LogicHeight() { return TileMap.TileToLogic(this.Height); }

    static LogicToTile(logicValue) { return Math.floor(logicValue / 300); }
    static TileToLogic(tile) { return 300 * tile + 150; }

    GetTile(x, y, isTile) {
        if (!isTile) { x = TileMap.LogicToTile(x); y = TileMap.LogicToTile(y); }
        if (x >= 0 && x < this.Width && y >= 0 && y < this.Height) return this.Tiles[y][x];
        return null;
    }
}

class BattleMode {
    constructor(locationId) {
        this.Id = 0;
        this.IsGameOver = false;
        this.m_locationId = locationId;
        this.m_gameModeVariation = GameModeUtil.GetGameModeVariation(this.Location.GameMode);
        this.m_playersCountWithGameModeVariation = GamePlayUtil.GetPlayerCountWithGameModeVariation(this.m_gameModeVariation);
        this.m_inputQueue = [];
        this.m_randomSeed = 0;
        this.m_random = new LogicRandom(this.m_randomSeed);
        this.m_players = [];
        this.m_playersBySessionId = new Map();
        this.m_playersByObjectGlobalId = new Map();
        this.m_deadPlayers = [];
        this.m_time = { Tick: 0, IncreaseTick() { this.Tick++; }, GetTick() { return this.Tick; }, Reset() { this.Tick = 0; } };
        this.m_tileMap = new TileMap(20, 20, '0'.repeat(400));
        this.m_playArea = { StartX: 0, StartY: 0, EndX: this.m_tileMap.LogicWidth, EndY: this.m_tileMap.LogicHeight };
        this.m_gameObjectManager = new GameObjectManager(this);
        this.m_ART_TEST = false;
        this.m_NORMAL_TICKS = 3600;
        this.m_SHOWDOWN_TICKS = 16000;
        this.m_spectators = new Map();
        this.m_winnerTeam = -1;
        this.m_playersAlive = 0;
        this.m_updateTimer = null;
        this.m_gemGrabCountdown = 0;
    }

    get Location() {
        const { DataTables } = require('./DataTables');
        const dt = DataTables.Get(15);
        return dt ? dt.GetDataByGlobalId(this.m_locationId) : { GameMode: 'CoinRush', AllowedMaps: '' };
    }

    GetGameModeVariation() { return this.m_gameModeVariation; }
    GetPlayersCountWithGameModeVariation() { return this.m_playersCountWithGameModeVariation; }
    GetTicksGone() { return this.m_time.GetTick(); }
    GetRandomInt(min, max) { return this.m_random.Rand(max - min) + min; }

    GetTeamPlayersCount(teamIndex) {
        let count = 0;
        for (const p of this.m_players) { if (p.TeamIndex === teamIndex) count++; }
        return count;
    }

    GetPlayers() { return this.m_players.slice(); }
    GetPlayerBySessionId(sessionId) { return this.m_playersBySessionId.get(sessionId) || null; }
    GetPlayerWithObject(globalId) { return this.m_playersByObjectGlobalId.get(globalId) || null; }

    AddPlayer(player, sessionId) {
        player.SessionId = sessionId;
        this.m_players.push(player);
        if (sessionId > 0) this.m_playersBySessionId.set(sessionId, player);
        if (player.Avatar) {
            player.Avatar.BattleId = this.Id;
            player.Avatar.TeamIndex = player.TeamIndex;
            player.Avatar.OwnIndex = player.PlayerIndex;
        }
    }

    AddGameObjects() {
        this.m_playersAlive = this.m_players.length;
        for (const player of this.m_players) {
            const character = new Character(16, player.CharacterId % 1000000);
            character.SetIndex(player.PlayerIndex + (16 * player.TeamIndex));
            character.SetHeroLevel(player.HeroPowerLevel);
            const spawnX = 1500 + (player.TeamIndex * 3000);
            const spawnY = 1500 + (player.PlayerIndex * 500);
            character.SetPosition(spawnX, spawnY, 0);
            character.SetBot(player.IsBot());
            player.SetSpawnPoint(spawnX, spawnY);
            player.OwnObjectId = character.GetGlobalID();
            this.m_gameObjectManager.AddGameObject(character);
            this.m_playersByObjectGlobalId.set(player.OwnObjectId, player);
        }
    }

    Start() {
        this.m_updateTimer = setInterval(() => this.ExecuteOneTick(), 1000 / 20);
    }

    ExecuteOneTick() {
        this.m_time.IncreaseTick();
        this.m_gameObjectManager.Tick();

        // Send vision updates
        for (const [sessionId, player] of this.m_playersBySessionId) {
            if (!player.GameListener) continue;
            const bitStream = new BitStream(256);
            // Encode game objects
            const objects = this.m_gameObjectManager.GetGameObjects();
            bitStream.WritePositiveInt(objects.length, 14);
            for (const obj of objects) {
                const isOwn = obj.GetGlobalID() === player.OwnObjectId;
                bitStream.WritePositiveInt(obj.GetObjectType(), 5);
                bitStream.WritePositiveInt(obj.GetGlobalID() % 1000000, 14);
                obj.Encode(bitStream, isOwn, player.TeamIndex);
            }

            const visionMsg = new VisionUpdateMessage();
            visionMsg.Tick = this.m_time.GetTick();
            visionMsg.HandledInputs = player.GameListener.HandledInputs;
            visionMsg.VisionBitStream = bitStream;
            player.GameListener.SendMessage(visionMsg);
        }

        // Check game over
        const ticks = this.m_time.GetTick();
        const maxTicks = this.m_gameModeVariation === 6 ? this.m_SHOWDOWN_TICKS : this.m_NORMAL_TICKS;
        if (ticks >= maxTicks) {
            this.IsGameOver = true;
            if (this.m_updateTimer) clearInterval(this.m_updateTimer);
        }
    }

    AddClientInput(input, sessionId) {
        const player = this.m_playersBySessionId.get(sessionId);
        if (!player) return;
        player.LastHandledInput++;
        if (player.GameListener) player.GameListener.HandledInputs++;

        const character = this.m_gameObjectManager.GetGameObjects().find(o => o.GetGlobalID() === player.OwnObjectId);
        if (!character) return;

        if (input.Type === 0) {
            // Move
            character.Position.X = input.X;
            character.Position.Y = input.Y;
        }
    }

    HandleSpectatorInput(input, sessionId) {}

    PlayerDied(player) {
        if (!player) return;
        if (this.m_gameModeVariation === 6) {
            const rank = this.m_playersAlive;
            this.m_playersAlive--;
            player.IsAlive = false;
            player.BattleRoyaleRank = rank;

            const message = new BattleEndMessage();
            message.GameMode = 5;
            message.IsPvP = true;
            message.Players = [player];
            message.OwnPlayer = player;
            message.Result = rank;
            const tokensReward = Math.floor(40 / rank);
            message.TokensReward = tokensReward;
            message.TrophiesReward = 0;

            if (player.Avatar) {
                player.Avatar.BattleId = -1;
                const hero = player.Avatar.GetHero(player.CharacterId);
                if (rank > 5) {
                    let trophiesReward = -(rank - 5);
                    if (hero && hero.Trophies < -trophiesReward) trophiesReward = -hero.Trophies;
                    message.TrophiesReward = trophiesReward;
                    if (hero) hero.AddTrophies(trophiesReward);
                } else {
                    const trophiesReward = (5 - rank) * 2;
                    message.TrophiesReward = trophiesReward;
                    if (hero) hero.AddTrophies(trophiesReward);
                }
            }

            if (player.GameListener) player.GameListener.SendTCPMessage(message);
        }
    }
}

module.exports = { BattleMode, GameObject, Character, Projectile, AreaEffect, Item, GameObjectManager, TileMap };
