'use strict';

const { ByteStream } = require('./ByteStream');

class GameMessage {
    constructor() {
        this.Stream = new ByteStream(10);
        this._version = 0;
    }

    Encode() {}
    Decode() {}

    GetMessageType() { throw new Error('Abstract'); }
    GetServiceNodeType() { throw new Error('Abstract'); }

    SetVersion(version) { this._version = version; }
    GetVersion() { return this._version; }
    GetByteStream() { return this.Stream; }
    GetMessageBytes() { return this.Stream.GetByteArray(); }
    GetEncodingLength() { return this.Stream.GetOffset(); }
}

module.exports = { GameMessage };
