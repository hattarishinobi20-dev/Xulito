'use strict';

class GameModeUtil {
    static PlayersCollectPowerCubes(variation) {
        const v1 = variation - 6;
        if (v1 >= 0 && v1 <= 8) return ((0x119 >> v1) & 1) !== 0;
        return false;
    }

    static GetBattleTicks(a1, LogicBattleModeServer) {
        if (LogicBattleModeServer.m_ART_TEST) return 99999999;
        return a1 !== 6 ? LogicBattleModeServer.m_NORMAL_TICKS : LogicBattleModeServer.m_SHOWDOWN_TICKS;
    }

    static GetRespawnSeconds(variation) {
        switch (variation) {
            case 0: case 2: return 3;
            case 3: return 1;
            default: return 5;
        }
    }

    static PlayersCollectBountyStars(variation) {
        return variation === 3;
    }

    static HasTwoTeams(variation) {
        return variation !== 6;
    }

    static GetGameModeVariation(mode) {
        switch (mode) {
            case 'CoinRush': return 0;
            case 'Campaign': console.log('[WARNING] Campaign only works on DEV BUILD'); return 1;
            case 'AttackDefend': return 2;
            case 'BountyHunter': return 3;
            case 'Artifact': return 4;
            case 'LaserBall': return 5;
            case 'BattleRoyale': return 6;
            default: console.error('Wrong game mode!'); return -1;
        }
    }
}

module.exports = { GameModeUtil };
