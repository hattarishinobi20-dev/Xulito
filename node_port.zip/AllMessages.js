'use strict';

const { GameMessage } = require('./GameMessage');
const { ByteStreamHelper } = require('./ByteStreamHelper');

// === Battle Messages ===

class BattleEndMessage extends GameMessage {
    constructor() { super(); this.milestones = null; this.HomeMode = null; this.Result = 0; this.TokensReward = 0; this.TrophiesReward = 0; this.Players = []; this.OwnPlayer = null; this.StarToken = false; this.GameMode = 0; this.IsPvP = false; }
    Encode() {
        this.Stream.WriteVInt(this.GameMode);
        this.Stream.WriteVInt(0);
        this.Stream.WriteVInt(this.TokensReward);
        this.Stream.WriteVInt(0);
        this.Stream.WriteVInt(0);
        this.Stream.WriteBoolean(false);
        this.Stream.WriteVInt(this.Result);
        this.Stream.WriteVInt(this.TrophiesReward);
        ByteStreamHelper.WriteDataReference(this.Stream, this.OwnPlayer.DisplayData.ThumbnailId);
        this.Stream.WriteBoolean(false);
        this.Stream.WriteBoolean(this.IsPvP);
        this.Stream.WriteVInt(50);
        this.Stream.WriteVInt(0);
        this.Stream.WriteVInt(0);
        this.Stream.WriteVInt(this.Players.length);
        for (const player of this.Players) {
            this.Stream.WriteStringReference(player.DisplayData.Name);
            this.Stream.WriteBoolean(player.AccountId === this.OwnPlayer.AccountId);
            this.Stream.WriteBoolean(player.TeamIndex !== this.OwnPlayer.TeamIndex);
            this.Stream.WriteBoolean(false);
            ByteStreamHelper.WriteDataReference(this.Stream, player.CharacterId);
            ByteStreamHelper.WriteDataReference(this.Stream, player.SkinId);
            this.Stream.WriteVInt(player.Trophies);
        }
        this.Stream.WriteVInt(2);
        this.Stream.WriteVInt(0); this.Stream.WriteVInt(0); this.Stream.WriteVInt(8); this.Stream.WriteVInt(0);
        this.Stream.WriteVInt(0);
        this.Stream.WriteVInt(2);
        this.Stream.WriteVInt(1); this.Stream.WriteVInt(this.OwnPlayer.Trophies); this.Stream.WriteVInt(this.OwnPlayer.HighestTrophies);
        this.Stream.WriteVInt(5); this.Stream.WriteVInt(100); this.Stream.WriteVInt(100);
        this.Stream.WriteBoolean(true);
        if (this.milestones) this.milestones.WriteMilestones(this.Stream);
    }
    GetMessageType() { return 23456; }
    GetServiceNodeType() { return 27; }
}

class ClientInputMessage extends GameMessage {
    constructor() { super(); this.Inputs = []; }
    Decode() {
        this.Stream.ReadVInt(); this.Stream.ReadVInt();
        const count = this.Stream.ReadVInt();
        for (let i = 0; i < count; i++) {
            const { ClientInput } = require('./ClientInput');
            const input = new ClientInput();
            input.Decode(this.Stream);
            this.Inputs.push(input);
        }
    }
    GetMessageType() { return 10555; }
    GetServiceNodeType() { return 27; }
}

class StartLoadingMessage extends GameMessage {
    constructor() { super(); this.Players = []; this.OwnIndex = 0; this.TeamIndex = 0; this.LocationId = 0; this.GameMode = 0; this.SpectateMode = 0; }
    Encode() {
        this.Stream.WriteInt(this.Players.length);
        this.Stream.WriteInt(this.OwnIndex);
        this.Stream.WriteInt(this.TeamIndex);
        this.Stream.WriteInt(this.Players.length);
        for (const player of this.Players) { player.Encode(this.Stream); }
        this.Stream.WriteInt(0);
        this.Stream.WriteVInt(this.GameMode);
        this.Stream.WriteVInt(1);
        this.Stream.WriteVInt(1);
        this.Stream.WriteBoolean(false);
        ByteStreamHelper.WriteDataReference(this.Stream, this.LocationId);
        this.Stream.WriteBoolean(false);
    }
    GetMessageType() { return 20559; }
    GetServiceNodeType() { return 4; }
}

class StartSpectateMessage extends GameMessage {
    constructor() { super(); this.AccountId = 0; }
    Decode() { this.AccountId = Number(this.Stream.ReadLong()); }
    GetMessageType() { return 14104; }
    GetServiceNodeType() { return 9; }
}

class VisionUpdateMessage extends GameMessage {
    constructor() { super(); this.Tick = 0; this.HandledInputs = 0; this.Viewers = 0; this.VisionBitStream = null; }
    Encode() {
        this.Stream.WriteVInt(this.Tick);
        this.Stream.WriteVInt(this.HandledInputs);
        this.Stream.WriteVInt(1);
        this.Stream.WriteBytes(this.VisionBitStream.GetByteArray(), this.VisionBitStream.GetLength());
    }
    GetMessageType() { return 24109; }
    GetServiceNodeType() { return 4; }
}

// === Home Messages ===

class GoHomeMessage extends GameMessage {
    GetMessageType() { return 14101; }
    GetServiceNodeType() { return 9; }
}

class CancelMatchmakingMessage extends GameMessage {
    GetMessageType() { return 14106; }
    GetServiceNodeType() { return 9; }
}

class MatchmakeRequestMessage extends GameMessage {
    constructor() { super(); this.CharacterInstanceId = 0; this.SelectedCard = 0; this.EventSlot = 0; }
    Decode() {
        this.Stream.ReadVInt();
        this.SelectedCard = ByteStreamHelper.ReadDataReference(this.Stream);
        this.EventSlot = this.Stream.ReadVInt();
        this.Stream.ReadVInt();
    }
    GetMessageType() { return 14103; }
    GetServiceNodeType() { return 9; }
}

class MatchMakingStatusMessage extends GameMessage {
    constructor() { super(); this.Seconds = 0; this.Found = 0; this.Max = 0; this.ShowTips = false; this.Status = false; }
    Encode() {
        this.Stream.WriteInt(this.Seconds);
        this.Stream.WriteInt(this.Found);
        for (let i = 0; i < this.Found; i++) {
            this.Stream.WriteString("dudka");
            this.Stream.WriteBoolean(this.Status);
            this.Stream.WriteLong(i);
        }
        this.Stream.WriteInt(this.Max);
    }
    GetMessageType() { return 20405; }
    GetServiceNodeType() { return 9; }
}

class MatchMakingCancelledMessage extends GameMessage {
    GetMessageType() { return 20406; }
    GetServiceNodeType() { return 9; }
}

class PlayerStatusMessage extends GameMessage {
    constructor() { super(); this.Status = 0; }
    Decode() { this.Status = this.Stream.ReadVInt(); }
    GetMessageType() { return 14366; }
    GetServiceNodeType() { return 9; }
}

class StopSpectateMessage extends GameMessage {
    GetMessageType() { return 14107; }
    GetServiceNodeType() { return 9; }
}

class OutOfSyncMessage extends GameMessage {
    Encode() { this.Stream.WriteVInt(0); this.Stream.WriteVInt(0); this.Stream.WriteVInt(0); }
    GetMessageType() { return 24104; }
    GetServiceNodeType() { return 9; }
}

class OwnHomeDataMessage extends GameMessage {
    constructor() { super(); this.Home = null; this.Avatar = null; }
    Encode() {
        try {
            this.Home.Encode(this.Stream);
            this.Avatar.Encode(this.Stream);
            this.Stream.WriteVInt(1337);
        } catch (e) { console.error(e); }
    }
    GetMessageType() { return 24101; }
    GetServiceNodeType() { return 9; }
}

// === UDP Messages ===

class ClientInfoMessage extends GameMessage {
    GetMessageType() { return 10177; }
    GetServiceNodeType() { return 27; }
}

class UdpConnectionInfoMessage extends GameMessage {
    constructor() { super(); this.ServerPort = 0; this.ServerAddress = ''; this.SessionId = 0; }
    Encode() {
        this.Stream.WriteVInt(this.ServerPort);
        this.Stream.WriteString(this.ServerAddress);
        this.Stream.WriteInt(10);
        this.Stream.WriteLong(this.SessionId);
        this.Stream.WriteShort(0);
        this.Stream.WriteInt(0);
    }
    GetMessageType() { return 24112; }
    GetServiceNodeType() { return 27; }
}

// === Team Messages ===

class TeamMessage extends GameMessage {
    constructor() { super(); this.Team = null; }
    Encode() { this.Team.Encode(this.Stream); }
    GetMessageType() { return 24124; }
    GetServiceNodeType() { return 9; }
}

class TeamCreateMessage extends GameMessage {
    constructor() { super(); this.EventSlot = 0; this.TeamType = 0; }
    Decode() { this.Stream.ReadVInt(); this.EventSlot = this.Stream.ReadVInt(); this.TeamType = this.Stream.ReadVInt(); }
    GetMessageType() { return 14350; }
    GetServiceNodeType() { return 9; }
}

class TeamLeaveMessage extends GameMessage {
    GetMessageType() { return 14353; }
    GetServiceNodeType() { return 9; }
}

class TeamLeftMessage extends GameMessage {
    constructor() { super(); this.Reason = 0; }
    Encode() { this.Stream.WriteInt(this.Reason); }
    GetMessageType() { return 24125; }
    GetServiceNodeType() { return 9; }
}

class TeamGameStartingMessage extends GameMessage {
    constructor() { super(); this.Slot = 0; this.LocationId = 0; }
    Encode() { this.Stream.WriteVInt(0); this.Stream.WriteVInt(0); ByteStreamHelper.WriteDataReference(this.Stream, this.LocationId); }
    GetMessageType() { return 24130; }
    GetServiceNodeType() { return 9; }
}

class TeamSetMemberReadyMessage extends GameMessage {
    constructor() { super(); this.IsReady = false; }
    Decode() { this.IsReady = this.Stream.ReadBoolean(); }
    GetMessageType() { return 14355; }
    GetServiceNodeType() { return 9; }
}

class TeamSetEventMessage extends GameMessage {
    constructor() { super(); this.EventSlot = 0; }
    Decode() { this.Stream.ReadVInt(); this.EventSlot = this.Stream.ReadVInt(); }
    GetMessageType() { return 14362; }
    GetServiceNodeType() { return 9; }
}

class TeamSetLocationMessage extends GameMessage {
    GetMessageType() { return 14363; }
    GetServiceNodeType() { return 9; }
}

class TeamChangeMemberSettingsMessage extends GameMessage {
    constructor() { super(); this.CharacterId = 0; this.SkinId = 0; }
    Decode() { this.Stream.ReadVInt(); this.CharacterId = ByteStreamHelper.ReadDataReference(this.Stream); }
    GetMessageType() { return 14354; }
    GetServiceNodeType() { return 9; }
}

class TeamMemberStatusMessage extends GameMessage {
    constructor() { super(); this.Status = 0; }
    Decode() { this.Status = this.Stream.ReadVInt(); }
    GetMessageType() { return 14361; }
    GetServiceNodeType() { return 9; }
}

class TeamInviteMessage extends GameMessage {
    constructor() { super(); this.AvatarId = 0; this.Team = 0; }
    Decode() { this.AvatarId = Number(this.Stream.ReadVLong()); this.Team = this.Stream.ReadVInt(); }
    GetMessageType() { return 14365; }
    GetServiceNodeType() { return 9; }
}

class TeamInvitationMessage extends GameMessage {
    constructor() { super(); this.Unknown = 0; this.TeamId = 0; this.FriendEntry = null; }
    Encode() { this.Stream.WriteVInt(this.Unknown); this.Stream.WriteLong(this.TeamId); if (this.FriendEntry) this.FriendEntry.Encode(this.Stream); }
    GetMessageType() { return 24589; }
    GetServiceNodeType() { return 9; }
}

class TeamInvitationResponseMessage extends GameMessage {
    constructor() { super(); this.Response = 0; this.TeamId = 0; this.MutePlayer = false; }
    Decode() { this.Response = this.Stream.ReadVInt(); this.TeamId = Number(this.Stream.ReadLong()); this.MutePlayer = this.Stream.ReadBoolean(); }
    GetMessageType() { return 14479; }
    GetServiceNodeType() { return 9; }
}

class TeamChatMessage extends GameMessage {
    constructor() { super(); this.Message = ''; }
    Decode() { this.Message = this.Stream.ReadString(); }
    GetMessageType() { return 14359; }
    GetServiceNodeType() { return 9; }
}

class TeamPremadeChatMessage extends GameMessage {
    constructor() { super(); this.MessageDataId = 0; this.TargetId = -1; this.Unknown1 = 0; this.Unknown2 = 0; }
    Decode() {
        this.MessageDataId = ByteStreamHelper.ReadDataReference(this.Stream);
        const v2 = this.Stream.ReadBoolean();
        if (v2) this.TargetId = Number(this.Stream.ReadLong());
        this.Unknown1 = this.Stream.ReadVInt();
        this.Unknown2 = this.Stream.ReadVInt();
        if (!this.Stream.IsAtEnd()) this.Stream.ReadVInt();
    }
    GetMessageType() { return 14369; }
    GetServiceNodeType() { return 9; }
}

class TeamStreamMessage extends GameMessage {
    constructor() { super(); this.TeamId = 0; this.Entries = []; }
    Encode() {
        this.Stream.WriteVLong(this.TeamId);
        this.Stream.WriteVInt(this.Entries.length);
        for (const entry of this.Entries) { entry.Encode(this.Stream); }
    }
    GetMessageType() { return 24131; }
    GetServiceNodeType() { return 9; }
}

module.exports = {
    BattleEndMessage, ClientInputMessage, StartLoadingMessage, StartSpectateMessage, VisionUpdateMessage,
    GoHomeMessage, CancelMatchmakingMessage, MatchmakeRequestMessage, MatchMakingStatusMessage,
    MatchMakingCancelledMessage, PlayerStatusMessage, StopSpectateMessage, OutOfSyncMessage, OwnHomeDataMessage,
    ClientInfoMessage, UdpConnectionInfoMessage,
    TeamMessage, TeamCreateMessage, TeamLeaveMessage, TeamLeftMessage, TeamGameStartingMessage,
    TeamSetMemberReadyMessage, TeamSetEventMessage, TeamSetLocationMessage, TeamChangeMemberSettingsMessage,
    TeamMemberStatusMessage, TeamInviteMessage, TeamInvitationMessage, TeamInvitationResponseMessage,
    TeamChatMessage, TeamPremadeChatMessage, TeamStreamMessage
};
