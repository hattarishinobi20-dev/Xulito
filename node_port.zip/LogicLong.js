'use strict';

class LogicLong {
    constructor(highInteger, lowInteger) {
        this.m_highInteger = highInteger || 0;
        this.m_lowInteger = lowInteger || 0;
    }

    static ToLong(highValue, lowValue) {
        return ((highValue << 32) | (lowValue >>> 0));
    }

    Clone() {
        return new LogicLong(this.m_highInteger, this.m_lowInteger);
    }

    IsZero() {
        return this.m_highInteger === 0 && this.m_lowInteger === 0;
    }

    GetHigherInt() {
        return this.m_highInteger;
    }

    GetLowerInt() {
        return this.m_lowInteger;
    }

    Decode(stream) {
        this.m_highInteger = stream.ReadInt();
        this.m_lowInteger = stream.ReadInt();
    }

    Encode(stream) {
        if (stream.WriteInt) {
            stream.WriteInt(this.m_highInteger);
            stream.WriteInt(this.m_lowInteger);
        } else {
            stream.WriteInt(this.m_highInteger);
            stream.WriteInt(this.m_lowInteger);
        }
    }

    HashCode() {
        return this.m_lowInteger + 31 * this.m_highInteger;
    }

    toString() {
        return `LogicLong(${this.m_highInteger}-${this.m_lowInteger})`;
    }

    static FromNumber(value) {
        return new LogicLong(Math.floor(value / 0x100000000) | 0, value | 0);
    }

    toNumber() {
        return ((this.m_highInteger * 0x100000000) + (this.m_lowInteger >>> 0));
    }
}

module.exports = { LogicLong };
