'use strict';

const net = require('net');
const { Connection } = require('./Connection');
const { Messaging } = require('./Processor');
const { MessageManager } = require('./MessageManager');
const { Sessions } = require('./Sessions');

class TCPGateway {
    static ActiveConnections = [];
    static Socket = null;

    static Init(host, port) {
        TCPGateway.ActiveConnections = [];

        TCPGateway.Socket = net.createServer((clientSocket) => {
            console.log('Accepting connection...');
            const connection = new Connection(clientSocket);
            connection.Messaging = new Messaging(connection);
            connection.MessageManager = new MessageManager(connection);
            TCPGateway.ActiveConnections.push(connection);
            console.log('New connection!');

            clientSocket.on('data', (data) => {
                try {
                    connection.Memory = Buffer.concat([connection.Memory, data]);
                    if (connection.Messaging.OnReceive() !== 0) {
                        TCPGateway.RemoveConnection(connection);
                        connection.Close();
                        console.log('client disconnected.');
                    }
                } catch (e) {
                    TCPGateway.RemoveConnection(connection);
                    connection.Close();
                    console.log('client disconnected.');
                }
            });

            clientSocket.on('close', () => {
                console.log('client disconnected.');
                TCPGateway.RemoveConnection(connection);
                connection.Close();
            });

            clientSocket.on('error', (err) => {
                TCPGateway.RemoveConnection(connection);
                connection.Close();
                console.log('client disconnected.');
            });
        });

        TCPGateway.Socket.listen(100);
        TCPGateway.Socket.on('error', (err) => {
            console.error('TCP Server error:', err);
        });

        TCPGateway.Socket.listen(port, host, () => {
            console.log(`TCP Server started at ${host}:${port}`);
        });
    }

    static RemoveConnection(connection) {
        const idx = TCPGateway.ActiveConnections.indexOf(connection);
        if (idx !== -1) TCPGateway.ActiveConnections.splice(idx, 1);
        if (connection.MessageManager && connection.MessageManager.HomeMode) {
            Sessions.Remove(connection.Avatar.AccountId);
        }
    }

    static OnSend(socket, data) {
        try {
            socket.write(data);
        } catch (e) {}
    }
}

module.exports = { TCPGateway };
