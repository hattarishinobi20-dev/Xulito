'use strict';

const { OwnHomeDataMessage } = require('./AllMessages');
const { UdpConnectionInfoMessage } = require('./AllMessages');
const { KeepAliveServerMessage } = require('./MessageFactory');
const { HomeMode } = require('./HomeMode');
const { HomeGameListener } = require('./HomeGameListener');
const { Sessions } = require('./Sessions');
const { Events } = require('./Events');
const { Matchmaking } = require('./Matchmaking');
const { Teams } = require('./Teams');
const { TeamMember } = require('./TeamEntry');
const { PlayerDisplayData } = require('./PlayerDisplayData');
const { GameModeUtil } = require('./GameModeUtil');
const { GamePlayUtil } = require('./GamePlayUtil');
const { LogicServerListener } = require('./LogicServerListener');

class MessageManager {
    constructor(connection) {
        this.Connection = connection;
        this.HomeMode = null;
        this.LastKeepAlive = new Date();
    }

    IsAlive() {
        return Math.floor((new Date() - this.LastKeepAlive) / 1000) < 30;
    }

    ReceiveMessage(message) {
        const type = message.GetMessageType();
        switch (type) {
            case 10101: this.LoginReceived(message); break;
            case 10108:
                this.LastKeepAlive = new Date();
                this.Connection.Send(new KeepAliveServerMessage());
                break;
            case 10177: this.ClientInfoReceived(message); break;
            case 14101: this.GoHomeReceived(message); break;
            case 14103: this.MatchmakeRequestReceived(message); break;
            case 14106: this.CancelMatchMaking(message); break;
            case 14350: this.TeamCreateReceived(message); break;
            case 14353: this.TeamLeaveReceived(message); break;
            case 14354: this.TeamChangeMemberSettingsReceived(message); break;
            case 14355: this.TeamSetMemberReadyReceived(message); break;
            case 14359: this.TeamChatReceived(message); break;
            case 14362: this.TeamSetEventReceived(message); break;
            case 14366: this.PlayerStatusReceived(message); break;
            default:
                console.log(`MessageManager::ReceiveMessage - no case for type ${type}`);
                break;
        }
    }

    LoginReceived(message) {
        const { Accounts } = require('./Accounts');
        (async () => {
            let account;
            if (message.AccountId > 0) {
                account = await Accounts.Load(message.AccountId);
            }
            if (!account) {
                account = await Accounts.Create();
            }

            const gameListener = new HomeGameListener(this.Connection);
            this.HomeMode = HomeMode.LoadHomeState(gameListener, account.Home, account.Avatar, Events.GetEvents());
            Sessions.Create(this.HomeMode, this.Connection);

            const ohd = new OwnHomeDataMessage();
            ohd.Home = account.Home;
            ohd.Avatar = account.Avatar;
            this.Connection.Send(ohd);
        })().catch(e => console.error('Login error:', e));
    }

    ClientInfoReceived(message) {
        const { UDPGateway } = require('./UDPGateway');
        const socket = UDPGateway.CreateSocket();
        socket.TCPConnection = this.Connection;
        this.Connection.UdpSessionId = socket.SessionId;

        const info = new UdpConnectionInfoMessage();
        info.ServerPort = 9449;
        info.ServerAddress = '0.0.0.0'; // Will be set from config
        info.SessionId = socket.SessionId;
        this.Connection.Send(info);
    }

    GoHomeReceived(message) {
        const ohd = new OwnHomeDataMessage();
        ohd.Home = this.HomeMode.Home;
        ohd.Avatar = this.HomeMode.Avatar;
        this.Connection.Send(ohd);
    }

    MatchmakeRequestReceived(message) {
        const { CharacterId } = this.HomeMode.Home;
        this.HomeMode.Home.CharacterId = CharacterId;
        Matchmaking.RequestMatchmake(this.Connection, message.EventSlot);
    }

    CancelMatchMaking(message) {
        Matchmaking.CancelMatchmake(this.Connection);
    }

    TeamCreateReceived(message) {
        const team = Teams.Create();
        team.Type = message.TeamType;
        team.EventSlot = message.EventSlot;
        const event = Events.GetEvent(message.EventSlot);
        if (event) team.LocationId = event.LocationId;

        const member = new TeamMember();
        member.IsOwner = true;
        member.AccountId = this.HomeMode.Avatar.AccountId;
        member.CharacterId = this.HomeMode.Home.CharacterId;
        member.SkinId = 0;
        member.DisplayData = new PlayerDisplayData(this.HomeMode.Home.ThumbnailId, this.HomeMode.Avatar.Name);
        const hero = this.HomeMode.Avatar.GetHero(this.HomeMode.Home.CharacterId);
        if (hero) {
            member.HeroTrophies = hero.Trophies;
            member.HeroHighestTrophies = hero.HighestTrophies;
        }
        team.Members.push(member);
        this.HomeMode.Avatar.TeamId = team.Id;
        team.TeamUpdated();
    }

    TeamLeaveReceived(message) {
        if (this.HomeMode.Avatar.TeamId <= 0) return;
        const team = Teams.Get(this.HomeMode.Avatar.TeamId);
        if (!team) return;

        const idx = team.Members.findIndex(m => m.AccountId === this.HomeMode.Avatar.AccountId);
        if (idx !== -1) team.Members.splice(idx, 1);

        this.HomeMode.Avatar.TeamId = 0;

        const { TeamLeftMessage } = require('./AllMessages');
        const left = new TeamLeftMessage();
        left.Reason = 0;
        this.Connection.Send(left);

        if (team.Members.length === 0) {
            Teams.Remove(team.Id);
        } else {
            team.TeamUpdated();
        }
    }

    TeamChangeMemberSettingsReceived(message) {
        if (this.HomeMode.Avatar.TeamId <= 0) return;
        const team = Teams.Get(this.HomeMode.Avatar.TeamId);
        if (!team) return;
        const member = team.GetMember(this.HomeMode.Avatar.AccountId);
        if (!member) return;

        member.CharacterId = message.CharacterId;
        this.HomeMode.Home.CharacterId = message.CharacterId;
        const hero = this.HomeMode.Avatar.GetHero(message.CharacterId);
        if (hero) {
            member.HeroTrophies = hero.Trophies;
            member.HeroHighestTrophies = hero.HighestTrophies;
        }
        member.IsReady = false;
        team.TeamUpdated();
    }

    TeamSetMemberReadyReceived(message) {
        if (this.HomeMode.Avatar.TeamId <= 0) return;
        const team = Teams.Get(this.HomeMode.Avatar.TeamId);
        if (!team) return;
        const member = team.GetMember(this.HomeMode.Avatar.AccountId);
        if (!member) return;
        member.IsReady = message.IsReady;
        team.TeamUpdated();
        if (team.IsEveryoneReady()) {
            Teams.StartGame(team);
        }
    }

    TeamSetEventReceived(message) {
        if (this.HomeMode.Avatar.TeamId <= 0) return;
        const team = Teams.Get(this.HomeMode.Avatar.TeamId);
        if (!team) return;
        team.EventSlot = message.EventSlot;
        const event = Events.GetEvent(message.EventSlot);
        if (event) team.LocationId = event.LocationId;
        for (const m of team.Members) m.IsReady = false;
        team.TeamUpdated();
    }

    TeamChatReceived(message) {
        if (this.HomeMode.Avatar.TeamId <= 0) return;
        const team = Teams.Get(this.HomeMode.Avatar.TeamId);
        if (!team) return;
        const { ChatStreamEntry } = require('./TeamStreamEntries');
        const entry = new ChatStreamEntry();
        entry.AccountId = this.HomeMode.Avatar.AccountId;
        entry.Name = this.HomeMode.Avatar.Name;
        entry.Message = message.Message;
        team.AddStreamEntry(entry);
    }

    PlayerStatusReceived(message) {
        this.HomeMode.Avatar.PlayerStatus = message.Status;
    }
}

module.exports = { MessageManager };
