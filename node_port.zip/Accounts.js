'use strict';

const mysql = require('mysql2/promise');
const { Account } = require('./Account');
const { AccountCache } = require('./AccountCache');
const { Hero } = require('./Hero');
const { StringUtil } = require('./StringUtil');

class Accounts {
    static AvatarIdCounter = 0;
    static ConnectionString = null;
    static pool = null;

    static async Init(user, password, databaseName) {
        Accounts.pool = mysql.createPool({
            host: '127.0.0.1',
            user: user,
            password: password,
            database: databaseName,
            charset: 'utf8mb4',
            waitForConnections: true,
            connectionLimit: 10
        });

        AccountCache.Init();
        Accounts.AvatarIdCounter = await Accounts.GetMaxAvatarId();
    }

    static async GetMaxAvatarId() {
        try {
            const [rows] = await Accounts.pool.query('SELECT COALESCE(MAX(Id), 0) as maxId FROM accounts');
            return parseInt(rows[0].maxId) || 0;
        } catch (e) {
            console.error('GetMaxAvatarId error:', e.message);
            return 0;
        }
    }

    static async Create() {
        const account = new Account();
        account.AccountId = ++Accounts.AvatarIdCounter;
        account.PassToken = StringUtil.RandomString(40);
        account.Avatar.AccountId = account.AccountId;
        account.Avatar.PassToken = account.PassToken;
        account.Home.HomeId = account.AccountId;

        const hero = new Hero(16000000, 23000000);
        account.Avatar.Heroes.push(hero);

        const json = JSON.stringify(account);

        try {
            await Accounts.pool.query(
                'INSERT INTO accounts (Id, Trophies, Data) VALUES (?, ?, ?)',
                [account.AccountId, account.Avatar.Trophies, json]
            );
        } catch (e) {
            console.error('Create account error:', e.message);
        }

        AccountCache.Cache(account);
        return account;
    }

    static async Save(account) {
        if (!account) return;
        const json = JSON.stringify(account);
        try {
            await Accounts.pool.query(
                'UPDATE accounts SET Trophies = ?, Data = ? WHERE Id = ?',
                [account.Avatar.Trophies, json, account.AccountId]
            );
        } catch (e) {
            console.error('Save account error:', e.message);
        }
    }

    static async Load(id) {
        if (AccountCache.IsAccountCached(id)) {
            return AccountCache.GetAccount(id);
        }

        try {
            const [rows] = await Accounts.pool.query('SELECT * FROM accounts WHERE Id = ?', [id]);
            if (rows.length > 0) {
                const account = JSON.parse(rows[0].Data);
                AccountCache.Cache(account);
                return account;
            }
        } catch (e) {
            console.error('Load account error:', e.message);
        }
        return null;
    }

    static async GetRankingList() {
        const list = [];
        try {
            const [rows] = await Accounts.pool.query('SELECT * FROM accounts ORDER BY Trophies DESC LIMIT 200');
            for (const row of rows) {
                list.push(JSON.parse(row.Data));
            }
        } catch (e) {
            console.error('GetRankingList error:', e.message);
        }
        return list;
    }
}

module.exports = { Accounts };
