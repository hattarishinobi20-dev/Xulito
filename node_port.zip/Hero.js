'use strict';

const { ByteStreamHelper } = require('./ByteStreamHelper');
const { DataTables } = require('./DataTables');
const { DataType } = require('./DataTables');
const { GlobalId } = require('./GlobalId');

class Hero {
    constructor(characterId, cardId) {
        this.CharacterId = characterId;
        this.CardId = cardId;
        this.Trophies = 0;
        this.HighestTrophies = 0;
        this.Upgrades = [];
    }

    get CharacterData() {
        const dt = DataTables.Get(DataType.Character);
        return dt ? dt.GetDataByGlobalId(this.CharacterId) : null;
    }

    get CardData() {
        const dt = DataTables.Get(DataType.Card);
        return dt ? dt.GetDataByGlobalId(this.CardId) : null;
    }

    AddTrophies(trophies) {
        this.Trophies += trophies;
        if (this.Trophies > this.HighestTrophies) this.HighestTrophies = this.Trophies;
    }

    Encode(stream) {
        ByteStreamHelper.WriteDataReference(stream, this.CharacterData);
        ByteStreamHelper.WriteDataReference(stream, null);
        stream.WriteVInt(this.Trophies);
        stream.WriteVInt(this.HighestTrophies);
        stream.WriteVInt(0);
    }
}

module.exports = { Hero };
