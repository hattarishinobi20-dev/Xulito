'use strict';

class ClientInput {
    constructor() {
        this.Index = 0;
        this.Type = 0;
        this.X = 0;
        this.Y = 0;
        this.AutoAttack = false;
        this.AutoAttackTarget = 0;
        this.OwnerSessionId = 0;
    }

    Decode(Stream) {
        this.Index = Stream.ReadVInt();
        Stream.ReadVInt(); // always 1
        this.Type = Stream.ReadVInt();
        this.X = Stream.ReadVInt();
        this.Y = Stream.ReadVInt();
    }
}

module.exports = { ClientInput };
