'use strict';

class Session {
    constructor(home, connection) {
        this.Home = home;
        this.Connection = connection;
    }

    get GameListener() {
        return this.Home.GameListener;
    }
}

module.exports = { Session };
