'use strict';

const { LogicData } = require('./LogicData');

// Helper to define property metadata on data classes
function defineProperties(obj, props) {
    obj._properties = props.map(p => ({ name: p[0], type: p[1] || 'string' }));
}

class ProjectileData extends LogicData {
    constructor(row, datatable) {
        super(row, datatable);
        defineProperties(this, [
            ['Name'], ['Speed', 'int'], ['FileName'], ['BlueExportName'], ['RedExportName'],
            ['ShadowExportName'], ['BlueGroundGlowExportName'], ['RedGroundGlowExportName'],
            ['PreExplosionBlueExportName'], ['PreExplosionRedExportName'], ['PreExplosionTimeMs', 'int'],
            ['HitEffectEnv'], ['HitEffectChar'], ['MaxRangeReachedEffect'], ['Radius', 'int'],
            ['Indirect', 'bool'], ['ConstantFlyTime', 'bool'], ['TriggerWithDelayMs', 'int'],
            ['BouncePercent', 'int'], ['Gravity', 'int'], ['EarlyTicks', 'int'], ['HideTime', 'int'],
            ['Scale', 'int'], ['RandomStartFrame', 'bool'], ['SpawnAreaEffectObject'],
            ['SpawnAreaEffectObject2'], ['SpawnCharacter'], ['SpawnItem'], ['TrailEffect'],
            ['ShotByHero', 'bool'], ['IsBeam', 'bool'], ['IsBouncing', 'bool'], ['Rendering'],
            ['PiercesCharacters', 'bool'], ['PiercesEnvironment', 'bool'],
            ['PiercesEnvironmentLikeButter', 'bool'], ['PushbackStrength', 'int'],
            ['ChainsToEnemies', 'int'], ['ChainBullet'], ['DamagePercentStart', 'int'],
            ['DamagePercentEnd', 'int'], ['DamagesConstantly', 'bool'], ['FreezeStrength', 'int'],
            ['StunLengthMS', 'int'], ['ScaleStart', 'int'], ['ScaleEnd', 'int'],
            ['AttractsPet', 'bool'], ['LifeStealPercent', 'int'], ['PassesEnvironment', 'bool'],
            ['PoisonDamagePercent', 'int'], ['SameProjectileCanNotDamageMS', 'int'],
            ['HealOwnPercent', 'int']
        ]);
        this.LoadData(this, this.constructor, row);
    }
    GetDamagePercentStart() { return this.DamagePercentStart === 0 ? 100 : this.DamagePercentStart; }
    GetDamagePercentEnd() { return this.DamagePercentEnd === 0 ? 100 : this.DamagePercentEnd; }
}

class AllianceBadgeData extends LogicData {
    constructor(row, datatable) {
        super(row, datatable);
        defineProperties(this, [['Name'], ['IconSWF'], ['IconExportName'], ['Category']]);
        this.LoadData(this, this.constructor, row);
    }
}

class LocationData extends LogicData {
    constructor(row, datatable) {
        super(row, datatable);
        defineProperties(this, [['Name'], ['TID'], ['TileSetPrefix'], ['GameMode'], ['AllowedMaps'], ['Music']]);
        this.LoadData(this, this.constructor, row);
    }
}

class CharacterData extends LogicData {
    constructor(row, datatable) {
        super(row, datatable);
        defineProperties(this, [
            ['Name'], ['Disabled', 'bool'], ['WeaponSkill'], ['UltimateSkill'], ['Pet'],
            ['Speed', 'int'], ['Hitpoints', 'int'], ['MeleeAutoAttackSplashDamage', 'bool'],
            ['AutoAttackSpeedMs', 'int'], ['AutoAttackDamage', 'int'],
            ['AutoAttackBulletsPerShot', 'int'], ['AutoAttackMode'],
            ['AutoAttackProjectileSpread', 'int'], ['AutoAttackProjectile'],
            ['AutoAttackRange', 'int'], ['RegeneratePerSecond', 'int'],
            ['UltiChargeMul', 'int'], ['UltiChargeDiv', 'int'], ['Type'],
            ['DamagerPercentFromAliens', 'int'], ['DefaultSkin'], ['FileName'],
            ['BlueExportName'], ['RedExportName'], ['ShadowExportName'], ['AreaEffect'],
            ['DeathAreaEffect'], ['TakeDamageEffect'], ['DeathEffect'], ['MoveEffect'],
            ['ReloadEffect'], ['OutOfAmmoEffect'], ['DryFireEffect'], ['SpawnEffect'],
            ['MeleeHitEffect'], ['AutoAttackStartEffect'], ['KillCelebrationSoundVO'],
            ['InLeadCelebrationSoundVO'], ['StartSoundVO'], ['UseUltiSoundVO'],
            ['TakeDamageSoundVO'], ['DeathSoundVO'], ['AttackStartEffectOffset', 'int'],
            ['ShadowScaleX', 'int'], ['ShadowScaleY', 'int'], ['ShadowX', 'int'],
            ['ShadowY', 'int'], ['ShadowSkew', 'int'], ['Scale', 'int'],
            ['HeroScreenScale', 'int'], ['EndScreenScale', 'int'], ['CollisionRadius', 'int'],
            ['HealthBar'], ['HealthBarOffsetY', 'int'], ['FlyingHeight', 'int'],
            ['ProjectileStartZ', 'int'], ['StopMovementAfterMS', 'int'], ['WaitMS', 'int'],
            ['TID'], ['ForceAttackAnimationToEnd', 'bool'], ['IconSWF'], ['IconExportName'],
            ['ThumbnailCameraYAdjustment', 'int'], ['ThumbnailCameraZAdjustment', 'int'],
            ['Archetype', 'int'], ['DamageCtg', 'int'], ['SpeedCtg', 'int'], ['HpCtg', 'int'],
            ['RecoilAmount', 'int'], ['Homeworld'], ['FootstepClip'],
            ['DifferentFootstepOffset', 'int'], ['FootstepIntervalMS', 'int'],
            ['AttackingWeaponScale', 'int'], ['UseThrowingLeftWeaponBoneScaling', 'bool'],
            ['UseThrowingRightWeaponBoneScaling', 'bool']
        ]);
        this.LoadData(this, this.constructor, row);
    }
    isCampaignDefendTarget() { return this.Type === 'Campaign_DefendTarget'; }
    IsBase() { return this.Type === 'Pvp_Base'; }
    IsLootBox() { return this.Type === 'LootBox'; }
    IsCarryable() { return this.Type === 'Carryable'; }
    IsHero() { return this.Type === 'Hero'; }
    IsPet() { return this.Pet != null && this.Pet !== ''; }
    HasAutoAttack() { return this.AutoAttackDamage > 0; }
}

class AreaEffectData extends LogicData {
    constructor(row, datatable) {
        super(row, datatable);
        defineProperties(this, [
            ['Name'], ['FileName'], ['BlueExportName'], ['RedExportName'], ['Layer'],
            ['Effect'], ['Scale', 'int'], ['TimeMs', 'int'], ['Radius', 'int'],
            ['Damage', 'int'], ['CustomValue', 'int'], ['Type'],
            ['BulletExplosionBullet'], ['BulletExplosionBulletDistance', 'int'],
            ['DestroysEnvironment', 'bool'], ['PushbackStrength', 'int'],
            ['PushbackStrengthSelf', 'int'], ['FreezeStrength', 'int']
        ]);
        this.LoadData(this, this.constructor, row);
    }
    GetAreaEffectType() {
        const v1 = this.Type;
        if (v1 === 'Damage') return 0;
        if (v1 === 'SmokeScreen') return 1;
        if (v1 === 'Dot') return 2;
        if (v1 === 'Heal') return 3;
        if (v1 === 'SpeedBoost') return 4;
        if (v1 === 'BulletExplosion') return 5;
        if (v1 === 'Hot') return 6;
        return -1;
    }
}

class ItemData extends LogicData {
    constructor(row, datatable) {
        super(row, datatable);
        defineProperties(this, [
            ['Name'], ['FileName'], ['ExportName'], ['Effect'], ['Effect2'],
            ['Value', 'int'], ['Value2', 'int'], ['TriggerRangeSubTiles', 'int'],
            ['TriggerAreaEffect'], ['CanBePickedUp', 'bool'], ['SpawnEffect'],
            ['RespawnSeconds', 'int'], ['RespawnSeconds2', 'int']
        ]);
        this.LoadData(this, this.constructor, row);
    }
}

class SkillData extends LogicData {
    constructor(row, datatable) {
        super(row, datatable);
        defineProperties(this, [
            ['Name'], ['BehaviorType'], ['CanMoveAtSameTime', 'bool'], ['Targeted', 'bool'],
            ['Cooldown', 'int'], ['ActiveTime', 'int'], ['CastingTime', 'int'],
            ['CastingRange', 'int'], ['MaxCastingRange', 'int'], ['RechargeTime', 'int'],
            ['MaxCharge', 'int'], ['Damage', 'int'], ['MsBetweenAttacks', 'int'],
            ['Spread', 'int'], ['AttackPattern', 'int'], ['NumBulletsInOneAttack', 'int'],
            ['TwoGuns', 'bool'], ['ExecuteFirstAttackImmediately', 'bool'],
            ['ChargePushback', 'int'], ['ChargeSpeed', 'int'], ['ChargeType', 'int'],
            ['NumSpawns', 'int'], ['MaxSpawns', 'int'], ['AlwaysCastAtMaxRange', 'bool'],
            ['Projectile'], ['SummonedCharacter'], ['AreaEffectObject'], ['AreaEffectObject2'],
            ['SpawnedItem'], ['IconSWF'], ['IconExportName'], ['LargeIconSWF'],
            ['LargeIconExportName'], ['ButtonSWF'], ['ButtonExportName'], ['AttackEffect'],
            ['UseEffect'], ['EndEffect'], ['LoopEffect']
        ]);
        this.LoadData(this, this.constructor, row);
    }
}

class CardData extends LogicData {
    constructor(row, datatable) {
        super(row, datatable);
        defineProperties(this, [
            ['Name'], ['IconSWF'], ['IconExportName'], ['Target'], ['RequiresCard'],
            ['Type'], ['Skill'], ['Value', 'int'], ['Value2', 'int'], ['Rarity'],
            ['TID'], ['PowerNumberTID'], ['PowerNumber2TID'],
            ['PowerIcon1ExportName'], ['PowerIcon2ExportName']
        ]);
        this.LoadData(this, this.constructor, row);
    }
}

class TileData extends LogicData {
    constructor(row, datatable) {
        super(row, datatable);
        defineProperties(this, [
            ['Name'], ['TileCode'], ['BlocksMovement', 'bool'], ['BlocksProjectiles', 'bool'],
            ['IsDestructible', 'bool'], ['IsDestructibleNormalWeapon', 'bool'],
            ['HidesHero', 'bool'], ['RespawnSeconds', 'int'], ['CollisionMargin', 'int'],
            ['BaseExportName'], ['BaseExplosionEffect'], ['BaseHitEffect'], ['BaseWindEffect'],
            ['BaseBulletHole1'], ['BaseBulletHole2'], ['BaseCrack1'], ['BaseCrack2'],
            ['SortOffset', 'int'], ['HasHitAnim', 'bool'], ['HasWindAnim', 'bool'],
            ['ShadowScaleX', 'int'], ['ShadowScaleY', 'int'], ['ShadowX', 'int'],
            ['ShadowY', 'int'], ['ShadowSkew', 'int']
        ]);
        this.LoadData(this, this.constructor, row);
    }
}

class PlayerThumbnailData extends LogicData {
    constructor(row, datatable) {
        super(row, datatable);
        defineProperties(this, [
            ['Name'], ['RequiredExpLevel', 'int'], ['RequiredTotalTrophies', 'int'],
            ['RequiredHero'], ['IconSWF'], ['IconExportName']
        ]);
        this.LoadData(this, this.constructor, row);
    }
}

class SkinData extends LogicData {
    constructor(row, datatable) {
        super(row, datatable);
        defineProperties(this, [['Name'], ['Character'], ['PetSkin'], ['CostGems', 'int']]);
        this.LoadData(this, this.constructor, row);
    }
}

module.exports = {
    ProjectileData, AllianceBadgeData, LocationData, CharacterData,
    AreaEffectData, ItemData, SkillData, CardData, TileData,
    PlayerThumbnailData, SkinData
};
