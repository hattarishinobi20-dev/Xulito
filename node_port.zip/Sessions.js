'use strict';

const { Session } = require('./Session');

class Sessions {
    static Maintenance = false;
    static ActiveSessions = new Map();

    static get Count() { return Sessions.ActiveSessions.size; }

    static Init() {
        Sessions.ActiveSessions = new Map();
    }

    static StartShutdown() {
        const { ShutdownStartedMessage, AuthenticationFailedMessage } = require('./MessageFactory');
        Sessions.Maintenance = true;
        for (const session of Sessions.ActiveSessions.values()) {
            session.Connection.Send(new ShutdownStartedMessage());
        }
        setTimeout(() => {
            for (const session of Sessions.ActiveSessions.values()) {
                const msg = new AuthenticationFailedMessage();
                msg.ErrorCode = 10;
                session.Connection.Send(msg);
            }
        }, 1000);
    }

    static Remove(id) {
        const { Teams } = require('./Teams');
        const { LogicServerListener } = require('./LogicServerListener');

        if (Sessions.ActiveSessions.has(id)) {
            const session = Sessions.ActiveSessions.get(id);
            session.Home.Avatar.LastOnline = new Date();
            session.Home.Avatar.PlayerStatus = 0;

            if (session.Home.Avatar.TeamId > 0) {
                const team = Teams.Get(session.Home.Avatar.TeamId);
                if (team) {
                    const member = team.GetMember(id);
                    if (member) {
                        member.State = 0;
                        team.TeamUpdated();
                    }
                }
            }
        }
        Sessions.ActiveSessions.delete(id);
    }

    static Create(home, connection) {
        const { DisconnectedMessage } = require('./MessageFactory');

        if (Sessions.ActiveSessions.has(home.Avatar.AccountId)) {
            const oldSession = Sessions.ActiveSessions.get(home.Avatar.AccountId);
            const msg = new DisconnectedMessage();
            msg.Reason = 1;
            oldSession.Connection.Send(msg);
        }

        const session = new Session(home, connection);
        Sessions.ActiveSessions.set(home.Avatar.AccountId, session);
        return session;
    }

    static IsSessionActive(id) {
        return Sessions.ActiveSessions.has(id);
    }

    static GetSession(id) {
        return Sessions.ActiveSessions.get(id) || null;
    }
}

module.exports = { Sessions };
