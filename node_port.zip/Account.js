'use strict';

class Account {
    constructor() {
        const { ClientHome } = require('./ClientHome');
        const { ClientAvatar } = require('./ClientAvatar');
        this.AccountId = 0;
        this.PassToken = '';
        this.Home = new ClientHome();
        this.Avatar = new ClientAvatar();
    }
}

module.exports = { Account };
