'use strict';

const { Account } = require('./Account');

class AccountCache {
    static CachedAccounts = new Map();
    static _thread = null;
    static Started = true;

    static get Count() { return AccountCache.CachedAccounts.size; }

    static Init() {
        AccountCache.CachedAccounts = new Map();
        AccountCache._thread = setInterval(() => {
            AccountCache.SaveAll();
        }, 1000 * 30);
    }

    static SaveAll() {
        const { Accounts } = require('./Accounts');
        try {
            for (const avatar of AccountCache.CachedAccounts.values()) {
                try {
                    Accounts.Save(avatar);
                } catch (ex) {
                    console.error('Unhandled exception while saving account:', ex.message);
                }
            }
        } catch (e) {}
    }

    static IsAccountCached(id) { return AccountCache.CachedAccounts.has(id); }

    static GetAccount(id) { return AccountCache.CachedAccounts.get(id) || null; }

    static Cache(account) {
        AccountCache.CachedAccounts.set(account.AccountId, account);
    }
}

module.exports = { AccountCache };
