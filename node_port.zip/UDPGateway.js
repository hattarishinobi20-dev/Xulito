'use strict';

const dgram = require('dgram');
const { ByteStream } = require('./ByteStream');
const { MessageFactory } = require('./MessageFactory');

class UDPSocket {
    constructor(sessionId) {
        this.SessionId = sessionId;
        this.EndPoint = null;
        this.Battle = null;
        this.TCPConnection = null;
        this.IsSpectator = false;
    }

    get IsConnected() { return this.EndPoint !== null; }

    SetEndPoint(endPoint) {
        this.EndPoint = endPoint;
    }

    SendMessage(message) {
        if (message.GetEncodingLength() === 0) message.Encode();

        const stream = new ByteStream(256);
        stream.WriteLong(this.SessionId);
        stream.WriteShort(0);
        stream.WriteVInt(message.GetMessageType());
        stream.WriteVInt(message.GetEncodingLength());
        stream.WriteBytesWithoutLength(message.GetMessageBytes(), message.GetEncodingLength());

        UDPGateway.SendTo(stream.GetByteArray(), 0, stream.GetOffset(), this.EndPoint);
    }

    ProcessReceive(stream) {
        const type = stream.ReadVInt();
        const length = stream.ReadVInt();
        const data = stream.ReadBytes(length, 2000);

        const message = MessageFactory.Instance.CreateMessageByType(type);
        if (message) {
            message.GetByteStream().SetByteArray(data, length);
            message.Decode();
            this.HandleMessage(message);
        }
    }

    HandleMessage(message) {
        if (message.GetMessageType() === 10555) {
            const { ClientInput } = require('./ClientInput');
            for (const clientInput of message.Inputs) {
                if (!this.IsSpectator) {
                    if (this.Battle) this.Battle.AddClientInput(clientInput, this.SessionId);
                } else {
                    if (this.Battle) this.Battle.HandleSpectatorInput(clientInput, this.SessionId);
                }
            }
        }
    }
}

class UDPGateway {
    static Socket = null;
    static SessionCounter = 0;
    static Sockets = new Map();

    static Init(host, port) {
        UDPGateway.Sockets = new Map();

        UDPGateway.Socket = dgram.createSocket('udp4');

        UDPGateway.Socket.on('message', (msg, rinfo) => {
            try {
                const stream = new ByteStream(msg, msg.length);
                const sessionId = Number(stream.ReadLong());
                stream.ReadShort();

                if (!UDPGateway.Sockets.has(sessionId)) return;

                const client = UDPGateway.Sockets.get(sessionId);
                if (!client.IsConnected) {
                    client.SetEndPoint({ address: rinfo.address, port: rinfo.port });

                    if (!client.Battle) return;

                    if (!client.IsSpectator) {
                        const { UDPGameListener } = require('./UDPGameListener');
                        const player = client.Battle.GetPlayerBySessionId(client.SessionId);
                        if (player) player.GameListener = new UDPGameListener(client, client.TCPConnection);
                    }
                }

                client.ProcessReceive(stream);
            } catch (e) {
                console.error('UDP receive error:', e.message);
            }
        });

        UDPGateway.Socket.bind(port, host, () => {
            console.log(`UDP Server started at ${host}:${port}`);
        });
    }

    static CreateSocket() {
        const socket = new UDPSocket(++UDPGateway.SessionCounter);
        UDPGateway.Sockets.set(socket.SessionId, socket);
        return socket;
    }

    static SendTo(data, startIndex, count, remoteEndPoint) {
        try {
            if (!remoteEndPoint) return;
            UDPGateway.Socket.send(data, startIndex, count, remoteEndPoint.port, remoteEndPoint.address);
        } catch (e) {}
    }
}

module.exports = { UDPGateway, UDPSocket };
