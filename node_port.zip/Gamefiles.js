'use strict';

const { DataTable } = require('./DataTable');

class Gamefiles {
    constructor() {
        this._dataTables = {};
    }

    Dispose() {
        this._dataTables = {};
    }

    Get(index) {
        return this._dataTables[index] || null;
    }

    ContainsTable(t) {
        return t in this._dataTables;
    }

    Initialize(table, index) {
        this._dataTables[index] = new DataTable(table, index);
    }
}

module.exports = { Gamefiles };
