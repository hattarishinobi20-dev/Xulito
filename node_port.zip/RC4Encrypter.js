'use strict';

// RC4 Encrypter - matching the C# implementation
class RC4Encrypter {
    constructor() {
        // Using the default key from the original project
        this.key = Buffer.from('nonce');
        this._state = null;
        this._i = 0;
        this._j = 0;
        this.Init();
    }

    Init() {
        // Simple RC4 with nonce-based key
        const key = this.key;
        this._state = new Uint8Array(256);
        for (let i = 0; i < 256; i++) this._state[i] = i;

        let j = 0;
        for (let i = 0; i < 256; i++) {
            j = (j + this._state[i] + key[i % key.length]) & 0xFF;
            const tmp = this._state[i];
            this._state[i] = this._state[j];
            this._state[j] = tmp;
        }
        this._i = 0;
        this._j = 0;

        // Pre-iterate (matching Brawl Stars RC4 - skip first 256 bytes)
        for (let k = 0; k < 256; k++) {
            this._i = (this._i + 1) & 0xFF;
            this._j = (this._j + this._state[this._i]) & 0xFF;
            const tmp = this._state[this._i];
            this._state[this._i] = this._state[this._j];
            this._state[this._j] = tmp;
        }
    }

    Encrypt(data) {
        const result = Buffer.alloc(data.length);
        const state = new Uint8Array(this._state);
        let i = this._i;
        let j = this._j;

        for (let k = 0; k < data.length; k++) {
            i = (i + 1) & 0xFF;
            j = (j + state[i]) & 0xFF;
            const tmp = state[i];
            state[i] = state[j];
            state[j] = tmp;
            result[k] = data[k] ^ state[(state[i] + state[j]) & 0xFF];
        }

        this._state = state;
        this._i = i;
        this._j = j;
        return result;
    }

    Decrypt(data) {
        return this.Encrypt(data); // RC4 is symmetric
    }
}

module.exports = { RC4Encrypter };
