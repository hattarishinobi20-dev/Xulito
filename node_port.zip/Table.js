'use strict';

const fs = require('fs');
const { Column } = require('./Column');
const { Row } = require('./Row');

function parseCSVLine(line) {
    const result = [];
    let current = '';
    let inQuotes = false;

    for (let i = 0; i < line.length; i++) {
        const ch = line[i];
        if (ch === '"') {
            if (inQuotes && i + 1 < line.length && line[i + 1] === '"') {
                current += '"';
                i++;
            } else {
                inQuotes = !inQuotes;
            }
        } else if (ch === ',' && !inQuotes) {
            result.push(current);
            current = '';
        } else {
            current += ch;
        }
    }
    result.push(current);
    return result;
}

function parseCSV(text) {
    const lines = [];
    let current = '';
    let inQuotes = false;

    for (let i = 0; i < text.length; i++) {
        const ch = text[i];
        if (ch === '"') {
            if (inQuotes && i + 1 < text.length && text[i + 1] === '"') {
                current += '""';
                i++;
            } else {
                inQuotes = !inQuotes;
                current += ch;
            }
        } else if ((ch === '\n' || ch === '\r') && !inQuotes) {
            if (ch === '\r' && i + 1 < text.length && text[i + 1] === '\n') i++;
            if (current.length > 0) {
                lines.push(current);
            }
            current = '';
        } else {
            current += ch;
        }
    }
    if (current.length > 0) lines.push(current);
    return lines;
}

class Table {
    constructor(path) {
        this._rows = [];
        this._headers = [];
        this._types = [];
        this._columns = [];

        const content = fs.readFileSync(path, 'utf8');
        const lines = parseCSV(content);

        if (lines.length < 2) return;

        // First line: headers
        const headers = parseCSVLine(lines[0]);
        for (const header of headers) {
            this._headers.push(header);
            this._columns.push(new Column());
        }

        // Second line: types
        const types = parseCSVLine(lines[1]);
        for (const type of types) {
            this._types.push(type);
        }

        // Data lines
        for (let i = 2; i < lines.length; i++) {
            const values = parseCSVLine(lines[i]);

            // Ensure we have enough values
            while (values.length < this._headers.length) {
                values.push('');
            }

            if (values[0] !== '' && values[0] !== undefined) {
                this.AddRow(new Row(this));
            }

            for (let j = 0; j < this._headers.length; j++) {
                this._columns[j].Add(values[j] || '');
            }
        }
    }

    AddRow(row) {
        this._rows.push(row);
    }

    GetArraySizeAt(row, columnIndex) {
        const index = this._rows.indexOf(row) + 1;
        if (index === -1) return 0;

        let nextOffset;
        if (index + 1 >= this._rows.length) {
            nextOffset = this._columns[columnIndex].GetSize();
        } else {
            const nextRow = this._rows[index + 1];
            nextOffset = nextRow.Offset;
        }

        return Column.GetArraySize(row.Offset, nextOffset);
    }

    GetColumnIndexByName(name) {
        return this._headers.indexOf(name);
    }

    GetColumnName(index) {
        return this._headers[index];
    }

    GetColumnRowCount() {
        return this._columns.length > 0 ? this._columns[0].GetSize() : 0;
    }

    GetRowAt(index) {
        return this._rows[index];
    }

    GetRowCount() {
        return this._rows.length;
    }

    GetValue(name, level) {
        const index = this._headers.indexOf(name);
        return this.GetValueAt(index, level);
    }

    GetValueAt(column, row) {
        if (column < 0 || column >= this._columns.length) return '';
        return this._columns[column].Get(row) || '';
    }
}

module.exports = { Table };
