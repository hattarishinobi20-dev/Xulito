'use strict';

class Column {
    constructor() {
        this._values = [];
    }

    static GetArraySize(offset, nOffset) {
        return nOffset - offset;
    }

    Add(value) {
        if (value === null || value === undefined) {
            this._values.push(this._values.length > 0 ? this._values[this._values.length - 1] : '');
        } else {
            this._values.push(value);
        }
    }

    Get(row) {
        return this._values[row];
    }

    GetSize() {
        return this._values.length;
    }
}

module.exports = { Column };
