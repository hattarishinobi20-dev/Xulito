'use strict';

class MatchmakingEntry {
    constructor(connection) {
        this.Connection = connection;
        this.Player = null;
        this.PlayerTeamId = -1;
        this.PrefferedTeam = -1;
    }
}

class MatchmakingSlot {
    constructor(eventData, playersRequired) {
        this.RequestQueue = [];
        this.RemoveQueue = [];
        this.Queue = [];
        this.PlayersRequired = playersRequired;
        this.EventData = eventData;
        this.SecondsLeft = MatchmakingSlot.SEARCH_TIMEOUT;
        this.Turns = 0;
    }

    static SEARCH_TIMEOUT = 20;

    Add(entry) { this.Queue.push(entry); }
    Remove(entry) {
        const idx = this.Queue.indexOf(entry);
        if (idx !== -1) this.Queue.splice(idx, 1);
    }

    Update() {
        if (this.Queue.length >= this.PlayersRequired) {
            this.StartBattle(this.Queue.slice(0, this.PlayersRequired));
            this.Queue.splice(0, this.PlayersRequired);
        } else if (this.Queue.length > 0) {
            this.SecondsLeft--;
            if (this.SecondsLeft <= 0) {
                this.StartBattle(this.Queue.slice());
                this.Queue = [];
            }
        }
    }

    StartBattle(entries) {
        const { BattleMode } = require('./BattleMode');
        const { UDPGateway } = require('./UDPGateway');
        const { GameModeUtil } = require('./GameModeUtil');
        const { GamePlayUtil } = require('./GamePlayUtil');
        const { BattlePlayer } = require('./BattlePlayer');
        const { StartLoadingMessage } = require('./AllMessages');
        const { DataTables } = require('./DataTables');
        const { DataType } = require('./DataTables');

        const locationId = this.EventData.LocationId;
        const gameModeVariation = GameModeUtil.GetGameModeVariation(this.EventData.Location.GameMode);
        const battle = new BattleMode(locationId);
        battle.Id = require('./Battles').Battles.Add(battle);

        const hasTwoTeams = GameModeUtil.HasTwoTeams(gameModeVariation);
        const rand = { Next: (min, max) => Math.floor(Math.random() * (max - min)) + min };
        const botBrawlers = [0, 1, 2, 3, 4, 5, 6, 7, 8];

        // Sort entries by team
        const sortedEntries = [];
        if (hasTwoTeams) {
            const entriesWithTeam = entries.filter(e => e.PlayerTeamId > 0);
            const entriesWithoutTeam = entries.filter(e => e.PlayerTeamId <= 0);
            const teamEntries = {};

            for (const entry of entriesWithTeam) {
                if (!teamEntries[entry.PlayerTeamId]) teamEntries[entry.PlayerTeamId] = [];
                teamEntries[entry.PlayerTeamId].push(entry);
            }

            let teamIdx = 0;
            for (const teamId of Object.keys(teamEntries)) {
                for (const entry of teamEntries[teamId]) {
                    sortedEntries.push(entry);
                    entry.PrefferedTeam = teamIdx;
                }
                teamIdx++;
            }

            for (const entry of entriesWithoutTeam) sortedEntries.push(entry);
        } else {
            for (const entry of entries) sortedEntries.push(entry);
        }

        // Add players
        if (hasTwoTeams) {
            for (let i = 0; i < sortedEntries.length; i++) {
                const socket = UDPGateway.CreateSocket();
                socket.TCPConnection = sortedEntries[i].Connection;
                socket.Battle = battle;
                sortedEntries[i].Connection.UdpSessionId = socket.SessionId;

                let teamIndex = i % 2;
                if (sortedEntries[i].PrefferedTeam !== -1) teamIndex = sortedEntries[i].PrefferedTeam;
                if (battle.GetTeamPlayersCount(teamIndex) >= 3) teamIndex = teamIndex === 1 ? 0 : 1;

                const player = BattlePlayer.Create(
                    sortedEntries[i].Connection.Home,
                    sortedEntries[i].Connection.Avatar,
                    i, teamIndex
                );
                player.TeamId = sortedEntries[i].PlayerTeamId;
                sortedEntries[i].Player = player;
                battle.AddPlayer(player, sortedEntries[i].Connection.UdpSessionId);
            }
        } else {
            for (let i = 0; i < sortedEntries.length; i++) {
                const socket = UDPGateway.CreateSocket();
                socket.TCPConnection = sortedEntries[i].Connection;
                socket.Battle = battle;
                sortedEntries[i].Connection.UdpSessionId = socket.SessionId;

                const player = BattlePlayer.Create(
                    sortedEntries[i].Connection.Home,
                    sortedEntries[i].Connection.Avatar,
                    i, i
                );
                player.TeamId = sortedEntries[i].PlayerTeamId;
                sortedEntries[i].Player = player;
                battle.AddPlayer(player, sortedEntries[i].Connection.UdpSessionId);
            }
        }

        // Add bots
        const totalPlayers = battle.GetPlayersCountWithGameModeVariation();
        for (let i = sortedEntries.length; i < totalPlayers; i++) {
            const botCharacter = 16000000 + botBrawlers[Math.floor(Math.random() * botBrawlers.length)];
            const teamIndex = hasTwoTeams ? i % 2 : i;
            const dt = DataTables.Get(DataType.Character);
            const data = dt ? dt.GetDataByGlobalId(botCharacter) : null;
            const name = data ? data.Name.toUpperCase() : 'Bot ' + i;
            const bot = BattlePlayer.CreateBotInfo(name, i, teamIndex, botCharacter);
            battle.AddPlayer(bot, -1);
        }

        battle.AddGameObjects();

        // Send StartLoading to all players
        for (let i = 0; i < sortedEntries.length; i++) {
            const startLoading = new StartLoadingMessage();
            startLoading.LocationId = battle.Location.GetGlobalId();
            startLoading.TeamIndex = sortedEntries[i].Player.TeamIndex;
            startLoading.OwnIndex = sortedEntries[i].Player.PlayerIndex;
            startLoading.GameMode = battle.GetGameModeVariation() === 6 ? 6 : 1;
            sortedEntries[i].Connection.Avatar.UdpSessionId = sortedEntries[i].Connection.UdpSessionId;
            startLoading.Players = battle.GetPlayers();
            sortedEntries[i].Connection.Send(startLoading);
        }

        battle.Start();
    }
}

class Matchmaking {
    static Slots = new Map();
    static UpdateInterval = null;

    static Init() {
        try {
            const { Events } = require('./Events');
            Matchmaking.Slots = new Map();
            const events = Events.GetEvents();
            for (const e of events) {
                const mode = GameModeUtil.GetGameModeVariation(e.Location.GameMode);
                console.log('added new slot');
                Matchmaking.Slots.set(e.Slot, new MatchmakingSlot(e, GamePlayUtil.GetPlayerCountWithGameModeVariation(mode)));
            }
            Matchmaking.UpdateInterval = setInterval(() => Matchmaking.Update(), 250);
        } catch (e) {
            console.error(e);
        }
    }

    static Update() {
        for (const slot of Matchmaking.Slots.values()) {
            slot.Update();
        }
    }

    static RequestMatchmake(connection, slot, team) {
        team = team || -1;
        const { Events } = require('./Events');
        const { GameModeUtil } = require('./GameModeUtil');
        const { GamePlayUtil } = require('./GamePlayUtil');

        console.log('Possible slots:', Array.from(Matchmaking.Slots.keys()));
        console.log('Requested slot:', slot);

        if (!Matchmaking.Slots.has(slot)) {
            const events = Events.GetEvents();
            const defaultEvent = events[slot - 1];
            if (defaultEvent) {
                const mode = GameModeUtil.GetGameModeVariation(defaultEvent.Location.GameMode);
                Matchmaking.Slots.set(slot, new MatchmakingSlot(defaultEvent, GamePlayUtil.GetPlayerCountWithGameModeVariation(mode)));
            } else {
                console.log('No EventData available to create slot.');
                return;
            }
        }

        connection.MatchmakeSlot = slot;
        const entry = new MatchmakingEntry(connection);
        entry.PlayerTeamId = team;
        connection.MatchmakingEntry = entry;
        Matchmaking.Slots.get(slot).Add(entry);
    }

    static CancelMatchmake(connection) {
        const slot = connection.MatchmakeSlot;
        if (Matchmaking.Slots.has(slot)) {
            connection.MatchmakeSlot = -1;
            Matchmaking.Slots.get(slot).Remove(connection.MatchmakingEntry);
        }
    }
}

const { GameModeUtil } = require('./GameModeUtil');
const { GamePlayUtil } = require('./GamePlayUtil');

module.exports = { Matchmaking, MatchmakingSlot, MatchmakingEntry };
