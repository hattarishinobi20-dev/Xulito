'use strict';

const { ChecksumEncoder } = require('./ChecksumEncoder');

class ByteStream extends ChecksumEncoder {
    constructor(capacityOrBuffer, length) {
        super();
        this.BitOffset = 0;

        if (Buffer.isBuffer(capacityOrBuffer)) {
            this.Buffer = capacityOrBuffer;
            this.Length = length || capacityOrBuffer.length;
        } else if (ArrayBuffer.isView(capacityOrBuffer)) {
            this.Buffer = Buffer.from(capacityOrBuffer);
            this.Length = length || capacityOrBuffer.length;
        } else if (typeof capacityOrBuffer === 'number') {
            this.Buffer = Buffer.alloc(capacityOrBuffer);
            this.Length = 0;
        } else {
            this.Buffer = Buffer.alloc(10);
            this.Length = 0;
        }

        this.Offset = 0;
    }

    GetLength() {
        if (this.Offset < this.Length) return this.Length;
        return this.Offset;
    }

    GetOffset() {
        return this.Offset;
    }

    IsAtEnd() {
        return this.Offset >= this.Length;
    }

    Clear(capacity) {
        this.Buffer = Buffer.alloc(capacity);
        this.Offset = 0;
        this.Length = 0;
    }

    GetByteArray() {
        return this.Buffer;
    }

    SetByteArray(data, length) {
        this.Buffer = Buffer.isBuffer(data) ? data : Buffer.from(data);
        this.Length = length;
        this.Offset = 0;
        this.BitOffset = 0;
    }

    ReadBoolean() {
        if (this.BitOffset === 0) {
            ++this.Offset;
        }
        const value = (this.Buffer[this.Offset - 1] & (1 << this.BitOffset)) !== 0;
        this.BitOffset = (this.BitOffset + 1) & 7;
        return value;
    }

    ReadByte() {
        this.BitOffset = 0;
        return this.Buffer[this.Offset++];
    }

    ReadShort() {
        this.BitOffset = 0;
        return (this.Buffer[this.Offset++] << 8) | this.Buffer[this.Offset++];
    }

    ReadInt() {
        this.BitOffset = 0;
        return ((this.Buffer[this.Offset++] << 24) |
                (this.Buffer[this.Offset++] << 16) |
                (this.Buffer[this.Offset++] << 8) |
                this.Buffer[this.Offset++]);
    }

    ReadVInt() {
        this.BitOffset = 0;
        let value = 0;
        let byteValue = this.Buffer[this.Offset++];

        if ((byteValue & 0x40) !== 0) {
            value |= byteValue & 0x3F;

            if ((byteValue & 0x80) !== 0) {
                value |= ((byteValue = this.Buffer[this.Offset++]) & 0x7F) << 6;

                if ((byteValue & 0x80) !== 0) {
                    value |= ((byteValue = this.Buffer[this.Offset++]) & 0x7F) << 13;

                    if ((byteValue & 0x80) !== 0) {
                        value |= ((byteValue = this.Buffer[this.Offset++]) & 0x7F) << 20;

                        if ((byteValue & 0x80) !== 0) {
                            value |= ((byteValue = this.Buffer[this.Offset++]) & 0x7F) << 27;
                            return (value | 0x80000000) | 0;
                        }

                        return (value | 0xF8000000) | 0;
                    }

                    return (value | 0xFFF00000) | 0;
                }

                return (value | 0xFFFFE000) | 0;
            }

            return (value | 0xFFFFFFC0) | 0;
        }

        value |= byteValue & 0x3F;

        if ((byteValue & 0x80) !== 0) {
            value |= ((byteValue = this.Buffer[this.Offset++]) & 0x7F) << 6;

            if ((byteValue & 0x80) !== 0) {
                value |= ((byteValue = this.Buffer[this.Offset++]) & 0x7F) << 13;

                if ((byteValue & 0x80) !== 0) {
                    value |= ((byteValue = this.Buffer[this.Offset++]) & 0x7F) << 20;

                    if ((byteValue & 0x80) !== 0) {
                        value |= ((byteValue = this.Buffer[this.Offset++]) & 0x7F) << 27;
                    }
                }
            }
        }

        return value;
    }

    ReadLong() {
        const buff = this.ReadBytes(8, 8);
        // Reverse for big-endian to little-endian
        const reversed = Buffer.from(buff).reverse();
        return reversed.readBigInt64LE(0);
    }

    ReadVLong() {
        const high = this.ReadVInt();
        const low = this.ReadVInt();
        return BigInt(((high * 0x100000000) + (low >>> 0)));
    }

    ReadBytesLength() {
        this.BitOffset = 0;
        return ((this.Buffer[this.Offset++] << 24) |
                (this.Buffer[this.Offset++] << 16) |
                (this.Buffer[this.Offset++] << 8) |
                this.Buffer[this.Offset++]);
    }

    ReadBytes(length, maxCapacity) {
        this.BitOffset = 0;

        if (length <= -1) return null;

        if (length <= maxCapacity) {
            const array = Buffer.alloc(length);
            this.Buffer.copy(array, 0, this.Offset, this.Offset + length);
            this.Offset += length;
            return array;
        }

        return null;
    }

    ReadString(maxCapacity) {
        maxCapacity = maxCapacity || 9000000;
        const length = this.ReadBytesLength();

        if (length <= -1) return null;

        if (length <= maxCapacity) {
            const value = this.Buffer.toString('utf8', this.Offset, this.Offset + length);
            this.Offset += length;
            return value;
        }

        return null;
    }

    ReadStringReference(maxCapacity) {
        const length = this.ReadBytesLength();

        if (length <= -1) return '';

        if (length <= maxCapacity) {
            const value = this.Buffer.toString('utf8', this.Offset, this.Offset + length);
            this.Offset += length;
            return value;
        }

        return '';
    }

    EnsureCapacity(capacity) {
        if (this.Offset + capacity > this.Buffer.length) {
            const newBuffer = Buffer.alloc(Math.max(this.Buffer.length * 2, this.Offset + capacity));
            this.Buffer.copy(newBuffer);
            this.Buffer = newBuffer;
        }
    }

    WriteBoolean(value) {
        if (this.BitOffset === 0) {
            this.EnsureCapacity(1);
            this.Buffer[this.Offset++] = 0;
        }

        if (value) {
            this.Buffer[this.Offset - 1] |= (1 << this.BitOffset);
        }

        this.BitOffset = (this.BitOffset + 1) & 7;
        return value;
    }

    WriteByte(value) {
        this.EnsureCapacity(1);
        this.BitOffset = 0;
        this.Buffer[this.Offset++] = value & 0xFF;
    }

    WriteShort(value) {
        this.EnsureCapacity(2);
        this.BitOffset = 0;
        this.Buffer[this.Offset++] = (value >> 8) & 0xFF;
        this.Buffer[this.Offset++] = value & 0xFF;
    }

    WriteInt(value) {
        this.EnsureCapacity(4);
        this.BitOffset = 0;
        this.Buffer[this.Offset++] = (value >> 24) & 0xFF;
        this.Buffer[this.Offset++] = (value >> 16) & 0xFF;
        this.Buffer[this.Offset++] = (value >> 8) & 0xFF;
        this.Buffer[this.Offset++] = value & 0xFF;
    }

    WriteVInt(value) {
        this.EnsureCapacity(5);
        this.BitOffset = 0;

        value = value | 0; // ensure integer

        if (value >= 0) {
            if (value >= 64) {
                if (value >= 0x2000) {
                    if (value >= 0x100000) {
                        if (value >= 0x8000000) {
                            this.Buffer[this.Offset++] = (value & 0x3F) | 0x80;
                            this.Buffer[this.Offset++] = ((value >> 6) & 0x7F) | 0x80;
                            this.Buffer[this.Offset++] = ((value >> 13) & 0x7F) | 0x80;
                            this.Buffer[this.Offset++] = ((value >> 20) & 0x7F) | 0x80;
                            this.Buffer[this.Offset++] = (value >> 27) & 0xF;
                        } else {
                            this.Buffer[this.Offset++] = (value & 0x3F) | 0x80;
                            this.Buffer[this.Offset++] = ((value >> 6) & 0x7F) | 0x80;
                            this.Buffer[this.Offset++] = ((value >> 13) & 0x7F) | 0x80;
                            this.Buffer[this.Offset++] = (value >> 20) & 0x7F;
                        }
                    } else {
                        this.Buffer[this.Offset++] = (value & 0x3F) | 0x80;
                        this.Buffer[this.Offset++] = ((value >> 6) & 0x7F) | 0x80;
                        this.Buffer[this.Offset++] = (value >> 13) & 0x7F;
                    }
                } else {
                    this.Buffer[this.Offset++] = (value & 0x3F) | 0x80;
                    this.Buffer[this.Offset++] = (value >> 6) & 0x7F;
                }
            } else {
                this.Buffer[this.Offset++] = value & 0x3F;
            }
        } else {
            if (value < -64) {
                if (value < -0x2000) {
                    if (value < -0x100000) {
                        if (value < -0x8000000) {
                            this.Buffer[this.Offset++] = (value & 0x3F) | 0xC0;
                            this.Buffer[this.Offset++] = ((value >>> 6) & 0x7F) | 0x80;
                            this.Buffer[this.Offset++] = ((value >>> 13) & 0x7F) | 0x80;
                            this.Buffer[this.Offset++] = ((value >>> 20) & 0x7F) | 0x80;
                            this.Buffer[this.Offset++] = ((value >>> 27) & 0xF) | 0x8;
                        } else {
                            this.Buffer[this.Offset++] = (value & 0x3F) | 0xC0;
                            this.Buffer[this.Offset++] = ((value >>> 6) & 0x7F) | 0x80;
                            this.Buffer[this.Offset++] = ((value >>> 13) & 0x7F) | 0x80;
                            this.Buffer[this.Offset++] = (value >>> 20) & 0x7F;
                        }
                    } else {
                        this.Buffer[this.Offset++] = (value & 0x3F) | 0xC0;
                        this.Buffer[this.Offset++] = ((value >>> 6) & 0x7F) | 0x80;
                        this.Buffer[this.Offset++] = (value >>> 13) & 0x7F;
                    }
                } else {
                    this.Buffer[this.Offset++] = (value & 0x3F) | 0xC0;
                    this.Buffer[this.Offset++] = (value >>> 6) & 0x7F;
                }
            } else {
                this.Buffer[this.Offset++] = (value & 0x3F) | 0x40;
            }
        }
    }

    WriteLong(value) {
        if (typeof value === 'bigint') {
            const buf = Buffer.alloc(8);
            buf.writeBigInt64BE(value, 0);
            for (let i = 0; i < 8; i++) {
                this.WriteByte(buf[i]);
            }
        } else {
            // value is a number
            const high = Math.floor(value / 0x100000000);
            const low = value | 0;
            this.WriteInt(high);
            this.WriteInt(low);
        }
    }

    WriteVLong(value) {
        if (typeof value === 'bigint') {
            const high = Number(value >> 32n) | 0;
            const low = Number(value & 0xFFFFFFFFn) | 0;
            this.WriteVInt(high);
            this.WriteVInt(low);
        } else {
            const high = Math.floor(value / 0x100000000) | 0;
            const low = value | 0;
            this.WriteVInt(high);
            this.WriteVInt(low);
        }
    }

    WriteBytes(data, length) {
        if (data === null) {
            this.WriteInt(-1);
            return;
        }
        this.WriteInt(length);
        this.EnsureCapacity(length);
        for (let i = 0; i < length; i++) {
            this.Buffer[this.Offset++] = data[i];
        }
    }

    WriteBytesWithoutLength(data, length) {
        this.EnsureCapacity(length);
        for (let i = 0; i < length; i++) {
            this.Buffer[this.Offset++] = data[i];
        }
    }

    WriteString(value) {
        if (value === null || value === undefined) {
            this.WriteInt(-1);
            return;
        }

        const bytes = Buffer.from(value, 'utf8');
        this.WriteInt(bytes.length);
        this.EnsureCapacity(bytes.length);
        bytes.copy(this.Buffer, this.Offset);
        this.Offset += bytes.length;
    }

    WriteStringReference(value) {
        const bytes = Buffer.from(value || '', 'utf8');
        this.WriteInt(bytes.length);
        this.EnsureCapacity(bytes.length);
        bytes.copy(this.Buffer, this.Offset);
        this.Offset += bytes.length;
    }

    IsCheckSumOnlyMode() {
        return false;
    }
}

module.exports = { ByteStream };
