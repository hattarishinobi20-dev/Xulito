'use strict';

class PlayerDisplayData {
    constructor(thumbnail, name) {
        this.ThumbnailId = thumbnail || 0;
        this.Name = name || '';
    }

    Encode(stream) {
        stream.WriteString(this.Name);
        stream.WriteVInt(100);
        stream.WriteVInt(this.ThumbnailId);
        stream.WriteVInt(43000000);
    }
}

module.exports = { PlayerDisplayData };
