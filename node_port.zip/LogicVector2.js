'use strict';

const { LogicMath } = require('./LogicMath');

class LogicVector2 {
    constructor(x, y) {
        this.X = x || 0;
        this.Y = y || 0;
    }

    Destruct() {
        this.X = 0;
        this.Y = 0;
    }

    Add(vector2) {
        this.X += vector2.X;
        this.Y += vector2.Y;
    }

    Clone() {
        return new LogicVector2(this.X, this.Y);
    }

    Dot(vector2) {
        return this.X * vector2.X + this.Y * vector2.Y;
    }

    GetAngle() {
        return LogicMath.GetAngle(this.X, this.Y);
    }

    GetAngleBetween(x, y) {
        return LogicMath.GetAngleBetween(LogicMath.GetAngle(this.X, this.Y), LogicMath.GetAngle(x, y));
    }

    GetDistance(vector2) {
        const x = this.X - vector2.X;
        let distance = 0x7FFFFFFF;

        if ((x + 46340) >>> 0 <= 92680) {
            const y = this.Y - vector2.Y;
            if ((y + 46340) >>> 0 <= 92680) {
                const distanceX = x * x;
                const distanceY = y * y;
                if ((distanceY >>> 0) < ((distanceX ^ 0x7FFFFFFF) >>> 0)) {
                    distance = distanceX + distanceY;
                }
            }
        }

        return LogicMath.Sqrt(distance);
    }

    GetDistanceSquared(vector2) {
        const x = this.X - vector2.X;
        let distance = 0x7FFFFFFF;

        if ((x + 46340) >>> 0 <= 92680) {
            const y = this.Y - vector2.Y;
            if ((y + 46340) >>> 0 <= 92680) {
                const distanceX = x * x;
                const distanceY = y * y;
                if ((distanceY >>> 0) < ((distanceX ^ 0x7FFFFFFF) >>> 0)) {
                    distance = distanceX + distanceY;
                }
            }
        }

        return distance;
    }

    GetLength() {
        let length = 0x7FFFFFFF;

        if ((46340 - this.X) >>> 0 <= 92680) {
            if ((46340 - this.Y) >>> 0 <= 92680) {
                const lengthX = this.X * this.X;
                const lengthY = this.Y * this.Y;
                if ((lengthY >>> 0) < ((lengthX ^ 0x7FFFFFFF) >>> 0)) {
                    length = lengthX + lengthY;
                }
            }
        }

        return LogicMath.Sqrt(length);
    }

    IsEqual(vector2) {
        return this.X === vector2.X && this.Y === vector2.Y;
    }

    Multiply(vector2) {
        this.X *= vector2.X;
        this.Y *= vector2.Y;
    }

    Normalize(value) {
        const length = this.GetLength();
        if (length !== 0) {
            this.X = (this.X * value / length) | 0;
            this.Y = (this.Y * value / length) | 0;
        }
        return length;
    }

    Rotate(degrees) {
        const newX = LogicMath.GetRotatedX(this.X, this.Y, degrees);
        const newY = LogicMath.GetRotatedY(this.X, this.Y, degrees);
        this.X = newX;
        this.Y = newY;
    }

    Set(x, y) {
        this.X = x;
        this.Y = y;
    }

    Substract(vector2) {
        this.X -= vector2.X;
        this.Y -= vector2.Y;
    }

    Decode(stream) {
        this.X = stream.ReadVInt();
        this.Y = stream.ReadVInt();
    }

    Encode(stream) {
        stream.WriteVInt(this.X);
        stream.WriteVInt(this.Y);
    }

    toString() {
        return `LogicVector2(${this.X},${this.Y})`;
    }
}

module.exports = { LogicVector2 };
