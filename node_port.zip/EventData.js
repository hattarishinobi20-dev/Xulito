'use strict';

const { ByteStreamHelper } = require('./ByteStreamHelper');
const { DataTables } = require('./DataTables');
const { DataType } = require('./DataTables');

class EventData {
    constructor() {
        this.Slot = 0;
        this.LocationId = 0;
        this.EndTime = new Date();
    }

    get Location() {
        const dt = DataTables.Get(DataType.Location);
        return dt ? dt.GetDataByGlobalId(this.LocationId) : null;
    }

    Encode(encoder) {
        encoder.WriteVInt(this.Slot);
        console.log(this.Slot);
        encoder.WriteVInt(this.Slot);
        encoder.WriteVInt(0);
        encoder.WriteVInt(Math.floor((this.EndTime - new Date()) / 1000));
        encoder.WriteVInt(10);
        encoder.WriteVInt(10);
        encoder.WriteVInt(60);
        encoder.WriteBoolean(true);
        encoder.WriteBoolean(true);
        ByteStreamHelper.WriteDataReference(encoder, this.Location);
        encoder.WriteVInt(0);
        encoder.WriteVInt(2);
        encoder.WriteString("Royale Brawl v1 by PrimoDEVHacc");
    }
}

class Milestones {
    WriteMilestones(encoder) {
        encoder.WriteVInt(0);
    }
}

module.exports = { EventData, Milestones };
