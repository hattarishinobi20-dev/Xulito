'use strict';

const { LogicGameListener } = require('./LogicGameListener');

class Connection {
    constructor(socket) {
        this.Socket = socket;
        this.ReadBuffer = Buffer.alloc(1024);
        this.Memory = Buffer.alloc(0);
        this.MemoryOffset = 0;
        this.IsOpen = true;
        this.MatchmakeSlot = -1;
        this.MatchmakingEntry = null;
        this.UdpSessionId = -1;
        this.Ping = 0;
        this.MessageManager = null;
        this.Messaging = null;

        console.log('New connection from', socket.remoteAddress + ':' + socket.remotePort);
    }

    get Home() {
        if (this.MessageManager && this.MessageManager.HomeMode) {
            return this.MessageManager.HomeMode.Home;
        }
        return null;
    }

    get Avatar() {
        if (this.MessageManager && this.MessageManager.HomeMode) {
            return this.MessageManager.HomeMode.Avatar;
        }
        return null;
    }

    PingUpdated(value) {
        this.Ping = value;
    }

    Send(message) {
        if (this.Messaging) {
            this.Messaging.Send(message);
        }
    }

    Close() {
        try {
            this.IsOpen = false;
            if (this.Socket) this.Socket.destroy();
        } catch (e) {}
    }

    Write(stream) {
        try {
            if (this.Socket && !this.Socket.destroyed) {
                this.Socket.write(stream);
            }
        } catch (e) {}
    }
}

module.exports = { Connection };
