'use strict';

// Pre-computed sin/cos tables (matching C# LogicMath)
const SIN_TABLE = new Int32Array(512);
const COS_TABLE = new Int32Array(512);
const TAN_TABLE = new Int32Array(512);
const ACOS_TABLE = new Int32Array(512);

for (let i = 0; i < 512; i++) {
    SIN_TABLE[i] = Math.round(Math.sin((i / 512) * 2 * Math.PI) * 1024);
    COS_TABLE[i] = Math.round(Math.cos((i / 512) * 2 * Math.PI) * 1024);
    TAN_TABLE[i] = Math.round(Math.tan((i / 512) * 2 * Math.PI) * 1024);
}

for (let i = 0; i < 512; i++) {
    ACOS_TABLE[i] = Math.round(Math.acos((i / 512) * 2 - 1) * (512 / Math.PI));
}

// sqrt table
const sqrtTable = new Int32Array(1024);
for (let i = 0; i < 1024; i++) {
    sqrtTable[i] = Math.round(Math.sqrt(i) * 16);
}

class LogicMath {
    static Sin(angle) {
        return SIN_TABLE[angle & 0x1FF];
    }

    static Cos(angle) {
        return COS_TABLE[angle & 0x1FF];
    }

    static Tan(angle) {
        return TAN_TABLE[angle & 0x1FF];
    }

    static GetAngle(x, y) {
        if (x === 0 && y === 0) return 0;

        let result = 0;
        let absX = Math.abs(x);
        let absY = Math.abs(y);

        if (absX > absY) {
            result = Math.round((Math.atan2(absY, absX) / (2 * Math.PI)) * 512);
        } else {
            result = 128 - Math.round((Math.atan2(absX, absY) / (2 * Math.PI)) * 512);
        }

        if (x < 0) result = 256 - result;
        if (y < 0) result = 512 - result;

        return result & 0x1FF;
    }

    static GetAngleBetween(angle1, angle2) {
        let result = angle2 - angle1;
        if (result > 256) result -= 512;
        if (result < -256) result += 512;
        return result;
    }

    static GetRotatedX(x, y, angle) {
        return (x * COS_TABLE[angle & 0x1FF] - y * SIN_TABLE[angle & 0x1FF]) >> 10;
    }

    static GetRotatedY(x, y, angle) {
        return (x * SIN_TABLE[angle & 0x1FF] + y * COS_TABLE[angle & 0x1FF]) >> 10;
    }

    static Sqrt(value) {
        if (value >= 0x1000000) {
            let num;
            if (value >= 0x100000000) {
                return -1;
            } else if (value >= 0x10000000) {
                num = sqrtTable[value >>> 24] << 8;
            } else if (value >= 0x4000000) {
                num = sqrtTable[value >>> 22] << 7;
            } else if (value >= 0x1000000) {
                num = sqrtTable[value >>> 20] << 6;
            }
            num = (num + 1 + value / num) >> 1;
            num = (num + 1 + value / num) >> 1;
            return num * num <= value ? num : num - 1;
        }

        if (value >= 0x10000) {
            let num;
            if (value >= 0x100000) {
                if (value >= 0x400000) {
                    num = sqrtTable[value >>> 18] << 5;
                } else {
                    num = sqrtTable[value >>> 16] << 4;
                }
            } else {
                if (value >= 0x40000) {
                    num = sqrtTable[value >>> 14] << 3;
                } else {
                    num = sqrtTable[value >>> 12] << 2;
                }
            }
            num = (num + 1 + value / num) >> 1;
            return num * num <= value ? num : num - 1;
        }

        if (value >= 0x100) {
            let num;
            if (value >= 0x1000) {
                if (value >= 0x4000) {
                    num = sqrtTable[value >>> 8] + 1;
                } else {
                    num = (sqrtTable[value >>> 6] >> 1) + 1;
                }
            } else if (value >= 0x400) {
                num = (sqrtTable[value >>> 4] >> 2) + 1;
            } else {
                num = (sqrtTable[value >>> 2] >> 3) + 1;
            }
            return num * num <= value ? num : num - 1;
        }

        if (value >= 0) {
            return sqrtTable[value] >> 4;
        }

        return -1;
    }

    static Abs(value) {
        return value < 0 ? -value : value;
    }

    static Clamp(clampValue, minValue, maxValue) {
        if (clampValue >= maxValue) return maxValue;
        if (clampValue <= minValue) return minValue;
        return clampValue;
    }

    static Max(valueA, valueB) {
        return valueA >= valueB ? valueA : valueB;
    }

    static Min(valueA, valueB) {
        return valueA <= valueB ? valueA : valueB;
    }

    static GetRadius(x, y) {
        x = LogicMath.Abs(x);
        y = LogicMath.Abs(y);
        const maxValue = LogicMath.Max(x, y);
        const minValue = LogicMath.Min(x, y);
        return maxValue + (53 * minValue >> 7);
    }
}

module.exports = { LogicMath };
