'use strict';

const fs = require('fs');
const { EventData } = require('./EventData');
const { DataTables } = require('./DataTables');
const { DataType } = require('./DataTables');
const { LogicJSONParser } = require('./LogicJSONParser');

class Events {
    static REFRESH_MINUTES = 60;
    static RefreshTimer = null;
    static ConfigSlots = [];
    static Slots = new Map();

    static Init() {
        Events.LoadSettings();
        Events.Slots = new Map();
        Events.RefreshTimer = setInterval(() => Events.RefreshTimerElapsed(), Events.REFRESH_MINUTES * 60 * 1000);
        Events.GenerateEvents();
    }

    static GenerateEvents() {
        for (const config of Events.ConfigSlots) {
            Events.Slots.set(config.Slot, Events.GenerateEvent(config.AllowedModes, config.Slot));
        }
    }

    static RefreshTimerElapsed() {
        Events.GenerateEvents();
    }

    static GenerateEvent(gameModes, slot) {
        const dt = DataTables.Get(DataType.Location);
        if (!dt) return null;
        const count = dt.Count;
        while (true) {
            const location = dt.GetDataWithId(Math.floor(Math.random() * count));
            if (location && gameModes.includes(location.GameMode) && location.Name !== 'Tutorial') {
                console.log(location.Name);
                const ev = new EventData();
                ev.EndTime = new Date(Date.now() + Events.REFRESH_MINUTES * 60 * 1000);
                ev.LocationId = location.GetGlobalId();
                ev.Slot = slot;
                return ev;
            }
        }
    }

    static LoadSettings() {
        try {
            const content = fs.readFileSync('./gameplay.json', 'utf8');
            const settings = LogicJSONParser.ParseObject(content);
            const slots = settings.GetJSONArray('slots');
            Events.ConfigSlots = [];

            for (let i = 0; i < slots.Size(); i++) {
                const config = {};
                const slot = slots.GetJSONObject(i);
                config.Slot = slot.GetJSONNumber('slot').GetIntValue();
                const gameModes = slot.GetJSONArray('game_modes');
                config.AllowedModes = [];
                for (let j = 0; j < gameModes.Size(); j++) {
                    config.AllowedModes.push(gameModes.GetJSONString(j).GetStringValue());
                }
                Events.ConfigSlots.push(config);
            }
        } catch (e) {
            console.error('LoadSettings error:', e.message);
        }
    }

    static GetEvent(i) {
        return Events.Slots.get(i) || null;
    }

    static HasSlot(slot) {
        return Events.Slots.has(slot);
    }

    static GetEvents() {
        return Array.from(Events.Slots.values());
    }
}

module.exports = { Events };
