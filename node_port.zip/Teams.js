'use strict';

const { TeamEntry } = require('./TeamEntry');

class Teams {
    static Entries = new Map();
    static TeamIdCounter = 0;

    static Init() {
        Teams.Entries = new Map();
        Teams.TeamIdCounter = 0;
    }

    static get Count() { return Teams.Entries.size; }

    static Create() {
        const entry = new TeamEntry();
        entry.Id = ++Teams.TeamIdCounter;
        Teams.Entries.set(entry.Id, entry);
        return entry;
    }

    static Remove(id) {
        Teams.Entries.delete(id);
    }

    static StartGame(team) {
        try {
            const { Matchmaking } = require('./Matchmaking');
            const { Sessions } = require('./Sessions');
            const { TeamGameStartingMessage } = require('./AllMessages');

            for (const member of team.Members) {
                const session = Sessions.GetSession(member.AccountId);
                if (session) {
                    const connection = session.Connection;
                    connection.Send(new TeamGameStartingMessage({ LocationId: team.LocationId }));
                    Matchmaking.RequestMatchmake(connection, team.EventSlot, team.Id);
                    member.IsReady = false;
                }
            }
        } catch (e) {
            console.error(e);
        }
    }

    static Get(id) {
        return Teams.Entries.get(id) || null;
    }
}

module.exports = { Teams };
