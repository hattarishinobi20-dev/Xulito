# RoyaleBrawl Server - Node.js Port

Port 1:1 do emulador de servidor Brawl Stars (RoyaleBrawl v1) de C# para Node.js.

## Estrutura

Todos os arquivos `.js` mantêm a mesma estrutura plana do zip original, com cada arquivo `.cs` convertido para `.js` com o mesmo nome.

## Requisitos

- Node.js >= 16.0.0
- MySQL Server

## Instalação

```bash
npm install
```

## Configuração

Edite `config.json`:

```json
{
  "udp_host": "0.0.0.0",
  "udp_port": 9449,
  "database_username": "root",
  "database_password": "",
  "database_name": "v1"
}
```

## Banco de Dados

Importe o arquivo `database.sql` no MySQL:

```bash
mysql -u root -p v1 < database.sql
```

## Executar

```bash
npm start
```

ou

```bash
node Program.js
```

## Portas

- TCP: 9339
- UDP: 9449 (configurável)

## Arquivos Principais

### Fundação (Titan)
- `ByteStream.js` - Serialização binária
- `BitStream.js` - Streams de bits
- `ChecksumEncoder.js` - Encoder com checksum
- `LogicMath.js` - Matemática do jogo
- `LogicVector2.js` - Vetores 2D
- `LogicRandom.js` - Gerador aleatório
- `LogicLong.js` - Inteiros 64-bit
- `LogicJSONParser.js` - Parser JSON customizado

### Dados (Logic/Data)
- `DataTables.js` - Carregamento de tabelas CSV
- `DataTable.js` - Tabela individual
- `DataTypes.js` - Tipos de dados (Character, Projectile, etc.)
- `GlobalId.js` - IDs globais do jogo

### Mensagens
- `GameMessage.js` - Classe base de mensagens
- `MessageFactory.js` - Fábrica de mensagens
- `AllMessages.js` - Todas as mensagens implementadas

### Batalha
- `BattleMode.js` - Modo de batalha principal
- `BattlePlayer.js` - Jogador na batalha
- `ClientInput.js` - Input do cliente

### Home/Avatar
- `ClientHome.js` - Dados da home
- `ClientAvatar.js` - Dados do avatar
- `HomeMode.js` - Modo home
- `Hero.js` - Herói/Brawler

### Teams
- `TeamEntry.js` - Entrada de time
- `TeamStreamEntries.js` - Streams de time

### Rede
- `TCPGateway.js` - Gateway TCP
- `UDPGateway.js` - Gateway UDP
- `Connection.js` - Conexão
- `Sessions.js` - Sessões ativas
- `Processor.js` - Processador de mensagens
- `RC4Encrypter.js` - Criptografia RC4

### Servidor
- `Program.js` - Entry point
- `Resources.js` - Inicialização de recursos
- `Accounts.js` - Gerenciamento de contas
- `Battles.js` - Gerenciamento de batalhas
- `Events.js` - Eventos do jogo
- `Matchmaking.js` - Matchmaking
- `Teams.js` - Gerenciamento de times

## Diferenças do Original C#

1. **Namespaces** → Módulos CommonJS (`require`/`module.exports`)
2. **Classes estáticas** → Objetos exportados
3. **Threading** → `setInterval`/`setTimeout` (Node.js é single-threaded)
4. **ConcurrentDictionary** → `Map`
5. **System.Net.Sockets** → `net` (TCP) e `dgram` (UDP)
6. **MySql.Data** → `mysql2/promise`
7. **Reflection (CSV loading)** → Sistema de propriedades customizado
8. **RC4** → Implementação JavaScript pura

## Notas

- O port mantém a mesma lógica binária do original para compatibilidade com o cliente
- A estrutura de mensagens e encoding é 1:1 com o C#
- Os CSVs são carregados da mesma forma que no original
- O sistema de batalha funciona com ticks a 20Hz (50ms por tick)

## Licença

Mesma licença do projeto original RoyaleBrawl v1.
