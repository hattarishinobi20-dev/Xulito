'use strict';

const { GlobalId } = require('./GlobalId');
const { LogicMath } = require('./LogicMath');
const { LogicVector2 } = require('./LogicVector2');
const { ByteStreamHelper } = require('./ByteStreamHelper');
const { PlayerDisplayData } = require('./PlayerDisplayData');

class PlayerKillEntry {
    constructor() { this.PlayerIndex = 0; this.BountyStarsEarned = 0; }
}

class BattlePlayer {
    constructor(home, avatar) {
        this.AccountId = 0;
        this.PlayerIndex = 0;
        this.TeamIndex = 0;
        this.TeamId = -1;
        this.DisplayData = new PlayerDisplayData();
        this.CharacterId = 0;
        this.SkinId = 0;
        this.SessionId = 0;
        this.GameListener = null;
        this.OwnObjectId = 0;
        this.LastHandledInput = 0;
        this.Trophies = 0;
        this.HighestTrophies = 0;
        this.HeroPowerLevel = 0;
        this.Score = 0;
        this.SpawnPoint = new LogicVector2();
        this.StartUsingPinTicks = -9999;
        this.PinIndex = 0;
        this.Bot = false;
        this.UltiCharge = 0;
        this.IsAlive = true;
        this.BattleRoyaleRank = -1;
        this.KillList = [];
        this.Kills = 0;
        this.Damage = 0;
        this.Heals = 0;
        this.Home = home || null;
        this.Avatar = avatar || null;
    }

    Healed(heals) { this.Heals += heals; }
    DamageDealed(damage) { this.Damage += damage; }

    KilledPlayer(index, bountyStars) {
        this.KillList.push({ PlayerIndex: index, BountyStarsEarned: bountyStars });
        this.Kills++;
    }

    HasUlti() { return this.UltiCharge >= 1000; }
    GetUltiCharge() { return this.UltiCharge; }

    AddUltiCharge(amount) {
        this.UltiCharge = LogicMath.Min(1000, this.UltiCharge + amount);
    }

    ChargeUlti(CharacterData, a2) {
        if (CharacterData) {
            const result = CharacterData.UltiChargeDiv;
            if (result !== 0) {
                const v5 = CharacterData.UltiChargeMul * a2;
                let v6 = this.UltiCharge + Math.floor(v5 / result);
                if (v6 > 1000) v6 = 1000;
                this.UltiCharge = v6;
            }
        }
    }

    UseUlti() { this.UltiCharge = 0; }
    IsBot() { return this.Bot; }
    AddScore(a) { this.Score += a; }
    ResetScore() { this.Score = 0; }

    UsePin(index, ticks) { this.StartUsingPinTicks = ticks; this.PinIndex = index; }
    IsUsingPin(ticks) { return ticks - this.StartUsingPinTicks < 80; }
    GetPinIndex() { return this.PinIndex; }
    GetPinUseCooldown(ticks) { return this.StartUsingPinTicks + 100; }
    GetScore() { return this.Score; }

    SetSpawnPoint(x, y) { this.SpawnPoint.Set(x, y); }
    GetSpawnPoint() { return this.SpawnPoint.Clone(); }

    Encode(stream) {
        stream.WriteLong(this.AccountId);
        stream.WriteString(this.DisplayData.Name);
        stream.WriteVInt(this.PlayerIndex);
        stream.WriteVInt(this.TeamIndex);
        stream.WriteVInt(0);
        stream.WriteVInt(0);
        stream.WriteInt(0);
        ByteStreamHelper.WriteDataReference(stream, this.CharacterId);
        ByteStreamHelper.WriteDataReference(stream, null);
        stream.WriteInt(0);
    }

    static Create(home, avatar, playerIndex, teamIndex) {
        const player = new BattlePlayer(home, avatar);
        player.DisplayData.Name = avatar.Name;
        player.DisplayData.ThumbnailId = home.ThumbnailId;
        player.AccountId = avatar.AccountId;
        player.CharacterId = home.CharacterId;
        player.SkinId = 0;
        player.PlayerIndex = playerIndex;
        player.TeamIndex = teamIndex;
        const hero = avatar.GetHero(home.CharacterId);
        if (hero) {
            player.Trophies = hero.Trophies;
            player.HighestTrophies = hero.HighestTrophies;
        }
        return player;
    }

    static CreateBotInfo(name, playerIndex, teamIndex, character) {
        character = character || 16000000;
        const player = new BattlePlayer();
        player.DisplayData.Name = name;
        player.DisplayData.ThumbnailId = GlobalId.CreateGlobalId(28, 0);
        player.AccountId = 100000 + playerIndex;
        player.CharacterId = character;
        player.PlayerIndex = playerIndex;
        player.TeamIndex = teamIndex;
        player.SessionId = -1;
        player.Bot = true;
        return player;
    }
}

module.exports = { BattlePlayer, PlayerKillEntry };
