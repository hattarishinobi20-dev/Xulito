'use strict';

const path = require('path');
const { Table } = require('./Table');
const { Gamefiles } = require('./Gamefiles');
const { DataType, DataTypes, Types } = require('./DataTables.Types');
const {
    ProjectileData, AllianceBadgeData, LocationData, CharacterData,
    AreaEffectData, ItemData, SkillData, CardData, TileData,
    PlayerThumbnailData, SkinData
} = require('./DataTypes');
const { Debugger } = require('./Debugger');

// Populate DataTypes and Types maps
DataTypes.set(DataType.Projectile, ProjectileData);
DataTypes.set(DataType.AllianceBadge, AllianceBadgeData);
DataTypes.set(DataType.Location, LocationData);
DataTypes.set(DataType.Character, CharacterData);
DataTypes.set(DataType.AreaEffect, AreaEffectData);
DataTypes.set(DataType.Item, ItemData);
DataTypes.set(DataType.Skill, SkillData);
DataTypes.set(DataType.Card, CardData);
DataTypes.set(DataType.Tile, TileData);
DataTypes.set(DataType.PlayerThumbnail, PlayerThumbnailData);
DataTypes.set(DataType.Skin, SkinData);

for (const [key, value] of DataTypes) {
    Types.set(value, key);
}

const GamefilesMap = {};
let Tables = null;

const DataTables = {
    Gamefiles: GamefilesMap,

    AddFilesToLoad() {
        const assetsDir = path.join(__dirname, 'Assets', 'csv_logic');
        GamefilesMap[DataType.Projectile] = path.join(assetsDir, 'projectiles.csv');
        GamefilesMap[DataType.AllianceBadge] = path.join(assetsDir, 'alliance_badges.csv');
        GamefilesMap[DataType.Location] = path.join(assetsDir, 'locations.csv');
        GamefilesMap[DataType.Character] = path.join(assetsDir, 'characters.csv');
        GamefilesMap[DataType.AreaEffect] = path.join(assetsDir, 'area_effects.csv');
        GamefilesMap[DataType.Item] = path.join(assetsDir, 'items.csv');
        GamefilesMap[DataType.Skill] = path.join(assetsDir, 'skills.csv');
        GamefilesMap[DataType.Card] = path.join(assetsDir, 'cards.csv');
        GamefilesMap[DataType.Tile] = path.join(assetsDir, 'tiles.csv');
        GamefilesMap[DataType.PlayerThumbnail] = path.join(assetsDir, 'player_thumbnails.csv');
        GamefilesMap[DataType.Skin] = path.join(assetsDir, 'skins.csv');
    },

    Load() {
        DataTables.AddFilesToLoad();
        Tables = new Gamefiles();

        for (const [dataType, filePath] of Object.entries(GamefilesMap)) {
            try {
                const table = new Table(filePath);
                Tables.Initialize(table, parseInt(dataType));
            } catch (e) {
                console.error(`Failed to load ${filePath}: ${e.message}`);
            }
        }

        Debugger.Print(`${Object.keys(GamefilesMap).length} Data Tables initialized!`);
    },

    TableExists(t) {
        return Tables ? Tables.ContainsTable(t) : false;
    },

    Get(classIdOrDataType) {
        if (!Tables) return null;
        return Tables.Get(typeof classIdOrDataType === 'number' ? classIdOrDataType : classIdOrDataType);
    },

    Create(file, row, dataTable) {
        const Constructor = DataTypes.get(file);
        if (Constructor) {
            return new Constructor(row, dataTable);
        }
        return null;
    }
};

module.exports = { DataTables, DataType };
