'use strict';

const { LogicGameListener } = require('./LogicGameListener');

class UDPGameListener extends LogicGameListener {
    constructor(socket, connection) {
        super();
        this.Socket = socket;
        this.TCPConnection = connection;
    }

    SendMessage(message) {
        this.Socket.SendMessage(message);
    }

    SendTCPMessage(message) {
        try {
            this.TCPConnection.Send(message);
        } catch (e) {
            console.error(e);
        }
    }
}

module.exports = { UDPGameListener };
