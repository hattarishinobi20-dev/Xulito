'use strict';

class LogicRandom {
    constructor(seed) {
        this.Seed = seed || 0;
    }

    GetIteratedRandomSeed() {
        return this.Seed;
    }

    SetIteratedRandomSeed(value) {
        this.Seed = value;
    }

    Rand(max) {
        if (max > 0) {
            this.Seed = this.IterateRandomSeed();
            let tmpVal = this.Seed;
            if (tmpVal < 0) tmpVal = -tmpVal;
            return tmpVal % max;
        }
        return 0;
    }

    IterateRandomSeed() {
        let seed = this.Seed;
        if (seed === 0) seed = -1;

        let tmp = (seed ^ (seed << 13)) | 0;
        tmp = (tmp ^ (tmp >>> 17)) | 0;
        let tmp2 = (tmp ^ (32 * tmp)) | 0;
        return tmp2;
    }

    Decode(stream) {
        this.Seed = stream.ReadVInt();
    }

    Encode(stream) {
        stream.WriteVInt(this.Seed);
    }
}

module.exports = { LogicRandom };
