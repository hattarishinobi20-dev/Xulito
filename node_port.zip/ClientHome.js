'use strict';

const { ByteStreamHelper } = require('./ByteStreamHelper');
const { GlobalId } = require('./GlobalId');
const { DataTables } = require('./DataTables');
const { DataType } = require('./DataTables');
const { EventData, Milestones } = require('./EventData');

class ClientHome {
    constructor() {
        this.HomeId = 0;
        this.ThumbnailId = GlobalId.CreateGlobalId(28, 0);
        this.CharacterId = GlobalId.CreateGlobalId(16, 0);
        this.TrophiesReward = 0;
        this.TokenReward = 0;
        this.TrophyRoadProgress = 1;
        this.Milestones = new Milestones();
        this.Events = [];
        this.LastVisitHomeTime = new Date(0);
        this.HomeMode = null;
    }

    get Thumbnail() {
        const dt = DataTables.Get(DataType.PlayerThumbnail);
        return dt ? dt.GetDataByGlobalId(this.ThumbnailId) : null;
    }

    get Character() {
        const dt = DataTables.Get(DataType.Character);
        return dt ? dt.GetDataByGlobalId(this.CharacterId) : null;
    }

    HomeVisited() {
        this.LastVisitHomeTime = new Date();
    }

    Tick() {
        this.LastVisitHomeTime = new Date();
        this.TokenReward = 0;
        this.TrophiesReward = 0;
    }

    Encode(encoder) {
        const utcNow = new Date();
        encoder.WriteVInt(utcNow.getUTCHours() * 3600 + utcNow.getUTCMinutes() * 60 + utcNow.getUTCSeconds());
        encoder.WriteVInt(0);
        encoder.WriteVInt(this.HomeMode.Avatar.Trophies);
        encoder.WriteVInt(this.HomeMode.Avatar.HighestTrophies);
        encoder.WriteVInt(99999);
        ByteStreamHelper.WriteDataReference(encoder, this.Thumbnail);
        encoder.WriteVInt(7);
        for (let i = 0; i < 7; i++) encoder.WriteVInt(i);
        encoder.WriteVInt(0);
        encoder.WriteVInt(0);
        encoder.WriteBoolean(false);
        encoder.WriteVInt(0);
        encoder.WriteVInt(this.TokenReward);
        encoder.WriteVInt(0);
        encoder.WriteBoolean(false);
        encoder.WriteVInt(0);
        encoder.WriteVInt(0);
        encoder.WriteBoolean(false);
        this.TokenReward = 0;
        encoder.WriteVInt(utcNow.getUTCFullYear() * 1000 + Math.floor((utcNow - new Date(utcNow.getUTCFullYear(), 0, 0)) / 86400000));
        encoder.WriteVInt(100);
        encoder.WriteVInt(10);
        encoder.WriteVInt(20);
        encoder.WriteVInt(50);
        encoder.WriteVInt(50);
        encoder.WriteVInt(1000);
        encoder.WriteVInt(7 * 24);
        encoder.WriteVInt(1);
        encoder.WriteVInt(2);
        encoder.WriteVInt(10);
        encoder.WriteVInt(60);
        encoder.WriteVInt(3);
        encoder.WriteVInt(10);
        encoder.WriteVInt(70);
        encoder.WriteVInt(600);
        encoder.WriteVInt(4);
        for (let i = 1; i <= 4; i++) {
            encoder.WriteVInt(i);
            encoder.WriteVInt(0);
        }
        encoder.WriteVInt(this.Events.length);
        for (const data of this.Events) {
            data.Encode(encoder);
        }
        encoder.WriteVInt(0);
        encoder.WriteVInt(5);
        for (let i = 1; i <= 5; i++) encoder.WriteVInt(i);
        this.Milestones.WriteMilestones(encoder);
        encoder.WriteLong(this.HomeId);
    }
}

module.exports = { ClientHome };
