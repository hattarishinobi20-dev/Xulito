'use strict';

const { LogicServerListener } = require('./LogicServerListener');
const { Accounts } = require('./Accounts');
const { Sessions } = require('./Sessions');

class ServerListener extends LogicServerListener {
    GetAvatar(id) {
        return Accounts.Load(id).then(a => a ? a.Avatar : null);
    }

    GetGameListener(id) {
        if (Sessions.IsSessionActive(id)) {
            return Sessions.GetSession(id).GameListener;
        }
        return null;
    }

    GetHomeMode(id) {
        if (Sessions.IsSessionActive(id)) {
            return Sessions.GetSession(id).Home;
        }
        return null;
    }

    IsPlayerOnline(id) {
        return Sessions.IsSessionActive(id);
    }
}

module.exports = { ServerListener };
