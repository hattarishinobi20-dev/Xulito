'use strict';

class Debugger {
    static Print(message) {
        console.log('[DEBUG] ' + message);
    }

    static Error(message) {
        console.error('[ERROR] ' + message);
    }

    static Warning(message) {
        console.warn('[WARNING] ' + message);
    }

    static DoAssert(condition, message) {
        if (!condition) {
            console.error('[ASSERT] ' + message);
            return false;
        }
        return true;
    }
}

module.exports = { Debugger };
