'use strict';

const { GlobalId } = require('./GlobalId');

class DataTable {
    constructor(table, index) {
        this.Datas = [];
        this.Index = index || 0;

        if (table) {
            const { DataTables } = require('./DataTables');
            for (let i = 0; i < table.GetRowCount(); i += 2) {
                const row = table.GetRowAt(i);
                const data = DataTables.Create(this.Index, row, this);
                this.Datas.push(data);
            }
        }
    }

    get Count() {
        return this.Datas ? this.Datas.length : 0;
    }

    GetDatas() {
        return this.Datas;
    }

    GetProjectileDataWithName(name) {
        for (const data of this.Datas) {
            if (data.GetName() === name) return data;
        }
        return null;
    }

    GetDataWithId(id) {
        return this.Datas[GlobalId.GetInstanceId(id)];
    }

    GetData(nameOrId) {
        if (typeof nameOrId === 'string') {
            return this.Datas.find(d => d.GetName() === nameOrId) || null;
        }
        if (this.Datas.length < nameOrId) return null;
        return this.Datas[nameOrId] || null;
    }

    GetDataByGlobalId(id) {
        id = GlobalId.GetInstanceId(id);
        if (this.Datas.length < id) return null;
        return this.Datas[id] || null;
    }

    GetInstanceId(name) {
        const data = this.Datas.find(d => d.GetName() === name);
        return data ? data.GetInstanceId() : -1;
    }

    GetIndex() {
        return this.Index;
    }
}

module.exports = { DataTable };
