'use strict';

const { BattleMode } = require('./BattleMode');

class Battles {
    static m_battleIdCounter = 0;
    static m_battles = new Map();

    static Init() {
        Battles.m_battles = new Map();
        Battles.m_battleIdCounter = 0;
        setInterval(() => Battles.Update(), 1000);
    }

    static Update() {
        for (const [id, battle] of Battles.m_battles) {
            if (battle.IsGameOver) {
                Battles.m_battles.delete(id);
            }
        }
    }

    static Add(battle) {
        const id = ++Battles.m_battleIdCounter;
        Battles.m_battles.set(id, battle);
        return id;
    }

    static Get(id) {
        return Battles.m_battles.get(id) || null;
    }
}

module.exports = { Battles };
