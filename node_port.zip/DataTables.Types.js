'use strict';

const DataType = {
    Projectile: 6,
    AllianceBadge: 8,
    Location: 15,
    Character: 16,
    AreaEffect: 17,
    Item: 18,
    Skill: 20,
    Card: 23,
    Tile: 27,
    PlayerThumbnail: 28,
    Skin: 29
};

// Will be populated after all data classes are defined
const DataTypes = new Map();
const Types = new Map();

module.exports = { DataType, DataTypes, Types };
