'use strict';

class BitStream {
    constructor(lengthOrBuffer, length) {
        if (Buffer.isBuffer(lengthOrBuffer) || ArrayBuffer.isView(lengthOrBuffer)) {
            this.buffer = Buffer.isBuffer(lengthOrBuffer) ? lengthOrBuffer : Buffer.from(lengthOrBuffer);
            this.length = length || lengthOrBuffer.length;
        } else {
            this.buffer = Buffer.alloc(lengthOrBuffer || 10);
            this.length = lengthOrBuffer || 10;
        }
        this.offset = 0;
        this.bitOffset = 0;
    }

    GetLength() {
        if (this.length > this.offset) return this.length;
        return this.offset;
    }

    GetByteArray() {
        return this.buffer;
    }

    EnsureCapacity(bytes) {
        if (this.offset + bytes >= this.buffer.length) {
            const newBuf = Buffer.alloc(Math.max(this.buffer.length * 2, this.offset + bytes + 10));
            this.buffer.copy(newBuf);
            this.buffer = newBuf;
        }
    }

    ReadBit() {
        if (this.offset >= this.buffer.length) return 0;
        const value = (this.buffer[this.offset] >> this.bitOffset) & 1;
        this.bitOffset++;
        if (this.bitOffset === 8) {
            this.bitOffset = 0;
            this.offset += 1;
        }
        return value;
    }

    ReadBytes(length) {
        const data = [];
        for (let i = 0; i < length;) {
            let value = 0;
            for (let p = 0; p < 8 && i < length; p++, i++) {
                value |= (this.ReadBit() << p);
            }
            data.push(value & 0xFF);
        }
        return Buffer.from(data);
    }

    ReadPositiveInt(bitsCount) {
        const bytes = this.ReadBytes(bitsCount);
        if (bytes.length === 1) return bytes[0];
        if (bytes.length === 2) return bytes.readUInt16LE(0);
        if (bytes.length === 3) return bytes[0] | (bytes[1] << 8) | (bytes[2] << 16);
        if (bytes.length === 4) return bytes.readInt32LE(0);
        return -1;
    }

    ReadInt(bits) {
        const v2 = 2 * this.ReadPositiveInt(1) - 1;
        return v2 * this.ReadPositiveInt(bits);
    }

    ReadIntMax32767() {
        return this.ReadInt(15);
    }

    ReadPositiveVIntMax255() {
        const v2 = this.ReadPositiveInt(3);
        return this.ReadPositiveInt(v2);
    }

    ReadPositiveIntMax15() {
        return this.ReadPositiveInt(4);
    }

    ReadPositiveIntMax32767() {
        return this.ReadPositiveInt(15);
    }

    ReadBoolean() {
        return this.ReadPositiveInt(1) === 1;
    }

    WriteBit(data) {
        if (this.bitOffset === 0) {
            this.EnsureCapacity(1);
            this.offset += 1;
            this.buffer[this.offset - 1] = 0;
        }
        let value = this.buffer[this.offset - 1];
        value &= ~(1 << this.bitOffset);
        value |= (data << this.bitOffset);
        this.buffer[this.offset - 1] = value & 0xFF;
        this.bitOffset = (this.bitOffset + 1) % 8;
    }

    WriteBits(bits, count) {
        let position = 0;
        for (let i = 0; i < count;) {
            for (let p = 0; p < 8 && i < count; i++, p++) {
                const value = (bits[position] >> p) & 1;
                this.WriteBit(value);
            }
            position++;
        }
    }

    WritePositiveInt(value, bits) {
        const buf = Buffer.alloc(4);
        buf.writeInt32LE(value, 0);
        this.WriteBits(buf, bits);
    }

    WritePositiveIntMax1(value) { this.WritePositiveInt(value, 1); }
    WritePositiveIntMax3(value) { this.WritePositiveInt(value, 2); }
    WritePositiveIntMax7(value) { this.WritePositiveInt(value, 3); }
    WritePositiveIntMax15(value) { this.WritePositiveInt(value, 4); }
    WritePositiveIntMax31(value) { this.WritePositiveInt(value, 5); }
    WritePositiveIntMax63(value) { this.WritePositiveInt(value, 6); }
    WritePositiveIntMax127(value) { this.WritePositiveInt(value, 7); }
    WritePositiveIntMax255(value) { this.WritePositiveInt(value, 8); }
    WritePositiveIntMax511(value) { this.WritePositiveInt(value, 9); }
    WritePositiveIntMax1023(value) { this.WritePositiveInt(value, 10); }
    WritePositiveIntMax2047(value) { this.WritePositiveInt(value, 11); }
    WritePositiveIntMax4095(value) { this.WritePositiveInt(value, 12); }
    WritePositiveIntMax8191(value) { this.WritePositiveInt(value, 13); }
    WritePositiveIntMax16383(value) { this.WritePositiveInt(value, 14); }
    WritePositiveIntMax32767(value) { this.WritePositiveInt(value, 15); }
    WritePositiveIntMax65535(value) { this.WritePositiveInt(value, 16); }
    WritePositiveIntMax131071(value) { this.WritePositiveInt(value, 17); }
    WritePositiveIntMax262143(value) { this.WritePositiveInt(value, 18); }
    WritePositiveIntMax524287(value) { this.WritePositiveInt(value, 19); }
    WritePositiveIntMax1048575(value) { this.WritePositiveInt(value, 20); }
    WritePositiveIntMax2097151(value) { this.WritePositiveInt(value, 21); }
    WritePositiveIntMax4194303(value) { this.WritePositiveInt(value, 22); }

    WriteBoolean(value) {
        if (value) this.WritePositiveInt(1, 1);
        else this.WritePositiveInt(0, 1);
        return value;
    }

    WriteInt(value, bits) {
        let val = value;
        if (val <= -1) {
            this.WritePositiveInt(0, 1);
            val = -value;
        } else if (val >= 0) {
            this.WritePositiveInt(1, 1);
            val = value;
        }
        this.WritePositiveInt(val, bits);
    }

    WriteIntMax1(value) { this.WriteInt(value, 1); }
    WriteIntMax3(value) { this.WriteInt(value, 2); }
    WriteIntMax7(value) { this.WriteInt(value, 3); }
    WriteIntMax15(value) { this.WriteInt(value, 4); }
    WriteIntMax31(value) { this.WriteInt(value, 5); }
    WriteIntMax63(value) { this.WriteInt(value, 6); }
    WriteIntMax127(value) { this.WriteInt(value, 7); }
    WriteIntMax2047(value) { this.WriteInt(value, 11); }
    WriteIntMax16383(value) { this.WriteInt(value, 14); }
    WriteIntMax65535(value) { this.WriteInt(value, 16); }

    WritePositiveVInt(value, bits) {
        let v3 = 1;
        let v7 = value;
        if (v7 !== 0) {
            if (v7 < 1) {
                v3 = 0;
            } else {
                let v8 = v7;
                v3 = 0;
                do {
                    v3 += 1;
                    v8 >>= 1;
                } while (v8 !== 0);
            }
        }
        this.WritePositiveInt(v3 - 1, bits);
        this.WritePositiveInt(v7, v3);
    }

    WritePositiveVIntMax255OftenZero(value) {
        if (value === 0) {
            this.WritePositiveInt(1, 1);
            return;
        }
        this.WritePositiveInt(0, 1);
        this.WritePositiveVInt(value, 3);
    }

    WritePositiveVIntMax65535OftenZero(value) {
        if (value === 0) {
            this.WritePositiveInt(1, 1);
            return;
        }
        this.WritePositiveInt(0, 1);
        this.WritePositiveVInt(value, 4);
    }

    WritePositiveVIntMax65535(value) {
        this.WritePositiveVInt(value, 4);
    }

    WritePositiveVIntMax255(value) {
        this.WritePositiveVInt(value, 3);
    }

    WriteByte(value) {
        this.EnsureCapacity(1);
        this.bitOffset = 0;
        this.buffer[this.offset] = value;
        this.offset += 1;
    }

    GetOffset() {
        return this.offset;
    }
}

module.exports = { BitStream };
