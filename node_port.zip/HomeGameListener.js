'use strict';

const { LogicGameListener } = require('./LogicGameListener');

class HomeGameListener extends LogicGameListener {
    constructor(connection) {
        super();
        this.Connection = connection;
    }

    SendMessage(message) {
        this.Connection.Send(message);
    }

    SendTCPMessage(message) {
        this.Connection.Send(message);
    }
}

module.exports = { HomeGameListener };
