'use strict';

const { Accounts } = require('./Accounts');
const { DataTables } = require('./DataTables');
const { Events } = require('./Events');
const { Sessions } = require('./Sessions');
const { Battles } = require('./Battles');
const { Matchmaking } = require('./Matchmaking');
const { Teams } = require('./Teams');
const { Processor } = require('./Processor');
const { TCPGateway } = require('./TCPGateway');
const { UDPGateway } = require('./UDPGateway');
const { LogicServerListener } = require('./LogicServerListener');
const { ServerListener } = require('./ServerListener');

class Resources {
    static Configuration = null;

    static async InitDatabase() {
        await Accounts.Init(
            Resources.Configuration.database_username,
            Resources.Configuration.database_password,
            Resources.Configuration.database_name
        );
    }

    static InitLogic() {
        DataTables.Load();
        Events.Init();
        Sessions.Init();
        Battles.Init();
        Matchmaking.Init();
        Teams.Init();
    }

    static InitNetwork() {
        Processor.Init();
        LogicServerListener.Instance = new ServerListener();
        UDPGateway.Init('0.0.0.0', Resources.Configuration.udp_port);
        TCPGateway.Init('0.0.0.0', 9339);
    }
}

module.exports = { Resources };
