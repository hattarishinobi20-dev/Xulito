'use strict';

const fs = require('fs');
const path = require('path');
const { Resources } = require('./Resources');

const SERVER_VERSION = '1.2';
const BUILD_TYPE = 'Beta';

async function Main() {
    // Change to script directory
    process.chdir(__dirname);

    console.log(`
    ____                    __     ____                      __
   / __ \\____  __  ______ _/ /__  / __ )_________ __      __/ /
  / /_/ / __ \\/ / / / __ \`/ / _ \\/ __  / ___/ __ \`/ | /| / / / 
 / _, _/ /_/ / /_/ / /_/ / /  __/ /_/ / /  / /_/ /| |/ |/ / /  
/_/ |_|\\____/\\__, /\\__,_/_/\\___/_____/_/   \\__,_/ |__/|__/_/   
            /____/                                             


`);

    console.log('RoyaleBrawl Server Emulator is now starting...');

    // Load configuration
    const config = JSON.parse(fs.readFileSync('./config.json', 'utf8'));
    Resources.Configuration = config;

    // Initialize
    await Resources.InitDatabase();
    Resources.InitLogic();
    Resources.InitNetwork();

    console.log('Server started! Let\'s play Brawl Stars!');

    // Handle shutdown
    process.on('SIGINT', () => {
        console.log('\nShutting down...');
        process.exit(0);
    });

    process.on('SIGTERM', () => {
        console.log('\nShutting down...');
        process.exit(0);
    });
}

Main().catch(err => {
    console.error('Fatal error:', err);
    process.exit(1);
});
