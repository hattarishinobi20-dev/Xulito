const GameConfig = require("../Logic/Server/GameConfig")
const PlayerDatabase = require("./PlayerDatabase")
const Storage = require("./Storage")

const COLLECTION = "alliances"

/**
 * AllianceDatabase
 *
 * One document per alliance (club) in Storage collection "alliances" (MongoDB document /
 * Database/alliances/{id}.json). Alliances are kept in memory after init and written on every change.
 *
 * Alliance = { id, name, description, region, badge, type, requiredTrophies,
 *              members: [{ lowId, role }], stream: [entry], nextStreamId }
 * Roles (AllianceRole csv): 1 member, 2 leader, 3 elder, 4 co-leader.
 */
class AllianceDatabase {
    static alliances = new Map()
    static lastId = 0

    static init () {
        for (const [, alliance] of Storage.getAll(COLLECTION)) {
            AllianceDatabase.alliances.set(alliance.id, alliance)
            if (alliance.id > AllianceDatabase.lastId) AllianceDatabase.lastId = alliance.id
        }

        Log(`AllianceDatabase: ${AllianceDatabase.alliances.size} alliances loaded.`)
    }

    static save (alliance) {
        Storage.put(COLLECTION, alliance.id, alliance)
    }

    static remove (alliance) {
        AllianceDatabase.alliances.delete(alliance.id)
        Storage.remove(COLLECTION, alliance.id)
    }

    /**
     * @param { Number } id Alliance id
     * @returns { Object | null } Alliance
     */
    static get (id) {
        return AllianceDatabase.alliances.get(Number(id)) || null
    }

    /**
     * @returns { Array<Object> } All alliances
     */
    static getAll () {
        return Array.from(AllianceDatabase.alliances.values())
    }

    /**
     * Create an alliance with the player as leader
     * @param { Object } player Player
     * @param { Object } settings { name, description, badge, type, requiredTrophies }
     * @returns { Object } Alliance
     */
    static create (player, settings) {
        const alliance = {
            id: ++AllianceDatabase.lastId,
            name: settings.name,
            description: settings.description,
            region: player.region,
            badge: settings.badge,
            type: settings.type, // 1 open, 2 invite only, 3 closed
            requiredTrophies: settings.requiredTrophies,
            members: [{ lowId: player.lowId, role: 2 }],
            stream: [],
            nextStreamId: 1
        }

        AllianceDatabase.alliances.set(alliance.id, alliance)
        AllianceDatabase.save(alliance)

        return alliance
    }

    /**
     * Player object of a member (online session player when connected, else stored account)
     * @param { Number } lowId Account low id
     * @returns { Object | null } Player
     */
    static getMemberPlayer (lowId) {
        if (global.sessions) {
            for (const session of global.sessions.values()) {
                if (session.player && session.player.lowId === lowId) return session.player
            }
        }

        return PlayerDatabase.loadAccountByLowId(lowId)
    }

    /**
     * Sessions of the online members of the alliance
     * @param { Object } alliance Alliance
     * @returns { Array<Session> } Sessions
     */
    static getOnlineSessions (alliance) {
        const sessions = []

        if (!global.sessions) return sessions

        for (const session of global.sessions.values()) {
            if (session.player && session.player.allianceId === alliance.id && !session.destroyed) sessions.push(session)
        }

        return sessions
    }

    /**
     * Members with their player data
     * @param { Object } alliance Alliance
     * @returns { Array<Object> } [{ lowId, role, player }]
     */
    static getMembers (alliance) {
        const members = []

        for (const member of alliance.members) {
            const player = AllianceDatabase.getMemberPlayer(member.lowId)

            if (player) members.push({ lowId: member.lowId, role: member.role, player })
        }

        return members
    }

    static getMember (alliance, lowId) {
        return alliance.members.find(m => m.lowId === lowId) || null
    }

    static getTrophies (alliance) {
        return AllianceDatabase.getMembers(alliance).reduce((sum, m) => sum + m.player.trophies, 0)
    }

    static getOnlineMembersCount (alliance) {
        return AllianceDatabase.getOnlineSessions(alliance).length
    }

    /**
     * Add a member
     * @param { Object } alliance Alliance
     * @param { Object } player Player
     * @param { Number } role Role
     */
    static addMember (alliance, player, role = 1) {
        if (!AllianceDatabase.getMember(alliance, player.lowId)) alliance.members.push({ lowId: player.lowId, role })

        player.allianceId = alliance.id
        player.allianceRole = role

        PlayerDatabase.save(player)
        AllianceDatabase.save(alliance)
    }

    /**
     * Remove a member. The alliance is deleted when the last member leaves; the leadership is passed
     * to the highest ranked member when the leader leaves.
     * @param { Object } alliance Alliance
     * @param { Object } player Player
     */
    static removeMember (alliance, player) {
        const wasLeader = player.allianceRole === 2

        alliance.members = alliance.members.filter(m => m.lowId !== player.lowId)
        player.allianceId = 0
        player.allianceRole = 0
        PlayerDatabase.save(player)

        if (alliance.members.length === 0) return AllianceDatabase.remove(alliance)

        if (wasLeader) {
            const order = [4, 3, 1]
            const next = alliance.members.slice().sort((a, b) => order.indexOf(a.role) - order.indexOf(b.role))[0]

            AllianceDatabase.setRole(alliance, next.lowId, 2)
        }

        AllianceDatabase.save(alliance)
    }

    /**
     * Change the role of a member (updates the account too)
     * @param { Object } alliance Alliance
     * @param { Number } lowId Member low id
     * @param { Number } role New role
     */
    static setRole (alliance, lowId, role) {
        const member = AllianceDatabase.getMember(alliance, lowId)

        if (!member) return

        member.role = role

        const player = AllianceDatabase.getMemberPlayer(lowId)

        if (player) {
            player.allianceRole = role
            PlayerDatabase.save(player)
        }

        AllianceDatabase.save(alliance)
    }

    /**
     * Add a stream entry
     * @param { Object } alliance Alliance
     * @param { Object } entry { type (2 chat, 3 join request, 4 alliance event), playerId, playerName, playerRole, message, event, targetId, targetName }
     * @returns { Object } Stored entry
     */
    static addStreamEntry (alliance, entry) {
        const stored = {
            id: alliance.nextStreamId++,
            type: entry.type,
            playerId: entry.playerId,
            playerName: entry.playerName,
            playerRole: entry.playerRole || 0,
            message: entry.message || "",
            event: entry.event || 0,
            targetId: entry.targetId || 0,
            targetName: entry.targetName || "",
            responderName: "",
            timestamp: Math.floor(Date.now() / 1000)
        }

        alliance.stream.push(stored)

        while (alliance.stream.length > GameConfig.allianceStreamLength) alliance.stream.shift()

        AllianceDatabase.save(alliance)

        return stored
    }

    static getStreamEntry (alliance, id) {
        return alliance.stream.find(e => e.id === id) || null
    }

    /**
     * Alliances the player can join (open / invite only), largest first
     * @param { Number } maxLength Max results
     * @returns { Array<Object> } Alliances
     */
    static getJoinable (maxLength = 50) {
        return AllianceDatabase.getAll()
            .filter(a => a.type <= 2 && a.members.length < GameConfig.allianceMaxMembers)
            .sort((a, b) => b.members.length - a.members.length)
            .slice(0, maxLength)
    }

    /**
     * Search alliances by name (or by id when the query is a number)
     * @param { String } query Search text
     * @param { Number } maxLength Max results
     * @returns { Array<Object> } Alliances
     */
    static search (query, maxLength = 30) {
        const text = (query || "").trim().toLowerCase()
        const id = /^#?\d+$/.test(text) ? Number(text.replace("#", "")) : -1

        return AllianceDatabase.getAll()
            .filter(a => a.type <= 2 && (text === "" || a.name.toLowerCase().includes(text) || a.id === id))
            .slice(0, maxLength)
    }
}

module.exports = AllianceDatabase
