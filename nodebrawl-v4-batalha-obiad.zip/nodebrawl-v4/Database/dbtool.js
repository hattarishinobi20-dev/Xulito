/**
 * dbtool
 *
 * Maintenance for the MongoDB storage (GameConfig.database.mongodb):
 *
 *   node Database/dbtool.js migrate   copies Database/players/*.json, Database/alliances/*.json and
 *                                     Database/season.json into MongoDB (existing documents are replaced,
 *                                     the files are left untouched)
 *   node Database/dbtool.js export    writes every MongoDB document back to those JSON files (backup)
 *   node Database/dbtool.js stats     prints the document count per collection
 *   node Database/dbtool.js wipe      deletes every document of players / alliances / settings (tests)
 */
const fs = require("node:fs")
const path = require("node:path")
const { MongoClient } = require("mongodb")
const GameConfig = require("../Logic/Server/GameConfig")

const COLLECTIONS = { players: "players", alliances: "alliances", settings: "" }

const readDirectory = (dir) => {
    if (!fs.existsSync(dir)) return []

    return fs.readdirSync(dir).filter(f => f.endsWith(".json")).map(f => {
        const id = f.slice(0, -5)

        return [isNaN(Number(id)) ? id : Number(id), JSON.parse(fs.readFileSync(path.join(dir, f)))]
    })
}

const readCollectionFiles = (collection) => {
    if (collection === "settings") {
        const file = path.join(__dirname, "season.json")

        return fs.existsSync(file) ? [["season", JSON.parse(fs.readFileSync(file))]] : []
    }

    return readDirectory(path.join(__dirname, COLLECTIONS[collection]))
}

const writeCollectionFile = (collection, id, doc) => {
    const file = collection === "settings"
        ? path.join(__dirname, `${id}.json`)
        : path.join(__dirname, COLLECTIONS[collection], `${id}.json`)

    fs.mkdirSync(path.dirname(file), { recursive: true })
    fs.writeFileSync(file, JSON.stringify(doc, null, 4))
}

const main = async () => {
    const action = process.argv[2]

    if (!["migrate", "export", "stats", "wipe"].includes(action)) {
        console.log("usage: node Database/dbtool.js migrate | export | stats | wipe")
        process.exit(1)
    }

    const client = new MongoClient(process.env.MONGODB_URI || GameConfig.database.mongodb.uri, { serverSelectionTimeoutMS: 15000 })

    await client.connect()

    const db = client.db(GameConfig.database.mongodb.name || "nodebrawl")

    for (const collection of Object.keys(COLLECTIONS)) {
        const col = db.collection(collection)

        if (action === "stats") {
            console.log(`${collection}: ${await col.countDocuments()} documents`)
        } else if (action === "wipe") {
            const result = await col.deleteMany({})
            console.log(`${collection}: ${result.deletedCount} documents deleted`)
        } else if (action === "migrate") {
            const docs = readCollectionFiles(collection)

            for (const [id, doc] of docs) {
                delete doc._id
                await col.replaceOne({ _id: id }, doc, { upsert: true })
            }

            console.log(`${collection}: ${docs.length} documents written`)
        } else if (action === "export") {
            const docs = await col.find({}).toArray()

            for (const doc of docs) {
                const id = doc._id
                delete doc._id
                writeCollectionFile(collection, id, doc)
            }

            console.log(`${collection}: ${docs.length} documents exported`)
        }
    }

    await client.close()
}

main().catch(e => {
    console.error(e.message)
    process.exit(1)
})
