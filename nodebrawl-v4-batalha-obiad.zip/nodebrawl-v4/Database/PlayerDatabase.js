const GameConfig = require("../Logic/Server/GameConfig")
const Storage = require("./Storage")
const { generateRandomString } = require("../Utils/Random")

const COLLECTION = "players"

/**
 * PlayerDatabase
 *
 * One document per account in Storage collection "players" (MongoDB document / Database/players/{lowId}.json),
 * keyed by lowId. Every load returns a fresh copy; save() stores the given object.
 */
class PlayerDatabase {
    static tokens = {}

    static init () {
        for (const [lowId, data] of Storage.getAll(COLLECTION)) {
            if (data && data.token) PlayerDatabase.tokens[data.token] = Number(lowId)
        }

        Log(`PlayerDatabase: ${Object.keys(PlayerDatabase.tokens).length} accounts loaded.`)
    }

    static getNextLowId () {
        const ids = Object.values(PlayerDatabase.tokens)

        return ids.length === 0 ? 1 : Math.max(...ids) + 1
    }

    /**
     * Create new account
     * @param { String } token Account token (generated if empty)
     * @returns { Object } Account data
     */
    static createAccount (token) {
        const account = JSON.parse(JSON.stringify(GameConfig.defaultAccount))

        account.highId = 0
        account.lowId = PlayerDatabase.getNextLowId()
        account.token = token || generateRandomString(40)
        account.region = "EN"
        account.tutorialState = GameConfig.startingTutorialState
        account.homeNotifications = []

        PlayerDatabase.tokens[account.token] = account.lowId
        PlayerDatabase.save(account)

        return account
    }

    /**
     * Load account by token
     * @param { String } token Account token
     * @returns { Object | null } Account data
     */
    static loadAccountByToken (token) {
        const lowId = PlayerDatabase.tokens[token]

        if (!lowId) return null

        return PlayerDatabase.loadAccountByLowId(lowId)
    }

    /**
     * Load account by low id
     * @param { Number } lowId Account low id
     * @returns { Object | null } Account data
     */
    static loadAccountByLowId (lowId) {
        const account = Storage.get(COLLECTION, Number(lowId))

        if (!account) return null

        // Fill fields added after the account was created
        for (const key in GameConfig.defaultAccount) {
            if (account[key] === undefined) account[key] = JSON.parse(JSON.stringify(GameConfig.defaultAccount[key]))
        }

        return account
    }

    /**
     * Load all accounts
     * @returns { Array<Object> } Accounts data
     */
    static getAllAccounts () {
        const accounts = []

        for (const lowId of Object.values(PlayerDatabase.tokens)) {
            const account = PlayerDatabase.loadAccountByLowId(lowId)

            if (account) accounts.push(account)
        }

        return accounts
    }

    /**
     * Save account
     * @param { Object } account Account data
     */
    static save (account) {
        Storage.put(COLLECTION, account.lowId, account)
    }
}

module.exports = PlayerDatabase
