const fs = require("node:fs")
const path = require("node:path")
const GameConfig = require("../Logic/Server/GameConfig")

/**
 * Storage
 *
 * Persistence backend shared by PlayerDatabase, AllianceDatabase and LogicSeason. Synchronous API so the
 * callers (message handlers, admin console) stay unchanged:
 *
 *   get(collection, id)      -> document copy or null
 *   getAll(collection)       -> Map<id, document copy>
 *   put(collection, id, doc) -> stores a copy of doc
 *   remove(collection, id)
 *   refresh(collection, id)  -> async, re-reads one document from the backend (mongodb only)
 *
 * Driver "mongodb" (GameConfig.database): every collection is loaded into memory at init(); reads come from
 * memory, writes update memory and are flushed to MongoDB right away (replaceOne upsert / deleteOne, one
 * bulk write per collection, retried every RETRY_MS while the connection is down). The server process is the
 * only writer, so memory is authoritative.
 *
 * The NODEBRAWL_DB_DRIVER environment variable overrides GameConfig.database.driver (tests).
 *
 * Driver "json": one file per document (Database/<collection>/<id>.json, Database/<id>.json for the
 * "settings" collection). Files are read on every get() so they can be edited while the server runs.
 */
class Storage {
    static RETRY_MS = 5000
    static FILE_COLLECTIONS = { players: "players", alliances: "alliances", settings: "" }

    static driver = "json"
    static client = null
    static db = null
    static cache = new Map()   // collection -> Map<id, doc>
    static dirty = new Map()   // collection -> Set<id>
    static flushing = false
    static flushAgain = false
    static flushTimer = null
    static retryTimer = null
    static pending = Promise.resolve()

    static async init () {
        const config = GameConfig.database || { driver: "json" }
        const driver = process.env.NODEBRAWL_DB_DRIVER || config.driver

        Storage.driver = driver === "mongodb" ? "mongodb" : "json"

        if (Storage.driver === "json") {
            for (const collection in Storage.FILE_COLLECTIONS) {
                const dir = Storage.getDirectory(collection)
                if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true })
            }

            Log("Storage: json files (Database/).")
            return
        }

        const { MongoClient } = require("mongodb")
        const uri = process.env.MONGODB_URI || config.mongodb.uri

        Storage.client = new MongoClient(uri, { serverSelectionTimeoutMS: 15000 })
        await Storage.client.connect()
        Storage.db = Storage.client.db(config.mongodb.name || "nodebrawl")

        for (const collection of Object.keys(Storage.FILE_COLLECTIONS)) {
            const docs = await Storage.db.collection(collection).find({}).toArray()
            const map = new Map()

            for (const doc of docs) {
                const id = doc._id
                delete doc._id
                map.set(id, doc)
            }

            Storage.cache.set(collection, map)
            Storage.dirty.set(collection, new Set())
        }

        Log(`Storage: mongodb "${Storage.db.databaseName}" (${[...Storage.cache].map(([c, m]) => `${m.size} ${c}`).join(", ")}).`)

        for (const signal of ["SIGINT", "SIGTERM"]) {
            process.once(signal, async () => {
                await Storage.close()
                process.exit(0)
            })
        }
    }

    /**
     * Flushes pending writes and closes the connection
     */
    static async close () {
        if (Storage.driver !== "mongodb" || !Storage.client) return

        if (Storage.flushTimer) { clearImmediate(Storage.flushTimer); Storage.flushTimer = null }
        if (Storage.retryTimer) { clearTimeout(Storage.retryTimer); Storage.retryTimer = null }

        await Storage.flush()
        await Storage.pending
        await Storage.client.close()
        Storage.client = null
    }

    static clone (doc) {
        return JSON.parse(JSON.stringify(doc))
    }

    // json driver

    static getDirectory (collection) {
        return path.join(__dirname, Storage.FILE_COLLECTIONS[collection] || "")
    }

    static getFilePath (collection, id) {
        return path.join(Storage.getDirectory(collection), `${id}.json`)
    }

    static readFile (collection, id) {
        try {
            return JSON.parse(fs.readFileSync(Storage.getFilePath(collection, id)))
        } catch (e) {
            return null
        }
    }

    // api

    /**
     * @param { String } collection Collection name
     * @param { Number | String } id Document id
     * @returns { Object | null } Document copy
     */
    static get (collection, id) {
        if (Storage.driver === "json") return Storage.readFile(collection, id)

        const doc = Storage.cache.get(collection).get(Storage.key(id))

        return doc ? Storage.clone(doc) : null
    }

    /**
     * @param { String } collection Collection name
     * @returns { Map<Number | String, Object> } Document copies by id
     */
    static getAll (collection) {
        const result = new Map()

        if (Storage.driver === "json") {
            const dir = Storage.getDirectory(collection)

            if (collection === "settings" || !fs.existsSync(dir)) return result

            for (const file of fs.readdirSync(dir)) {
                if (!file.endsWith(".json")) continue

                const id = file.slice(0, -5)
                const doc = Storage.readFile(collection, id)

                if (doc) result.set(isNaN(Number(id)) ? id : Number(id), doc)
                else Warn(`Storage: unable to read ${collection}/${file}`)
            }

            return result
        }

        for (const [id, doc] of Storage.cache.get(collection)) result.set(id, Storage.clone(doc))

        return result
    }

    /**
     * @param { String } collection Collection name
     * @param { Number | String } id Document id
     * @param { Object } doc Document (a copy is stored)
     */
    static put (collection, id, doc) {
        if (Storage.driver === "json") {
            fs.writeFileSync(Storage.getFilePath(collection, id), JSON.stringify(doc, null, 4))
            return
        }

        Storage.cache.get(collection).set(Storage.key(id), Storage.clone(doc))
        Storage.markDirty(collection, id)
    }

    /**
     * @param { String } collection Collection name
     * @param { Number | String } id Document id
     */
    static remove (collection, id) {
        if (Storage.driver === "json") {
            try { fs.unlinkSync(Storage.getFilePath(collection, id)) } catch (e) { }
            return
        }

        Storage.cache.get(collection).delete(Storage.key(id))
        Storage.markDirty(collection, id)
    }

    /**
     * Re-reads a document from MongoDB (so it can be edited from outside while the server runs)
     * @param { String } collection Collection name
     * @param { Number | String } id Document id
     */
    static async refresh (collection, id) {
        if (Storage.driver !== "mongodb" || Storage.dirty.get(collection).has(Storage.key(id))) return

        const doc = await Storage.db.collection(collection).findOne({ _id: Storage.key(id) })

        if (!doc) return Storage.cache.get(collection).delete(Storage.key(id))

        delete doc._id
        Storage.cache.get(collection).set(Storage.key(id), doc)
    }

    // mongodb write-behind

    static key (id) {
        return typeof id === "string" && !isNaN(Number(id)) && id !== "" ? Number(id) : id
    }

    static markDirty (collection, id) {
        Storage.dirty.get(collection).add(Storage.key(id))

        if (!Storage.flushTimer) Storage.flushTimer = setImmediate(() => { Storage.flushTimer = null; Storage.flush() })
    }

    static flush () {
        if (Storage.flushing) {
            Storage.flushAgain = true
            return Storage.pending
        }

        Storage.flushing = true
        Storage.pending = Storage.doFlush().finally(() => {
            Storage.flushing = false

            if (Storage.flushAgain) {
                Storage.flushAgain = false
                Storage.flushTimer = Storage.flushTimer || setImmediate(() => { Storage.flushTimer = null; Storage.flush() })
            }
        })

        return Storage.pending
    }

    static async doFlush () {
        let failed = false

        for (const [collection, dirty] of Storage.dirty) {
            if (dirty.size === 0) continue

            const ids = Array.from(dirty)
            const cache = Storage.cache.get(collection)
            const operations = ids.map(id => {
                const doc = cache.get(id)

                return doc
                    ? { replaceOne: { filter: { _id: id }, replacement: doc, upsert: true } }
                    : { deleteOne: { filter: { _id: id } } }
            })

            dirty.clear()

            try {
                await Storage.db.collection(collection).bulkWrite(operations, { ordered: false })
            } catch (e) {
                failed = true
                for (const id of ids) dirty.add(id)
                Warn(`Storage: mongodb write of ${ids.length} ${collection} failed (${e.message}), retrying in ${Storage.RETRY_MS / 1000}s.`)
            }
        }

        if (failed && !Storage.retryTimer) {
            Storage.retryTimer = setTimeout(() => { Storage.retryTimer = null; Storage.flush() }, Storage.RETRY_MS)
        }
    }
}

module.exports = Storage
