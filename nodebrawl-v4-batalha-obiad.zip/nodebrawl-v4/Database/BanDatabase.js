const fs = require("node:fs")
const path = require("node:path")

const ACCOUNTS_PATH = path.join(__dirname, "banned_acc.json")
const IPS_PATH = path.join(__dirname, "banned_ip.json")

/**
 * BanDatabase
 *
 * Account / ip ban lists, same file format as Obiad Brawl v4 (banned_acc.json / banned_ip.json):
 * { "<lowId>": { "reason": "text" } } and { "<ip>": { "reason": "text" } }.
 * The files are read on every login so they can be edited while the server runs.
 */
class BanDatabase {
    static read (file) {
        try {
            if (!fs.existsSync(file)) return {}

            return JSON.parse(fs.readFileSync(file)) || {}
        } catch (e) {
            Warn(`BanDatabase: unable to read ${path.basename(file)}: ${e.message}`)
            return {}
        }
    }

    static write (file, data) {
        fs.writeFileSync(file, JSON.stringify(data, null, 4))
    }

    /**
     * @param { Number } lowId Account low id
     * @returns { String | null } Ban reason
     */
    static getAccountBan (lowId) {
        const entry = BanDatabase.read(ACCOUNTS_PATH)[String(lowId)]

        return entry ? entry.reason || "" : null
    }

    /**
     * @param { String } ip Ip address
     * @returns { String | null } Ban reason
     */
    static getIpBan (ip) {
        const entry = BanDatabase.read(IPS_PATH)[ip]

        return entry ? entry.reason || "" : null
    }

    static banAccount (lowId, reason) {
        const data = BanDatabase.read(ACCOUNTS_PATH)

        data[String(lowId)] = { reason }
        BanDatabase.write(ACCOUNTS_PATH, data)
    }

    static banIp (ip, reason) {
        const data = BanDatabase.read(IPS_PATH)

        data[ip] = { reason }
        BanDatabase.write(IPS_PATH, data)
    }

    static unbanAccount (lowId) {
        const data = BanDatabase.read(ACCOUNTS_PATH)

        delete data[String(lowId)]
        BanDatabase.write(ACCOUNTS_PATH, data)
    }

    static unbanIp (ip) {
        const data = BanDatabase.read(IPS_PATH)

        delete data[ip]
        BanDatabase.write(IPS_PATH, data)
    }

    /**
     * Check the ban lists for a login. Like Obiad, a banned account bans the ip and a banned ip bans the account.
     * @param { Number } lowId Account low id
     * @param { String } ip Ip address (without port)
     * @returns { String | null } Ban reason, null when not banned
     */
    static check (lowId, ip) {
        const accountReason = BanDatabase.getAccountBan(lowId)

        if (accountReason !== null) {
            if (ip && BanDatabase.getIpBan(ip) === null) BanDatabase.banIp(ip, accountReason)

            return accountReason
        }

        const ipReason = ip ? BanDatabase.getIpBan(ip) : null

        if (ipReason !== null) {
            BanDatabase.banAccount(lowId, ipReason)

            return ipReason
        }

        return null
    }
}

module.exports = BanDatabase
