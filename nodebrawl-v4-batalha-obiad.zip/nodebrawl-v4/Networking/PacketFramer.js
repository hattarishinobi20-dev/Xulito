const LogicConfig = require("../Logic/Server/LogicConfig")

/**
 * PacketFramer
 *
 * Splits the TCP byte stream of a session into complete Supercell packets
 * (7 byte header: id u16, length u24, version u16, then `length` payload bytes).
 *
 * Replaces the `Queue` based handling of index.js: TCP does not preserve message
 * boundaries, so one `data` event can hold several packets, a packet can be split
 * across several `data` events, and both can happen at once (N complete packets
 * followed by the beginning of the next one). `Queue.unmerge` dispatched such a
 * trailing partial packet with a truncated payload and then parsed the rest of it as a
 * new header (garbage id / length), after which the session never released again and
 * was destroyed on overfilling. The framer keeps the unread bytes until the whole
 * packet arrived and dispatches the packets one by one, in order.
 */
class PacketFramer {
    static HEADER_LENGTH = 7

    /**
     * @param { Session } session User session
     * @param { MessagesHandler } messageHandler Handler which dispatches complete packets
     */
    constructor (session, messageHandler) {
        this.session = session
        this.messageHandler = messageHandler
        this.buffer = Buffer.alloc(0)
        this.chain = Promise.resolve()
        this.closed = false
    }

    /**
     * Push bytes received from the socket.
     * @param { Buffer } bytes
     */
    push (bytes) {
        if (this.closed) return

        this.buffer = this.buffer.length === 0 ? bytes : Buffer.concat([this.buffer, bytes])

        while (!this.closed && this.buffer.length >= PacketFramer.HEADER_LENGTH) {
            const id = this.buffer.readUInt16BE(0)
            const length = this.buffer.readUIntBE(2, 3)
            const version = this.buffer.readUInt16BE(5)

            if (id < 10000 || id >= 20000) {
                return this.fail(`Invalid packet header (id ${id}, length ${length}), stream is out of sync.`)
            }

            if (LogicConfig.queue.maxSize > 0 && length > LogicConfig.queue.maxSize) {
                if (LogicConfig.queue.enableOverfillingWarning) this.session.warn(`Packet ${id} is bigger than the queue limit! Length: ${length}`)
                if (LogicConfig.queue.disconnectSessionOnOverfilling) return this.fail("Client disconnected.")
            }

            const total = PacketFramer.HEADER_LENGTH + length

            if (this.buffer.length < total) break

            const payload = Buffer.from(this.buffer.subarray(PacketFramer.HEADER_LENGTH, total))

            this.buffer = this.buffer.length === total ? Buffer.alloc(0) : Buffer.from(this.buffer.subarray(total))

            this.dispatch(id, payload, version)
        }
    }

    /**
     * Dispatch one complete packet, keeping the order of the packets of the session.
     */
    dispatch (id, payload, version) {
        this.chain = this.chain.then(async () => {
            if (this.closed || this.session.destroyed) return

            const bytes = LogicConfig.crypto.activate ? this.session.crypto.decrypt(id, payload) : payload

            await this.messageHandler.handle(id, bytes, { version })
        }).catch(e => this.session.errLog(e.stack))
    }

    /**
     * Queue compatible state (used by the admin console): 0 free, 1 waiting for the rest of a packet.
     */
    get state () {
        return this.buffer.length === 0 ? 0 : 1
    }

    fail (reason) {
        this.closed = true
        this.buffer = Buffer.alloc(0)
        global.destroySession(this.session, "warn", reason)
    }

    close () {
        this.closed = true
        this.buffer = Buffer.alloc(0)
    }
}

module.exports = PacketFramer
