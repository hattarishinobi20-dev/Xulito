// MongoDB storage test. Starts the server itself (NODEBRAWL_DB_DRIVER=mongodb), so no server may be running.
// 1. wipes the players / alliances / settings collections
// 2. server A: new account, rename, control mode, create alliance, alliance chat -> documents checked in MongoDB
// 3. server A stopped with SIGTERM (pending writes flushed), server B started: login with the same token must
//    return LoginOk + OwnHomeData + the alliance (MyAlliance with id), rename again -> document updated
// Usage: node TestFiles/testMongo.js
const net = require("net")
const { spawn } = require("child_process")
const RC4 = require("simple-rc4")
const { MongoClient } = require("mongodb")
const ByteStream = require("../Titan/DataStream/ByteStream")
const FP_SHA = require("fs").readFileSync(__dirname + "/../AssetsServer/lastversion.txt", "utf8").trim().split("...")[1]
const config = require("../config.dev.json")
const GameConfig = require("../Logic/Server/GameConfig")

const HOST = "127.0.0.1", PORT = config.port
const keyNonce = () => Buffer.concat([Buffer.from(config.crypto.rc4.key), Buffer.from(config.crypto.rc4.nonce)])
const sleep = (ms) => new Promise(r => setTimeout(r, ms))

let failed = 0
const check = (name, ok, extra = "") => { console.log(`${ok ? "ok  " : "FAIL"} ${name}${extra ? " -> " + extra : ""}`); if (!ok) failed++ }

// server process management

let server = null
const startServer = async (label) => {
  server = spawn(process.execPath, ["index.js"], { cwd: __dirname + "/..", env: { ...process.env, NODEBRAWL_DB_DRIVER: "mongodb" }, stdio: ["ignore", "pipe", "pipe"] })
  let out = ""
  server.stdout.on("data", d => { out += d })
  server.stderr.on("data", d => { out += d })
  for (let i = 0; i < 60; i++) {
    await sleep(500)
    const up = await new Promise(r => { const s = net.createConnection(PORT, HOST); s.once("connect", () => { s.end(); r(true) }); s.once("error", () => r(false)) })
    if (up) { await sleep(500); console.log(`server ${label} up`); return out }
  }
  throw new Error("server did not start:\n" + out)
}
const stopServer = async () => {
  if (!server) return
  const p = new Promise(r => server.once("exit", r))
  server.kill("SIGTERM")
  await Promise.race([p, sleep(10000)])
  server = null
}

// client

function session (token, steps) {
  return new Promise((resolve) => {
    const enc = new RC4(keyNonce()); enc.update(keyNonce())
    const dec = new RC4(keyNonce()); dec.update(keyNonce())
    const socket = net.createConnection(PORT, HOST)
    let queue = Buffer.alloc(0), step = 0
    const log = [], info = { token, allianceId: -1 }

    const send = (id, stream, version = 0) => {
      const payload = config.crypto.activate ? enc.update(Buffer.from(stream.buffer)) : stream.buffer
      const header = Buffer.alloc(7)
      header.writeUInt16BE(id, 0); header.writeUIntBE(payload.length, 2, 3); header.writeUInt16BE(version, 5)
      socket.write(Buffer.concat([header, payload]))
    }
    const command = (type, writeBody) => {
      const s = new ByteStream()
      s.writeBoolean(true); s.writeVInt(1); s.writeVInt(0); s.writeVInt(1); s.writeVInt(type)
      for (let i = 0; i < 4; i++) s.writeVInt(0) // command header
      if (writeBody) writeBody(s)
      send(14102, s)
    }
    const api = { send, command, ByteStream }
    const next = () => { if (step < steps.length) { steps[step++](api); setTimeout(next, 300) } else setTimeout(() => { socket.end(); resolve({ log, info }) }, 800) }

    socket.on("connect", () => {
      const s = new ByteStream()
      s.writeInt(0); s.writeInt(1); s.writeInt(4); s.writeInt(0); s.writeInt(1); s.writeString("fp"); s.writeInt(2); s.writeInt(2)
      send(10100, s)
    })
    socket.on("data", (bytes) => {
      queue = Buffer.concat([queue, bytes])
      while (queue.length >= 7) {
        const id = queue.readUInt16BE(0), len = queue.readUIntBE(2, 3)
        if (queue.length < 7 + len) break
        let payload = Buffer.from(queue.slice(7, 7 + len)); queue = queue.slice(7 + len)
        if (config.crypto.activate && len) payload = dec.update(payload)
        onMessage(id, payload)
      }
    })
    socket.on("error", () => resolve({ log, info }))

    function onMessage (id, payload) {
      if (id === 65535) return
      const s = new ByteStream(payload)
      log.push(id)
      if (id === 20100) {
        const l = new ByteStream()
        l.writeInt(0); l.writeInt(0); l.writeString(info.token || null); l.writeInt(4); l.writeInt(0); l.writeInt(1)
        l.writeString(FP_SHA); l.writeString(null); l.writeString("dev"); l.writeString(null); l.writeString("iPhone"); l.writeVInt(1); l.writeString("pt-BR")
        send(10101, l)
      } else if (id === 20104) {
        s.readLong(); s.readLong(); info.token = s.readString()
      } else if (id === 24399) {
        // MyAllianceMessage: vint online, bool hasAlliance, [dataref role, dataref type, alliance header (long id ...)]
        s.readVInt()
        if (s.readBoolean()) { s.readVInt(); s.readVInt(); info.allianceId = s.readLong()[1] }
        else info.allianceId = 0
      } else if (id === 24101 && log.filter(e => e === 24101).length === 1) {
        next()
      }
    }
  })
}

const createAlliance = (send, name) => {
  const s = new ByteStream()
  s.writeString(name); s.writeString("mongo test club"); s.writeVInt(8); s.writeVInt(1); s.writeVInt(1); s.writeVInt(0)
  send(14301, s)
}

const main = async () => {
  const client = new MongoClient(process.env.MONGODB_URI || GameConfig.database.mongodb.uri, { serverSelectionTimeoutMS: 15000 })
  await client.connect()
  const db = client.db(GameConfig.database.mongodb.name || "nodebrawl")
  for (const c of ["players", "alliances", "settings"]) await db.collection(c).deleteMany({})
  console.log("collections wiped")

  const outA = await startServer("A")
  check("server A started with mongodb storage", /Storage: mongodb/.test(outA), (outA.match(/Storage: mongodb[^\n]*/) || [""])[0].trim())

  const one = await session("", [
    ({ send }) => { const s = new ByteStream(); s.writeString("MongoTester"); send(10212, s) },
    ({ command }) => command(509, s => s.writeVInt(1)),
    ({ send }) => createAlliance(send, "MongoClub"),
    ({ send }) => { const s = new ByteStream(); s.writeString("hello from mongo test"); send(14315, s) }
  ])
  const token = one.info.token
  check("session 1: LoginOk + OwnHomeData", one.log.includes(20104) && one.log.includes(24101), `token ${token}`)
  check("session 1: alliance created (24399 with id)", one.info.allianceId > 0 || one.log.includes(24310), `allianceId ${one.info.allianceId} log ${one.log.join(",")}`)

  await sleep(1500)
  let player = await db.collection("players").findOne({ token })
  check("mongodb: player document written", !!player, player ? `_id ${player._id} name "${player.name}" controlMode ${player.controlMode} allianceId ${player.allianceId}` : "missing")
  check("mongodb: name / control mode persisted", player && player.name === "MongoTester" && player.controlMode === 1)
  const alliance = player ? await db.collection("alliances").findOne({ "members.lowId": player.lowId }) : null
  check("mongodb: alliance document written", !!alliance, alliance ? `_id ${alliance._id} name "${alliance.name}" members ${alliance.members.length} stream ${alliance.stream.length}` : "missing")
  check("mongodb: player.allianceId matches", player && alliance && player.allianceId === alliance.id && player.allianceRole === 2)
  const season = await db.collection("settings").findOne({ _id: "season" })
  check("mongodb: season document written", !!season && season.nextSeasonEndTimestamp > Date.now() / 1000)

  await stopServer()
  console.log("server A stopped")
  const outB = await startServer("B")
  check("server B loaded documents from mongodb", /1 players, 1 alliances/.test(outB), (outB.match(/Storage: mongodb[^\n]*/) || [""])[0].trim())

  const two = await session(token, [
    ({ send }) => { const s = new ByteStream(); s.writeString("MongoTester2"); send(10212, s) }
  ])
  check("session 2: same token -> LoginOk + OwnHomeData (no new account)", two.log.includes(20104) && two.log.includes(24101) && two.info.token === token)
  check("session 2: alliance restored after restart", alliance && two.info.allianceId === alliance.id, `allianceId ${two.info.allianceId}`)

  await sleep(1500)
  player = await db.collection("players").findOne({ token })
  check("mongodb: rename after restart persisted", player && player.name === "MongoTester2", player ? `name "${player.name}"` : "missing")
  check("mongodb: still one player document", await db.collection("players").countDocuments() === 1)

  await stopServer()
  await client.close()
  console.log(failed === 0 ? "\nALL GOOD: mongodb storage works" : `\n${failed} FAILED`)
  process.exit(failed === 0 ? 0 : 1)
}

main().catch(async e => { console.error(e); await stopServer(); process.exit(1) })
setTimeout(() => { console.log("timeout"); stopServer().then(() => process.exit(1)) }, 120000)
