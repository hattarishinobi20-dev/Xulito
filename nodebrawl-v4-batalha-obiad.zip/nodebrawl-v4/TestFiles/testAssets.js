// Content update flow (Obiad AssetsServer): outdated fingerprint -> LoginFailed 7 with fingerprint json + content url,
// http assets server (fingerprint.json, csv fallback to Content/assets, 404, path traversal), up to date -> LoginOk.
// Usage (server running with GameConfig.fingerprintCheck = true and assetsServer.enabled = true): node TestFiles/testAssets.js
const net = require("net"), fs = require("fs"), http = require("http"), RC4 = require("simple-rc4")
const ByteStream = require("../Titan/DataStream/ByteStream"), config = require("../config.dev.json")
const GameConfig = require("../Logic/Server/GameConfig")
const FP_SHA = fs.readFileSync(__dirname + "/../AssetsServer/lastversion.txt", "utf8").trim().split("...")[1]
const keyNonce = () => Buffer.concat([Buffer.from(config.crypto.rc4.key), Buffer.from(config.crypto.rc4.nonce)])

function client (label, fingerprintSha) {
  const enc = new RC4(keyNonce()); enc.update(keyNonce()); const dec = new RC4(keyNonce()); dec.update(keyNonce())
  const c = { label, token: "", lowId: 0, log: [], last: {}, closed: false }
  const socket = net.createConnection(config.port, "127.0.0.1"); let queue = Buffer.alloc(0)
  c.send = (id, s) => { const p = config.crypto.activate ? enc.update(Buffer.from(s.buffer)) : s.buffer; const h = Buffer.alloc(7); h.writeUInt16BE(id, 0); h.writeUIntBE(p.length, 2, 3); socket.write(Buffer.concat([h, p])) }
  c.end = () => socket.end()
  c.done = new Promise(resolve => { c.ready = resolve })
  socket.on("close", () => { c.closed = true }); socket.on("error", () => { c.closed = true })
  socket.on("connect", () => { const s = new ByteStream(); s.writeInt(0); s.writeInt(1); s.writeInt(4); s.writeInt(0); s.writeInt(1); s.writeString("fp"); s.writeInt(2); s.writeInt(2); c.send(10100, s) })
  socket.on("data", (b) => { queue = Buffer.concat([queue, b]); while (queue.length >= 7) { const id = queue.readUInt16BE(0), len = queue.readUIntBE(2, 3); if (queue.length < 7 + len) break; let p = Buffer.from(queue.slice(7, 7 + len)); queue = queue.slice(7 + len); if (config.crypto.activate && len) p = dec.update(p); onMessage(id, p) } })
  function onMessage (id, payload) {
    if (id === 65535) return
    const s = new ByteStream(payload); c.log.push(id)
    if (id === 20100) { const l = new ByteStream(); l.writeInt(0); l.writeInt(0); l.writeString(null); l.writeInt(4); l.writeInt(0); l.writeInt(1); l.writeString(fingerprintSha); l.writeString(null); l.writeString("dev"); l.writeString(null); l.writeString("iPhone"); l.writeVInt(1); l.writeString("pt-BR"); c.send(10101, l) }
    else if (id === 20104) { s.readLong(); c.lowId = s.readLong()[1]; c.token = s.readString(); console.log(`[${label}] << 20104 LoginOk (id ${c.lowId})`) }
    else if (id === 20103) {
      const f = { code: s.readInt(), fingerprint: s.readString(), host: s.readString(), content: s.readString(), update: s.readString(), reason: s.readString(), maintenance: s.readInt() }
      s.bitOffset = 0; f.support = s.readBoolean(); s.readString(); s.readString(); f.i0 = s.readInt(); f.i3 = s.readInt(); s.readString(); s.readString(); s.readInt(); s.readInt()
      f.remaining = payload.length - s.offset
      c.last.loginFailed = f
      console.log(`[${label}] << 20103 LoginFailed code=${f.code} content=${f.content} fingerprint=${f.fingerprint ? f.fingerprint.length + " chars" : null} reason=${JSON.stringify(f.reason)}`)
      if (c.ready) { c.ready(); c.ready = null }
    }
    else if (id === 20105) { if (c.ready) { c.ready(); c.ready = null } }
  }
  return c
}

const get = (url) => new Promise((resolve) => {
  http.get(url, (res) => { const chunks = []; res.on("data", d => chunks.push(d)); res.on("end", () => resolve({ status: res.statusCode, type: res.headers["content-type"], body: Buffer.concat(chunks) })) })
    .on("error", (e) => resolve({ status: 0, error: e.message, body: Buffer.alloc(0) }))
})

const checks = []
const check = (name, ok) => { checks.push(ok); console.log(`${ok ? "OK  " : "FAIL"} ${name}`) }
const wait = (ms) => new Promise(r => setTimeout(r, ms))

async function main () {
  console.log(`Expected content sha: ${FP_SHA}`)

  // 1. outdated client -> LoginFailed 7
  const old = client("outdated", "0000000000000000000000000000000000000000")
  await Promise.race([old.done, wait(4000)])
  const f = old.last.loginFailed
  check("outdated fingerprint -> 20103 LoginFailed", !!f)
  check("error code 7 (patch)", f && f.code === 7)
  let fp = null
  try { fp = JSON.parse(f.fingerprint) } catch (e) {}
  check("fingerprint json parses, sha matches lastversion.txt", fp && fp.sha === FP_SHA)
  check("fingerprint lists the v4 files (893)", fp && Array.isArray(fp.files) && fp.files.length === 893 && fp.version === "4.7.1")
  check("content url points to the assets server", f && /^http:\/\/127\.0\.0\.1:8080\/$/.test(f.content))
  check("v4 layout tail (int 0, int 3, two packed bools = 1 byte left)", f && f.i0 === 0 && f.i3 === 3 && f.remaining === 1)
  check("no LoginOk was sent", !old.log.includes(20104))
  old.end()

  // 2. assets http server
  const base = f ? f.content : `http://127.0.0.1:${GameConfig.assetsServer.port}/`
  const r1 = await get(`${base}${FP_SHA}/fingerprint.json`)
  let served = null
  try { served = JSON.parse(r1.body.toString()) } catch (e) {}
  check("GET /<sha>/fingerprint.json -> 200 json", r1.status === 200 && /json/.test(r1.type) && served && served.sha === FP_SHA)
  const r2 = await get(`${base}${FP_SHA}/csv_logic/characters.csv`)
  check("GET /<sha>/csv_logic/characters.csv -> 200 (Content/assets fallback)", r2.status === 200 && r2.body.length > 100 && r2.body.toString().includes("Name"))
  const r3 = await get(`${base}${FP_SHA}/csv_logic/nope.csv`)
  check("GET missing file -> 404", r3.status === 404)
  const r4 = await get(`${base}wrongsha/fingerprint.json`)
  check("GET unknown sha without content copy -> 404", r4.status === 404)
  const r5 = await get(`${base}${FP_SHA}/..%2F..%2F..%2Fconfig.dev.json`)
  const r6 = await get(`${base}${FP_SHA}/../../package.json`)
  check("path traversal blocked", r5.status === 404 && r6.status !== 200)

  // 3. up to date client -> normal login
  const ok = client("uptodate", FP_SHA)
  await Promise.race([ok.done, wait(4000)])
  check("matching fingerprint -> 20104 LoginOk + 24101 OwnHomeData", ok.log.includes(20104) && ok.log.includes(24101) && !ok.log.includes(20103))
  ok.end()

  await wait(200)
  const failed = checks.filter(v => !v).length
  console.log(failed ? `WRONG: ${failed} of ${checks.length} checks failed` : `ALL GOOD: content update flow works (${checks.length} checks)`)
  process.exit(failed ? 1 : 0)
}

main()
