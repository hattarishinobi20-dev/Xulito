// Alliance flow with two online clients: create, search, join, chat, promote, kick, join request, leave.
// Usage (server running, clean Database/players and Database/alliances): node TestFiles/testAlliance.js
const net = require("net"), RC4 = require("simple-rc4")
const ByteStream = require("../Titan/DataStream/ByteStream"), config = require("../config.dev.json")
const FP_SHA = require("fs").readFileSync(__dirname + "/../AssetsServer/lastversion.txt", "utf8").trim().split("...")[1]
const keyNonce = () => Buffer.concat([Buffer.from(config.crypto.rc4.key), Buffer.from(config.crypto.rc4.nonce)])

function client (label) {
  const enc = new RC4(keyNonce()); enc.update(keyNonce()); const dec = new RC4(keyNonce()); dec.update(keyNonce())
  const c = { label, token: "", lowId: 0, log: [], last: {}, ready: null }
  const socket = net.createConnection(config.port, "127.0.0.1"); let queue = Buffer.alloc(0)
  c.send = (id, s) => { const p = config.crypto.activate ? enc.update(Buffer.from(s.buffer)) : s.buffer; const h = Buffer.alloc(7); h.writeUInt16BE(id, 0); h.writeUIntBE(p.length, 2, 3); socket.write(Buffer.concat([h, p])) }
  c.end = () => socket.end()
  c.loggedIn = new Promise(resolve => { c.ready = resolve })
  socket.on("connect", () => { const s = new ByteStream(); s.writeInt(0); s.writeInt(1); s.writeInt(4); s.writeInt(0); s.writeInt(1); s.writeString("fp"); s.writeInt(2); s.writeInt(2); c.send(10100, s) })
  socket.on("data", (b) => { queue = Buffer.concat([queue, b]); while (queue.length >= 7) { const id = queue.readUInt16BE(0), len = queue.readUIntBE(2, 3); if (queue.length < 7 + len) break; let p = Buffer.from(queue.slice(7, 7 + len)); queue = queue.slice(7 + len); if (config.crypto.activate && len) p = dec.update(p); onMessage(id, p) } })

  const readBool = (s) => { s.bitOffset = 0; return s.readBoolean() }
  const readHeader = (s, full) => { const id = s.readLong()[1]; const name = s.readString(); s.readVInt(); const badge = s.readVInt(); const type = s.readVInt(); const members = s.readVInt(); const trophies = s.readVInt(); const required = s.readVInt(); s.readVInt(); if (!full) s.readVInt(); return { id, name, badge, type, members, trophies, required } }
  const readEntry = (s) => { const type = s.readVInt(); s.readVInt(); const id = s.readVInt(); s.readVInt(); const playerId = s.readVInt(); const playerName = s.readString(); const role = s.readVInt(); s.readVInt(); readBool(s); const e = { type, id, playerId, playerName, role }; if (type === 2) e.message = s.readString(); else if (type === 3) { e.message = s.readString(); e.responder = s.readString(); e.state = s.readVInt() } else if (type === 4) { e.event = s.readVInt(); readBool(s); s.readVInt(); e.targetId = s.readVInt(); e.targetName = s.readString() } return e }

  function onMessage (id, payload) {
    if (id === 65535) return
    const s = new ByteStream(payload); c.log.push(id)
    if (id === 20100) { const l = new ByteStream(); l.writeInt(0); l.writeInt(0); l.writeString(c.token || null); l.writeInt(4); l.writeInt(0); l.writeInt(1); l.writeString(FP_SHA); l.writeString(null); l.writeString("dev"); l.writeString(null); l.writeString("iPhone"); l.writeVInt(1); l.writeString("pt-BR"); c.send(10101, l) }
    else if (id === 20104) { s.readLong(); c.lowId = s.readLong()[1]; c.token = s.readString() }
    else if (id === 24399) { const online = s.readVInt(); const inAlliance = readBool(s); const r = { online, inAlliance }; if (inAlliance) { s.readVInt(); r.role = s.readVInt(); r.id = s.readLong()[1]; r.name = s.readString(); s.readVInt(); r.badge = s.readVInt(); r.type = s.readVInt(); r.members = s.readVInt(); r.trophies = s.readVInt() } c.last.myAlliance = r; console.log(`[${label}] << 24399 MyAlliance ${JSON.stringify(r)}`) }
    else if (id === 24333) { const e = s.readVInt(); c.last.events = (c.last.events || []).concat(e); console.log(`[${label}] << 24333 AllianceEvent ${e}`) }
    else if (id === 24311) { const n = s.readVInt(); const entries = []; for (let i = 0; i < n; i++) entries.push(readEntry(s)); c.last.stream = entries; console.log(`[${label}] << 24311 AllianceStream ${n} entries`) }
    else if (id === 24312) { const e = readEntry(s); c.last.entries = (c.last.entries || []).concat([e]); console.log(`[${label}] << 24312 StreamEntry ${JSON.stringify(e)}`) }
    else if (id === 24301) { const h = readHeader(s, true); h.description = s.readString(); const n = s.readVInt(); h.memberList = []; for (let i = 0; i < n; i++) { const lo = s.readLong()[1]; const name = s.readString(); const role = s.readVInt(); s.readVInt(); const t = s.readVInt(); s.readVInt(); s.readVInt(); h.memberList.push({ lo, name, role, t }) } c.last.data = h; console.log(`[${label}] << 24301 AllianceData ${JSON.stringify(h)}`) }
    else if (id === 24304) { const n = s.readVInt(); const list = []; for (let i = 0; i < n; i++) list.push(readHeader(s)); c.last.joinable = list; console.log(`[${label}] << 24304 Joinable ${n}`) }
    else if (id === 24310) { const q = s.readString(); const n = s.readVInt(); const list = []; for (let i = 0; i < n; i++) list.push(readHeader(s)); c.last.search = { q, list }; console.log(`[${label}] << 24310 SearchResult "${q}" ${n}`) }
    else if (id === 24113) { s.readVInt(); const lo = s.readVInt(); s.readString(); s.readVInt(); const nb = s.readVInt(); for (let i = 0; i < nb; i++) { s.readVInt(); s.readVInt(); s.readVInt(); s.readVInt(); s.readVInt(); s.readVInt() } const ns = s.readVInt(); for (let i = 0; i < ns; i++) { s.readVInt(); s.readVInt() } const inAlliance = readBool(s); const r = { lo, inAlliance }; if (inAlliance) { r.id = s.readLong()[1]; r.name = s.readString(); s.readVInt(); r.badge = s.readVInt(); r.type = s.readVInt(); r.online = s.readVInt(); r.members = s.readVInt(); r.trophies = s.readVInt(); r.required = s.readVInt(); s.readVInt(); s.readVInt(); r.role = s.readVInt() } c.last.profile = r; console.log(`[${label}] << 24113 Profile ${JSON.stringify(r)}`) }
    else if (id === 24403) { const type = s.readVInt(); const cls = s.readVInt(); if (cls) s.readVInt(); s.readString(); const n = s.readVInt(); const names = []; for (let i = 0; i < n; i++) { s.readVInt(); s.readVInt(); s.readVInt(); const t = s.readVInt(); const isPlayer = readBool(s); if (isPlayer) { const name = s.readString(); const an = s.readString(); s.readVInt(); s.readVInt(); s.readVInt(); readBool(s); names.push(`${name}[${an}](${t})`) } else { s.readBoolean(); const name = s.readString(); const m = s.readVInt(); s.readVInt(); s.readVInt(); names.push(`${name}{${m}}(${t})`) } } c.last["lb" + type] = names; console.log(`[${label}] << 24403 Leaderboard ${type}: ${names.join(", ")}`) }
    else if (id === 20105) { if (c.ready) { c.ready(); c.ready = null } }
  }
  return c
}

const wait = (ms) => new Promise(r => setTimeout(r, ms))
const str = (v) => { const s = new ByteStream(); s.writeString(v); return s }
const long = (lo, extra) => { const s = new ByteStream(); s.writeInt(0); s.writeInt(lo); if (extra) extra(s); return s }
const checks = []
const check = (name, ok) => { checks.push(ok); console.log(`${ok ? "OK  " : "FAIL"} ${name}`) }

async function main () {
  const A = client("A"), B = client("B")
  await Promise.all([A.loggedIn, B.loggedIn])
  await wait(300)
  check("login sends AllianceStream (24311) + MyAlliance (24399) without alliance", A.log.includes(24311) && A.log.includes(24399) && A.last.myAlliance && A.last.myAlliance.inAlliance === false)

  // A creates the alliance
  const cr = new ByteStream(); cr.writeString("Node Club"); cr.writeString("test club"); cr.writeVInt(8); cr.writeVInt(3); cr.writeVInt(1); cr.writeVInt(0)
  A.send(14301, cr); await wait(400)
  check("create: event 20 + MyAlliance leader role 2", A.last.events && A.last.events.includes(20) && A.last.myAlliance.inAlliance && A.last.myAlliance.role === 2 && A.last.myAlliance.name === "Node Club" && A.last.myAlliance.badge === 3)
  const allianceId = A.last.myAlliance.id
  check("create: stream has the join event of the leader", A.last.stream && A.last.stream.length === 1 && A.last.stream[0].type === 4 && A.last.stream[0].event === 3)

  // B searches and lists joinable alliances
  const sq = new ByteStream(); sq.writeString("node"); sq.writeInt(0); sq.writeInt(0); sq.writeInt(0); sq.writeInt(0); sq.writeBoolean(false); sq.writeInt(0); sq.writeInt(0)
  B.send(14324, sq); B.send(14303, new ByteStream()); await wait(400)
  check("search: 'node' finds the alliance", B.last.search && B.last.search.list.length === 1 && B.last.search.list[0].id === allianceId && B.last.search.list[0].members === 1)
  check("joinable list contains the alliance", B.last.joinable && B.last.joinable.length === 1)

  // B asks alliance data then joins
  B.send(14302, long(allianceId)); await wait(300)
  check("alliance data: 1 member, description", B.last.data && B.last.data.memberList.length === 1 && B.last.data.description === "test club" && B.last.data.memberList[0].role === 2)
  B.send(14305, long(allianceId)); await wait(500)
  check("join: B gets event 40 + MyAlliance role 1 with 2 members", B.last.events && B.last.events.includes(40) && B.last.myAlliance.inAlliance && B.last.myAlliance.role === 1 && B.last.myAlliance.members === 2 && B.last.myAlliance.online === 2)
  check("join: A receives the join stream entry and refreshed MyAlliance", A.last.entries && A.last.entries.some(e => e.type === 4 && e.event === 3 && e.targetId === B.lowId) && A.last.myAlliance.members === 2)

  // Chat
  A.send(14315, str("hello club")); await wait(400)
  check("chat: both members receive the chat entry", [A, B].every(c => c.last.entries.some(e => e.type === 2 && e.message === "hello club" && e.playerId === A.lowId && e.role === 2)))

  // Profile + leaderboards show alliance
  B.send(14113, long(A.lowId)); const lb = new ByteStream(); lb.writeVInt(0); lb.writeVInt(1); lb.writeVInt(0); B.send(14403, lb); const lb2 = new ByteStream(); lb2.writeVInt(0); lb2.writeVInt(2); lb2.writeVInt(0); B.send(14403, lb2); await wait(500)
  check("profile shows alliance block with role", B.last.profile && B.last.profile.inAlliance && B.last.profile.id === allianceId && B.last.profile.role === 2 && B.last.profile.members === 2)
  check("player leaderboard shows alliance name", B.last.lb1 && B.last.lb1.every(n => n.includes("[Node Club]")))
  check("alliance leaderboard lists the alliance", B.last.lb2 && B.last.lb2.length === 1 && B.last.lb2[0].startsWith("Node Club{2}"))

  // B cannot promote (member); A promotes B to co-leader (4)
  B.send(14306, long(A.lowId, s => s.writeVInt(1))); await wait(300)
  A.send(14306, long(B.lowId, s => s.writeVInt(4))); await wait(500)
  check("promote: A still leader, B co-leader, events 81/101", A.last.myAlliance.role === 2 && B.last.myAlliance.role === 4 && A.last.events.includes(81) && B.last.events.includes(101) && A.last.entries.some(e => e.type === 4 && e.event === 5 && e.targetId === B.lowId))

  // B (co-leader) cannot kick leader; A kicks B
  B.send(14307, long(A.lowId, s => s.writeString("no"))); await wait(300)
  check("kick: co-leader cannot kick the leader", A.last.myAlliance.inAlliance)
  A.send(14307, long(B.lowId, s => s.writeString("bye"))); await wait(500)
  check("kick: B gets 100 + MyAlliance none, A gets 70 + kicked entry", B.last.events.includes(100) && B.last.myAlliance.inAlliance === false && A.last.events.includes(70) && A.last.entries.some(e => e.type === 4 && e.event === 1 && e.targetId === B.lowId) && A.last.myAlliance.members === 1)

  // A sets the alliance invite only; B sends a join request; A accepts
  const st = new ByteStream(); st.writeString("invite only now"); st.writeVInt(8); st.writeVInt(5); st.writeVInt(2); st.writeVInt(0)
  A.send(14316, st); await wait(300)
  check("settings: event 10, badge 5, type 2", A.last.events.includes(10) && A.last.myAlliance.badge === 5 && A.last.myAlliance.type === 2)
  B.send(14305, long(allianceId)); await wait(300)
  check("join: direct join refused on invite only alliance", B.last.myAlliance.inAlliance === false)
  B.send(14317, long(allianceId, s => s.writeString("let me in"))); await wait(400)
  const request = A.last.entries.find(e => e.type === 3 && e.playerId === B.lowId)
  check("join request: B gets 50, A receives pending request entry", B.last.events.includes(50) && request && request.state === 1 && request.message === "let me in")
  const rs = new ByteStream(); rs.writeInt(0); rs.writeInt(request ? request.id : 0); rs.writeBoolean(true)
  A.send(14321, rs); await wait(500)
  check("accept request: A gets 90, B is member again with stream", A.last.events.includes(90) && B.last.myAlliance.inAlliance && B.last.myAlliance.role === 1 && B.last.stream && B.last.stream.some(e => e.type === 3 && e.state === 2 && e.responder === "Brawler") && A.last.myAlliance.members === 2)

  // A (leader) leaves: B must become leader. Then B leaves: alliance deleted
  A.send(14308, new ByteStream()); await wait(500)
  check("leave: A gets 80 + no alliance; B promoted to leader", A.last.events.includes(80) && A.last.myAlliance.inAlliance === false && B.last.myAlliance.role === 2 && B.last.myAlliance.members === 1 && B.last.entries.some(e => e.type === 4 && e.event === 4 && e.targetId === A.lowId))
  B.send(14308, new ByteStream()); await wait(400)
  B.send(14302, long(allianceId)); B.send(14303, new ByteStream()); await wait(400)
  check("last member leaves: alliance deleted", B.last.myAlliance.inAlliance === false && B.last.joinable && B.last.joinable.length === 0)

  // Reconnect A: MyAlliance must be empty after leaving
  A.end(); B.end(); await wait(300)
  const A2 = client("A2"); A2.token = A.token; await A2.loggedIn; await wait(300)
  check("relogin after leaving: not in alliance", A2.last.myAlliance && A2.last.myAlliance.inAlliance === false)
  A2.end()

  const ok = checks.every(Boolean)
  console.log(ok ? "\nALL GOOD: alliances work" : `\nSOMETHING WRONG (${checks.filter(c => !c).length} failed)`)
  process.exit(ok ? 0 : 1)
}

main().catch(e => { console.error(e); process.exit(1) })
setTimeout(() => { console.log("TIMEOUT"); process.exit(1) }, 30000)
