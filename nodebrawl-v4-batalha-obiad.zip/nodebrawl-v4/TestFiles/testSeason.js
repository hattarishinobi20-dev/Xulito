// Season end test (offline, no server): resets brawlers above the threshold, gives coins and a 99 notification,
// and checks the OwnHomeData encoding of that notification + the coins booster expiry notification.
// Usage: node TestFiles/testSeason.js
require("../Logic/Server/LogicConfig").loadConfig()
require("../Utils/Logger")
const GameConfig = require("../Logic/Server/GameConfig")
const LogicSeason = require("../Logic/Home/LogicSeason")
const LogicClientHome = require("../Logic/Home/LogicClientHome")
const ByteStream = require("../Titan/DataStream/ByteStream")

const threshold = GameConfig.getBrawlersTrophiesForSeasonReset() // 500 with maximumRank 20
const player = JSON.parse(JSON.stringify(GameConfig.defaultAccount))
Object.assign(player, { highId: 0, lowId: 1, name: "Season", token: "x", trophies: 1300, highestTrophies: 1300, gold: 0, coinsReward: 0, homeNotifications: [], coinsBooster: Math.floor(Date.now() / 1000) - 10 })
player.brawlers = {
  0: { cards: { 0: 1 }, skins: [0], selectedSkin: 0, trophies: 700, highestTrophies: 700, powerLevel: 0 }, // -100
  1: { cards: { 4: 1 }, skins: [], selectedSkin: 0, trophies: 501, highestTrophies: 501, powerLevel: 0 }, // -1
  2: { cards: { 8: 1 }, skins: [], selectedSkin: 0, trophies: 99, highestTrophies: 99, powerLevel: 0 } // untouched
}

const changed = LogicSeason.resetPlayer(player, threshold)
const notification = player.homeNotifications.find(n => n.id === 99)
console.log(`threshold=${threshold} changed=${changed} trophies=${player.trophies} b0=${player.brawlers[0].trophies} b1=${player.brawlers[1].trophies} b2=${player.brawlers[2].trophies} gold=${player.gold}`)
console.log("notification:", JSON.stringify(notification))

const boosterAdded = LogicSeason.checkCoinsBooster(player)
const boosterAgain = LogicSeason.checkCoinsBooster(player)

// encode home data and read the notifications back
const stream = new ByteStream()
LogicClientHome.encode(stream, player)
const read = new ByteStream(stream.buffer)
// skip daily data + conf data by re-encoding them separately and measuring their length
const prefix = new ByteStream(); LogicClientHome.encodeDailyData(prefix, player); LogicClientHome.encodeConfData(prefix, player)
read.offset = prefix.buffer.length + 8 // + player id long
const count = read.readVInt()
const ids = []
for (let i = 0; i < count; i++) {
  const id = read.readVInt(); ids.push(id)
  if (id === 97) read.readVInt()
  if (id === 99) { const v = []; for (let j = 0; j < 14; j++) v.push(read.readVInt()); console.log("99 payload:", v.join(",")) }
}
console.log(`booster notification added=${boosterAdded} again=${boosterAgain} home notifications=${ids.join(",")}`)

const ok = changed && player.trophies === 1199 && player.brawlers[0].trophies === 600 && player.brawlers[1].trophies === 500 && player.brawlers[2].trophies === 99 &&
  player.gold === 101 && notification.bestBrawler === 0 && notification.bestBrawlerPoints === 100 && notification.totalTrophiesPoints === 101 &&
  boosterAdded && !boosterAgain && player.coinsBooster === 0 && ids.join(",") === "99,97" && LogicSeason.getSecondsLeft() >= 0
console.log(ok ? "\nALL GOOD: season reset works" : "\nSOMETHING WRONG")
process.exit(ok ? 0 : 1)
