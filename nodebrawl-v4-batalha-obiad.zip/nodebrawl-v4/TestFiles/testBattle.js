// Battle flow test: matchmake -> start loading -> vision updates -> input -> ask for battle end (rewards),
// then a second battle that the server ends by itself (GameConfig.battleTicksOverride must be small, e.g. 100).
// Usage: node TestFiles/testBattle.js
const net = require("net"), fs = require("fs"), RC4 = require("simple-rc4")
const ByteStream = require("../Titan/DataStream/ByteStream"), config = require("../config.dev.json")
const FP_SHA = require("fs").readFileSync(__dirname + "/../AssetsServer/lastversion.txt", "utf8").trim().split("...")[1]
const keyNonce = () => Buffer.concat([Buffer.from(config.crypto.rc4.key), Buffer.from(config.crypto.rc4.nonce)])

function connect (token, steps, onDone) {
  const enc = new RC4(keyNonce()); enc.update(keyNonce()); const dec = new RC4(keyNonce()); dec.update(keyNonce())
  const socket = net.createConnection(config.port, "127.0.0.1"); let queue = Buffer.alloc(0), step = 0; const log = [], results = { visions: 0, ticks: [] }
  const send = (id, s) => { const p = config.crypto.activate ? enc.update(Buffer.from(s.buffer)) : s.buffer; const h = Buffer.alloc(7); h.writeUInt16BE(id, 0); h.writeUIntBE(p.length, 2, 3); socket.write(Buffer.concat([h, p])) }
  const next = () => { if (step < steps.length) { const s = steps[step++]; s.fn({ send, ByteStream, results }); setTimeout(next, s.wait || 300) } else setTimeout(() => { socket.end(); onDone(token, log, results) }, 400) }
  socket.on("connect", () => { const s = new ByteStream(); s.writeInt(0); s.writeInt(1); s.writeInt(4); s.writeInt(0); s.writeInt(1); s.writeString("fp"); s.writeInt(2); s.writeInt(2); send(10100, s) })
  socket.on("data", (b) => { queue = Buffer.concat([queue, b]); while (queue.length >= 7) { const id = queue.readUInt16BE(0), len = queue.readUIntBE(2, 3); if (queue.length < 7 + len) break; let p = Buffer.from(queue.slice(7, 7 + len)); queue = queue.slice(7 + len); if (config.crypto.activate && len) p = dec.update(p); onMessage(id, p) } })
  function onMessage (id, payload) {
    if (id === 65535) return
    const s = new ByteStream(payload); log.push(id)
    const readBool = () => { s.bitOffset = 0; return s.readBoolean() }
    if (id === 20100) { const l = new ByteStream(); l.writeInt(0); l.writeInt(0); l.writeString(token || null); l.writeInt(4); l.writeInt(0); l.writeInt(1); l.writeString(FP_SHA); l.writeString(null); l.writeString("dev"); l.writeString(null); l.writeString("iPhone"); l.writeVInt(1); l.writeString("pt-BR"); send(10101, l) }
    else if (id === 20104) { s.readLong(); s.readLong(); token = s.readString() }
    else if (id === 23457) { results.online = s.readVInt(); if (step === 0) next() }
    else if (id === 20405) { results.mmTimer = s.readInt(); results.mmPlayers = s.readInt(); console.log(`<< 20405 MatchMakingStatus timer=${results.mmTimer} players=${results.mmPlayers}`) }
    else if (id === 20559) { s.readInt(); s.readInt(); s.readInt(); const n = s.readInt(); s.readLong(); results.loadingName = s.readString(); results.loadingPlayers = n; console.log(`<< 20559 StartLoading players=${n} first="${results.loadingName}"`) }
    else if (id === 24109) { results.visions++; results.ticks.push(s.readVInt()); s.readVInt(); s.readVInt(); results.lastVisionLen = s.readInt() }
    else if (id === 23456) { const mode = s.readVInt(); s.readVInt(); const coins = s.readVInt(); s.readVInt(); s.readVInt(); readBool(); const result = s.readVInt(); const trophies = s.readVInt(); s.readVInt(); s.readVInt(); const flags = s.buffer[s.offset++]; const realGame = (flags & 2) !== 0; /* bools: isTutorial bit0, isInRealGame bit1 */ results.ends = results.ends || []; results.ends.push({ mode, coins, result, trophies, realGame }); console.log(`<< 23456 BattleEnd mode=${mode} result=${result} coins=${coins} trophies=${trophies} realGame=${realGame}`) }
    else if (id === 24101) { results.homes = (results.homes || 0) + 1 }
  }
}
const matchmake = (slot) => ({ wait: 1500, fn: ({ send, ByteStream }) => { const s = new ByteStream(); s.writeVInt(0); s.writeVInt(16); s.writeVInt(0); s.writeVInt(slot); s.writeVInt(0); s.writeVInt(0); s.writeVInt(0); send(14103, s) } })
const input = (type, x, y) => ({ wait: 200, fn: ({ send, ByteStream }) => { const s = new ByteStream(); s.writeVInt(1); s.writeVInt(0); s.writeVInt(1); s.writeVInt(0); s.writeVInt(0); s.writeVInt(type); s.writeVInt(x); s.writeVInt(y); send(10555, s) } })
const battleEnd = (type, rank) => ({ wait: 800, fn: ({ send, ByteStream }) => { const s = new ByteStream(); s.writeVInt(type); s.writeVInt(100); s.writeVInt(rank); s.writeVInt(0); s.writeVInt(1); s.writeVInt(6); for (let i = 0; i < 6; i++) { s.writeVInt(16); s.writeVInt(i); s.writeVInt(0); s.writeVInt(i < 3 ? 1 : 2); s.writeBoolean(i === 0); s.writeString(i === 0 ? "Me" : "Bot") } send(14110, s) } })
const goHome = () => ({ wait: 500, fn: ({ send, ByteStream }) => send(14101, new ByteStream()) })
const wait = (ms) => ({ wait: ms, fn: () => {} })
const cancel = () => ({ wait: 500, fn: ({ send, ByteStream }) => send(14106, new ByteStream()) })

connect("", [
  matchmake(1), input(100, 2000, 9000), input(107, 0, 0), input(108, 0, 0), wait(1000), battleEnd(0, 0), goHome(),
  matchmake(2), cancel(), goHome(),
  matchmake(1), wait(9000) // server forces the end (override ticks) and sends 23456 with realGame=false
], (token, log, r) => {
  const account = fs.readdirSync(__dirname + "/../Database/players/").map(f => JSON.parse(fs.readFileSync(__dirname + "/../Database/players/" + f))).find(a => a.token === token)
  console.log(`account: gold=${account.gold} trophies=${account.trophies} exp=${account.experience} 3v3wins=${account.threeVsThreeWins} brawler0=${account.brawlers[0].trophies}`)
  console.log(`visions=${r.visions} ticks(first,last)=${r.ticks[0]},${r.ticks[r.ticks.length - 1]} lastVisionLen=${r.lastVisionLen} online=${r.online}`)
  const ok = r.mmPlayers === 1 && r.loadingPlayers === 6 && r.visions > 20 && r.ends && r.ends.length === 2 &&
    r.ends[0].realGame === true && r.ends[0].coins === 20 && r.ends[0].trophies === 6 && r.ends[1].realGame === false && r.ends[1].coins === 0 &&
    account.gold === 92 + 20 && account.trophies === 6 && account.experience === 20 && account.threeVsThreeWins === 1 && log.filter(e => e === 20405).length === 4
  console.log(ok ? "\nALL GOOD: battle flow works" : "\nSOMETHING WRONG " + JSON.stringify(r) + " " + log.filter(e => e !== 24109).join(","))
  process.exit(ok ? 0 : 1)
})
setTimeout(() => { console.log("timeout"); process.exit(1) }, 40000)
