// Simulates a v4 client: ClientHello -> Login -> KeepAlive -> GoHome
// Usage: node TestFiles/testClient.js [host] [port]
const net = require("net")
const RC4 = require("simple-rc4")
const ByteStream = require("../Titan/DataStream/ByteStream")
const FP_SHA = require("fs").readFileSync(__dirname + "/../AssetsServer/lastversion.txt", "utf8").trim().split("...")[1]
const config = require("../config.dev.json")

const HOST = process.argv[2] || "127.0.0.1"
const PORT = Number(process.argv[3] || config.port)

// simple-rc4 updates buffers in place, so every stream needs its own copy of key+nonce
const keyNonce = () => Buffer.concat([Buffer.from(config.crypto.rc4.key), Buffer.from(config.crypto.rc4.nonce)])
const enc = new RC4(keyNonce()); enc.update(keyNonce())
const dec = new RC4(keyNonce()); dec.update(keyNonce())
const useCrypto = config.crypto.activate

let token = process.env.TOKEN || ""
let queue = Buffer.alloc(0)
const received = []

const socket = net.createConnection(PORT, HOST)

function send (id, stream, version = 0) {
  const payload = useCrypto ? enc.update(Buffer.from(stream.buffer)) : stream.buffer
  const header = Buffer.alloc(7)
  header.writeUInt16BE(id, 0)
  header.writeUIntBE(payload.length, 2, 3)
  header.writeUInt16BE(version, 5)
  socket.write(Buffer.concat([header, payload]))
  console.log(`>> sent ${id}`)
}

function clientHello () {
  const s = new ByteStream()
  s.writeInt(0); s.writeInt(1); s.writeInt(4); s.writeInt(0); s.writeInt(1)
  s.writeString("fingerprint"); s.writeInt(2); s.writeInt(2)
  send(10100, s)
}

function login () {
  const s = new ByteStream()
  s.writeInt(0); s.writeInt(0); s.writeString(token || null)
  s.writeInt(4); s.writeInt(0); s.writeInt(1)
  s.writeString(FP_SHA); s.writeString(null); s.writeString("device-id"); s.writeString(null)
  s.writeString("iPhone"); s.writeVInt(1); s.writeString("pt-BR")
  send(10101, s)
}

function keepAlive () { send(10108, new ByteStream()) }
function goHome () { send(14101, new ByteStream()) }

socket.on("connect", () => { console.log("connected"); clientHello() })

socket.on("data", (bytes) => {
  queue = Buffer.concat([queue, bytes])
  while (queue.length >= 7) {
    const id = queue.readUInt16BE(0)
    const len = queue.readUIntBE(2, 3)
    if (queue.length < 7 + len) break
    let payload = Buffer.from(queue.slice(7, 7 + len))
    queue = queue.slice(7 + len)
    if (useCrypto) payload = dec.update(payload)
    onMessage(id, payload)
  }
})

function onMessage (id, payload) {
  received.push(id)
  console.log(`<< got ${id} (${payload.length} bytes)`)
  const s = new ByteStream(payload)

  switch (id) {
    case 20100:
      login()
      break
    case 20103: {
      const code = s.readInt()
      console.log("LOGIN FAILED, code:", code, s.readString(), s.readString(), s.readString(), s.readString(), s.readString())
      process.exit(1)
    }
    case 20104: {
      const [high, low] = s.readLong(); s.readLong()
      token = s.readString()
      console.log(`   LoginOk: id ${high}-${low}, token ${token}`)
      break
    }
    case 24101: {
      const ts = s.readVInt(), timer = s.readVInt(), trophies = s.readVInt(), highest = s.readVInt()
      console.log(`   OwnHomeData: ts=${ts} trophies=${trophies} highest=${highest}`)
      if (received.filter(e => e === 24101).length === 1) { keepAlive() } else { finish() }
      break
    }
    case 20108:
      goHome()
      break
  }
}

function finish () {
  const ok = [20100, 20104, 24101, 20108, 24101].every((id, i) => received.filter(e => e === id).length >= 1)
  console.log(ok ? "\nALL GOOD: login flow works (token: " + token + ")" : "\nSOMETHING MISSING: " + received.join(","))
  socket.end()
  process.exit(ok ? 0 : 1)
}

socket.on("error", (e) => { console.error("socket error", e.message); process.exit(1) })
setTimeout(() => { console.log("timeout, received:", received.join(",")); process.exit(1) }, 8000)
