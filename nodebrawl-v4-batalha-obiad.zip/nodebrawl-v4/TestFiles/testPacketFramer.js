// Offline test of Networking/PacketFramer against the TCP chunk patterns a client produces, and a
// demonstration of why the core Queue (Networking/Queue.js) was replaced: a chunk holding complete packets
// followed by the beginning of the next one was dispatched truncated and desynchronised the stream.
// Usage: node TestFiles/testPacketFramer.js
const path = require("node:path")
const ROOT = path.join(__dirname, "..")

global.Log = () => {}
global.Warn = () => {}
global.Fatal = () => {}
global.destroySession = (session, type, reason) => { session.destroyed = true; session.destroyReason = reason }

const LogicConfig = require(path.join(ROOT, "Logic/Server/LogicConfig"))
LogicConfig.crypto = { activate: false }
LogicConfig.queue = { maxSize: 1024, disconnectSessionOnOverfilling: true, enableOverfillingWarning: false }

const PacketFramer = require(path.join(ROOT, "Networking/PacketFramer"))
const Queue = require(path.join(ROOT, "Networking/Queue"))

const results = { passed: 0, failed: 0 }
const check = (name, ok, detail = "") => { results[ok ? "passed" : "failed"]++; console.log(`  ${ok ? "ok  " : "FAIL"} ${name} ${ok ? "" : detail}`) }
const packet = (id, len) => { const h = Buffer.alloc(7); h.writeUInt16BE(id, 0); h.writeUIntBE(len, 2, 3); return Buffer.concat([h, Buffer.alloc(len, id & 0xFF)]) }
const sleep = (ms) => new Promise(r => setTimeout(r, ms))

function framerSession () {
  const handled = []
  const session = { id: 1, destroyed: false, log () {}, warn () {}, errLog: e => console.error(e) }
  const framer = new PacketFramer(session, { handle: async (id, bytes) => { handled.push(`${id}/${bytes.length}`) } })
  return { session, framer, handled }
}

function queueRun (chunks) {
  const q = new Queue(1024, true)
  const out = []
  for (const chunk of chunks) {
    q.push(chunk)
    if (!q.isBusy()) {
      const data = q.release()
      if (Array.isArray(data)) for (const p of data) out.push(`${p.id}/${p.bytes.length}`)
      else out.push(`${data.readUInt16BE(0)}/${data.length - 7}`)
    } else out.push(`busy(expected ${q.getQueueExpectedSize()})`)
  }
  return out
}

async function main () {
  const a = packet(10555, 20), b = packet(10555, 30), c = packet(10108, 0), d = packet(10177, 12)

  // framer: complete + complete + partial, then the rest merged with more packets
  let f = framerSession()
  f.framer.push(Buffer.concat([a, c, b.subarray(0, 10)]))
  f.framer.push(Buffer.concat([b.subarray(10), d, a.subarray(0, 3)]))
  f.framer.push(a.subarray(3))
  await sleep(10)
  check("framer: merged + partial + split header", f.handled.join(" ") === "10555/20 10108/0 10555/30 10177/12 10555/20" && !f.session.destroyed, f.handled.join(" "))

  // framer: byte by byte
  f = framerSession()
  const stream = Buffer.concat([d, c, a])
  for (const byte of stream) f.framer.push(Buffer.from([byte]))
  await sleep(10)
  check("framer: one byte per tcp chunk", f.handled.join(" ") === "10177/12 10108/0 10555/20", f.handled.join(" "))

  // framer: out of sync stream is refused instead of being parsed as packets
  f = framerSession()
  f.framer.push(Buffer.from([0xF8, 0x00, 0x00, 0x00, 0x10, 0x00, 0x00]))
  check("framer: invalid header closes the session", f.session.destroyed === true)

  // framer: oversized packet honours queue.maxSize
  f = framerSession()
  f.framer.push(packet(10101, 2000).subarray(0, 7))
  check("framer: packet above queue.maxSize closes the session", f.session.destroyed === true)

  // core queue: same "complete + partial" pattern
  const legacy = queueRun([Buffer.concat([a, b.subarray(0, 10)]), b.subarray(10)])
  check("core Queue dispatches the partial packet truncated and desynchronises (documented defect)", legacy[1] === "10555/3" && legacy[2].startsWith("busy"), legacy.join(" "))

  console.log(`\n${results.passed} passed, ${results.failed} failed`)
  console.log(results.failed === 0 ? "ALL GOOD: packet framer works" : "FAILED")
  process.exit(results.failed === 0 ? 0 : 1)
}

main()
