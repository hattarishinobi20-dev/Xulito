// Creates 2 accounts, then asks profile and leaderboards. Usage: node TestFiles/testProfile.js
const net = require("net"), fs = require("fs"), RC4 = require("simple-rc4")
const ByteStream = require("../Titan/DataStream/ByteStream"), config = require("../config.dev.json")
const FP_SHA = require("fs").readFileSync(__dirname + "/../AssetsServer/lastversion.txt", "utf8").trim().split("...")[1]
const keyNonce = () => Buffer.concat([Buffer.from(config.crypto.rc4.key), Buffer.from(config.crypto.rc4.nonce)])

function connect (token, steps, onDone) {
  const enc = new RC4(keyNonce()); enc.update(keyNonce()); const dec = new RC4(keyNonce()); dec.update(keyNonce())
  const socket = net.createConnection(config.port, "127.0.0.1"); let queue = Buffer.alloc(0), step = 0; const log = [], results = {}
  const send = (id, s) => { const p = config.crypto.activate ? enc.update(Buffer.from(s.buffer)) : s.buffer; const h = Buffer.alloc(7); h.writeUInt16BE(id, 0); h.writeUIntBE(p.length, 2, 3); socket.write(Buffer.concat([h, p])) }
  const next = () => { if (step < steps.length) { steps[step++]({ send, ByteStream }); setTimeout(next, 250) } else setTimeout(() => { socket.end(); onDone(token, log, results) }, 400) }
  socket.on("connect", () => { const s = new ByteStream(); s.writeInt(0); s.writeInt(1); s.writeInt(4); s.writeInt(0); s.writeInt(1); s.writeString("fp"); s.writeInt(2); s.writeInt(2); send(10100, s) })
  socket.on("data", (b) => { queue = Buffer.concat([queue, b]); while (queue.length >= 7) { const id = queue.readUInt16BE(0), len = queue.readUIntBE(2, 3); if (queue.length < 7 + len) break; let p = Buffer.from(queue.slice(7, 7 + len)); queue = queue.slice(7 + len); if (config.crypto.activate && len) p = dec.update(p); onMessage(id, p) } })
  function onMessage (id, payload) {
    if (id === 65535) return
    const s = new ByteStream(payload); log.push(id)
    const readBool = () => { s.bitOffset = 0; return s.readBoolean() } // core reader does not reset bitOffset after int/string reads
    if (id === 20100) { const l = new ByteStream(); l.writeInt(0); l.writeInt(0); l.writeString(token || null); l.writeInt(4); l.writeInt(0); l.writeInt(1); l.writeString(FP_SHA); l.writeString(null); l.writeString("dev"); l.writeString(null); l.writeString("iPhone"); l.writeVInt(1); l.writeString("pt-BR"); send(10101, l) }
    else if (id === 20104) { s.readLong(); s.readLong(); token = s.readString() }
    else if (id === 20105) { next() }
    else if (id === 24113) { const hi = s.readVInt(), lo = s.readVInt(), name = s.readString(); s.readVInt(); const n = s.readVInt(); results["profile" + lo] = { name, brawlers: n }; console.log(`<< 24113 Profile: ${hi}-${lo} "${name}" brawlers=${n}`) }
    else if (id === 24403) { const type = s.readVInt(); const cls = s.readVInt(); if (cls) s.readVInt(); const region = s.readString(); const n = s.readVInt(); const names = []; for (let i = 0; i < n; i++) { s.readVInt(); s.readVInt(); s.readVInt(); const t = s.readVInt(); readBool(); names.push(`${s.readString()}(${t})`); s.readString(); s.readVInt(); s.readVInt(); s.readVInt(); readBool() } results["lb" + type + (region || "")] = names; console.log(`<< 24403 Leaderboard type=${type} region="${region}": ${names.join(", ")}`) }
  }
}
const profile = (lowId) => ({ send, ByteStream }) => { const s = new ByteStream(); s.writeInt(0); s.writeInt(lowId); send(14113, s) }
const leaderboard = (isLocal, type, brawler) => ({ send, ByteStream }) => { const s = new ByteStream(); s.writeVInt(isLocal); s.writeVInt(type); if (type === 0) { s.writeVInt(16); s.writeVInt(brawler) } else s.writeVInt(0); send(14403, s) }
const setAccount = (token, fn) => { const d = __dirname + "/../Database/players/"; for (const f of fs.readdirSync(d)) { const p = d + f, a = JSON.parse(fs.readFileSync(p)); if (a.token === token) { fn(a); fs.writeFileSync(p, JSON.stringify(a, null, 4)) } } }

connect("", [], (tokenA) => {
  setAccount(tokenA, a => { a.name = "Alpha"; a.trophies = 300; a.brawlers[0].trophies = 300 })
  connect("", [], (tokenB) => {
    setAccount(tokenB, a => { a.name = "Bravo"; a.trophies = 120; a.brawlers[0].trophies = 120; a.region = "US" })
    connect(tokenA, [ profile(1), profile(2), profile(99), leaderboard(0, 1), leaderboard(1, 1), leaderboard(0, 0, 0), leaderboard(0, 2) ], (t, log, r) => {
      const ok = r.profile1 && r.profile1.name === "Alpha" && r.profile2 && r.profile2.name === "Bravo" && !r.profile99 &&
        r.lb1 && r.lb1[0].startsWith("Alpha(300)") && r.lb1[1].startsWith("Bravo(120)") &&
        r.lb1BR && r.lb1BR.length === 1 && r.lb0 && r.lb0.length === 2 && r.lb2 && r.lb2.length === 0 && log.filter(e => e === 24403).length === 4
      console.log(ok ? "\nALL GOOD: profile + leaderboard work" : "\nSOMETHING WRONG " + JSON.stringify(r) + " " + log.join(","))
      process.exit(ok ? 0 : 1)
    })
  })
})
setTimeout(() => { console.log("timeout"); process.exit(1) }, 15000)
