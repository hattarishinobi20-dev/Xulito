// Team (game room) flow with two online clients: create, join, chat, change brawler, kick, ready -> shared battle,
// inputs, battle end, relogin while in room, leave, room deleted.
// Usage (server running, GameConfig.battleTicksOverride = 100 recommended): node TestFiles/testTeam.js
const net = require("net"), RC4 = require("simple-rc4")
const ByteStream = require("../Titan/DataStream/ByteStream"), config = require("../config.dev.json")
const FP_SHA = require("fs").readFileSync(__dirname + "/../AssetsServer/lastversion.txt", "utf8").trim().split("...")[1]
const keyNonce = () => Buffer.concat([Buffer.from(config.crypto.rc4.key), Buffer.from(config.crypto.rc4.nonce)])

function client (label) {
  const enc = new RC4(keyNonce()); enc.update(keyNonce()); const dec = new RC4(keyNonce()); dec.update(keyNonce())
  const c = { label, token: "", lowId: 0, log: [], last: { visions: 0, ticks: [] }, ready: null }
  const socket = net.createConnection(config.port, "127.0.0.1"); let queue = Buffer.alloc(0)
  c.send = (id, s) => { const p = config.crypto.activate ? enc.update(Buffer.from(s.buffer)) : s.buffer; const h = Buffer.alloc(7); h.writeUInt16BE(id, 0); h.writeUIntBE(p.length, 2, 3); socket.write(Buffer.concat([h, p])) }
  c.end = () => socket.end()
  c.loggedIn = new Promise(resolve => { c.ready = resolve })
  socket.on("connect", () => { const s = new ByteStream(); s.writeInt(0); s.writeInt(1); s.writeInt(4); s.writeInt(0); s.writeInt(1); s.writeString("fp"); s.writeInt(2); s.writeInt(2); c.send(10100, s) })
  socket.on("data", (b) => { queue = Buffer.concat([queue, b]); while (queue.length >= 7) { const id = queue.readUInt16BE(0), len = queue.readUIntBE(2, 3); if (queue.length < 7 + len) break; let p = Buffer.from(queue.slice(7, 7 + len)); queue = queue.slice(7 + len); if (config.crypto.activate && len) p = dec.update(p); onMessage(id, p) } })

  const readBool = (s) => { s.bitOffset = 0; return s.readBoolean() }
  const readEntry = (s) => { const type = s.readVInt(); s.readVInt(); const id = s.readVInt(); s.readVInt(); const playerId = s.readVInt(); const playerName = s.readString(); s.readVInt(); s.readVInt(); readBool(s); const e = { type, id, playerId, playerName }; if (type === 2) e.message = s.readString(); else if (type === 4) { e.event = s.readVInt(); readBool(s); s.readVInt(); e.targetId = s.readVInt(); e.targetName = s.readString() } return e }

  function onMessage (id, payload) {
    if (id === 65535) return
    const s = new ByteStream(payload); c.log.push(id)
    if (id === 20100) { const l = new ByteStream(); l.writeInt(0); l.writeInt(0); l.writeString(c.token || null); l.writeInt(4); l.writeInt(0); l.writeInt(1); l.writeString(FP_SHA); l.writeString(null); l.writeString("dev"); l.writeString(null); l.writeString("iPhone"); l.writeVInt(1); l.writeString("pt-BR"); c.send(10101, l) }
    else if (id === 20104) { s.readLong(); c.lowId = s.readLong()[1]; c.token = s.readString() }
    else if (id === 24124) { const roomType = s.readVInt(); const practice = readBool(s); s.readVInt(); const teamId = s.readLong()[1]; s.readVInt(); s.readVInt(); const adAlliance = s.readVInt(); s.readVInt(); const location = s.readVInt(); const n = s.readVInt(); const members = []; for (let i = 0; i < n; i++) { const lo = s.readLong()[1]; const name = s.readString(); s.readVInt(); s.readVInt(); const brawler = s.readVInt(); s.readVInt(); const t = s.readVInt(); s.readVInt(); s.readVInt(); const status = s.readVInt(); s.readVInt(); const ready = readBool(s); const side = s.readVInt(); members.push({ lo, name, brawler, t, status, ready, side }) } c.last.team = { roomType, practice, teamId, adAlliance, location, members }; console.log(`[${label}] << 24124 Team ${JSON.stringify(c.last.team)}`) }
    else if (id === 24125) { c.last.left = s.readInt(); console.log(`[${label}] << 24125 TeamLeft reason=${c.last.left}`) }
    else if (id === 24129) { c.last.error = s.readVInt(); console.log(`[${label}] << 24129 TeamError ${c.last.error}`) }
    else if (id === 24130) { c.last.starting = (c.last.starting || 0) + 1; console.log(`[${label}] << 24130 TeamGameStarting`) }
    else if (id === 24131) { s.readVInt(); const teamId = s.readVInt(); const n = s.readVInt(); const entries = []; for (let i = 0; i < n; i++) entries.push(readEntry(s)); c.last.stream = entries; c.last.entries = (c.last.entries || []).concat(entries); console.log(`[${label}] << 24131 TeamStream team=${teamId} ${JSON.stringify(entries)}`) }
    else if (id === 20405) { c.last.matchmaking = { timer: s.readInt(), players: s.readInt() }; console.log(`[${label}] << 20405 MatchMakingStatus ${JSON.stringify(c.last.matchmaking)}`) }
    else if (id === 20559) { s.readInt(); s.readInt(); s.readInt(); const n = s.readInt(); const players = []; for (let i = 0; i < n; i++) { const lo = s.readLong()[1]; const name = s.readString(); const idx = s.readVInt(); const team = s.readVInt(); s.readVInt(); s.readVInt(); s.readInt(); s.readVInt(); const brawler = s.readVInt(); s.readVInt(); s.readInt(); players.push({ lo, name, idx, team, brawler }) } c.last.loading = players; console.log(`[${label}] << 20559 StartLoading ${players.map(p => `${p.name}#${p.lo}@${p.idx}/${p.team}`).join(" ")}`) }
    else if (id === 24109) { c.last.visions++; c.last.ticks.push(s.readVInt()); s.readVInt(); s.readVInt(); c.last.visionLen = s.readInt() }
    else if (id === 23456) { c.last.battleEnd = (c.last.battleEnd || 0) + 1; console.log(`[${label}] << 23456 BattleEnd`) }
    else if (id === 20105) { if (c.ready) { c.ready(); c.ready = null } }
  }
  return c
}

const wait = (ms) => new Promise(r => setTimeout(r, ms))
const vints = (...values) => { const s = new ByteStream(); for (const v of values) s.writeVInt(v); return s }
const checks = []
const check = (name, ok) => { checks.push(ok); console.log(`${ok ? "OK  " : "FAIL"} ${name}`) }

async function main () {
  const A = client("A"), B = client("B")
  await Promise.all([A.loggedIn, B.loggedIn])
  await wait(300)

  // A creates a room
  A.send(14350, vints(1, 0, 1)); await wait(400)
  check("create: TeamMessage with 1 member + stream with created event", A.last.team && A.last.team.members.length === 1 && A.last.team.members[0].lo === A.lowId && A.last.team.location > 0 && A.last.stream && A.last.stream.length === 1 && A.last.stream[0].event === 101)
  const teamId = A.last.team.teamId

  // A cannot create another one, B cannot join a wrong id
  A.send(14350, vints(1, 0, 1)); B.send(14351, vints(0, 999, 0)); await wait(400)
  check("errors: already in room (10) / room not found (6)", A.last.error === 10 && B.last.error === 6)

  // B joins
  B.send(14351, vints(0, teamId, 0)); await wait(500)
  check("join: B gets Team with 2 members + stream; A gets joined entry + Team refresh", B.last.team && B.last.team.members.length === 2 && B.last.entries.some(e => e.event === 101) && B.last.entries.some(e => e.event === 102) && A.last.team.members.length === 2 && A.last.entries.some(e => e.type === 4 && e.event === 102 && e.targetId === B.lowId))

  // chat + brawler change + status + practice
  A.send(14359, (() => { const s = new ByteStream(); s.writeString("gogo"); return s })()); await wait(300)
  check("chat: both receive the chat entry", [A, B].every(c => c.last.entries.some(e => e.type === 2 && e.message === "gogo" && e.playerId === A.lowId)))
  B.send(14354, vints(0, 16, 0)); B.send(14361, vints(2)); A.send(14356, new ByteStream()); await wait(400)
  const bMember = A.last.team.members.find(m => m.lo === B.lowId)
  check("member settings: brawler 0 / status 2 / practice toggled visible to A", bMember && bMember.brawler === 0 && bMember.status === 2 && A.last.team.practice === true)

  // kick: B cannot kick host, A kicks B
  B.send(14352, vints(0, A.lowId)); await wait(300)
  A.send(14352, vints(0, B.lowId)); await wait(400)
  check("kick: B gets TeamLeft reason 1, A gets kicked entry + 1 member", B.last.left === 1 && A.last.team.members.length === 1 && A.last.entries.some(e => e.type === 4 && e.event === 104 && e.targetId === B.lowId))

  // B joins again, both ready -> battle
  B.send(14351, vints(0, teamId, 0)); await wait(400)
  const readyMsg = (ready) => { const s = new ByteStream(); s.writeBoolean(ready); s.writeVInt(0); return s }
  A.send(14355, readyMsg(true)); await wait(400)
  check("ready: A ready, B not -> no battle yet", A.last.team.members.find(m => m.lo === A.lowId).ready === true && !A.last.starting)
  B.send(14355, readyMsg(true)); await wait(800)
  check("all ready: both get TeamGameStarting + MatchMakingStatus(2 players) + StartLoading", [A, B].every(c => c.last.starting === 1 && c.last.matchmaking && c.last.matchmaking.players === 2 && c.last.loading && c.last.loading.length === 6))
  check("start loading: A hero 0 team 0, B hero 1 team 0, same list for both", A.last.loading[0].lo === A.lowId && A.last.loading[1].lo === B.lowId && A.last.loading[1].team === 0 && B.last.loading[0].lo === A.lowId && B.last.loading[1].lo === B.lowId && A.last.loading[3].team === 1)
  check("visions: both receive VisionUpdate", A.last.visions > 3 && B.last.visions > 3)
  const lenA = A.last.visionLen, lenB = B.last.visionLen

  // B moves (input) -> own vision; A goes home (leaves the battle), B keeps receiving visions
  const input = new ByteStream(); input.writeVInt(0); input.writeVInt(0); input.writeVInt(1); input.writeVInt(0); input.writeVInt(0); input.writeVInt(100); input.writeVInt(3000); input.writeVInt(5000)
  B.send(10555, input); await wait(300)
  A.send(14101, new ByteStream()); await wait(200)
  const visionsA = A.last.visions, visionsB = B.last.visions
  await wait(600)
  check("A left the battle (GoHome): A stops receiving visions, B still does", A.last.visions === visionsA && B.last.visions > visionsB)
  check("vision payload length is the same for both hero indexes", lenA === lenB && lenA > 0)

  // B asks battle end
  const end = new ByteStream(); end.writeVInt(0); end.writeVInt(10); end.writeVInt(0); end.writeVInt(0); end.writeVInt(1); end.writeVInt(1); end.writeVInt(16); end.writeVInt(0); end.writeVInt(0); end.writeVInt(1); end.writeBoolean(true); end.writeString("B")
  B.send(14110, end); await wait(500)
  check("battle end: B receives BattleEnd", B.last.battleEnd === 1)

  // A reconnects while still in the room -> Team + TeamStream on login
  A.end(); await wait(300)
  const A2 = client("A2"); A2.token = A.token; await A2.loggedIn; await wait(400)
  check("relogin while in room: TeamMessage + TeamStream sent on login, still 2 members", A2.last.team && A2.last.team.teamId === teamId && A2.last.team.members.length === 2 && A2.last.stream && A2.last.stream.length > 0)

  // B leaves, A2 leaves -> room deleted
  B.send(14353, new ByteStream()); await wait(400)
  check("leave: B gets TeamLeft reason 0, A2 gets left entry + 1 member", B.last.left === 0 && A2.last.team.members.length === 1 && A2.last.entries.some(e => e.type === 4 && e.event === 103 && e.targetId === B.lowId))
  A2.send(14353, new ByteStream()); await wait(300)
  B.send(14351, vints(0, teamId, 0)); await wait(300)
  check("last member leaves: room deleted (join -> error 6)", A2.last.left === 0 && B.last.error === 6)

  A2.end(); B.end()

  const ok = checks.every(Boolean)
  console.log(ok ? "\nALL GOOD: teams work" : `\nSOMETHING WRONG (${checks.filter(c => !c).length} failed)`)
  process.exit(ok ? 0 : 1)
}

main().catch(e => { console.error(e); process.exit(1) })
setTimeout(() => { console.log("TIMEOUT"); process.exit(1) }, 40000)
