// Logs in and sends home commands (EndClientTurn) to verify step 1.
// Usage: node TestFiles/testCommands.js
const net = require("net")
const fs = require("fs")
const RC4 = require("simple-rc4")
const ByteStream = require("../Titan/DataStream/ByteStream")
const FP_SHA = require("fs").readFileSync(__dirname + "/../AssetsServer/lastversion.txt", "utf8").trim().split("...")[1]
const config = require("../config.dev.json")

const HOST = "127.0.0.1", PORT = config.port
const keyNonce = () => Buffer.concat([Buffer.from(config.crypto.rc4.key), Buffer.from(config.crypto.rc4.nonce)])

const accountPath = (token) => { const d = __dirname + "/../Database/players/"; return d + fs.readdirSync(d).filter(f => f.endsWith(".json")).find(f => JSON.parse(fs.readFileSync(d + f)).token === token) }
const loadAccount = (token) => JSON.parse(fs.readFileSync(accountPath(token)))
const saveAccount = (a) => fs.writeFileSync(accountPath(a.token), JSON.stringify(a, null, 4))

function connect (token, steps, onDone) {
  const enc = new RC4(keyNonce()); enc.update(keyNonce())
  const dec = new RC4(keyNonce()); dec.update(keyNonce())
  const socket = net.createConnection(PORT, HOST)
  let queue = Buffer.alloc(0), step = 0
  const log = []

  const send = (id, stream, version = 0) => {
    const payload = config.crypto.activate ? enc.update(Buffer.from(stream.buffer)) : stream.buffer
    const header = Buffer.alloc(7)
    header.writeUInt16BE(id, 0); header.writeUIntBE(payload.length, 2, 3); header.writeUInt16BE(version, 5)
    socket.write(Buffer.concat([header, payload]))
  }
  // EndClientTurn: bool, tick, checksum, count, then per command: type + 4 header vints + body
  const writeCommand = (s, type, writeBody) => { s.writeVInt(type); for (let i = 0; i < 4; i++) s.writeVInt(0); if (writeBody) writeBody(s) }
  const command = (type, writeBody) => {
    const s = new ByteStream()
    s.writeBoolean(true); s.writeVInt(1); s.writeVInt(0); s.writeVInt(1)
    writeCommand(s, type, writeBody)
    send(14102, s)
  }
  const commands = (list) => { // several commands in one turn
    const s = new ByteStream()
    s.writeBoolean(true); s.writeVInt(1); s.writeVInt(0); s.writeVInt(list.length)
    for (const [type, writeBody] of list) writeCommand(s, type, writeBody)
    send(14102, s)
  }
  const api = { send, command, commands, ByteStream }
  const next = () => { if (step < steps.length) { steps[step++](api); setTimeout(next, 250) } else setTimeout(() => { socket.end(); onDone(token, log) }, 500) }

  socket.on("connect", () => {
    const s = new ByteStream()
    s.writeInt(0); s.writeInt(1); s.writeInt(4); s.writeInt(0); s.writeInt(1); s.writeString("fp"); s.writeInt(2); s.writeInt(2)
    send(10100, s)
  })
  socket.on("data", (bytes) => {
    queue = Buffer.concat([queue, bytes])
    while (queue.length >= 7) {
      const id = queue.readUInt16BE(0), len = queue.readUIntBE(2, 3)
      if (queue.length < 7 + len) break
      let payload = Buffer.from(queue.slice(7, 7 + len)); queue = queue.slice(7 + len)
      if (config.crypto.activate && len) payload = dec.update(payload)
      onMessage(id, payload)
    }
  })

  function onMessage (id, payload) {
    if (id === 65535) return
    const s = new ByteStream(payload)
    log.push(id)
    if (id === 20100) {
      const l = new ByteStream()
      l.writeInt(0); l.writeInt(0); l.writeString(token || null); l.writeInt(4); l.writeInt(0); l.writeInt(1)
      l.writeString(FP_SHA); l.writeString(null); l.writeString("dev"); l.writeString(null); l.writeString("iPhone"); l.writeVInt(1); l.writeString("pt-BR")
      send(10101, l)
    } else if (id === 20104) {
      s.readLong(); s.readLong(); token = s.readString(); console.log("logged in, token:", token)
    } else if (id === 24101 && log.filter(e => e === 24101).length === 1) {
      next()
    } else if (id === 24111) {
      const type = s.readVInt()
      if (type === 201) console.log(`<< 24111 ChangeAvatarName: name="${s.readString()}"`)
      else if (type === 203) {
        const boxId = s.readVInt(), count = s.readVInt(); const rewards = []
        for (let i = 0; i < count; i++) { const rarity = s.readVInt(), amount = s.readVInt(), cls = s.readVInt(), inst = cls ? s.readVInt() : 0, rtype = s.readVInt(); rewards.push(`r${rarity} x${amount} [${cls},${inst}] t${rtype}`) }
        console.log(`<< 24111 GiveDeliveryItems: box ${boxId}: ${rewards.join(" | ")}`)
      } else console.log("<< 24111 command", type)
    } else if (id === 24101) {
      console.log("<< 24101 OwnHomeData after commands")
    }
  }
}

let failed = 0
const check = (name, ok, extra = "") => { console.log(`${ok ? "ok  " : "FAIL"} ${name}${extra ? " -> " + extra : ""}`); if (!ok) failed++ }

// Session 1: create account, rename, settings
connect(process.env.TOKEN || "", [
  ({ send, ByteStream }) => { const s = new ByteStream(); s.writeString("NodeTester"); send(10212, s) }, // -> 24111 (201)
  ({ command }) => command(509, s => s.writeVInt(1)),  // control mode = joystick
  ({ command }) => command(513),                        // toggle battle hints
  ({ command }) => command(500, s => s.writeVInt(1)),  // coin box -> rejected (92 gold)
  ({ command }) => command(502, s => { s.writeVInt(23); s.writeVInt(8) }) // BullDude with chips -> rejected (0 chips)
], (token, log1) => {
  let p = loadAccount(token)
  check("session 1: rename / control mode / battle hints saved", p.name === "NodeTester" && p.controlMode === 1 && p.battleHints === true)
  check("session 1: coin box without gold refused, nothing changed", p.gold === 92 && log1.filter(e => e === 24111).length === 1)
  check("session 1: brawler without chips refused, not unlocked", Object.keys(p.brawlers).length === 1 && p.chips === 0)

  p.gold = 1000; p.gems = 500; p.chips = 10; saveAccount(p)
  console.log("   (test) gave 1000 gold / 500 gems / 10 chips, reconnecting...\n")

  // Session 2: shop
  connect(token, [
    ({ command }) => command(500, s => s.writeVInt(1)),  // coin box (100 gold) -> 24111 (203)
    ({ command }) => command(500, s => s.writeVInt(3)),  // big gem box (80 gems, 10 rewards)
    ({ command }) => command(514, s => s.writeVInt(1)),  // rare brawler box (30 gems)
    ({ command }) => command(510),                        // coins doubler (50 gems)
    ({ command }) => command(502, s => { s.writeVInt(23); s.writeVInt(8) }), // BullDude (rare, 10 chips) with chips
    ({ command }) => command(502, s => { s.writeVInt(23); s.writeVInt(8) }), // again -> already unlocked, no double charge
    ({ command }) => command(508, s => { s.writeVInt(29); s.writeVInt(1) }), // default skin -> rejected
    ({ commands }) => commands([[509, s => s.writeVInt(2)], [500, s => s.writeVInt(2)]]), // two commands in one turn
    ({ send, ByteStream }) => send(14101, new ByteStream()) // go home -> 24101
  ], (token, log2) => {
    p = loadAccount(token)
    console.log("\naccount:", { gold: p.gold, gems: p.gems, chips: p.chips, elixir: p.elixir, controlMode: p.controlMode, brawlers: Object.keys(p.brawlers), coinsDoubler: p.coinsDoubler })
    const rareIndexes = [2, 3, 6, 7]
    check("coin box: 100 gold taken, 203 received", p.gold === 900)
    check("gem boxes: 80 (big) + 30 (rare box) + 10 (small, in the 2-command turn) + 50 doubler taken", p.gems === 500 - 80 - 30 - 10 - 50, `gems ${p.gems}`)
    check("rare brawler box: a rare brawler unlocked", rareIndexes.some(i => p.brawlers[i]), `brawlers ${Object.keys(p.brawlers)}`)
    check("brawler bought with chips: BullDude (2) owned, 10 chips taken once (chips may have grown from duplicates)", !!p.brawlers[2] && p.chips >= 0 && p.chips !== 10, `chips ${p.chips}`)
    check("second purchase of the same brawler refused (no duplicate / no second charge)", log2.filter(e => e === 24111).length === 4 && p.brawlers[2].cards[8] === 1)
    check("two commands in one turn: control mode 2 + small gem box", p.controlMode === 2 && log2.filter(e => e === 24111).length === 4)
    check("coins doubler", p.coinsDoubler >= 1000)
    check("owned brawler progress intact (brawler 0 still has its card)", p.brawlers[0] && p.brawlers[0].cards[0] === 1)

    // Session 3: relogin -> rarity box when every rare brawler is owned gives chips and resets nothing
    const before = loadAccount(token)
    for (const i of rareIndexes) if (!before.brawlers[i]) before.brawlers[i] = { cards: {}, skins: [0], selectedSkin: 0, trophies: 0, highestTrophies: 0, powerLevel: 0 }
    before.brawlers[2].trophies = 77; before.brawlers[2].highestTrophies = 77; before.gems = 100; saveAccount(before)
    const chipsBefore = before.chips
    connect(token, [
      ({ command }) => command(514, s => s.writeVInt(1)) // rare box, all rare brawlers owned -> chips
    ], (token, log3) => {
      const q = loadAccount(token)
      check("relogin: brawlers bought earlier still owned", !!q.brawlers[2] && Object.keys(q.brawlers).length === Object.keys(before.brawlers).length)
      check("rare box with all rares owned: 30 gems taken, duplicate chips (2) given, 203 sent", q.gems === 70 && q.chips === chipsBefore + 2 && log3.includes(24111), `gems ${q.gems} chips ${q.chips}`)
      check("rare box never resets an owned brawler (BullDude keeps 77 trophies)", q.brawlers[2].trophies === 77 && q.brawlers[2].highestTrophies === 77)
      console.log(failed === 0 ? "\nALL GOOD: commands work" : `\n${failed} FAILED. session1: ${log1.join(",")} session2: ${log2.join(",")} session3: ${log3.join(",")}`)
      process.exit(failed === 0 ? 0 : 1)
    })
  })
})

setTimeout(() => { console.log("timeout"); process.exit(1) }, 25000)
