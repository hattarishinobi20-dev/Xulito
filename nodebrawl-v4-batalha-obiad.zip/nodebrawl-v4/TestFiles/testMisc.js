// Misc coverage: 10107 / 10177 / 14109, commands 506 / 511 / 515, team 14357 / 14358 / 14360, keep alive + MyAlliance,
// duplicate login, ban lists (LoginFailed 11), battle rejoin after a disconnect.
// Usage (server running, clean Database/players, Database/alliances and ban files): node TestFiles/testMisc.js
const net = require("net"), fs = require("fs"), RC4 = require("simple-rc4")
const ByteStream = require("../Titan/DataStream/ByteStream"), config = require("../config.dev.json")
const FP_SHA = require("fs").readFileSync(__dirname + "/../AssetsServer/lastversion.txt", "utf8").trim().split("...")[1]
const keyNonce = () => Buffer.concat([Buffer.from(config.crypto.rc4.key), Buffer.from(config.crypto.rc4.nonce)])
const DB = __dirname + "/../Database/"

function client (label, opts = {}) {
  const enc = new RC4(keyNonce()); enc.update(keyNonce()); const dec = new RC4(keyNonce()); dec.update(keyNonce())
  const c = { label, token: opts.token || "", lowId: 0, log: [], last: { visions: 0 }, closed: false }
  const socket = net.createConnection(config.port, "127.0.0.1"); let queue = Buffer.alloc(0)
  c.send = (id, s) => { const p = config.crypto.activate ? enc.update(Buffer.from(s.buffer)) : s.buffer; const h = Buffer.alloc(7); h.writeUInt16BE(id, 0); h.writeUIntBE(p.length, 2, 3); socket.write(Buffer.concat([h, p])) }
  c.end = () => socket.end(); c.destroy = () => socket.destroy()
  c.loggedIn = new Promise(resolve => { c.ready = resolve })
  socket.on("close", () => { c.closed = true }); socket.on("error", () => { c.closed = true })
  socket.on("connect", () => { const s = new ByteStream(); s.writeInt(0); s.writeInt(1); s.writeInt(4); s.writeInt(0); s.writeInt(1); s.writeString("fp"); s.writeInt(2); s.writeInt(2); c.send(10100, s) })
  socket.on("data", (b) => { queue = Buffer.concat([queue, b]); while (queue.length >= 7) { const id = queue.readUInt16BE(0), len = queue.readUIntBE(2, 3); if (queue.length < 7 + len) break; let p = Buffer.from(queue.slice(7, 7 + len)); queue = queue.slice(7 + len); if (config.crypto.activate && len) p = dec.update(p); onMessage(id, p) } })
  const readBool = (s) => { s.bitOffset = 0; return s.readBoolean() }
  function onMessage (id, payload) {
    if (id === 65535) return
    const s = new ByteStream(payload); c.log.push(id)
    if (id === 20100) { const l = new ByteStream(); l.writeInt(0); l.writeInt(0); l.writeString(c.token || null); l.writeInt(4); l.writeInt(0); l.writeInt(1); l.writeString(FP_SHA); l.writeString(null); l.writeString("dev"); l.writeString(null); l.writeString("iPhone"); l.writeVInt(1); l.writeString("pt-BR"); c.send(10101, l) }
    else if (id === 20104) { s.readLong(); c.lowId = s.readLong()[1]; c.token = s.readString() }
    else if (id === 20103) { c.last.loginFailed = { code: s.readInt(), fingerprint: s.readString(), host: s.readString(), content: s.readString(), update: s.readString(), reason: s.readString() }; console.log(`[${label}] << 20103 LoginFailed ${JSON.stringify(c.last.loginFailed)}`); if (c.ready) { c.ready(); c.ready = null } }
    else if (id === 24101) { c.last.ownHomeData = (c.last.ownHomeData || 0) + 1 }
    else if (id === 24399) { c.last.myAlliance = (c.last.myAlliance || 0) + 1 }
    else if (id === 24124) { s.readVInt(); readBool(s); s.readVInt(); const teamId = s.readLong()[1]; s.readVInt(); s.readVInt(); const adAlliance = s.readVInt(); s.readVInt(); s.readVInt(); const n = s.readVInt(); c.last.team = { teamId, adAlliance, members: n }; console.log(`[${label}] << 24124 Team ${JSON.stringify(c.last.team)}`) }
    else if (id === 24312) { const type = s.readVInt(); c.last.allianceEntries = (c.last.allianceEntries || []).concat(type); console.log(`[${label}] << 24312 AllianceStreamEntry type=${type}`) }
    else if (id === 20559) { c.last.startLoading = (c.last.startLoading || 0) + 1; console.log(`[${label}] << 20559 StartLoading`) }
    else if (id === 24109) { c.last.visions++ }
    else if (id === 20105) { if (c.ready) { c.ready(); c.ready = null } }
  }
  return c
}

const wait = (ms) => new Promise(r => setTimeout(r, ms))
const vints = (...values) => { const s = new ByteStream(); for (const v of values) s.writeVInt(v); return s }
const command = (type, writeBody) => { const s = new ByteStream(); s.writeBoolean(true); s.writeVInt(1); s.writeVInt(0); s.writeVInt(1); s.writeVInt(type); for (let i = 0; i < 4; i++) s.writeVInt(0); if (writeBody) writeBody(s); return s }
const account = (lowId) => JSON.parse(fs.readFileSync(DB + "players/" + lowId + ".json"))
const setAccount = (lowId, fn) => { const a = account(lowId); fn(a); fs.writeFileSync(DB + "players/" + lowId + ".json", JSON.stringify(a, null, 4)) }
const checks = []
const check = (name, ok) => { checks.push(ok); console.log(`${ok ? "OK  " : "FAIL"} ${name}`) }

async function main () {
  for (const f of ["banned_acc.json", "banned_ip.json"]) if (fs.existsSync(DB + f)) fs.unlinkSync(DB + f)

  let A = client("A"); await A.loggedIn; await wait(200)

  // 10107 / 10177 / 14109 / keep alive
  const cap = new ByteStream(); cap.writeVInt(1); cap.writeVInt(2); A.send(10107, cap)
  const info = new ByteStream(); info.writeVInt(1); info.writeString("info"); A.send(10177, info)
  A.send(14109, new ByteStream()); await wait(300)
  check("10107 / 10177 accepted silently, 14109 GoHomeFromOffline -> OwnHomeData", !A.closed && A.last.ownHomeData === 2)
  const ka = A.last.myAlliance || 0
  A.send(10108, new ByteStream()); await wait(300)
  check("KeepAlive -> 20108 + 24399 MyAlliance (Obiad parity)", A.log.includes(20108) && A.last.myAlliance === ka + 1)

  // commands 506 (thumbnail 3 requires ShotgunGirl = brawler 0), 511 (coins booster, 20 gems), 515 (handle notification 1 removes 99)
  A.end(); await wait(300)
  setAccount(A.lowId, a => { a.gems = 25; a.homeNotifications = [{ id: 99, type: 0, seen: false, bestBrawler: 0, trophies: 10, gold: 0 }] })
  A = client("A", { token: A.token }); await A.loggedIn; await wait(200)
  A.send(14102, command(506, s => { s.writeVInt(28); s.writeVInt(3) })); await wait(300)
  A.send(14102, command(511)); await wait(300)
  A.send(14102, command(515, s => s.writeVInt(1))); await wait(400)
  const acc = account(A.lowId)
  check("506: profileIcon == 3 persisted", acc.profileIcon === 3)
  check("511: gems 25 -> 5 and coinsBooster in the future", acc.gems === 5 && acc.coinsBooster > Math.floor(Date.now() / 1000))
  check("515 (type 1): notification 99 removed", !acc.homeNotifications.some(n => n.id === 99))

  // team: 14358 spectate (joins), 14357 toggle side, 14360 post ad to the alliance (type 77 entry)
  const B = client("B"); await B.loggedIn; await wait(200)
  const cr = new ByteStream(); cr.writeString("Ad Club"); cr.writeString(""); cr.writeVInt(8); cr.writeVInt(1); cr.writeVInt(1); cr.writeVInt(0); A.send(14301, cr); await wait(300)
  A.send(14350, vints(1, 0, 1)); await wait(300)
  B.send(14358, vints(0, A.last.team.teamId, 0)); await wait(400)
  check("14358 spectate: B joins the room (2 members)", B.last.team && B.last.team.members === 2 && A.last.team.members === 2)
  const teamMsgs = A.log.filter(i => i === 24124).length
  A.send(14357, vints(0, 1)); await wait(300)
  check("14357 toggle side: TeamMessage resent", A.log.filter(i => i === 24124).length === teamMsgs + 1)
  A.send(14360, new ByteStream()); await wait(400)
  check("14360 post ad: room advertised to the alliance + type 77 stream entry", A.last.team.adAlliance === 1 && (A.last.allianceEntries || []).includes(77))
  B.send(14353, new ByteStream()); A.send(14353, new ByteStream()); await wait(300)

  // duplicate login: the first session is closed, the new one stays
  const A2 = client("A2", { token: A.token }); await A2.loggedIn; await wait(500)
  check("duplicate login: previous session closed, new session logged in with the same lowId", A.closed && !A2.closed && A2.lowId === A.lowId)

  // battle rejoin: matchmake, hard disconnect, login again -> StartLoading + visions, no OwnHomeData
  const mm = new ByteStream(); mm.writeVInt(0); mm.writeVInt(16); mm.writeVInt(0); mm.writeVInt(1); mm.writeVInt(0); mm.writeVInt(0); mm.writeVInt(0)
  A2.send(14103, mm); await wait(500)
  check("battle started for A2", A2.last.visions > 0)
  A2.destroy(); await wait(600)
  const A3 = client("A3", { token: A.token }); await new Promise(r => { const t = setInterval(() => { if (A3.last.startLoading || A3.closed) { clearInterval(t); r() } }, 50); setTimeout(() => { clearInterval(t); r() }, 3000) }); await wait(600)
  check("battle rejoin: login -> 20559 StartLoading, visions resume, no OwnHomeData", A3.last.startLoading === 1 && A3.last.visions > 0 && !A3.last.ownHomeData)
  A3.send(14101, new ByteStream()); await wait(300)
  check("GoHome after rejoin -> OwnHomeData", A3.last.ownHomeData === 1)
  A3.end(); B.end(); await wait(300)

  // ban: account banned -> LoginFailed 11 with reason, ip gets banned too; unban -> login works
  fs.writeFileSync(DB + "banned_acc.json", JSON.stringify({ [String(A.lowId)]: { reason: "audit ban" } }))
  const BAN = client("BAN", { token: A.token }); await BAN.loggedIn; await wait(300)
  const ipBans = fs.existsSync(DB + "banned_ip.json") ? JSON.parse(fs.readFileSync(DB + "banned_ip.json")) : {}
  check("banned account: 20103 code 11 with reason, ip added to banned_ip.json", BAN.last.loginFailed && BAN.last.loginFailed.code === 11 && BAN.last.loginFailed.reason === "audit ban" && ipBans["127.0.0.1"] !== undefined)
  BAN.end()
  fs.writeFileSync(DB + "banned_acc.json", "{}"); fs.writeFileSync(DB + "banned_ip.json", "{}")
  const OK = client("OK", { token: A.token }); await OK.loggedIn; await wait(200)
  check("unbanned: login works again", OK.lowId === A.lowId && OK.last.ownHomeData === 1)
  OK.end()
  for (const f of ["banned_acc.json", "banned_ip.json"]) if (fs.existsSync(DB + f)) fs.unlinkSync(DB + f)

  const ok = checks.every(Boolean)
  console.log(ok ? "\nALL GOOD: misc features work" : `\nSOMETHING WRONG (${checks.filter(c => !c).length} failed)`)
  process.exit(ok ? 0 : 1)
}

main().catch(e => { console.error(e); process.exit(1) })
setTimeout(() => { console.log("TIMEOUT"); process.exit(1) }, 40000)
