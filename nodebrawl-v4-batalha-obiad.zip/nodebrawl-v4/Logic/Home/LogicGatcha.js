const V4DataTables = require("../Data/V4DataTables")
const GameConfig = require("../Server/GameConfig")
const { JSRandom, getRandomElementFromArray } = require("../../Utils/Random")

const RARITIES = ["common", "rare", "super_rare", "epic", "mega_epic", "legendary"]
const RARITY_WEIGHTS = [25, 20, 15, 12, 8, 5]

const REWARD_TYPE = {
    NEW_BRAWLER: 1,
    CHIPS: 2,
    ELIXIR: 3,
    COINS_DOUBLER: 4,
    COINS_BOOSTER: 5
}

/**
 * LogicGatcha
 *
 * Box rewards generation. Ported from Obiad Brawl v4 (LogicGiveDeliveryItemsCommand.py); prices and amounts come
 * from GameConfig.shop, the same table the client receives in OwnHomeData.
 */
class LogicGatcha {
    static REWARD_TYPE = REWARD_TYPE
    static RARITIES = RARITIES

    /**
     * Pick random index using weights
     * @param { Array<Number> } weights Weights
     * @returns { Number } Index
     */
    static weightedRandom (weights) {
        const total = weights.reduce((a, b) => a + b, 0)
        let roll = JSRandom(1, total)

        for (let i = 0; i < weights.length; i++) {
            roll -= weights[i]
            if (roll <= 0) return i
        }

        return weights.length - 1
    }

    /**
     * Create empty brawler entry
     * @param { Number } unlockCardIndex Unlock card index
     * @returns { Object } Brawler entry
     */
    static createBrawler (unlockCardIndex) {
        return { cards: { [unlockCardIndex]: 1 }, skins: [0], selectedSkin: 0, trophies: 0, highestTrophies: 0, powerLevel: 0 }
    }

    /**
     * Unlock the brawler of an unlock card. Never touches an already unlocked brawler.
     * @param { Object } player Player account
     * @param { Object } card Unlock card (cards.csv row)
     * @returns { Boolean } true when the brawler was unlocked, false when the player already had it
     */
    static unlockBrawler (player, card) {
        const brawlerIndex = V4DataTables.getCardBrawlerIndex(card.index)

        if (brawlerIndex === -1 || player.brawlers[brawlerIndex]) return false

        player.brawlers[brawlerIndex] = LogicGatcha.createBrawler(card.index)

        return true
    }

    /**
     * Brawler reward of a card: the brawler when the player does not have it, chips otherwise
     * @param { Object } player Player account
     * @param { Object } card Unlock card
     * @param { Number } rarity Rarity index
     * @returns { Object } Reward
     */
    static giveBrawlerCard (player, card, rarity) {
        if (LogicGatcha.unlockBrawler(player, card)) {
            return { rarity, amount: 1, dataRef: [23, card.index], rewardType: REWARD_TYPE.NEW_BRAWLER }
        }

        const chips = GameConfig.shop.duplicateBrawlerChips[rarity]

        player.chips += chips

        return { rarity, amount: chips, dataRef: [23, card.index], rewardType: REWARD_TYPE.CHIPS }
    }

    /**
     * Random brawler of given rarity (or chips if already unlocked)
     * @param { Object } player Player account
     * @param { Number } rarity Rarity index
     * @returns { Object | null } Reward
     */
    static giveBrawler (player, rarity) {
        const cards = V4DataTables.getUnlockCardsWithRarity(RARITIES[rarity])

        if (cards.length === 0) return null

        return LogicGatcha.giveBrawlerCard(player, getRandomElementFromArray(cards), rarity)
    }

    static giveElixir (player, rarity) {
        const amount = GameConfig.shop.boxElixir[rarity]

        player.elixir += amount

        return { rarity, amount, dataRef: [23, 0], rewardType: REWARD_TYPE.ELIXIR }
    }

    static giveCoinsDoubler (player, rarity) {
        player.coinsDoubler += 200

        return { rarity, amount: 200, dataRef: [23, 0], rewardType: REWARD_TYPE.COINS_DOUBLER }
    }

    static giveCoinsBooster (player, rarity) {
        const now = Math.floor(Date.now() / 1000)
        const seconds = 259200 // 3 days

        player.coinsBooster = player.coinsBooster > now ? player.coinsBooster + seconds : now + seconds

        return { rarity, amount: seconds, dataRef: [23, 0], rewardType: REWARD_TYPE.COINS_BOOSTER }
    }

    /**
     * Generate single random reward
     * @param { Object } player Player account
     * @returns { Object } Reward
     */
    static generateReward (player) {
        const rarity = LogicGatcha.weightedRandom(RARITY_WEIGHTS)
        let reward = null

        if (rarity === 2) {
            switch (LogicGatcha.weightedRandom([10, 30, 30, 30])) {
                case 0: reward = LogicGatcha.giveBrawler(player, rarity); break
                case 1: reward = LogicGatcha.giveElixir(player, rarity); break
                case 2: reward = LogicGatcha.giveCoinsDoubler(player, rarity); break
                case 3: reward = LogicGatcha.giveCoinsBooster(player, rarity); break
            }
        } else {
            const giveBrawler = LogicGatcha.weightedRandom([10, 90]) === 0 || (rarity === 0 && Object.keys(player.brawlers).length === 1)

            reward = giveBrawler ? LogicGatcha.giveBrawler(player, rarity) : LogicGatcha.giveElixir(player, rarity)
        }

        return reward || LogicGatcha.giveElixir(player, rarity)
    }

    /**
     * Open box. Takes the price from player.
     * @param { Object } player Player account
     * @param { Number } boxType 1 - coin box, 2 - small gem box, 3 - big gem box
     * @returns { Object | null } { boxId, rewards } or null if the box type is unknown or the player can't afford it
     */
    static openBox (player, boxType) {
        const shop = GameConfig.shop
        let boxId
        let rewardsAmount = 1

        switch (boxType) {
            case 1:
                if (player.gold < shop.goldBoxCost) return null
                player.gold -= shop.goldBoxCost
                boxId = 10
                break
            case 2:
                if (player.gems < shop.gemBoxCost) return null
                player.gems -= shop.gemBoxCost
                boxId = 10
                break
            case 3:
                if (player.gems < shop.bigBoxCost) return null
                player.gems -= shop.bigBoxCost
                boxId = 11
                rewardsAmount = shop.bigBoxRewards
                break
            default:
                return null
        }

        const rewards = []

        for (let i = 0; i < rewardsAmount; i++) {
            rewards.push(LogicGatcha.generateReward(player))
        }

        return { boxId, rewards }
    }

    /**
     * Open a box with a guaranteed brawler of the given rarity. Takes the price (GameConfig.shop.brawlerBoxCost)
     * from player. A brawler the player does not own yet is picked; when he owns every brawler of that rarity the
     * box gives the duplicate chips of the rarity instead (the owned brawler is never reset).
     * @param { Object } player Player account
     * @param { Number } rarity Rarity index of the box (1 rare, 2 super rare, 3 epic)
     * @returns { Object | null } { boxId, rewards } or null if the box is not sold or the player can't afford it
     */
    static openBrawlerBox (player, rarity) {
        const price = GameConfig.shop.brawlerBoxCost[rarity]

        if (!price || player.gems < price) return null

        const cards = V4DataTables.getUnlockCardsWithRarity(RARITIES[rarity])

        if (cards.length === 0) return null

        player.gems -= price

        const locked = cards.filter(card => !player.brawlers[V4DataTables.getCardBrawlerIndex(card.index)])
        const card = getRandomElementFromArray(locked.length > 0 ? locked : cards)

        return { boxId: rarity, rewards: [ LogicGatcha.giveBrawlerCard(player, card, rarity) ] }
    }
}

module.exports = LogicGatcha
