/**
 * LogicClientAvatar
 *
 * Player avatar data for OwnHomeDataMessage.
 * Ported from Obiad Brawl v4 (Entries/LogicClientAvatar.py)
 */
class LogicClientAvatar {
    /**
     * Encode avatar data to ByteStream
     * @param { ByteStream } stream ByteStream class instance
     * @param { Object } player Player account data
     */
    static encode (stream, player) {
        const resourcesIds = [1, 5, 6]
        const resources = [player.gold, player.chips, player.elixir]

        for (let i = 0; i < 3; i++) {
            stream.writeVInt(player.highId) // LogicLong - Player ids related to home menu
            stream.writeVInt(player.lowId)
        }

        stream.writeString(player.name)
        stream.writeBoolean(player.name !== "Brawler") // Name set
        stream.writeInt(1) // Player region

        stream.writeVInt(5) // Commodity array

        const cards = {}
        for (const brawler of Object.values(player.brawlers)) {
            for (const card in brawler.cards) {
                cards[card] = brawler.cards[card]
            }
        }

        stream.writeVInt(Object.keys(cards).length + resourcesIds.length) // Cards and resources array
        for (const card in cards) {
            stream.writeVInt(23) // DataReference (23, card)
            stream.writeVInt(Number(card))
            stream.writeVInt(cards[card]) // Upgrades count
        }

        for (let i = 0; i < resourcesIds.length; i++) {
            stream.writeVInt(5) // DataReference (5, resource)
            stream.writeVInt(resourcesIds[i])
            stream.writeVInt(resources[i]) // Count
        }

        const brawlersIds = Object.keys(player.brawlers)

        stream.writeVInt(brawlersIds.length) // Brawlers trophies
        for (const id of brawlersIds) {
            stream.writeVInt(16) // DataReference (16, brawler)
            stream.writeVInt(Number(id))
            stream.writeVInt(player.brawlers[id].trophies)
        }

        stream.writeVInt(brawlersIds.length) // Brawlers highest trophies
        for (const id of brawlersIds) {
            stream.writeVInt(16) // DataReference (16, brawler)
            stream.writeVInt(Number(id))
            stream.writeVInt(player.brawlers[id].highestTrophies)
        }

        stream.writeVInt(0) // Highest resources array

        stream.writeVInt(brawlersIds.length) // Brawlers seen state
        for (const id of brawlersIds) {
            stream.writeVInt(16) // DataReference (16, brawler)
            stream.writeVInt(Number(id))
            stream.writeVInt(2)
        }

        stream.writeVInt(player.gems) // Gems
        stream.writeVInt(13) // Free gems

        stream.writeVInt(0) // Experience level (unused)
        stream.writeVInt(0) // Cumulative purchased gems
        stream.writeVInt(0) // Battles count
        stream.writeVInt(0) // Win count
        stream.writeVInt(0) // Lose count
        stream.writeVInt(0) // Win/lose streak
        stream.writeVInt(0) // NPC win count
        stream.writeVInt(0) // NPC lose count

        stream.writeVInt(player.tutorialState) // Tutorial state
    }
}

module.exports = LogicClientAvatar
