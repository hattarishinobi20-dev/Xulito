const GameConfig = require("../Server/GameConfig")
const PlayerDatabase = require("../../Database/PlayerDatabase")
const Storage = require("../../Database/Storage")

const SEASON_COLLECTION = "settings"
const SEASON_ID = "season"

/**
 * LogicSeason
 *
 * Trophy season handling (ported from Obiad Brawl v4 seasonEndManagement.py / BackgroundTasks.py).
 * The season end timestamp is persisted in Storage collection "settings", document "season" (MongoDB document /
 * Database/season.json; re-read every `CHECK_INTERVAL_MS`, so editing it to a past timestamp forces a season end);
 * when the season is over every account gets its brawlers above the reset threshold trimmed
 * (half of the trophies above the threshold), receives coins for the removed trophies and a
 * season end notification (99) shown on the next OwnHomeData.
 */
class LogicSeason {
    static CHECK_INTERVAL_MS = 7000
    static endTimestamp = 0
    static interval = null

    static init () {
        LogicSeason.load()
        LogicSeason.check()

        LogicSeason.interval = setInterval(() => LogicSeason.check(), LogicSeason.CHECK_INTERVAL_MS)

        Log(`LogicSeason: season ends in ${LogicSeason.getSecondsLeft()} seconds.`)
    }

    static load () {
        const data = Storage.get(SEASON_COLLECTION, SEASON_ID)

        LogicSeason.endTimestamp = data ? Number(data.nextSeasonEndTimestamp) || 0 : 0

        if (LogicSeason.endTimestamp <= 0) {
            LogicSeason.endTimestamp = LogicSeason.getNextEndTimestamp()
            LogicSeason.save()
        }
    }

    static save () {
        Storage.put(SEASON_COLLECTION, SEASON_ID, { nextSeasonEndTimestamp: LogicSeason.endTimestamp })
    }

    static getNextEndTimestamp () {
        return Math.floor(Date.now() / 1000) + GameConfig.seasonLengthDays * 24 * 3600
    }

    /**
     * @returns { Number } Seconds left until the season ends (never negative)
     */
    static getSecondsLeft () {
        return Math.max(LogicSeason.endTimestamp - Math.floor(Date.now() / 1000), 0)
    }

    /**
     * Ends the season if the timestamp is reached
     */
    static async check () {
        try {
            await Storage.refresh(SEASON_COLLECTION, SEASON_ID)
        } catch (e) {
            Warn(`LogicSeason: unable to refresh the season document: ${e.message}`)
        }

        LogicSeason.load() // re-read so the season end can be forced by editing the stored timestamp

        if (LogicSeason.endTimestamp > Math.floor(Date.now() / 1000)) return

        try {
            LogicSeason.endSeason()
        } catch (e) {
            Err(`LogicSeason: season end failed: ${e.stack}`)
        }

        LogicSeason.endTimestamp = LogicSeason.getNextEndTimestamp()
        LogicSeason.save()
    }

    /**
     * Online player object for the account (so in-memory state is not overwritten)
     * @param { Number } lowId Account low id
     * @returns { Object | null } Player
     */
    static getOnlinePlayer (lowId) {
        if (!global.sessions) return null

        for (const session of global.sessions.values()) {
            if (session.player && session.player.lowId === lowId) return session.player
        }

        return null
    }

    /**
     * Applies the season reset to every account
     */
    static endSeason () {
        const threshold = GameConfig.getBrawlersTrophiesForSeasonReset()
        let affected = 0

        for (const stored of PlayerDatabase.getAllAccounts()) {
            const player = LogicSeason.getOnlinePlayer(stored.lowId) || stored

            if (LogicSeason.resetPlayer(player, threshold)) affected++

            PlayerDatabase.save(player)
        }

        Log(`LogicSeason: season ended, ${affected} accounts received season rewards.`)
    }

    /**
     * Season reset for one player
     * @param { Object } player Player
     * @param { Number } threshold Brawler trophies above which trophies are removed
     * @returns { Boolean } true when trophies were removed
     */
    static resetPlayer (player, threshold) {
        let totalRemoval = 0
        let bestBrawlerId = 0
        let bestBrawlerRemoval = 0

        for (const brawlerId in player.brawlers) {
            const brawler = player.brawlers[brawlerId]
            const removal = brawler.trophies > threshold ? Math.max(Math.floor((brawler.trophies - threshold) / 2), 1) : 0

            if (removal === 0) continue

            brawler.trophies -= removal
            player.trophies -= removal
            totalRemoval += removal

            if (removal > bestBrawlerRemoval) {
                bestBrawlerRemoval = removal
                bestBrawlerId = Number(brawlerId)
            }
        }

        if (totalRemoval === 0) return false

        const bonus = GameConfig.seasonEndBonus

        player.homeNotifications = player.homeNotifications.filter(n => n.id !== 99)
        player.homeNotifications.push({
            id: 99,
            bestBrawler: bestBrawlerId,
            bestBrawlerPoints: bestBrawlerRemoval,
            bestBrawlerCoins: bestBrawlerRemoval,
            bestBrawlerBonus: bonus,
            totalTrophiesPoints: totalRemoval,
            totalTrophiesCoins: totalRemoval,
            totalTrophiesBonus: bonus,
            seen: false
        })

        player.gold += totalRemoval + bonus * 2
        player.coinsReward += totalRemoval + bonus * 2

        return true
    }

    /**
     * Adds the "coins booster expired" notification (97 / 1) when the player's booster ran out
     * @param { Object } player Player
     * @returns { Boolean } true when the notification was added
     */
    static checkCoinsBooster (player) {
        const now = Math.floor(Date.now() / 1000)

        if (player.coinsBooster <= 0 || player.coinsBooster > now) return false

        player.coinsBooster = 0

        if (player.homeNotifications.some(n => n.id === 97 && n.type === 1)) return false

        player.homeNotifications.push({ id: 97, type: 1, seen: false })

        return true
    }
}

module.exports = LogicSeason
