const LogicSeason = require("./LogicSeason")
const GameConfig = require("../Server/GameConfig")
const Events = require("./Events")
const Milestones = require("./Milestones")

/**
 * LogicClientHome
 *
 * Home data (daily data + conf data) for OwnHomeDataMessage.
 * Ported from Obiad Brawl v4 (Entries/LogicClientHome.py, LogicDailyData.py, LogicConfData.py)
 */
class LogicClientHome {
    /**
     * Encode home data to ByteStream
     * @param { ByteStream } stream ByteStream class instance
     * @param { Object } player Player account data
     */
    static encode (stream, player) {
        LogicClientHome.encodeDailyData(stream, player)
        LogicClientHome.encodeConfData(stream, player)

        stream.writeLong(player.highId, player.lowId) // Player id

        const notifications = player.homeNotifications.filter(n => !n.seen)

        stream.writeVInt(notifications.length)

        for (const notification of notifications) {
            stream.writeVInt(notification.id) // 97 (expired coins booster), 98 (gacha drop), 99 (season end)

            switch (notification.id) {
                case 97:
                    stream.writeVInt(notification.type)
                    break
                case 98:
                    stream.writeVInt(1)
                    stream.writeVInt(2)
                    break
                case 99:
                    stream.writeVInt(player.brawlers[notification.bestBrawler] ? player.brawlers[notification.bestBrawler].trophies : 0) // Best brawler trophies
                    stream.writeVInt(notification.bestBrawlerPoints)
                    stream.writeVInt(notification.bestBrawlerCoins)
                    stream.writeVInt(notification.bestBrawlerBonus)
                    stream.writeVInt(player.trophies)
                    stream.writeVInt(notification.totalTrophiesPoints)
                    stream.writeVInt(notification.totalTrophiesCoins)
                    stream.writeVInt(notification.totalTrophiesBonus)
                    stream.writeVInt(0)
                    stream.writeVInt(9000)
                    stream.writeVInt(16) // DataReference (16, brawler)
                    stream.writeVInt(notification.bestBrawler)
                    stream.writeVInt(9000)
                    stream.writeVInt(0)
                    break
            }
        }
    }

    static encodeDailyData (stream, player) {
        const now = Math.floor(Date.now() / 1000)

        stream.writeVInt(2017189) // Timestamp
        stream.writeVInt(10) // Create new band timer

        stream.writeVInt(player.trophies) // Trophies
        stream.writeVInt(player.highestTrophies) // Highest trophies
        stream.writeVInt(0)
        stream.writeVInt(player.experience) // Experience

        stream.writeVInt(28) // DataReference (28, icon) - Player icon
        stream.writeVInt(player.profileIcon)

        stream.writeVInt(7) // Played game modes count
        for (let i = 0; i < 7; i++) {
            stream.writeVInt(i) // Played game mode
        }

        const brawlers = Object.values(player.brawlers)

        const selectedSkins = brawlers.filter(b => b.selectedSkin !== 0).map(b => b.selectedSkin)
        stream.writeVInt(selectedSkins.length)
        for (const skin of selectedSkins) {
            stream.writeVInt(29) // DataReference (29, skin)
            stream.writeVInt(skin)
        }

        const unlockedSkins = []
        for (const brawler of brawlers) {
            for (const skin of brawler.skins) {
                if (skin !== 0) unlockedSkins.push(skin)
            }
        }
        stream.writeVInt(unlockedSkins.length)
        for (const skin of unlockedSkins) {
            stream.writeVInt(29) // DataReference (29, skin)
            stream.writeVInt(skin)
        }

        stream.writeBoolean(false) // Is time required to create new band
        stream.writeVInt(0)
        stream.writeVInt(player.coinsReward) // Coins got
        stream.writeBoolean(false)
        stream.writeVInt(player.controlMode) // Control mode [0 - Tap to move, 1 - Joystick move, 2 - Double joysticks]
        stream.writeBoolean(player.battleHints) // Is battle hints enabled
        stream.writeVInt(player.coinsDoubler) // Coins doubler coins remaining (0 = not activated)
        stream.writeVInt(player.coinsBooster - now > 0 ? player.coinsBooster - now : 0) // Coin boost seconds remaining
        stream.writeVInt(LogicSeason.getSecondsLeft()) // Season end timer
        stream.writeBoolean(false)

        stream.writeVInt(0) // LogicLong (0, 1)
        stream.writeVInt(1)
        stream.writeVInt(0) // LogicLong (0, 1)
        stream.writeVInt(1)
        stream.writeVInt(0) // LogicLong (0, 1)
        stream.writeVInt(1)
        stream.writeVInt(0) // LogicLong (0, 1)
        stream.writeVInt(1)

        stream.writeVInt(0) // DataReference (0) - Shop
        stream.writeVInt(0)
        stream.writeBoolean(true)
        stream.writeBoolean(true)
    }

    static encodeConfData (stream, player) {
        const shop = GameConfig.shop

        stream.writeVInt(2017189) // Shop timestamp
        stream.writeVInt(shop.goldBoxCost) // Box cost (gold)
        stream.writeVInt(shop.gemBoxCost) // Box cost (gems)
        stream.writeVInt(shop.bigBoxCost) // Big box cost (gems)
        stream.writeVInt(shop.gemBoxCost) // Box cost (gems)
        stream.writeVInt(shop.coinsBoosterCost) // Coin boost cost
        stream.writeVInt(50) // Coin boost %
        stream.writeVInt(shop.coinsDoublerCost) // Coin doubler cost
        stream.writeVInt(shop.coinsDoublerAmount) // Coin doubled
        stream.writeVInt(7 * 24) // Coin boost hours
        stream.writeVInt(GameConfig.getBrawlersTrophiesForSeasonReset()) // Minimum brawler trophies for season reset
        stream.writeVInt(50) // Brawler trophy loss percentage in season reset
        stream.writeVInt(9999) // Coin limit remaining

        LogicClientHome.writeVIntArray(stream, shop.duplicateBrawlerChips) // Duplicated brawler chips
        LogicClientHome.writeVIntArray(stream, shop.brawlerChipCost) // Brawler chip cost
        LogicClientHome.writeVIntArray(stream, shop.brawlerBoxCost) // Boxes with guaranteed brawlers cost

        // Brawlers required for events
        const requiredBrawlers = [0, 3, 5, 7]

        stream.writeVInt(GameConfig.eventSlots)
        for (let event = 0; event < GameConfig.eventSlots; event++) {
            stream.writeVInt(event + 1) // Event index
            stream.writeVInt(requiredBrawlers[event]) // Brawlers needed
        }

        Events.encodeEventsList(stream, Events.getActiveEvents()) // Active events
        Events.encodeEventsList(stream, Events.getComingSoonEvents()) // Coming soon events

        stream.writeVInt(GameConfig.maximumUpgradeLevel) // Upgrades array
        for (let i = 0; i < GameConfig.maximumUpgradeLevel; i++) {
            stream.writeVInt(i + 1) // Price
        }

        Milestones.encode(stream, GameConfig.maximumRank)
    }

    static writeVIntArray (stream, array) {
        stream.writeVInt(array.length)

        for (const value of array) {
            stream.writeVInt(value)
        }
    }
}

module.exports = LogicClientHome
