const fs = require("node:fs")
const path = require("node:path")
const CSVNode = require("../../Titan/CSV/CSVNode")
const GameConfig = require("../Server/GameConfig")
const { getRandomElementFromArray } = require("../../Utils/Random")

const LOCATIONS_CSV = path.join(__dirname, "..", "..", "GameAssets", "v4", "csv_logic", "locations.csv")

/**
 * Events
 *
 * Simple event rotation. Replaces "Events" table from Obiad Brawl.
 * Slot 3 (Boss fight / 4th slot) is only active on weekends.
 */
class Events {
    static refreshHours = [2, 14, 8, 2]
    static active = []
    static comingSoon = []

    static init () {
        const now = Math.floor(Date.now() / 1000)

        for (let slot = 0; slot < GameConfig.eventSlots; slot++) {
            Events.active.push({ slot, locationId: Events.getRandomLocationId(), timestamp: now + Events.refreshHours[slot] * 3600, tokens: 10 })
            Events.comingSoon.push({ slot, locationId: Events.getRandomLocationId(), timestamp: now + Events.refreshHours[slot] * 3600, tokens: 10 })
        }

        setInterval(() => Events.reroll(), 7000)
    }

    /**
     * Get all playable locations ids (all except Tutorial)
     * @returns { Array<Number> } Locations ids
     */
    static getLocationsIds () {
        if (Events.locationsIds) return Events.locationsIds

        const ids = []

        try {
            const table = new CSVNode(fs.readFileSync(LOCATIONS_CSV).toString().split("\n"), "locations.csv").getTable()

            for (let i = 0; i < table.getRowCount(); i++) {
                if (table.getRowAt(i).getName() !== "Tutorial") ids.push(i)
            }
        } catch (e) {
            Warn("Events: unable to read locations.csv, using default location.")
        }

        Events.locationsIds = ids.length !== 0 ? ids : [0]

        return Events.locationsIds
    }

    static getRandomLocationId () {
        return getRandomElementFromArray(Events.getLocationsIds())
    }

    static isWeekend () {
        const day = new Date().getDay()

        return day === 0 || day === 6
    }

    static reroll () {
        const now = Math.floor(Date.now() / 1000)

        for (const list of [Events.active, Events.comingSoon]) {
            for (const event of list) {
                if (now >= event.timestamp) {
                    event.timestamp = now + Events.refreshHours[event.slot] * 3600
                    event.locationId = Events.getRandomLocationId()
                }
            }
        }
    }

    /**
     * Currently visible active events
     * @returns { Array<Object> } Events
     */
    static getActiveEvents () {
        return Events.isWeekend() ? Events.active : Events.active.filter(e => e.slot !== 3)
    }

    /**
     * Currently visible coming soon events
     * @returns { Array<Object> } Events
     */
    static getComingSoonEvents () {
        return Events.isWeekend() ? Events.comingSoon.filter(e => e.slot !== 3) : Events.comingSoon
    }

    /**
     * Encode events list to ByteStream
     * @param { ByteStream } stream ByteStream class instance
     * @param { Array<Object> } events Events list
     */
    static encodeEventsList (stream, events) {
        const now = Math.floor(Date.now() / 1000)

        stream.writeVInt(events.length)

        for (let index = 0; index < events.length; index++) {
            const event = events[index]

            stream.writeVInt(index + 1) // slot index
            stream.writeVInt(index + 1) // slot number
            stream.writeVInt(event.timestamp - now) // coming soon timer
            stream.writeVInt(event.timestamp - now) // time left
            stream.writeVInt(event.tokens) // coins to claim
            stream.writeVInt(8) // bonus coins
            stream.writeVInt(999) // coins to win
            stream.writeBoolean(false) // double coins
            stream.writeBoolean(index === 3) // double exp
            stream.writeVInt(15) // DataReference (15, location) - map
            stream.writeVInt(event.locationId)
            stream.writeVInt(0) // coins already collected
            stream.writeVInt(2) // coins collected status
            stream.writeString(GameConfig.eventText) // event text (TID)
            stream.writeBoolean(false)
        }
    }
}

module.exports = Events
