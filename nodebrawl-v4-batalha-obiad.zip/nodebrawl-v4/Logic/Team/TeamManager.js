const V4DataTables = require('../Data/V4DataTables')
const Events = require('../Home/Events')

/**
 * TeamManager
 *
 * In-memory game rooms (teams). A team is not persisted: it lives while at least one member is online.
 *
 * Team = { id, roomType, eventSlot, locationId, practice, advertisedAllianceId, members: [member], stream: [entry], nextStreamId }
 * Member = { lowId, session, brawlerId, status, ready, side, host }
 * Stream entries reuse the alliance layout (type 2 chat, type 4 event: 101 created, 102 joined, 103 left, 104 kicked).
 */
class TeamManager {
    static MAX_MEMBERS = 3
    static STREAM_LENGTH = 50

    static EVENT_CREATED = 101
    static EVENT_JOINED = 102
    static EVENT_LEFT = 103
    static EVENT_KICKED = 104

    static ERROR_FULL = 2
    static ERROR_DISBANDED = 3
    static ERROR_NOT_FOUND = 6
    static ERROR_ALREADY_IN_ROOM = 10

    static LEFT_REASON_LEFT = 0
    static LEFT_REASON_KICKED = 1

    /** @type { Map<Number, Object> } teamId -> team */
    static teams = new Map()
    /** @type { Map<Number, Number> } player lowId -> teamId */
    static membership = new Map()
    static lastId = 0
    static interval = null

    /**
     * Start the cleanup timer (removes members whose session was closed)
     */
    static init () {
        if (TeamManager.interval) return

        TeamManager.interval = setInterval(() => TeamManager.cleanup().catch(e => Err(e.stack)), 5000)
        Log("TeamManager: initialized.")
    }

    /**
     * Team of the player
     * @param { Object } player Player
     * @returns { Object | null } Team
     */
    static getTeamOfPlayer (player) {
        const teamId = TeamManager.membership.get(player.lowId)

        return teamId ? TeamManager.teams.get(teamId) || null : null
    }

    /**
     * @param { Number } id Team id
     * @returns { Object | null } Team
     */
    static get (id) {
        return TeamManager.teams.get(Number(id)) || null
    }

    static getMember (team, lowId) {
        return team.members.find(m => m.lowId === lowId) || null
    }

    /**
     * Create a member entry for the session
     * @param { Session } session Session
     * @param { Boolean } host Is the room creator
     * @returns { Object } Member
     */
    static createMember (session, host) {
        const player = session.player
        const brawlerId = Number(Object.keys(player.brawlers)[0] || 0)

        return { lowId: player.lowId, session, brawlerId, status: 3, ready: false, side: 0, host }
    }

    /**
     * Create a team with the player as host
     * @param { Session } session Session
     * @param { Number } roomType Room type sent by the client
     * @param { Number } eventSlot Event slot (1-based)
     * @param { Number } locationId Location index (0 = location of the event slot)
     * @returns { Object } Team
     */
    static create (session, roomType, eventSlot, locationId) {
        if (!locationId || !V4DataTables.locations[locationId]) {
            const events = Events.getActiveEvents()
            const event = events[eventSlot - 1] || events[0]

            locationId = event ? event.locationId : 0
        }

        const team = {
            id: ++TeamManager.lastId,
            roomType,
            eventSlot,
            locationId,
            practice: false,
            advertisedAllianceId: 0,
            advertised: false,
            members: [TeamManager.createMember(session, true)],
            stream: [],
            nextStreamId: 1
        }

        TeamManager.teams.set(team.id, team)
        TeamManager.membership.set(session.player.lowId, team.id)

        return team
    }

    /**
     * Add the session to the team
     * @param { Object } team Team
     * @param { Session } session Session
     * @returns { Number } 0 on success, else a TeamError code
     */
    static join (team, session) {
        if (TeamManager.getTeamOfPlayer(session.player)) return TeamManager.ERROR_ALREADY_IN_ROOM
        if (team.members.length >= TeamManager.MAX_MEMBERS) return TeamManager.ERROR_FULL

        team.members.push(TeamManager.createMember(session, false))
        TeamManager.membership.set(session.player.lowId, team.id)

        return 0
    }

    /**
     * Remove a member. The team is deleted when the last member leaves.
     * @param { Object } team Team
     * @param { Number } lowId Player low id
     */
    static remove (team, lowId) {
        team.members = team.members.filter(m => m.lowId !== lowId)
        TeamManager.membership.delete(lowId)

        if (team.members.length === 0) TeamManager.teams.delete(team.id)
        else if (!team.members.some(m => m.host)) team.members[0].host = true
    }

    /**
     * Re-bind the session of a member after a new login
     * @param { Session } session Session
     * @returns { Object | null } Team of the player
     */
    static rebind (session) {
        const team = TeamManager.getTeamOfPlayer(session.player)

        if (!team) return null

        const member = TeamManager.getMember(team, session.player.lowId)

        if (member) {
            member.session = session
            member.ready = false
        }

        return team
    }

    /**
     * Add a stream entry (same layout as alliance entries)
     * @param { Object } team Team
     * @param { Object } entry { type, playerId, playerName, message, event, targetId, targetName }
     * @returns { Object } Stored entry
     */
    static addStreamEntry (team, entry) {
        const stored = {
            id: team.nextStreamId++,
            type: entry.type,
            playerId: entry.playerId,
            playerName: entry.playerName,
            playerRole: 0,
            message: entry.message || "",
            event: entry.event || 0,
            targetId: entry.targetId || 0,
            targetName: entry.targetName || "",
            responderName: "",
            timestamp: Math.floor(Date.now() / 1000)
        }

        team.stream.push(stored)

        while (team.stream.length > TeamManager.STREAM_LENGTH) team.stream.shift()

        return stored
    }

    /**
     * Add a team event entry (created / joined / left / kicked)
     * @param { Object } team Team
     * @param { Object } actor Player who did the action
     * @param { Number } event Event code
     * @param { Object } target Target player
     * @returns { Object } Stored entry
     */
    static addEvent (team, actor, event, target) {
        return TeamManager.addStreamEntry(team, { type: 4, playerId: actor.lowId, playerName: actor.name, event, targetId: target.lowId, targetName: target.name })
    }

    /**
     * Online sessions of the team members
     * @param { Object } team Team
     * @returns { Array<Session> } Sessions
     */
    static getSessions (team) {
        return team.members.filter(m => m.session && !m.session.destroyed && m.session.player).map(m => m.session)
    }

    /**
     * Send a message to every online member
     * @param { Object } team Team
     * @param { Function } createMessage (session) => PiranhaMessage
     * @param { Number } exceptLowId Member to skip (0 = none)
     */
    static async broadcast (team, createMessage, exceptLowId = 0) {
        for (const session of TeamManager.getSessions(team)) {
            if (session.player.lowId === exceptLowId) continue

            try {
                await createMessage(session).send()
            } catch (e) {
                session.errLog(e.stack)
            }
        }
    }

    /**
     * Send TeamMessage to every online member (room state changed)
     * @param { Object } team Team
     */
    static async refresh (team) {
        const TeamMessage = require('../../Protocol/Messages/Server/Team/TeamMessage')

        await TeamManager.broadcast(team, session => new TeamMessage(session, team))
    }

    /**
     * Add a stream entry and push it to every online member (TeamStreamMessage with one entry)
     * @param { Object } team Team
     * @param { Object } entry Stored entry
     */
    static async pushEntry (team, entry) {
        const TeamStreamMessage = require('../../Protocol/Messages/Server/Team/TeamStreamMessage')

        await TeamManager.broadcast(team, session => new TeamStreamMessage(session, team, [entry]))
    }

    /**
     * Make the player leave his team: event to the others, TeamLeft to him
     * @param { Session } session Session
     * @param { Number } reason 0 left, 1 kicked
     * @param { Object } actor Player who kicked (only for reason 1)
     */
    static async leave (session, reason = TeamManager.LEFT_REASON_LEFT, actor = null) {
        const TeamLeftMessage = require('../../Protocol/Messages/Server/Team/TeamLeftMessage')
        const player = session.player
        const team = TeamManager.getTeamOfPlayer(player)

        if (!team) return

        TeamManager.remove(team, player.lowId)

        if (!session.destroyed) await new TeamLeftMessage(session, reason).send()

        if (team.members.length > 0) {
            const entry = reason === TeamManager.LEFT_REASON_KICKED
                ? TeamManager.addEvent(team, actor || player, TeamManager.EVENT_KICKED, player)
                : TeamManager.addEvent(team, player, TeamManager.EVENT_LEFT, player)

            await TeamManager.pushEntry(team, entry)
            await TeamManager.refresh(team)
        }
    }

    /**
     * Remove members whose session was closed
     */
    static async cleanup () {
        for (const team of Array.from(TeamManager.teams.values())) {
            for (const member of [...team.members]) {
                if (member.session && member.session.destroyed) await TeamManager.leave(member.session)
            }
        }
    }

    /**
     * Whether every member is ready
     * @param { Object } team Team
     * @returns { Boolean } All ready
     */
    static isEveryoneReady (team) {
        return team.members.length > 0 && team.members.every(m => m.ready)
    }

    /**
     * Start the battle for the team: TeamGameStarting + MatchMakingStatus + StartLoading to every member.
     * All the members play in the same side (heroes 1-3); the rest are bots.
     * @param { Object } team Team
     */
    static async startBattle (team) {
        const LogicBattleManager = require('../Battle/LogicBattleManager')
        const TeamGameStartingMessage = require('../../Protocol/Messages/Server/Team/TeamGameStartingMessage')
        const MatchMakingStatusMessage = require('../../Protocol/Messages/Server/Battle/MatchMakingStatusMessage')
        const StartLoadingMessage = require('../../Protocol/Messages/Server/Battle/StartLoadingMessage')

        const sessions = TeamManager.getSessions(team)

        if (sessions.length === 0) return

        const humans = sessions.map(session => {
            const member = TeamManager.getMember(team, session.player.lowId)
            let brawlerId = member ? member.brawlerId : 0

            if (!session.player.brawlers[brawlerId]) brawlerId = Number(Object.keys(session.player.brawlers)[0] || 0)

            return { session, brawlerId }
        })

        // matchmaking data shared by every member (MatchMakingStatusMessage lists all of them)
        const matchmaking = LogicBattleManager.createMatchmaking(sessions[0], 6)

        matchmaking.players = sessions.map(session => session.player)

        for (const session of sessions) {
            LogicBattleManager.endBattle(session, false) // leave any previous battle first
            LogicBattleManager.matchmaking.set(session.id, matchmaking)
        }

        for (const session of sessions) {
            await new TeamGameStartingMessage(session, team).send()
            await new MatchMakingStatusMessage(session, true).send()
        }

        const battle = LogicBattleManager.createTeamBattle(humans, team.locationId, team.eventSlot)

        Log(`Team ${team.id}: battle ${battle.id} started with ${humans.length} players, location ${battle.locationId} (${battle.gameMode}).`)

        for (const session of sessions) await new StartLoadingMessage(session, battle).send()

        for (const member of team.members) member.ready = false

        battle.start()
    }
}

module.exports = TeamManager
