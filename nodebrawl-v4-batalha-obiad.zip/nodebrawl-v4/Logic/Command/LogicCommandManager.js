const path = require("node:path")
const glob = require("glob")

const getDirectories = (src, callback) => glob(src + '/**/*', callback);

class LogicCommandManager {
    static commands = {}

    static loadCommands () {
        getDirectories(path.join(__dirname, "Client"), (err, res) => {
            if (err) Err(err)
            const files = res.filter(e => e.endsWith(".js"))

            for (const file of files) {
              try{
                const Command = require("./" + path.relative(__dirname, file).replaceAll("\\", "/"))
                const CommandInstance = new Command()

                this.commands[CommandInstance.type] = Command
              }catch(err){
                Err(`A wild error while initializing "${file.split("/").slice(-1)}" command!`)
                console.log(err)
              }
            }
        })
    }

    /**
     * Get command class
     * @param { Number } type Command type
     * @returns { Class } Command class
     * @example
     *   const LogicGatchaCommand = LogicCommandManager.createCommand(500)
     */
    static createCommand (type) {
        return this.commands[type] ? this.commands[type] : null
    }
}

module.exports = LogicCommandManager
