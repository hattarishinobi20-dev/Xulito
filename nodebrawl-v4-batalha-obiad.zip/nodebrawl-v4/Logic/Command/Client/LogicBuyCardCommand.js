const LogicCommand = require('../LogicCommand')
const LogicGatcha = require('../../Home/LogicGatcha')
const V4DataTables = require('../../Data/V4DataTables')
const GameConfig = require('../../Server/GameConfig')

class LogicBuyCardCommand extends LogicCommand {
  constructor (session, stream) {
    super(session, stream)
    this.type = 502
  }

  async decode () {
    this.readHeader()
    this.card = this.readDataReference()
  }

  async execute () {
    const cardIndex = this.card[1]
    const unlockCard = V4DataTables.getUnlockCard(cardIndex)

    if (!unlockCard) return this.session.warn(`Unknown card ${cardIndex}`)

    const brawlerIndex = V4DataTables.getCardBrawlerIndex(unlockCard.index)

    if (unlockCard.index !== cardIndex) { // Upgrade card with elixir
      const brawler = this.player.brawlers[brawlerIndex]

      if (!brawler) return this.session.warn(`Brawler ${brawlerIndex} is locked`)

      const level = brawler.cards[cardIndex] || 0
      const price = level === 0 ? 1 : level + 1

      if (level + 1 > GameConfig.maximumUpgradeLevel) return this.session.warn(`Card ${cardIndex} is at maximum level`)
      if (this.player.elixir < price) return this.session.warn(`Not enough elixir for card ${cardIndex}`)

      brawler.cards[cardIndex] = level + 1
      this.player.elixir -= price

      return
    }

    // Buy brawler with chips
    if (V4DataTables.isCharacterDisabled(unlockCard.target)) return this.session.warn(`Brawler ${unlockCard.target} is disabled`)
    if (this.player.brawlers[brawlerIndex]) return this.session.warn(`Brawler ${brawlerIndex} is already unlocked`)

    const rarity = LogicGatcha.RARITIES.indexOf(unlockCard.rarity)
    const price = GameConfig.shop.brawlerChipCost[rarity]

    if (rarity === -1 || price === undefined) return this.session.warn(`Brawler ${unlockCard.target} has no chip price (rarity ${unlockCard.rarity})`)
    if (this.player.chips < price) return this.session.warn(`Not enough chips for brawler ${brawlerIndex} (${this.player.chips} < ${price})`)

    this.player.chips -= price
    LogicGatcha.unlockBrawler(this.player, unlockCard)

    this.session.log(`Brawler ${unlockCard.target} bought for ${price} chips (${this.player.chips} left).`)
  }
}

module.exports = LogicBuyCardCommand
