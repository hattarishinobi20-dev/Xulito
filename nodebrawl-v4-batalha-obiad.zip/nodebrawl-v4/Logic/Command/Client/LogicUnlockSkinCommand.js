const LogicCommand = require('../LogicCommand')
const V4DataTables = require('../../Data/V4DataTables')

class LogicUnlockSkinCommand extends LogicCommand {
  constructor (session, stream) {
    super(session, stream)
    this.type = 508
  }

  async decode () {
    this.readHeader()
    this.skin = this.readDataReference()
  }

  async execute () {
    const skinIndex = this.skin[1]
    const skin = V4DataTables.getSkin(skinIndex)

    if (!skin) return this.session.warn(`Unknown skin ${skinIndex}`)
    if (V4DataTables.isDefaultSkin(skinIndex)) return this.session.warn(`Skin ${skinIndex} is a default skin`)

    const brawlerIndex = V4DataTables.getSkinBrawlerIndex(skinIndex)
    const brawler = this.player.brawlers[brawlerIndex]

    if (!brawler) return this.session.warn(`Brawler ${brawlerIndex} is locked`)

    if (!brawler.skins.includes(skinIndex)) {
      if (this.player.gems < skin.costGems) return this.session.warn(`Not enough gems for skin ${skinIndex}`)

      this.player.gems -= skin.costGems
      brawler.skins.push(skinIndex)
    }

    brawler.selectedSkin = skinIndex
  }
}

module.exports = LogicUnlockSkinCommand
