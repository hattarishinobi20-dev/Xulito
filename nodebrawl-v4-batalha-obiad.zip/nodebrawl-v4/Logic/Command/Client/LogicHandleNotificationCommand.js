const LogicCommand = require('../LogicCommand')

class LogicHandleNotificationCommand extends LogicCommand {
  constructor (session, stream) {
    super(session, stream)
    this.type = 515
  }

  async decode () {
    this.readHeader()
    this.notificationType = this.stream.readVInt() // 1 - season end, 2 - coins doubler, 3 - coins booster, 4 - gacha drop
  }

  async execute () {
    const notifications = this.player.homeNotifications

    switch (this.notificationType) {
      case 1:
        this.player.homeNotifications = notifications.filter(n => n.id !== 99)
        break
      case 2:
        notifications.filter(n => n.id === 97 && n.type === 2).forEach(n => { n.seen = true })
        break
      case 3:
        notifications.filter(n => n.id === 97 && n.type === 1).forEach(n => { n.seen = true })
        break
      case 4:
        this.player.homeNotifications = notifications.filter(n => n.id !== 98)
        break
    }
  }
}

module.exports = LogicHandleNotificationCommand
