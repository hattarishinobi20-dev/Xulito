const LogicCommand = require('../LogicCommand')

class LogicSelectBattleHintsCommand extends LogicCommand {
  constructor (session, stream) {
    super(session, stream)
    this.type = 513
  }

  async decode () {
    this.readHeader()
  }

  async execute () {
    this.player.battleHints = !this.player.battleHints
  }
}

module.exports = LogicSelectBattleHintsCommand
