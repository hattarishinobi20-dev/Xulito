const LogicCommand = require('../LogicCommand')

class LogicSelectControlModeCommand extends LogicCommand {
  constructor (session, stream) {
    super(session, stream)
    this.type = 509
  }

  async decode () {
    this.readHeader()
    this.controlMode = this.stream.readVInt() // 0 - Tap to move, 1 - Joystick move, 2 - Double joysticks
  }

  async execute () {
    if (this.controlMode < 0 || this.controlMode > 2) return this.session.warn(`Invalid control mode ${this.controlMode}`)

    this.player.controlMode = this.controlMode
  }
}

module.exports = LogicSelectControlModeCommand
