const LogicCommand = require('../LogicCommand')
const LogicGatcha = require('../../Home/LogicGatcha')
const LogicGiveDeliveryItemsCommand = require('../Server/LogicGiveDeliveryItemsCommand')
const AvailableServerCommandMessage = require('../../../Protocol/Messages/Server/Home/AvailableServerCommandMessage')

class LogicBuyBrawlerCommand extends LogicCommand {
  constructor (session, stream) {
    super(session, stream)
    this.type = 514
  }

  async decode () {
    this.readHeader()
    this.rarity = this.stream.readVInt() // 1 - rare, 2 - super rare, 3 - epic
  }

  async execute () {
    const result = LogicGatcha.openBrawlerBox(this.player, this.rarity)

    if (!result) return this.session.warn(`Brawler box ${this.rarity} refused (not sold or not enough gems: ${this.player.gems})`)

    const command = new LogicGiveDeliveryItemsCommand(this.session)
    command.boxId = result.boxId
    command.rewards = result.rewards

    await new AvailableServerCommandMessage(this.session, command).send()
  }
}

module.exports = LogicBuyBrawlerCommand
