const LogicCommand = require('../LogicCommand')
const V4DataTables = require('../../Data/V4DataTables')
const Milestones = require('../../Home/Milestones')

class LogicSetPlayerThumbnailCommand extends LogicCommand {
  constructor (session, stream) {
    super(session, stream)
    this.type = 506
  }

  async decode () {
    this.readHeader()
    this.thumbnail = this.readDataReference()
  }

  async execute () {
    const thumbnail = V4DataTables.getThumbnail(this.thumbnail[1])

    if (!thumbnail) return this.session.warn(`Unknown thumbnail ${this.thumbnail[1]}`)
    if (thumbnail.requiredTotalTrophies > this.player.trophies) return this.session.warn(`Not enough trophies for thumbnail ${thumbnail.index}`)

    if (thumbnail.requiredHero) {
      const brawlerIndex = V4DataTables.getCharacterIndexByName(thumbnail.requiredHero)

      if (!this.player.brawlers[brawlerIndex]) return this.session.warn(`Brawler ${thumbnail.requiredHero} required for thumbnail ${thumbnail.index}`)
    }

    if (thumbnail.requiredExpLevel !== 0 && Milestones.ProgressStartExp[thumbnail.requiredExpLevel - 1] > this.player.experience) {
      return this.session.warn(`Not enough experience for thumbnail ${thumbnail.index}`)
    }

    this.player.profileIcon = thumbnail.index
  }
}

module.exports = LogicSetPlayerThumbnailCommand
