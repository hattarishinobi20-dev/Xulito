const LogicCommand = require('../LogicCommand')
const LogicGatcha = require('../../Home/LogicGatcha')
const LogicGiveDeliveryItemsCommand = require('../Server/LogicGiveDeliveryItemsCommand')
const AvailableServerCommandMessage = require('../../../Protocol/Messages/Server/Home/AvailableServerCommandMessage')

class LogicGatchaCommand extends LogicCommand {
  constructor (session, stream) {
    super(session, stream)
    this.type = 500
  }

  async decode () {
    this.readHeader()
    this.boxType = this.stream.readVInt() // 1 - coin box, 2 - small gem box, 3 - big gem box
  }

  async execute () {
    const result = LogicGatcha.openBox(this.player, this.boxType)

    if (!result) return this.session.warn(`Box ${this.boxType} refused (unknown type or not enough gold/gems: ${this.player.gold}/${this.player.gems})`)

    const command = new LogicGiveDeliveryItemsCommand(this.session)
    command.boxId = result.boxId
    command.rewards = result.rewards

    await new AvailableServerCommandMessage(this.session, command).send()
  }
}

module.exports = LogicGatchaCommand
