const LogicCommand = require('../LogicCommand')
const GameConfig = require('../../Server/GameConfig')

class LogicBuyCoinsBoosterCommand extends LogicCommand {
  constructor (session, stream) {
    super(session, stream)
    this.type = 511
  }

  async decode () {
    this.readHeader()
  }

  async execute () {
    if (this.player.gems < GameConfig.shop.coinsBoosterCost) return this.session.warn("Not enough gems for coins booster")

    const now = Math.floor(Date.now() / 1000)
    const seconds = 7 * 24 * 60 * 60

    this.player.gems -= GameConfig.shop.coinsBoosterCost
    this.player.coinsBooster = this.player.coinsBooster > now ? this.player.coinsBooster + seconds : now + seconds

    this.player.homeNotifications = this.player.homeNotifications.filter(n => !(n.id === 97 && n.type === 1))
  }
}

module.exports = LogicBuyCoinsBoosterCommand
