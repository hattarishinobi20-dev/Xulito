const LogicCommand = require('../LogicCommand')
const GameConfig = require('../../Server/GameConfig')

class LogicBuyCoinsDoublerCommand extends LogicCommand {
  constructor (session, stream) {
    super(session, stream)
    this.type = 510
  }

  async decode () {
    this.readHeader()
  }

  async execute () {
    if (this.player.gems < GameConfig.shop.coinsDoublerCost) return this.session.warn("Not enough gems for coins doubler")

    this.player.gems -= GameConfig.shop.coinsDoublerCost
    this.player.coinsDoubler += GameConfig.shop.coinsDoublerAmount

    this.player.homeNotifications = this.player.homeNotifications.filter(n => !(n.id === 97 && n.type === 2))
  }
}

module.exports = LogicBuyCoinsDoublerCommand
