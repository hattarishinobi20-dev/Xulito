const DataStream = require("../../Titan/DataStream")

/**
  * LogicCommand
  *
  * A main class for commands. (`EndClientTurnMessage` / `AvailableServerCommandMessage`)
 */
class LogicCommand {
  /**
   * LogicCommand
   *
   * @param { Session } session User session (`this.session`)
   * @param { ByteStream } stream ByteStream (client commands read from it, server commands write to it)
   */
  constructor (session, stream) {
    this.DataStream = DataStream
    /**
     * Command type.
     * @type { Number } Command type.
     */
    this.type = 0
    /**
     * Session variable.
     * @type { Session } User session.
     */
    this.session = session
    /**
     * ByteStream class instance.
     * @type { ByteStream } ByteStream class instance.
     */
    this.stream = stream || DataStream.getByteStream()
  }

  /**
   * Player account data of the session
   * @type { Object } Player account
   */
  get player () {
    return this.session.player
  }

  /**
   * Encode function for server commands.
   *
   * Need to use `write` functions
   */
  encode () {

  };

  /**
   * Decode function for client commands.
   *
   * Need to use `read` functions
   */
  decode () {

  };

  /**
   * Execute function for client commands.
   *
   * Your code here.
   */
  execute () {

  }

  /**
   * Read client command header: 4 VInts after the command type. Obiad Brawl v4 (readCommandHeader) skips 9 fields
   * counted from the start of the EndClientTurn payload = bool, tick, checksum, count, type (already read by
   * EndClientTurnMessage) + these 4.
   */
  readHeader () {
    for (let i = 0; i < 4; i++) {
      this.stream.readVInt()
    }
  }

  /**
   * Read DataReference from stream
   * @returns { Array<Number> } [ClassID, InstanceID]
   */
  readDataReference () {
    const classId = this.stream.readVInt()

    return [ classId, classId === 0 ? 0 : this.stream.readVInt() ]
  }

  /**
   * Write DataReference to stream
   * @param { Number } classId Class ID
   * @param { Number } instanceId Instance ID
   */
  writeDataReference (classId, instanceId) {
    this.stream.writeVInt(classId < 1 ? 0 : classId)

    if (classId > 0) this.stream.writeVInt(instanceId)
  }
}

module.exports = LogicCommand
