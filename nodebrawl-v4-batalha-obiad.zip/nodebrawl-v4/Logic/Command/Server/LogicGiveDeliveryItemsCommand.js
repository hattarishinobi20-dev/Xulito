const LogicCommand = require('../LogicCommand')

/**
 * LogicGiveDeliveryItemsCommand
 *
 * Box opening result.
 * `rewards` item: { rarity, amount, dataRef: [classId, instanceId], rewardType }
 * rewardType: 1 - new brawler, 2 - chips (duplicate brawler), 3 - elixir, 4 - coins doubler, 5 - coins booster
 */
class LogicGiveDeliveryItemsCommand extends LogicCommand {
  boxId = 10
  rewards = []

  constructor (session) {
    super(session)
    this.type = 203
  }

  async encode () {
    this.stream.writeVInt(this.boxId) // Box id
    this.stream.writeVInt(this.rewards.length) // Rewards amount

    for (const reward of this.rewards) {
      this.stream.writeVInt(reward.rarity) // Rarity
      this.stream.writeVInt(reward.amount) // Amount
      this.writeDataReference(reward.dataRef[0], reward.dataRef[1]) // Item type
      this.stream.writeVInt(reward.rewardType) // Item given
    }
  }
}

module.exports = LogicGiveDeliveryItemsCommand
