const LogicCommand = require('../LogicCommand')

class LogicAddNotificationCommand extends LogicCommand {
  notification = null

  constructor (session) {
    super(session)
    this.type = 206
  }

  async encode () {
    const notification = this.notification

    this.stream.writeBoolean(true)
    this.stream.writeVInt(notification.id) // 97 (expired coins booster), 98 (gacha drop), 99 (season end)

    switch (notification.id) {
      case 97:
        this.stream.writeVInt(notification.type)
        break
      case 98:
        this.stream.writeVInt(1)
        this.stream.writeVInt(2)
        break
      case 99:
        this.stream.writeVInt(1)
        this.stream.writeVInt(notification.bestBrawlerPoints)
        this.stream.writeVInt(notification.bestBrawlerCoins)
        this.stream.writeVInt(notification.bestBrawlerBonus)
        this.stream.writeVInt(notification.totalTrophies)
        this.stream.writeVInt(notification.totalTrophiesPoints)
        this.stream.writeVInt(notification.totalTrophiesCoins)
        this.stream.writeVInt(notification.totalTrophiesBonus)
        this.stream.writeVInt(1)
        this.stream.writeVInt(1)
        this.writeDataReference(16, notification.bestBrawler)
        this.stream.writeVInt(1)
        this.stream.writeVInt(1)
        break
    }
  }
}

module.exports = LogicAddNotificationCommand
