const LogicCommand = require('../LogicCommand')

class LogicDiamondsAddedCommand extends LogicCommand {
  diamonds = 0

  constructor (session) {
    super(session)
    this.type = 202
  }

  async encode () {
    this.stream.writeByte(0)
    this.stream.writeInt(this.diamonds)
    this.stream.writeInt(0)
    this.stream.writeInt(0)
    this.stream.writeString("hhh")
    this.stream.writeVInt(0)

    this.player.gems += this.diamonds
  }
}

module.exports = LogicDiamondsAddedCommand
