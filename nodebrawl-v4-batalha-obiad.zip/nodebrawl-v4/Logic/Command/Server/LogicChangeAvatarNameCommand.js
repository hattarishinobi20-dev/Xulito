const LogicCommand = require('../LogicCommand')

class LogicChangeAvatarNameCommand extends LogicCommand {
  constructor (session) {
    super(session)
    this.type = 201
  }

  async encode () {
    this.stream.writeString(this.player.name)
    this.stream.writeByte(0)
    this.stream.writeVInt(1)
    this.stream.writeVInt(0)
    this.stream.writeVInt(0)
    this.stream.writeVInt(0)
    this.stream.writeVInt(1)
  }
}

module.exports = LogicChangeAvatarNameCommand
