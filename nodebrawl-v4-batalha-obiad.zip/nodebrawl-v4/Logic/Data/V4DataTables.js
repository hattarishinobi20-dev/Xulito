const fs = require("node:fs")
const path = require("node:path")
const CSVNode = require("../../Titan/CSV/CSVNode")

const ASSETS_PATH = path.join(__dirname, "..", "..", "GameAssets", "v4", "csv_logic")

/**
 * V4DataTables
 *
 * Reads v4 csv files (cards, characters, skins, player thumbnails) with tails CSVNode.
 * Replaces Files/CsvLogic/*.py from Obiad Brawl.
 */
class V4DataTables {
    static cards = []
    static characters = []
    static skins = []
    static thumbnails = []
    static skills = []
    static locations = []

    static init () {
        V4DataTables.characters = V4DataTables.loadTable("characters.csv", (row, index) => ({
            index,
            name: row.getName(),
            disabled: row.getBooleanValue("Disabled", 0),
            type: row.getValue("Type", 0),
            defaultSkin: row.getValue("DefaultSkin", 0),
            weaponSkill: row.getValue("WeaponSkill", 0),
            ultimateSkill: row.getValue("UltimateSkill", 0),
            speed: row.getIntegerValue("Speed", 0),
            hitpoints: row.getIntegerValue("Hitpoints", 0)
        }))

        V4DataTables.skills = V4DataTables.loadTable("skills.csv", (row, index) => ({
            index,
            name: row.getName(),
            behaviorType: row.getValue("BehaviorType", 0),
            rechargeTime: row.getIntegerValue("RechargeTime", 0),
            maxCharge: row.getIntegerValue("MaxCharge", 0),
            damage: row.getIntegerValue("Damage", 0),
            chargeSpeed: row.getIntegerValue("ChargeSpeed", 0),
            chargeType: row.getIntegerValue("ChargeType", 0)
        }))

        V4DataTables.locations = V4DataTables.loadTable("locations.csv", (row, index) => ({
            index,
            name: row.getName(),
            gameMode: row.getValue("GameMode", 0),
            allowedMaps: row.getValue("AllowedMaps", 0)
        }))

        V4DataTables.cards = V4DataTables.loadTable("cards.csv", (row, index) => ({
            index,
            name: row.getName(),
            target: row.getValue("Target", 0),
            type: row.getValue("Type", 0),
            rarity: row.getValue("Rarity", 0)
        }))

        V4DataTables.skins = V4DataTables.loadTable("skins.csv", (row, index) => ({
            index,
            name: row.getName(),
            character: row.getValue("Character", 0),
            costGems: row.getIntegerValue("CostGems", 0)
        }))

        V4DataTables.thumbnails = V4DataTables.loadTable("player_thumbnails.csv", (row, index) => ({
            index,
            name: row.getName(),
            requiredExpLevel: row.getIntegerValue("RequiredExpLevel", 0),
            requiredTotalTrophies: row.getIntegerValue("RequiredTotalTrophies", 0),
            requiredHero: row.getValue("RequiredHero", 0)
        }))

        Log(`V4DataTables: ${V4DataTables.characters.length} characters, ${V4DataTables.cards.length} cards, ${V4DataTables.skins.length} skins, ${V4DataTables.thumbnails.length} thumbnails, ${V4DataTables.skills.length} skills, ${V4DataTables.locations.length} locations loaded.`)
    }

    static loadTable (file, mapRow) {
        const items = []

        try {
            const table = new CSVNode(fs.readFileSync(path.join(ASSETS_PATH, file)).toString().split("\n"), file).getTable()

            for (let i = 0; i < table.getRowCount(); i++) {
                items.push(mapRow(table.getRowAt(i), i))
            }
        } catch (e) {
            Err(`V4DataTables: unable to load ${file}`)
        }

        return items
    }

    // Characters

    static getCharacterByName (name) {
        return V4DataTables.characters.find(c => c.name === name) || null
    }

    static getCharacterIndexByName (name) {
        const character = V4DataTables.getCharacterByName(name)

        return character ? character.index : -1
    }

    static isCharacterDisabled (name) {
        const character = V4DataTables.getCharacterByName(name)

        return character ? character.disabled : true
    }

    // Cards

    static getCard (index) {
        return V4DataTables.cards[index] || null
    }

    /**
     * Get unlock card of the brawler which owns given card
     * @param { Number } cardIndex Card index
     * @returns { Object | null } Unlock card
     */
    static getUnlockCard (cardIndex) {
        const card = V4DataTables.getCard(cardIndex)

        if (!card) return null
        if (card.type === "unlock") return card

        return V4DataTables.cards.find(c => c.target === card.target && c.type === "unlock") || null
    }

    /**
     * Get brawler (character index) of the card
     * @param { Number } cardIndex Card index
     * @returns { Number } Character index
     */
    static getCardBrawlerIndex (cardIndex) {
        const card = V4DataTables.getCard(cardIndex)

        return card ? V4DataTables.getCharacterIndexByName(card.target) : -1
    }

    /**
     * Get unlock cards of enabled brawlers with given rarity
     * @param { String } rarity common, rare, super_rare, epic, mega_epic, legendary
     * @returns { Array<Object> } Unlock cards
     */
    static getUnlockCardsWithRarity (rarity) {
        return V4DataTables.cards.filter(c => c.type === "unlock" && c.rarity === rarity && !V4DataTables.isCharacterDisabled(c.target))
    }

    // Skins

    static getSkin (index) {
        return V4DataTables.skins[index] || null
    }

    static isDefaultSkin (index) {
        const skin = V4DataTables.getSkin(index)

        return skin ? V4DataTables.characters.some(c => c.defaultSkin === skin.name) : false
    }

    static getSkinBrawlerIndex (index) {
        const skin = V4DataTables.getSkin(index)

        return skin ? V4DataTables.getCharacterIndexByName(skin.character) : -1
    }

    // Thumbnails

    static getThumbnail (index) {
        return V4DataTables.thumbnails[index] || null
    }

    // Skills

    static getSkill (index) {
        return V4DataTables.skills[index] || null
    }

    static getSkillIndexByName (name) {
        return V4DataTables.skills.findIndex(s => s.name === name)
    }

    // Locations

    static getLocation (index) {
        return V4DataTables.locations[index] || null
    }

    /**
     * Get game mode name of the location (BountyHunter, CoinRush, AttackDefend, BattleRoyale, BossFight, LaserBall)
     * @param { Number } index Location index
     * @returns { String } Game mode
     */
    static getLocationGameMode (index) {
        const location = V4DataTables.getLocation(index)

        return location ? location.gameMode : "CoinRush"
    }
}

module.exports = V4DataTables
