const AllianceDatabase = require('../../Database/AllianceDatabase')

/**
 * AllianceManager
 *
 * Helpers shared by the alliance client messages: stream entries + broadcasting to online members.
 */
class AllianceManager {
    static ROLE_MEMBER = 1
    static ROLE_LEADER = 2
    static ROLE_ELDER = 3
    static ROLE_CO_LEADER = 4

    static EVENT_KICKED = 1
    static EVENT_JOINED = 3
    static EVENT_LEFT = 4
    static EVENT_PROMOTED = 5
    static EVENT_DEMOTED = 6

    /**
     * Send a message to every online member of the alliance
     * @param { Object } alliance Alliance
     * @param { Function } createMessage (session) => PiranhaMessage
     * @param { Number } exceptLowId Member to skip (0 = none)
     */
    static async broadcast (alliance, createMessage, exceptLowId = 0) {
        for (const session of AllianceDatabase.getOnlineSessions(alliance)) {
            if (session.player.lowId === exceptLowId) continue

            try {
                await createMessage(session).send()
            } catch (e) {
                session.errLog(e.stack)
            }
        }
    }

    /**
     * Session of an online player
     * @param { Number } lowId Player low id
     * @returns { Session | null } Session
     */
    static getSession (lowId) {
        if (!global.sessions) return null

        for (const session of global.sessions.values()) {
            if (session.player && session.player.lowId === lowId && !session.destroyed) return session
        }

        return null
    }

    /**
     * Add a stream entry and push it to online members (AllianceStreamEntryMessage)
     * @param { Object } alliance Alliance
     * @param { Object } entry Entry data (see AllianceDatabase.addStreamEntry)
     * @returns { Object } Stored entry
     */
    static async addStreamEntry (alliance, entry) {
        const AllianceStreamEntryMessage = require('../../Protocol/Messages/Server/Alliance/AllianceStreamEntryMessage')
        const stored = AllianceDatabase.addStreamEntry(alliance, entry)

        await AllianceManager.broadcast(alliance, session => new AllianceStreamEntryMessage(session, stored))

        return stored
    }

    /**
     * Add an alliance event entry (joined / left / kicked / promoted / demoted)
     * @param { Object } alliance Alliance
     * @param { Object } actor Player who did the action
     * @param { Number } event Event type
     * @param { Object } target Target player
     */
    static async addEvent (alliance, actor, event, target) {
        return AllianceManager.addStreamEntry(alliance, {
            type: 4,
            playerId: actor.lowId,
            playerName: actor.name,
            playerRole: actor.allianceRole,
            event,
            targetId: target.lowId,
            targetName: target.name
        })
    }

    /**
     * Send MyAllianceMessage to every online member (header changed)
     * @param { Object } alliance Alliance
     */
    static async refreshMembers (alliance) {
        const MyAllianceMessage = require('../../Protocol/Messages/Server/Alliance/MyAllianceMessage')

        await AllianceManager.broadcast(alliance, session => new MyAllianceMessage(session))
    }

    /**
     * Whether the actor can change the target role
     * @param { Number } actorRole Actor role
     * @param { Number } targetRole Current target role
     * @param { Number } newRole New role
     * @returns { Boolean } Allowed
     */
    static canChangeRole (actorRole, targetRole, newRole) {
        if (![1, 2, 3, 4].includes(newRole)) return false
        if (actorRole === AllianceManager.ROLE_LEADER) return true
        if (actorRole === AllianceManager.ROLE_CO_LEADER) return newRole !== AllianceManager.ROLE_LEADER && targetRole !== AllianceManager.ROLE_LEADER

        return false
    }

    /**
     * Whether the actor can kick the target
     * @param { Number } actorRole Actor role
     * @param { Number } targetRole Target role
     * @returns { Boolean } Allowed
     */
    static canKick (actorRole, targetRole) {
        const power = { 1: 0, 3: 1, 4: 2, 2: 3 }

        return (power[actorRole] || 0) >= 1 && (power[actorRole] || 0) > (power[targetRole] || 0)
    }
}

module.exports = AllianceManager
