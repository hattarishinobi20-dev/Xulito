const AllianceDatabase = require('../../Database/AllianceDatabase')

/**
 * AllianceEncoder
 *
 * Shared encoders for alliance header / stream entries (layouts from Obiad Brawl v4 Entries/*.py).
 */
class AllianceEncoder {
    /**
     * Alliance header entry (used by AllianceData, JoinableAlliancesList, AllianceSearchResult)
     * @param { ByteStream } stream ByteStream
     * @param { Object } alliance Alliance
     */
    static encodeHeader (stream, alliance) {
        stream.writeLong(0, alliance.id) // Alliance id
        stream.writeString(alliance.name)
        stream.writeVInt(8) // DataReference (8, badge)
        stream.writeVInt(alliance.badge)
        stream.writeVInt(alliance.type) // 1 open, 2 invite only, 3 closed
        stream.writeVInt(alliance.members.length) // Members count
        stream.writeVInt(AllianceDatabase.getTrophies(alliance)) // Alliance trophies
        stream.writeVInt(alliance.requiredTrophies)
        stream.writeVInt(0) // DataReference (0) - null (low is only written when high != 0)
        stream.writeVInt(alliance.members.length)
    }

    /**
     * Stream entry: vint type + entry body
     * @param { ByteStream } stream ByteStream
     * @param { Object } entry Stream entry
     */
    static encodeStreamEntry (stream, entry) {
        stream.writeVInt(entry.type)

        // StreamEntry::encode
        stream.writeVInt(0) // LogicLong (0, id)
        stream.writeVInt(entry.id)
        stream.writeVInt(0) // LogicLong (0, player id)
        stream.writeVInt(entry.playerId)
        stream.writeString(entry.playerName)
        stream.writeVInt(entry.playerRole)
        stream.writeVInt(Math.max(Math.floor(Date.now() / 1000) - entry.timestamp, 0)) // Age in seconds
        stream.writeBoolean(false)

        switch (entry.type) {
            case 2: // ChatStreamEntry
                stream.writeString(entry.message)
                break
            case 3: { // JoinRequestAllianceStreamEntry
                const player = AllianceDatabase.getMemberPlayer(entry.playerId)

                stream.writeString(entry.message) // Request message
                stream.writeString(entry.responderName) // Who accepted / rejected
                stream.writeVInt(entry.event) // 0 rejected, 1 pending, 2 accepted
                stream.writeVInt(0)
                stream.writeVInt(28) // DataReference (28, icon)
                stream.writeVInt(player ? player.profileIcon : 0)
                break
            }
            case 4: // AllianceEventStreamEntry
                stream.writeVInt(entry.event) // 1 kicked, 3 joined, 4 left, 5 promoted, 6 demoted (teams: 101 created, 102 joined, 103 left, 104 kicked)
                stream.writeBoolean(true)
                stream.writeVInt(0) // LogicLong (0, target id)
                stream.writeVInt(entry.targetId)
                stream.writeString(entry.targetName)
                break
            case 77: // TeamCreatedStreamEntry (team advertised to the alliance)
                stream.writeInt(0) // Long (0, team id)
                stream.writeInt(entry.targetId)
                stream.writeVInt(0) // Ad info tid
                stream.writeVInt(0)
                stream.writeVInt(0)
                break
        }
    }
}

module.exports = AllianceEncoder
