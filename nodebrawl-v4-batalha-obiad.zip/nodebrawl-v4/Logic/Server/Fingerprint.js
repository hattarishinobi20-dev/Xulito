const fs = require("fs")
const path = require("path")

const ASSETS_DIR = path.join(__dirname, "..", "..", "AssetsServer")

/**
 * Fingerprint
 *
 * Content version handling ported from Obiad Brawl v4 (Utils/Fingerprint.py, Utils/Utility.py).
 *
 * AssetsServer/lastversion.txt          "<version>...<sha>" (e.g. "4.7.1...c5c6304...")
 * AssetsServer/Update/<sha>/fingerprint.json  fingerprint sent to the client in LoginFailed (code 7)
 * AssetsServer/Content/assets/          source files, AssetsServer/Updater.js builds a new Update/<sha> from it
 */
class Fingerprint {
    static version = ""
    static sha = ""
    static data = ""

    /**
     * Reads lastversion.txt and the matching fingerprint.json. Safe to call again to reload.
     * @returns { Boolean } true when both files were loaded
     */
    static load () {
        try {
            const content = fs.readFileSync(path.join(ASSETS_DIR, "lastversion.txt"), "utf8").trim()
            const parts = content.split("...")

            Fingerprint.version = parts[0]
            Fingerprint.sha = parts[1]
            Fingerprint.data = JSON.stringify(JSON.parse(fs.readFileSync(Fingerprint.getUpdateFile(Fingerprint.sha, "fingerprint.json"), "utf8")))
            return true
        } catch (e) {
            Fingerprint.version = ""
            Fingerprint.sha = ""
            Fingerprint.data = ""
            Warn(`Could not load fingerprint: ${e.message}`)
            return false
        }
    }

    /**
     * @param { String } sha Client fingerprint sha (LoginMessage)
     * @returns { Boolean } true when the client content is up to date (or when nothing is loaded)
     */
    static isUpToDate (sha) {
        if (!Fingerprint.sha) return true
        return sha === Fingerprint.sha
    }

    /**
     * @param { String } sha Fingerprint sha
     * @param { String } file Relative file path
     * @returns { String } Absolute path inside AssetsServer/Update/<sha>/
     */
    static getUpdateFile (sha, file) {
        return path.join(ASSETS_DIR, "Update", sha, file)
    }

    /**
     * @returns { String } AssetsServer directory
     */
    static getAssetsDir () {
        return ASSETS_DIR
    }
}

module.exports = Fingerprint
