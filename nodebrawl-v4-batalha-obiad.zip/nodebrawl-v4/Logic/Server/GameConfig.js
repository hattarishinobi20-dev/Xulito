/**
 * GameConfig
 *
 * Gameplay related settings for the v4 client.
 * (Values based on Obiad Brawl v4 Settings.json)
 */
class GameConfig {
    /**
     * Client major version accepted by the server.
     */
    static clientMajorVersion = 4

    /**
     * Maximum brawler rank shown in milestones.
     */
    static maximumRank = 20

    /**
     * Maximum brawler upgrade level.
     */
    static maximumUpgradeLevel = 5

    /**
     * Tutorial state for new accounts. (2 = tutorial completed)
     */
    static startingTutorialState = 2

    /**
     * Season length in days. Season end timestamp is calculated from server start.
     */
    static seasonLengthDays = 14

    /**
     * Bonus coins given at season end (per section: best brawler + total trophies).
     */
    static seasonEndBonus = 0

    /**
     * Amount of event slots shown in the client.
     */
    static eventSlots = 4

    /**
     * Text shown on every event card.
     */
    static eventText = "nodebrawl-core"

    /**
     * Persistent storage (Database/Storage.js).
     * driver "mongodb": accounts, alliances and the season are kept in MongoDB (one document per account /
     * alliance, collections `players`, `alliances`, `settings`); the server keeps a copy in memory and writes
     * every change straight away. driver "json": one JSON file per account / alliance under Database/ (offline,
     * used by the tests). Ban lists always stay in Database/banned_acc.json / banned_ip.json.
     * `node Database/dbtool.js migrate` copies the JSON files into MongoDB.
     * Environment overrides: MONGODB_URI (`mongodb.uri`), NODEBRAWL_DB_DRIVER (`driver`).
     */
    static database = {
        driver: "mongodb",
        mongodb: {
            uri: "mongodb+srv://nyxa:nyxazy@cluster0.er2ngmi.mongodb.net/?appName=Cluster0",
            name: "nodebrawl"
        }
    }

    /**
     * Content update check on login (Obiad "AssetsServer").
     * When enabled, the fingerprint sha sent by the client in LoginMessage must match the sha stored in
     * AssetsServer/lastversion.txt, otherwise LoginFailed (code 7) is sent with the fingerprint of
     * AssetsServer/Update/{sha}/fingerprint.json and the url of the assets http server.
     */
    static fingerprintCheck = true

    /**
     * Assets http server (serves AssetsServer/Update/{sha}/... to the client after LoginFailed 7).
     */
    static assetsServer = {
        enabled: true,
        port: 8080,
        /**
         * Host written in the content url. Empty = the address the client connected to (recommended).
         */
        publicHost: ""
    }

    /**
     * Force battle duration in ticks (50 ms each). 0 = use the game mode duration.
     * Useful for tests (e.g. 200 = 10 seconds battle).
     */
    static battleTicksOverride = 0

    /**
     * Location (locations.csv index) written in StartLoadingMessage and used by the battle.
     * Obiad Brawl v4 always loads location 2 (the default positions of the heroes / item are made for that map).
     * -1 = use the location of the event chosen by the player.
     */
    static battleLocationId = 2

    /**
     * Battle experience given to the star player.
     */
    static starPlayerExp = 10

    /**
     * Maximum members of an alliance.
     */
    static allianceMaxMembers = 100

    /**
     * Maximum stream entries kept per alliance.
     */
    static allianceStreamLength = 50

    /**
     * Shop prices and box tables. The same values are sent to the client in OwnHomeData (LogicClientHome conf data,
     * so the client deducts / shows exactly what the server applies) and used by the commands
     * (LogicGatcha, LogicBuyCardCommand, LogicBuyCoins*Command). Arrays are indexed by rarity:
     * 0 common, 1 rare, 2 super_rare, 3 epic, 4 mega_epic, 5 legendary.
     */
    static shop = {
        goldBoxCost: 100,
        gemBoxCost: 10,
        bigBoxCost: 80,
        bigBoxRewards: 10,
        coinsBoosterCost: 20,
        coinsDoublerCost: 50,
        coinsDoublerAmount: 1000,
        /** Chips given when a box drops a brawler the player already owns. */
        duplicateBrawlerChips: [1, 2, 5, 10, 20, 60],
        /** Price in chips of a brawler bought directly (LogicBuyCardCommand). */
        brawlerChipCost: [3, 10, 20, 60, 200, 500],
        /** Price in gems of the boxes with a guaranteed brawler of that rarity (0 = not sold). */
        brawlerBoxCost: [0, 30, 80, 170, 0, 0],
        /** Elixir given by a box reward of that rarity. */
        boxElixir: [1, 2, 3, 5, 7, 10]
    }

    /**
     * Default resources for new accounts.
     */
    static defaultAccount = {
        name: "Brawler",
        gold: 92,
        gems: 0,
        chips: 0,
        elixir: 0,
        trophies: 0,
        highestTrophies: 0,
        experience: 0,
        profileIcon: 0,
        controlMode: 0,
        battleHints: false,
        coinsDoubler: 0,
        coinsBooster: 0,
        coinsReward: 0,
        soloWins: 0,
        duoWins: 0,
        threeVsThreeWins: 0,
        allianceId: 0,
        allianceRole: 0,
        brawlers: {
            0: { cards: { 0: 1 }, skins: [0], selectedSkin: 0, trophies: 0, highestTrophies: 0, powerLevel: 0 }
        }
    }

    static requiredTrophiesForRank = [0, 10, 20, 30, 40, 60, 80, 100, 120, 140, 160, 180, 220, 260, 300, 340, 380, 420, 460, 500, 550, 600, 650, 700, 750, 800, 850, 900, 950, 1000, 1050, 1100, 1150, 1200]

    /**
     * Minimum brawler trophies for season reset
     * @returns { Number } Trophies
     */
    static getBrawlersTrophiesForSeasonReset () {
        if (GameConfig.maximumRank <= 34) {
            return GameConfig.requiredTrophiesForRank[GameConfig.maximumRank - 1]
        }

        return GameConfig.requiredTrophiesForRank[33] + (50 * (GameConfig.maximumRank - 34))
    }
}

module.exports = GameConfig
