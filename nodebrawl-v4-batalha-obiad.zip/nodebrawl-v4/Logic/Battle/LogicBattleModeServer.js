/**
 * LogicBattleModeServer
 *
 * Battle constants (ticks are 50 ms each). Values from Obiad Brawl v4.
 */
class LogicBattleModeServer {
    static TICK_MS = 50
    static ART_TEST = false
    static BATTLE_ROYALE_TICKS = 16000 // 800s (6s intro + 13m14s battle)
    static LASER_BALL_TICKS = 4280 // 214s (4s intro + 3m battle + 30s overtime)
    static BOSS_FIGHT_TICKS = 9680 // 484s (4s intro + 8m battle)
    static NORMAL_TICKS = 3080 // 154s (4s intro + 2m30s battle)

    /**
     * Battle duration in ticks for the game mode variation
     * @param { Number } gameModeVariation Game mode variation
     * @returns { Number } Ticks
     */
    static getBattleTicks (gameModeVariation) {
        if (LogicBattleModeServer.ART_TEST) return 99999999

        switch (gameModeVariation) {
            case 6:
            case 9:
                return LogicBattleModeServer.BATTLE_ROYALE_TICKS
            case 5:
                return LogicBattleModeServer.LASER_BALL_TICKS
            case 7:
                return LogicBattleModeServer.BOSS_FIGHT_TICKS
            default:
                return LogicBattleModeServer.NORMAL_TICKS
        }
    }
}

module.exports = LogicBattleModeServer
