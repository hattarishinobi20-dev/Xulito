const LogicBattleModeServer = require('./LogicBattleModeServer')
const LogicCharacterServer = require('./Objects/LogicCharacterServer')
const LogicItemServer = require('./Objects/LogicItemServer')
const LogicProjectileServer = require('./Objects/LogicProjectileServer')
const LogicAreaEffectServer = require('./Objects/LogicAreaEffectServer')
const LogicMovement = require('./Tick/LogicMovement')
const V4DataTables = require('../Data/V4DataTables')
const GameConfig = require('../Server/GameConfig')

/**
 * LogicBattle
 *
 * Server side battle state (player + 5 bots) and the 50 ms tick loop
 * which sends VisionUpdateMessage to the client.
 * State layout, default values and loop ported from Obiad Brawl v4
 * (DatabaseManager.createBattle / LogicBattle.py / LogicGameObjectManagerServer.py).
 */
class LogicBattle {
    static DEFAULT_X = [1950, 2550, 3150, 1950, 2550, 3150]
    static DEFAULT_Y = [9750, 9750, 9750, 150, 150, 150]
    static DEFAULT_ANGLE = [270, 270, 270, 90, 90, 90]
    static MAX_X = 8191 // 13 bits
    static MAX_Y = 16383 // 14 bits
    static POINT_ITEM_ID = 10 // items.csv "Point"
    static HERO_HITPOINTS = 800 // Obiad Brawl v4 gives every hero 800 / 800 hitpoints
    static REJOIN_GRACE_TICKS = 600 // 30 seconds for a disconnected player to log in again and rejoin

    /**
     * @param { Array<Object> } humans Human players [{ session, brawlerId }] (1 to 3, all in team 0)
     * @param { Number } locationId Location index (locations.csv)
     * @param { Number } eventSlot Event slot chosen by the player (1-based)
     */
    constructor (humans, locationId, eventSlot) {
        // humans: heroIndex is 1-based (hero 1..3 = own team)
        this.humans = humans.slice(0, 3).map((human, i) => ({ session: human.session, player: human.session.player, brawlerId: human.brawlerId, heroIndex: i + 1 }))

        // first human, kept for single player code paths
        this.session = this.humans[0].session
        this.player = this.humans[0].player
        this.brawlerId = this.humans[0].brawlerId
        // Obiad Brawl v4 always loads location 2 whatever the event is (GameConfig.battleLocationId)
        this.locationId = GameConfig.battleLocationId >= 0 ? GameConfig.battleLocationId : locationId
        this.eventSlot = eventSlot
        this.gameMode = V4DataTables.getLocationGameMode(this.locationId)
        this.gameModeVariation = LogicBattle.getGameModeVariation(this.gameMode)

        this.id = 0
        this.ticks = 0
        this.interval = null
        this.started = false
        this.ended = false

        // Global state
        this.globalId = 2000000
        this.fadeCounter = 0
        this.isGameOver = false
        this.unknownBooleans = [true, true, true, true]
        this.unkMapSize = 0
        this.unkMapSize2 = 0
        this.tileMapWidth = 0
        this.tileMapHeight = 0
        this.destructibleTiles = []
        this.progressionSelf = 0
        this.progressionRival = 0

        // Heroes: index 1-3 own team (humans first, then bots), 4-6 enemies (bots)
        this.brawlers = this.humans.map(human => human.brawlerId)

        const heroesIds = V4DataTables.characters.filter(c => c.type === "Hero" && !c.disabled).map(c => c.index)

        while (this.brawlers.length < 6) this.brawlers.push(heroesIds[Math.floor(Math.random() * heroesIds.length)])

        this.heroes = []
        this.ultiArray = []
        this.killArray = []

        for (let i = 1; i <= 6; i++) {
            this.heroes.push(LogicCharacterServer.create(
                { x: LogicBattle.DEFAULT_X[i - 1], y: LogicBattle.DEFAULT_Y[i - 1], index: i <= 3 ? i - 1 : i + 15, z: 0, visibility: 10 },
                LogicBattle.DEFAULT_ANGLE[i - 1],
                LogicBattle.HERO_HITPOINTS
            ))
            this.ultiArray.push({ unknown: true, hasUlti: true, ultiCharge: 1000 })
            this.killArray.push({ score: 0, entries: [] })
        }

        this.items = [{ objectInfos: { x: 2550, y: 4950, index: 103, z: 0, visibility: 10 } }]
        this.projectiles = []
        this.areaEffects = []
        this.characters = []
    }

    /**
     * Game mode variation used for battle duration
     * @param { String } gameMode Game mode name from locations.csv
     * @returns { Number } Variation
     */
    static getGameModeVariation (gameMode) {
        switch (gameMode) {
            case "CoinRush": return 0
            case "BountyHunter": return 3
            case "AttackDefend": return 2
            case "LaserBall": return 5
            case "BattleRoyale": return 6
            case "BossFight": return 7
            default: return 0
        }
    }

    /**
     * Total battle ticks
     * @returns { Number } Ticks
     */
    getBattleTicks () {
        if (GameConfig.battleTicksOverride > 0) return GameConfig.battleTicksOverride

        return LogicBattleModeServer.getBattleTicks(this.gameModeVariation)
    }

    /**
     * Human entry of a session
     * @param { Session } session Session
     * @returns { Object | null } { session, player, brawlerId, heroIndex }
     */
    getHuman (session) {
        return this.humans.find(human => human.session === session) || null
    }

    /**
     * Human entry of a player (by account low id)
     * @param { Number } lowId Player low id
     * @returns { Object | null } Human entry
     */
    getHumanByLowId (lowId) {
        return this.humans.find(human => human.player.lowId === lowId) || null
    }

    /**
     * Remove a human from the battle (his hero stays as a bot)
     * @param { Session } session Session
     * @returns { Number } Remaining humans
     */
    removeHuman (session) {
        this.humans = this.humans.filter(human => human.session !== session)

        return this.humans.length
    }

    /**
     * Player team of the hero
     * @param { Number } heroIndex Hero index (1-based)
     * @returns { Number } Team (0 own team, 1 enemy)
     */
    getTeam (heroIndex) {
        return heroIndex <= 3 ? 0 : 1
    }

    /**
     * Start the tick loop
     */
    start () {
        if (this.started) return

        this.started = true
        this.interval = setInterval(() => this.tick().catch(e => Err(e.stack)), LogicBattleModeServer.TICK_MS)
    }

    /**
     * Stop the tick loop
     */
    stop () {
        if (this.interval) clearInterval(this.interval)

        this.interval = null
        this.started = false
    }

    /**
     * One battle tick (50 ms)
     */
    async tick () {
        if (this.ended) return this.stop()

        for (const human of [...this.humans]) {
            if (!human.session.destroyed) {
                human.disconnectedTick = -1
                continue
            }

            // disconnected player: keep his slot for a while so a new login can rejoin (LogicBattleManager.rebind)
            if (human.disconnectedTick === undefined || human.disconnectedTick < 0) {
                human.disconnectedTick = this.ticks
                Log(`Battle ${this.id}: session of ${human.player.name} closed, waiting ${LogicBattle.REJOIN_GRACE_TICKS} ticks for a rejoin.`)
            } else if (this.ticks - human.disconnectedTick >= LogicBattle.REJOIN_GRACE_TICKS) {
                Log(`Battle ${this.id}: ${human.player.name} did not rejoin, player dropped.`)
                LogicBattle.Manager.endBattle(human.session, false)
            }
        }

        if (this.ended) return this.stop()

        if (this.ticks > this.getBattleTicks()) {
            // time is over: the server sends BattleEndMessage itself (Obiad ForceSendBattleEnd) and drops the battle
            for (const human of [...this.humans]) LogicBattle.Manager.endBattle(human.session, true)
            return
        }

        this.ticks++

        LogicMovement.tick(this)
        LogicItemServer.tick(this)

        await this.sendVision()
    }

    /**
     * Send VisionUpdateMessage to every human player (or only to one session)
     * @param { Session } session Only this session (optional)
     */
    async sendVision (session) {
        const VisionUpdateMessage = require('../../Protocol/Messages/Server/Battle/VisionUpdateMessage')

        for (const human of this.humans) {
            if (session && human.session !== session) continue
            if (human.session.destroyed) continue

            await new VisionUpdateMessage(human.session, this, human.heroIndex).send()
        }
    }

    /**
     * Handle client input (ClientInputMessage), same rules as Obiad Brawl v4 ClientInputMessage.decode
     * @param { Session } session Session of the player
     * @param { Number } type 100 move, 107/108 ulti aim on/off, 0-99 skill (skills.csv index)
     * @param { Number } x X
     * @param { Number } y Y
     */
    handleInput (session, type, x, y) {
        const human = this.getHuman(session)

        if (!human) return

        const hero = this.heroes[human.heroIndex - 1]

        if (type === 100) {
            hero.movement = null
            hero.objectInfos.x = LogicBattle.clamp(x, 0, LogicBattle.MAX_X)
            hero.objectInfos.y = LogicBattle.clamp(y, 0, LogicBattle.MAX_Y)
        } else if (type === 107) {
            hero.ultiAiming = true
        } else if (type === 108) {
            hero.ultiAiming = false
        } else if (type >= 0 && type < 100) {
            const skill = V4DataTables.getSkill(type)

            if (skill && skill.behaviorType === "Charge") {
                const targetX = LogicBattle.clamp(x, 0, LogicBattle.MAX_X)
                const targetY = LogicBattle.clamp(y, 0, LogicBattle.MAX_Y)

                // Charge types handled by Obiad: 2 = jump (z peak = ChargeSpeed * 2), 4 = dash on the ground
                if (skill.chargeType === 2) {
                    LogicMovement.moveTo(hero, targetX, targetY, skill.chargeSpeed * 2, skill.chargeSpeed)
                } else if (skill.chargeType === 4) {
                    LogicMovement.moveTo(hero, targetX, targetY, 0, skill.chargeSpeed)
                }
            }
        }
    }

    /**
     * Collect an item with a hero
     * @param { Object } item Item
     * @param { Object } hero Hero
     */
    collectItem (item, hero) {
        const itemIndex = this.items.indexOf(item)
        const heroIndex = this.heroes.indexOf(hero)

        if (itemIndex === -1 || heroIndex === -1) return

        this.items.splice(itemIndex, 1)
        this.killArray[heroIndex].score = Math.min(this.killArray[heroIndex].score + 1, 127)
        hero.itemsAmount = Math.min(hero.itemsAmount + 1, 127)
    }

    /**
     * Game objects list (csv ids + running indexes) in the vision order
     * @returns { Array<Object> } [{ classId, instanceId, typeId, runningId }]
     */
    getGameObjects () {
        const objects = []

        for (let i = 0; i < this.heroes.length; i++) objects.push({ classId: 16, instanceId: this.brawlers[i], typeId: 2, runningId: i })
        for (let i = 0; i < this.projectiles.length; i++) objects.push({ classId: 6, instanceId: this.projectiles[i].projectileId || 0, typeId: 1, runningId: i })
        for (let i = 0; i < this.items.length; i++) objects.push({ classId: 18, instanceId: LogicBattle.POINT_ITEM_ID, typeId: 4, runningId: i })
        for (let i = 0; i < this.areaEffects.length; i++) objects.push({ classId: 17, instanceId: this.areaEffects[i].areaEffectId || 0, typeId: 3, runningId: i })

        return objects
    }

    /**
     * Encode the battle state (LogicGameObjectManagerServer::encode)
     * @param { BitStream } stream BitStream
     * @param { Number } ownIndex Hero index (1-based) of the player who receives the vision
     */
    encode (stream, ownIndex = 1) {
        stream.writePositiveInt(this.globalId, 21)
        stream.writePositiveInt(this.fadeCounter, 15)
        stream.writeBoolean(this.isGameOver)
        stream.writeBoolean(this.unknownBooleans[0])
        stream.writeBoolean(this.unknownBooleans[1])
        stream.writeBoolean(this.unknownBooleans[2])
        stream.writeBoolean(this.unknownBooleans[3])
        stream.writePositiveInt(this.unkMapSize, 5)
        stream.writePositiveInt(this.unkMapSize2, 6)
        stream.writePositiveInt(this.tileMapWidth, 5)
        stream.writePositiveInt(this.tileMapHeight, 6)

        for (const tile of this.destructibleTiles) stream.writeBoolean(tile.isDestroyed)

        stream.writeBoolean(false)

        for (let i = 0; i < this.ultiArray.length; i++) {
            stream.writeBoolean(this.ultiArray[i].unknown)
            stream.writeBoolean(this.ultiArray[i].hasUlti)

            if (i === ownIndex - 1) stream.writePositiveInt(this.ultiArray[i].ultiCharge, 10) // own ulti charge, 1000 = full
        }

        stream.writePositiveInt(this.progressionSelf, 3)
        stream.writePositiveInt(this.progressionRival, 3)

        for (const kill of this.killArray) {
            stream.writePositiveInt(kill.score, 7)
            stream.writePositiveInt(kill.entries.length, 4)

            for (const entry of kill.entries) {
                stream.writePositiveInt(entry.length, 3)

                for (const value of entry) stream.writePositiveInt(value, 4)
            }
        }

        const objects = this.getGameObjects()

        stream.writePositiveInt(objects.length, 7)

        for (const object of objects) {
            stream.writePositiveInt(object.classId, 5) // 16 characters, 6 projectiles, 18 items, 17 area effects
            stream.writePositiveInt(object.instanceId, 8)
        }

        for (const object of objects) {
            stream.writePositiveInt(object.typeId, 5) // 1 projectile, 2 character, 3 area effect, 4 item
            stream.writePositiveInt(object.runningId, 14)
        }

        for (let i = 0; i < this.heroes.length; i++) LogicCharacterServer.encode(stream, this.heroes[i], i + 1 === ownIndex)
        for (const projectile of this.projectiles) LogicProjectileServer.encode(stream, projectile)
        for (const item of this.items) LogicItemServer.encode(stream, item)
        for (const areaEffect of this.areaEffects) LogicAreaEffectServer.encode(stream, areaEffect)
        for (let i = 0; i < this.characters.length; i++) LogicCharacterServer.encode(stream, this.characters[i], false)
    }

    static clamp (value, min, max) {
        return Math.max(min, Math.min(max, Math.floor(value)))
    }
}

module.exports = LogicBattle
