const LogicBattle = require('./LogicBattle')

/**
 * LogicBattleManager
 *
 * Keeps matchmaking data and running battles per session.
 * A battle can be shared by up to 3 human players (team rooms); the same LogicBattle instance is
 * registered for every session that takes part in it.
 */
class LogicBattleManager {
    static lastBattleId = 0
    /** @type { Map<Number, Object> } sessionId -> matchmaking data */
    static matchmaking = new Map()
    /** @type { Map<Number, LogicBattle> } sessionId -> battle */
    static battles = new Map()

    /**
     * Create matchmaking data for the session (MatchMakingStatusMessage needs it)
     * @param { Session } session Session
     * @param { Number } maximumPlayers Players needed for the battle
     * @returns { Object } Matchmaking data
     */
    static createMatchmaking (session, maximumPlayers) {
        const data = {
            battleId: ++LogicBattleManager.lastBattleId,
            startedTime: Math.floor(Date.now() / 1000),
            displayTime: 20,
            maximumPlayers,
            players: [session.player]
        }

        LogicBattleManager.matchmaking.set(session.id, data)

        return data
    }

    /**
     * @param { Session } session Session
     * @returns { Object | null } Matchmaking data
     */
    static getMatchmaking (session) {
        return LogicBattleManager.matchmaking.get(session.id) || null
    }

    /**
     * @param { Session } session Session
     */
    static clearMatchmaking (session) {
        LogicBattleManager.matchmaking.delete(session.id)
    }

    /**
     * Create battle for the session (stops any previous battle first)
     * @param { Session } session Session
     * @param { Number } brawlerId Character index
     * @param { Number } locationId Location index
     * @param { Number } eventSlot Event slot (1-based)
     * @returns { LogicBattle } Battle
     */
    static createBattle (session, brawlerId, locationId, eventSlot) {
        return LogicBattleManager.createTeamBattle([{ session, brawlerId }], locationId, eventSlot)
    }

    /**
     * Create a battle shared by several sessions (all in the same team)
     * @param { Array<Object> } humans [{ session, brawlerId }]
     * @param { Number } locationId Location index
     * @param { Number } eventSlot Event slot (1-based)
     * @returns { LogicBattle } Battle
     */
    static createTeamBattle (humans, locationId, eventSlot) {
        const matchmaking = LogicBattleManager.getMatchmaking(humans[0].session)

        for (const human of humans) LogicBattleManager.endBattle(human.session, false)

        const battle = new LogicBattle(humans, locationId, eventSlot)

        battle.id = matchmaking ? matchmaking.battleId : ++LogicBattleManager.lastBattleId

        for (const human of battle.humans) LogicBattleManager.battles.set(human.session.id, battle)

        return battle
    }

    /**
     * @param { Session } session Session
     * @returns { LogicBattle | null } Battle of the session
     */
    static getBattle (session) {
        return LogicBattleManager.battles.get(session.id) || null
    }

    /**
     * Put a new session back into the battle its player was disconnected from (login while a battle is running)
     * @param { Session } session New session (session.player already set)
     * @returns { LogicBattle | null } Battle joined again, null when there is none
     */
    static rebind (session) {
        for (const battle of new Set(LogicBattleManager.battles.values())) {
            if (battle.ended) continue

            const human = battle.getHumanByLowId(session.player.lowId)

            if (!human || !human.session.destroyed) continue

            LogicBattleManager.battles.delete(human.session.id)
            LogicBattleManager.matchmaking.delete(human.session.id)

            human.session = session
            human.player = session.player
            human.disconnectedTick = -1

            if (battle.humans[0] === human) {
                battle.session = session
                battle.player = session.player
            }

            LogicBattleManager.battles.set(session.id, battle)

            return battle
        }

        return null
    }

    /**
     * Remove the session from its battle. The battle keeps running for the other humans
     * (the hero of the leaving player stays as a bot) and is stopped when nobody is left.
     * @param { Session } session Session
     * @param { Boolean } sendBattleEnd Send BattleEndMessage (forced end, no rewards)
     */
    static endBattle (session, sendBattleEnd) {
        const battle = LogicBattleManager.getBattle(session)

        LogicBattleManager.clearMatchmaking(session)

        if (!battle) return

        LogicBattleManager.battles.delete(session.id)

        if (sendBattleEnd && !session.destroyed) {
            const BattleEndMessage = require('../../Protocol/Messages/Server/Battle/BattleEndMessage')

            new BattleEndMessage(session, BattleEndMessage.fromBattle(battle, session)).send().catch(e => session.errLog(e.stack))
        }

        if (battle.removeHuman(session) === 0) {
            battle.ended = true
            battle.stop()
        }
    }

    /**
     * Stop all battles (server shutdown)
     */
    static stopAll () {
        for (const battle of LogicBattleManager.battles.values()) {
            battle.ended = true
            battle.stop()
        }

        LogicBattleManager.battles.clear()
        LogicBattleManager.matchmaking.clear()
    }
}

LogicBattle.Manager = LogicBattleManager

module.exports = LogicBattleManager
