/**
 * BitStream
 *
 * Bit level writer used by VisionUpdateMessage (LogicGameObjectManagerServer::encode).
 * Ported from Obiad Brawl v4 (Utils/BitStream.py). Bits are written LSB first.
 *
 * Note: the core Titan BitStream is not used because its writeBits advances the
 * source byte position per bit instead of per byte.
 */
class BitStream {
    constructor () {
        this.bytes = []
        this.bitIndex = 0
    }

    /**
     * Written bytes
     * @returns { Buffer } Buffer
     */
    get buffer () {
        return Buffer.from(this.bytes)
    }

    /**
     * @returns { Number } Length in bytes
     */
    getLength () {
        return this.bytes.length
    }

    writeBit (bit) {
        if (this.bitIndex === 0) this.bytes.push(0xFF)

        const index = this.bytes.length - 1
        let value = this.bytes[index]

        value &= ~(1 << this.bitIndex) & 0xFF
        value |= (bit << this.bitIndex)
        this.bytes[index] = value & 0xFF

        this.bitIndex = (this.bitIndex + 1) % 8
    }

    /**
     * Write the lowest `count` bits of value (LSB first)
     * @param { Number } value Positive value
     * @param { Number } count Bits count
     */
    writePositiveInt (value, count) {
        value = Math.max(0, Math.floor(value)) >>> 0

        for (let i = 0; i < count; i++) this.writeBit((value >>> i) & 1)
    }

    writeBoolean (value) {
        this.writePositiveInt(value ? 1 : 0, 1)
    }

    writeInt (value, count) {
        this.writePositiveInt(value <= -1 ? 0 : 1, 1)
        this.writePositiveInt(Math.abs(value), count)
    }

    writePositiveIntMax31 (value) { this.writePositiveInt(value, 5) }
    writePositiveIntMax255 (value) { this.writePositiveInt(value, 8) }
    writePositiveIntMax511 (value) { this.writePositiveInt(value, 9) }
    writePositiveIntMax1023 (value) { this.writePositiveInt(value, 10) }
    writePositiveIntMax2047 (value) { this.writePositiveInt(value, 11) }
    writePositiveIntMax4095 (value) { this.writePositiveInt(value, 12) }
    writePositiveIntMax8191 (value) { this.writePositiveInt(value, 13) }
    writePositiveIntMax16383 (value) { this.writePositiveInt(value, 14) }

    /**
     * Data reference (class id 5 bits + instance id 8 bits)
     */
    writeDataReference (classId, instanceId) {
        this.writePositiveIntMax31(classId)

        if (classId >= 1) this.writePositiveIntMax255(instanceId)
    }
}

module.exports = BitStream
