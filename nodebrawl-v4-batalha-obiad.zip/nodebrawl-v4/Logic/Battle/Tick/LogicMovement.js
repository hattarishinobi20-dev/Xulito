/**
 * LogicMovement
 *
 * Charge (dash) movement of a hero, ported from Obiad Brawl v4 (Logic/Battle/Tick/LogicMovement.py move_to):
 * linear x/y interpolation towards the target with a parabolic z that peaks at targetZ in the middle,
 * travel time = min(distance / speed, duration). Obiad runs the interpolation in a blocking loop which sends a
 * VisionUpdate every 50 ms; here the same steps are computed from the battle tick loop (same output cadence).
 */
class LogicMovement {
    static DEFAULT_SPEED = 500
    static DEFAULT_DURATION = 2.0 // seconds
    static MAX_Z = 4095 // 12 bits

    /**
     * Start moving a hero towards (targetX, targetY)
     * @param { Object } hero Hero state (LogicCharacterServer.create)
     * @param { Number } targetX Target x
     * @param { Number } targetY Target y
     * @param { Number } targetZ Z reached at the middle of the path
     * @param { Number } speed Units per second
     * @param { Number } duration Maximum travel time in seconds
     */
    static moveTo (hero, targetX, targetY, targetZ = 0, speed = LogicMovement.DEFAULT_SPEED, duration = LogicMovement.DEFAULT_DURATION) {
        const startX = hero.objectInfos.x
        const startY = hero.objectInfos.y
        const totalDistance = Math.hypot(targetX - startX, targetY - startY)
        const travelTime = Math.min(totalDistance / (speed > 0 ? speed : LogicMovement.DEFAULT_SPEED), duration)

        hero.movement = { startX, startY, targetX, targetY, targetZ, travelTime, startTime: Date.now() / 1000 }

        LogicMovement.update(hero)
    }

    /**
     * Update the position of a moving hero (one interpolation step)
     * @param { Object } hero Hero state
     * @returns { Boolean } true while the hero is still moving
     */
    static update (hero) {
        const movement = hero.movement

        if (!movement) return false

        const elapsed = Date.now() / 1000 - movement.startTime

        if (movement.travelTime <= 0 || elapsed >= movement.travelTime) {
            // final position is exactly the target
            hero.objectInfos.x = movement.targetX
            hero.objectInfos.y = movement.targetY
            hero.objectInfos.z = 0
            hero.movement = null

            return false
        }

        const t = Math.min(elapsed / movement.travelTime, 1)

        hero.objectInfos.x = Math.floor((1 - t) * movement.startX + t * movement.targetX)
        hero.objectInfos.y = Math.floor((1 - t) * movement.startY + t * movement.targetY)
        hero.objectInfos.z = Math.min(Math.max(Math.floor(movement.targetZ * (1 - Math.pow(2 * (t - 0.5), 2))), 0), LogicMovement.MAX_Z)

        return true
    }

    /**
     * Update every moving hero of the battle
     * @param { LogicBattle } battle Battle
     */
    static tick (battle) {
        for (const hero of battle.heroes) {
            if (hero.movement) LogicMovement.update(hero)
        }
    }
}

module.exports = LogicMovement
