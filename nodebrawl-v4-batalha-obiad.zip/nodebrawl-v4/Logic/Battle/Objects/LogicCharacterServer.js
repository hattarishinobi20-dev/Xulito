const LogicGameObjectServer = require('./LogicGameObjectServer')

/**
 * LogicCharacterServer
 *
 * Hero / character entry of the vision update. Layout from Obiad Brawl v4 (LogicCharacter.py).
 */
class LogicCharacterServer {
    /**
     * Create default hero state
     * @param { Object } objectInfos { x, y, index, z, visibility }
     * @param { Number } angle Facing angle
     * @param { Number } hitpoints Max hitpoints
     * @returns { Object } Hero state
     */
    static create (objectInfos, angle, hitpoints) {
        return {
            objectInfos,
            teamRotation: angle,
            enemyRotation: angle,
            state: 0, // 1: ?, 2: has attacked, 3: has used ulti, 4: normal
            slowed: false,
            unknown: false,
            playingAnAnimation: true,
            playedAnimation: 63,
            rotationRelated: false,
            stunned: false,
            unknown2: false,
            isPoisoned: false,
            unknown3: 0,
            unknown4: 0,
            currentHP: hitpoints,
            maximumHP: hitpoints,
            itemsAmount: 1, // bounty stars
            unknown5: 0,
            unknown6: 0,
            unknown7: false,
            hasImmunityShield: false,
            rotationRelated2: false,
            hasRage: false,
            ultiAiming: false,
            activatedUlti: false,
            invisible: false,
            notFullyVisible: false,
            unknown8: 0,
            unknown9: true,
            unknown10: 0,
            damagesArray: [],
            skillsArray: [
                { name: "Weapon", activeTicks: 0, unknown: false, unknown1: 0, ammos: 3000 },
                { name: "Ulti", activeTicks: 0, unknown: false, unknown1: 0, ammos: 3000 }
            ]
        }
    }

    /**
     * @param { BitStream } stream BitStream
     * @param { Object } hero Hero state
     * @param { Boolean } isOwn Hero of the player who receives the vision
     */
    static encode (stream, hero, isOwn) {
        LogicGameObjectServer.encode(stream, hero.objectInfos)

        if (isOwn) {
            stream.writePositiveInt(0, 1) // own player has no rotation data
        } else {
            stream.writePositiveInt(hero.teamRotation, 9) // rotation (own side)
            stream.writePositiveInt(hero.enemyRotation, 9) // rotation (enemy side)
        }

        stream.writePositiveInt(hero.state, 3)
        stream.writeBoolean(hero.slowed)
        stream.writeBoolean(hero.unknown)
        stream.writeBoolean(hero.playingAnAnimation)
        stream.writePositiveInt(hero.playedAnimation, 6)
        stream.writeBoolean(hero.rotationRelated)
        stream.writeBoolean(hero.stunned)
        stream.writeBoolean(hero.unknown2)
        stream.writeBoolean(hero.isPoisoned)
        stream.writePositiveInt(hero.unknown3, 7)
        stream.writePositiveInt(hero.unknown4, 5)
        stream.writePositiveInt(hero.currentHP, 11)
        stream.writePositiveInt(hero.maximumHP, 11)
        stream.writePositiveInt(hero.itemsAmount, 7)
        stream.writePositiveInt(hero.unknown5, 13)
        stream.writePositiveInt(hero.unknown6, 11)
        stream.writeBoolean(hero.unknown7)
        stream.writeBoolean(hero.hasImmunityShield)
        stream.writeBoolean(hero.rotationRelated2)
        stream.writeBoolean(hero.hasRage)
        stream.writeBoolean(hero.ultiAiming)
        stream.writeBoolean(hero.activatedUlti)
        stream.writeBoolean(hero.invisible)
        stream.writeBoolean(hero.notFullyVisible)
        stream.writePositiveInt(hero.unknown8, 9)

        if (isOwn) {
            stream.writeBoolean(hero.unknown9) // only for own player
            stream.writePositiveInt(hero.unknown10, 9)
        }

        stream.writePositiveInt(hero.damagesArray.length, 5)

        for (const damage of hero.damagesArray) {
            stream.writeBoolean(damage.unknown)
            stream.writePositiveInt(damage.damage, 12)
        }

        for (const skill of hero.skillsArray) {
            stream.writePositiveInt(skill.activeTicks, 11)
            stream.writeBoolean(skill.unknown)
            stream.writePositiveInt(skill.unknown1, 12)

            if (skill.name === "Weapon") stream.writePositiveInt(skill.ammos, 12) // 1000 = one full ammo
        }
    }
}

module.exports = LogicCharacterServer
