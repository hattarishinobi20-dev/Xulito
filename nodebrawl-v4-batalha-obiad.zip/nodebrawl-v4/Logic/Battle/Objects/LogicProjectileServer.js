/**
 * LogicProjectileServer
 *
 * Projectile entry of the vision update. Layout from Obiad Brawl v4 (LogicProjectile.py).
 */
class LogicProjectileServer {
    /**
     * @param { BitStream } stream BitStream
     * @param { Object } projectile Projectile state { x, y, index, z, state, path }
     */
    static encode (stream, projectile) {
        stream.writePositiveInt(projectile.x, 13)
        stream.writePositiveInt(projectile.y, 14)
        stream.writePositiveInt(projectile.index, 7)
        stream.writePositiveInt(projectile.z, 12)
        stream.writePositiveInt(projectile.state, 3)
        stream.writePositiveInt(projectile.path, 10)
        stream.writePositiveInt(0, 1)
    }
}

module.exports = LogicProjectileServer
