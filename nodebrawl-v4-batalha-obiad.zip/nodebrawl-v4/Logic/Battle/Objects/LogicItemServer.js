const LogicGameObjectServer = require('./LogicGameObjectServer')

/**
 * LogicItemServer
 *
 * Item entry of the vision update (bounty star / coin on the ground).
 */
class LogicItemServer {
    static PICKUP_DISTANCE = 300

    /**
     * @param { BitStream } stream BitStream
     * @param { Object } item Item state
     */
    static encode (stream, item) {
        LogicGameObjectServer.encode(stream, item.objectInfos)
    }

    /**
     * Collect items that are close to a hero
     * @param { LogicBattle } battle Battle
     */
    static tick (battle) {
        for (const item of [...battle.items]) {
            for (const hero of battle.heroes) {
                const dx = item.objectInfos.x - hero.objectInfos.x
                const dy = item.objectInfos.y - hero.objectInfos.y

                if (Math.sqrt(dx * dx + dy * dy) <= LogicItemServer.PICKUP_DISTANCE) {
                    battle.collectItem(item, hero)
                    break
                }
            }
        }
    }
}

module.exports = LogicItemServer
