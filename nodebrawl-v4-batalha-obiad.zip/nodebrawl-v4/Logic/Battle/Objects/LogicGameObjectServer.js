/**
 * LogicGameObjectServer
 *
 * Common game object header of the vision update (position, index, z, visibility).
 */
class LogicGameObjectServer {
    /**
     * @param { BitStream } stream BitStream
     * @param { Object } objectInfos { x, y, index, z, visibility }
     */
    static encode (stream, objectInfos) {
        stream.writePositiveInt(objectInfos.x, 13)
        stream.writePositiveInt(objectInfos.y, 14)
        stream.writePositiveInt(objectInfos.index, 7)
        stream.writePositiveInt(objectInfos.z, 12)
        stream.writePositiveInt(objectInfos.visibility, 4)
    }
}

module.exports = LogicGameObjectServer
