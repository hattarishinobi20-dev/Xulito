/**
 * LogicAreaEffectServer
 *
 * Area effect entry of the vision update. Layout from Obiad Brawl v4 (LogicAreaEffect.py).
 */
class LogicAreaEffectServer {
    /**
     * @param { BitStream } stream BitStream
     * @param { Object } areaEffect Area effect state { x, y, index, z, visibility }
     */
    static encode (stream, areaEffect) {
        stream.writePositiveInt(areaEffect.x, 13)
        stream.writePositiveInt(areaEffect.y, 14)
        stream.writePositiveInt(areaEffect.index, 7)
        stream.writePositiveInt(areaEffect.z, 12)
        stream.writePositiveInt(areaEffect.visibility, 4)
    }
}

module.exports = LogicAreaEffectServer
