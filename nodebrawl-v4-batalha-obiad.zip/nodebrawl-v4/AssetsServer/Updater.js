/**
 * Updater
 *
 * Ported from Obiad Brawl v4 (AssetsServer/Updater.py).
 *
 * Builds a new content version from AssetsServer/Content/assets:
 *   1. generates a new fingerprint sha (sha1 of the current timestamp, like Obiad),
 *   2. copies every file of Content/assets into Update/<sha>/,
 *   3. writes Update/<sha>/fingerprint.json ({ files: [{ file, sha }], sha, version }),
 *   4. bumps the middle version number in lastversion.txt ("4.7.1...<sha>" -> "4.8.1...<newsha>").
 *
 * Usage: node AssetsServer/Updater.js   (then restart the server)
 */
const fs = require("fs")
const path = require("path")
const crypto = require("crypto")

const ASSETS_DIR = __dirname
const CONTENT_DIR = path.join(ASSETS_DIR, "Content", "assets")
const UPDATE_DIR = path.join(ASSETS_DIR, "Update")
const LAST_VERSION_FILE = path.join(ASSETS_DIR, "lastversion.txt")

const sha1 = (data) => crypto.createHash("sha1").update(data).digest("hex")

const walk = (dir, list = []) => {
    for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
        const full = path.join(dir, entry.name)
        if (entry.isDirectory()) walk(full, list)
        else list.push(full)
    }
    return list
}

const main = () => {
    if (!fs.existsSync(CONTENT_DIR)) {
        console.log(`Missing ${CONTENT_DIR}`)
        process.exit(1)
    }

    const lastVersion = fs.readFileSync(LAST_VERSION_FILE, "utf8").trim()
    const version = lastVersion.split("...")[0].split(".")
    const newVersion = `${version[0]}.${parseInt(version[1]) + 1}.${version[2]}`
    const newSha = sha1(String(Date.now() / 1000))

    const files = walk(CONTENT_DIR).filter(f => path.basename(f) !== "fingerprint.json")
    const fingerprint = { files: [], sha: newSha, version: newVersion }
    const target = path.join(UPDATE_DIR, newSha)

    fs.mkdirSync(target, { recursive: true })

    for (const file of files) {
        const relative = path.relative(CONTENT_DIR, file).split(path.sep).join("/")
        const data = fs.readFileSync(file)

        fingerprint.files.push({ file: relative, sha: sha1(data) })

        fs.mkdirSync(path.dirname(path.join(target, relative)), { recursive: true })
        fs.copyFileSync(file, path.join(target, relative))
    }

    // Supercell fingerprints escape slashes ("csv_logic\/cards.csv"), same as Obiad
    const json = JSON.stringify(fingerprint).replace(/\//g, "\\/")

    fs.writeFileSync(path.join(target, "fingerprint.json"), json)
    fs.writeFileSync(path.join(CONTENT_DIR, "fingerprint.json"), json)
    fs.writeFileSync(LAST_VERSION_FILE, `${newVersion}...${newSha}`)

    console.log(`Content version ${newVersion} (${newSha}) created with ${files.length} files.`)
    console.log(`Restart the server to use it.`)
}

main()
