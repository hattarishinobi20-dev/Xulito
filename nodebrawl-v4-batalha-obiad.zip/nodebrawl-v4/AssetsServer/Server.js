const http = require("http")
const fs = require("fs")
const path = require("path")
const GameConfig = require("../Logic/Server/GameConfig")
const Fingerprint = require("../Logic/Server/Fingerprint")

const UPDATE_DIR = path.join(__dirname, "Update")
const CONTENT_DIR = path.join(__dirname, "Content", "assets")

const MIME_TYPES = {
    ".json": "application/json",
    ".csv": "text/csv",
    ".txt": "text/plain",
    ".sc": "application/octet-stream",
    ".png": "image/png",
    ".ogg": "audio/ogg",
    ".ttf": "font/ttf",
    ".fnt": "text/plain"
}

/**
 * AssetsServer
 *
 * Plain http file server ported from Obiad Brawl v4 (AssetsServer/Server.py).
 * The client requests "<contentUrl><sha>/<file>" after a LoginFailed (code 7):
 *
 *   GET /<sha>/fingerprint.json      -> AssetsServer/Update/<sha>/fingerprint.json
 *   GET /<sha>/csv_logic/cards.csv   -> AssetsServer/Update/<sha>/csv_logic/cards.csv
 *
 * Files missing in Update/<sha>/ are looked up in Content/assets/ (source folder) so a
 * fresh clone works without running the Updater first.
 */
class AssetsServer {
    constructor () {
        this.server = null
    }

    /**
     * @param { Number } port Http port (GameConfig.assetsServer.port)
     * @returns { Promise<void> }
     */
    start (port = GameConfig.assetsServer.port) {
        return new Promise((resolve) => {
            this.server = http.createServer((req, res) => this.handle(req, res))

            this.server.on("error", (e) => {
                Err(`Assets server error: ${e.message}`)
                resolve()
            })

            this.server.listen(port, "0.0.0.0", () => {
                ServerLog(`Assets server started on ${port} port! (content version ${Fingerprint.version || "?"}, sha ${Fingerprint.sha || "?"})`)
                resolve()
            })
        })
    }

    stop () {
        if (this.server) this.server.close()
    }

    /**
     * @param { http.IncomingMessage } req
     * @param { http.ServerResponse } res
     */
    handle (req, res) {
        if (req.method !== "GET" && req.method !== "HEAD") {
            res.writeHead(405)
            return res.end()
        }

        let requestPath
        try {
            requestPath = decodeURIComponent(req.url.split("?")[0])
        } catch (e) {
            res.writeHead(400)
            return res.end()
        }

        const relative = path.normalize(requestPath).replace(/^(\.\.[\/\\])+/, "").replace(/^[\/\\]+/, "")
        const parts = relative.split(/[\/\\]/).filter(p => p.length > 0)

        if (parts.length < 2 || parts.includes("..")) {
            return this.notFound(res)
        }

        const filePath = this.resolve(parts)

        if (!filePath) return this.notFound(res)

        const ext = path.extname(filePath).toLowerCase()

        fs.readFile(filePath, (err, data) => {
            if (err) return this.notFound(res)

            res.writeHead(200, {
                "Content-Type": MIME_TYPES[ext] || "application/octet-stream",
                "Content-Length": data.length
            })
            res.end(req.method === "HEAD" ? undefined : data)
        })
    }

    /**
     * @param { Array<String> } parts [sha, ...file path]
     * @returns { String|null } Existing file path or null
     */
    resolve (parts) {
        const sha = parts[0]
        const file = parts.slice(1).join("/")

        const candidates = [path.join(UPDATE_DIR, sha, file)]

        // source folder fallback only for the current content version
        if (sha === Fingerprint.sha) candidates.push(path.join(CONTENT_DIR, file))

        for (const candidate of candidates) {
            const root = candidate.startsWith(UPDATE_DIR) ? UPDATE_DIR : CONTENT_DIR

            if (!candidate.startsWith(root + path.sep)) continue

            try {
                if (fs.statSync(candidate).isFile()) return candidate
            } catch (e) {
                // try next candidate
            }
        }

        return null
    }

    notFound (res) {
        res.writeHead(404, { "Content-Type": "text/plain" })
        res.end("File not found")
    }
}

module.exports = AssetsServer
