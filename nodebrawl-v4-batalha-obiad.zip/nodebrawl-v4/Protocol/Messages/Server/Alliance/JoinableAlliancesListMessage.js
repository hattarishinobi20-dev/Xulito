const PiranhaMessage = require('../../../PiranhaMessage')
const AllianceDatabase = require('../../../../Database/AllianceDatabase')
const AllianceEncoder = require('../../../../Logic/Alliance/AllianceEncoder')

/**
 * JoinableAlliancesListMessage (24304)
 */
class JoinableAlliancesListMessage extends PiranhaMessage {
  constructor (session) {
    super(session)
    this.id = 24304
    this.version = 0
  }

  async encode () {
    const alliances = AllianceDatabase.getJoinable(50)

    this.stream.writeVInt(alliances.length)

    for (const alliance of alliances) AllianceEncoder.encodeHeader(this.stream, alliance)
  }
}

module.exports = JoinableAlliancesListMessage
