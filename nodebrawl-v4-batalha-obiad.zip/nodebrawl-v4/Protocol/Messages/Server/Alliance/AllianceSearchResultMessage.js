const PiranhaMessage = require('../../../PiranhaMessage')
const AllianceEncoder = require('../../../../Logic/Alliance/AllianceEncoder')

/**
 * AllianceSearchResultMessage (24310)
 */
class AllianceSearchResultMessage extends PiranhaMessage {
  /**
   * @param { Session } session Session
   * @param { String } query Search text
   * @param { Array<Object> } alliances Found alliances
   */
  constructor (session, query, alliances) {
    super(session)
    this.id = 24310
    this.version = 0
    this.query = query
    this.alliances = alliances
  }

  async encode () {
    this.stream.writeString(this.query)
    this.stream.writeVInt(this.alliances.length)

    for (const alliance of this.alliances) AllianceEncoder.encodeHeader(this.stream, alliance)
  }
}

module.exports = AllianceSearchResultMessage
