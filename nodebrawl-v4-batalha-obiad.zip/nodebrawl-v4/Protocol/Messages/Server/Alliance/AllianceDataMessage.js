const PiranhaMessage = require('../../../PiranhaMessage')
const AllianceDatabase = require('../../../../Database/AllianceDatabase')
const Milestones = require('../../../../Logic/Home/Milestones')

/**
 * AllianceDataMessage (24301)
 *
 * Full alliance info with members list. Layout from Obiad Brawl v4 AllianceData.py.
 */
class AllianceDataMessage extends PiranhaMessage {
  /**
   * @param { Session } session Session
   * @param { Object } alliance Alliance
   */
  constructor (session, alliance) {
    super(session)
    this.id = 24301
    this.version = 0
    this.alliance = alliance
  }

  static getExperienceLevel (experience) {
    const table = Milestones.ProgressStartExp

    for (let i = 0; i < table.length - 1; i++) {
      if (experience >= table[i] && experience < table[i + 1]) return i + 1
    }

    return table.length
  }

  async encode () {
    const alliance = this.alliance
    const members = AllianceDatabase.getMembers(alliance)

    this.stream.writeLong(0, alliance.id)
    this.stream.writeString(alliance.name)
    this.stream.writeVInt(8) // DataReference (8, badge)
    this.stream.writeVInt(alliance.badge)
    this.stream.writeVInt(alliance.type)
    this.stream.writeVInt(alliance.members.length)
    this.stream.writeVInt(members.reduce((sum, m) => sum + m.player.trophies, 0)) // Alliance trophies
    this.stream.writeVInt(alliance.requiredTrophies)
    this.stream.writeVInt(0) // DataReference (0) - null (low is only written when high != 0)
    this.stream.writeString(alliance.description)

    this.stream.writeVInt(members.length)

    for (const member of members) {
      this.stream.writeLong(0, member.lowId)
      this.stream.writeString(member.player.name)
      this.stream.writeVInt(member.role)
      this.stream.writeVInt(AllianceDataMessage.getExperienceLevel(member.player.experience))
      this.stream.writeVInt(member.player.trophies)
      this.stream.writeVInt(28) // DataReference (28, icon)
      this.stream.writeVInt(member.player.profileIcon)
    }
  }
}

module.exports = AllianceDataMessage
