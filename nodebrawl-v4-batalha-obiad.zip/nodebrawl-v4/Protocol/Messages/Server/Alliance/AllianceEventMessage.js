const PiranhaMessage = require('../../../PiranhaMessage')

/**
 * AllianceEventMessage (24333)
 *
 * Alliance action result shown by the client.
 * 10 settings changed, 20 created, 40 joined, 50 join request sent, 70 kicked someone, 80 left,
 * 81 promoted someone, 90 request accepted, 91 request rejected, 92 player already in alliance,
 * 100 you were kicked, 101 you were promoted.
 */
class AllianceEventMessage extends PiranhaMessage {
  constructor (session, event) {
    super(session)
    this.id = 24333
    this.version = 0
    this.event = event
  }

  async encode () {
    this.stream.writeVInt(this.event)
  }
}

module.exports = AllianceEventMessage
