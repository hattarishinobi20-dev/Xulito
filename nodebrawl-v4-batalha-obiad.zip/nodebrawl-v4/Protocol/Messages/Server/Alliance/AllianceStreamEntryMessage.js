const PiranhaMessage = require('../../../PiranhaMessage')
const AllianceEncoder = require('../../../../Logic/Alliance/AllianceEncoder')

/**
 * AllianceStreamEntryMessage (24312)
 *
 * One new stream entry pushed to alliance members. Layout from Obiad Brawl v4 AllianceChatServer.py.
 */
class AllianceStreamEntryMessage extends PiranhaMessage {
  /**
   * @param { Session } session Session
   * @param { Object } entry Stream entry
   */
  constructor (session, entry) {
    super(session)
    this.id = 24312
    this.version = 0
    this.entry = entry
  }

  async encode () {
    AllianceEncoder.encodeStreamEntry(this.stream, this.entry)
  }
}

module.exports = AllianceStreamEntryMessage
