const PiranhaMessage = require('../../../PiranhaMessage')
const AllianceDatabase = require('../../../../Database/AllianceDatabase')
const AllianceEncoder = require('../../../../Logic/Alliance/AllianceEncoder')

/**
 * AllianceStreamMessage (24311)
 *
 * Whole alliance chat / event stream. Layout from Obiad Brawl v4 ClanStream.py.
 */
class AllianceStreamMessage extends PiranhaMessage {
  constructor (session) {
    super(session)
    this.id = 24311
    this.version = 0
  }

  async encode () {
    const player = this.session.player
    const alliance = player.allianceId ? AllianceDatabase.get(player.allianceId) : null
    const entries = alliance ? alliance.stream : []

    this.stream.writeVInt(entries.length)

    for (const entry of entries) AllianceEncoder.encodeStreamEntry(this.stream, entry)
  }
}

module.exports = AllianceStreamMessage
