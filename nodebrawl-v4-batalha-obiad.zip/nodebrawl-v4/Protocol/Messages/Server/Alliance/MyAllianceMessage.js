const PiranhaMessage = require('../../../PiranhaMessage')
const AllianceDatabase = require('../../../../Database/AllianceDatabase')

/**
 * MyAllianceMessage (24399)
 *
 * Own alliance header (or "no alliance"). Layout from Obiad Brawl v4 MyAlliance.py.
 */
class MyAllianceMessage extends PiranhaMessage {
  constructor (session) {
    super(session)
    this.id = 24399
    this.version = 0
  }

  async encode () {
    const player = this.session.player
    const alliance = player.allianceId ? AllianceDatabase.get(player.allianceId) : null

    if (!alliance) {
      player.allianceId = 0
      player.allianceRole = 0

      this.stream.writeVInt(0)
      this.stream.writeBoolean(false)
      return
    }

    this.stream.writeVInt(AllianceDatabase.getOnlineMembersCount(alliance)) // Online members
    this.stream.writeBoolean(true)
    this.stream.writeVInt(25) // DataReference (25, role)
    this.stream.writeVInt(player.allianceRole)
    this.stream.writeLong(0, alliance.id)
    this.stream.writeString(alliance.name)
    this.stream.writeVInt(8) // DataReference (8, badge)
    this.stream.writeVInt(alliance.badge)
    this.stream.writeVInt(alliance.type)
    this.stream.writeVInt(alliance.members.length)
    this.stream.writeVInt(AllianceDatabase.getTrophies(alliance))
    this.stream.writeVInt(0) // DataReference (0) - null (low is only written when high != 0)
    this.stream.writeVInt(alliance.members.length)
  }
}

module.exports = MyAllianceMessage
