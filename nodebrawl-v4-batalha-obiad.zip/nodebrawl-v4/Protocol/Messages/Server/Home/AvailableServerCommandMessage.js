const PiranhaMessage = require('../../../PiranhaMessage')

class AvailableServerCommandMessage extends PiranhaMessage {
  /**
   * @param { Session } session User session
   * @param { LogicCommand } command Server command instance (Logic/Command/Server)
   */
  constructor (session, command) {
    super(session)
    this.id = 24111
    this.version = 0
    this.stream = this.DataStream.getByteStream()
    this.command = command
  }

  async encode () {
    this.stream.writeVInt(this.command.type)
    this.command.stream = this.stream
    await this.command.encode()
  }
}

module.exports = AvailableServerCommandMessage
