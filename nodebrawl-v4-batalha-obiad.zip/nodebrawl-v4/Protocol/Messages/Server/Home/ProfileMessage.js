const PiranhaMessage = require('../../../PiranhaMessage')
const AllianceDatabase = require('../../../../Database/AllianceDatabase')

class ProfileMessage extends PiranhaMessage {
  /**
   * Account to show. Set it before `send()`
   * @type { Object } Player account
   */
  account = null

  constructor (session) {
    super(session)
    this.id = 24113
    this.version = 0
    this.stream = this.DataStream.getByteStream()
  }

  /**
   * Power level of the brawler (sum of all cards levels, unlock card included)
   * @param { Object } brawler Brawler entry
   * @returns { Number } Power level
   */
  static getPowerLevel (brawler) {
    let powerLevel = 0

    for (const card in brawler.cards) {
      powerLevel += brawler.cards[card]
    }

    return powerLevel
  }

  async encode () {
    const account = this.account
    const brawlersIds = Object.keys(account.brawlers)

    this.stream.writeVInt(account.highId) // Player high id
    this.stream.writeVInt(account.lowId) // Player low id
    this.stream.writeString(account.name)
    this.stream.writeVInt(0)

    this.stream.writeVInt(brawlersIds.length)

    for (const id of brawlersIds) {
      const brawler = account.brawlers[id]

      this.stream.writeVInt(16) // DataReference (16, brawler)
      this.stream.writeVInt(Number(id))
      this.stream.writeVInt(0)
      this.stream.writeVInt(brawler.trophies) // Trophies
      this.stream.writeVInt(brawler.highestTrophies) // Trophies for rank
      this.stream.writeVInt(ProfileMessage.getPowerLevel(brawler) - 1) // Brawler upgrade level
    }

    this.stream.writeVInt(7) // Stats count
    this.stream.writeVInt(1) // Stats index
    this.stream.writeVInt(account.threeVsThreeWins) // Total victories
    this.stream.writeVInt(2)
    this.stream.writeVInt(account.experience) // Player experience points
    this.stream.writeVInt(3)
    this.stream.writeVInt(account.trophies) // Player trophies
    this.stream.writeVInt(4)
    this.stream.writeVInt(account.highestTrophies) // Highest trophies
    this.stream.writeVInt(5)
    this.stream.writeVInt(brawlersIds.length) // Unlocked brawlers
    this.stream.writeVInt(7)
    this.stream.writeVInt(28000000 + account.profileIcon) // Player profile icon
    this.stream.writeVInt(8)
    this.stream.writeVInt(account.soloWins) // Showdown victories

    const alliance = account.allianceId ? AllianceDatabase.get(account.allianceId) : null

    this.stream.writeBoolean(alliance !== null) // Joined in a band

    if (alliance) {
      this.stream.writeLong(0, alliance.id)
      this.stream.writeString(alliance.name)
      this.stream.writeVInt(8) // DataReference (8, badge)
      this.stream.writeVInt(alliance.badge)
      this.stream.writeVInt(alliance.type)
      this.stream.writeVInt(AllianceDatabase.getOnlineMembersCount(alliance))
      this.stream.writeVInt(alliance.members.length)
      this.stream.writeVInt(AllianceDatabase.getTrophies(alliance))
      this.stream.writeVInt(alliance.requiredTrophies)
      this.stream.writeVInt(0) // DataReference (0) - null (low is only written when high != 0)
      this.stream.writeVInt(25) // DataReference (25, role)
      this.stream.writeVInt(account.allianceRole)
    }
  }
}

module.exports = ProfileMessage
