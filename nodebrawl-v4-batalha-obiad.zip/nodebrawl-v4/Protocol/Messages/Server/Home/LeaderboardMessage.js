const PiranhaMessage = require('../../../PiranhaMessage')
const AllianceDatabase = require('../../../../Database/AllianceDatabase')
const Milestones = require('../../../../Logic/Home/Milestones')

class LeaderboardMessage extends PiranhaMessage {
  isLocal = 0
  leaderboardType = 1
  targetBrawler = [0, 0]
  /**
   * Sorted entries: { account, trophies }
   * @type { Array<Object> }
   */
  entries = []

  constructor (session) {
    super(session)
    this.id = 24403
    this.version = 0
    this.stream = this.DataStream.getByteStream()
  }

  /**
   * Experience level from experience points
   * @param { Number } experience Experience points
   * @returns { Number } Level
   */
  static getExperienceLevel (experience) {
    const required = Milestones.ProgressStartExp

    for (let i = 0; i < required.length - 1; i++) {
      if (required[i] <= experience && experience < required[i + 1]) return i + 1
    }

    return required.length
  }

  async encode () {
    const player = this.session.player
    let indexOfPlayer = 1

    this.stream.writeVInt(this.leaderboardType)

    if (this.leaderboardType === 0) {
      this.stream.writeVInt(16) // DataReference (16, brawler)
      this.stream.writeVInt(this.targetBrawler[1])
    } else {
      this.stream.writeVInt(0)
    }

    this.stream.writeString(this.isLocal ? player.region : null)

    this.stream.writeVInt(this.entries.length) // Entries count

    for (let i = 0; i < this.entries.length; i++) {
      const entry = this.entries[i]

      if (entry.alliance) {
        // alliance leaderboard entry
        const alliance = entry.alliance

        if (alliance.id === player.allianceId) indexOfPlayer = i + 1

        this.stream.writeVInt(0) // High id
        this.stream.writeVInt(alliance.id) // Low id
        this.stream.writeVInt(1)
        this.stream.writeVInt(entry.trophies) // Trophies

        this.stream.writeBoolean(false) // Is player
        this.stream.writeBoolean(true) // Is alliance
        this.stream.writeString(alliance.name)
        this.stream.writeVInt(alliance.members.length)
        this.stream.writeVInt(8) // DataReference (8, badge)
        this.stream.writeVInt(alliance.badge)
        continue
      }

      const account = entry.account
      const alliance = account.allianceId ? AllianceDatabase.get(account.allianceId) : null

      if (account.lowId === player.lowId) indexOfPlayer = i + 1

      this.stream.writeVInt(account.highId) // High id
      this.stream.writeVInt(account.lowId) // Low id
      this.stream.writeVInt(1)
      this.stream.writeVInt(entry.trophies) // Trophies

      this.stream.writeBoolean(true) // Is player
      this.stream.writeString(account.name)
      if (alliance) this.stream.writeString(alliance.name) // Alliance name
      else this.stream.writeInt(0) // Empty string
      this.stream.writeVInt(LeaderboardMessage.getExperienceLevel(account.experience))
      this.stream.writeVInt(28) // DataReference (28, thumbnail)
      this.stream.writeVInt(account.profileIcon)

      this.stream.writeBoolean(false) // Is alliance
    }

    this.stream.writeVInt(0)
    this.stream.writeVInt(indexOfPlayer)
    this.stream.writeVInt(0)
    this.stream.writeVInt(0) // Leaderboard region
    this.stream.writeString(player.region)
  }
}

module.exports = LeaderboardMessage
