const PiranhaMessage = require('../../../PiranhaMessage')
const LogicClientHome = require('../../../../Logic/Home/LogicClientHome')
const LogicClientAvatar = require('../../../../Logic/Home/LogicClientAvatar')

class OwnHomeDataMessage extends PiranhaMessage {
  constructor (session) {
    super(session)
    this.id = 24101
    this.version = 0
    this.stream = this.DataStream.getByteStream()
  }

  async encode () {
    LogicClientHome.encode(this.stream, this.session.player)
    LogicClientAvatar.encode(this.stream, this.session.player)
    this.stream.writeVInt(2017189) // Timestamp
  }
}

module.exports = OwnHomeDataMessage
