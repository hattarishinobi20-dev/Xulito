const PiranhaMessage = require('../../../PiranhaMessage')

class FriendListMessage extends PiranhaMessage {
  constructor (session) {
    super(session)
    this.id = 20105
    this.version = 0
    this.stream = this.DataStream.getByteStream()
  }

  async encode () {
    this.stream.writeInt(0) // Friends count
    this.stream.writeInt(0) // Friends count (again)
  }
}

module.exports = FriendListMessage
