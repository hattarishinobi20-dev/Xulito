const PiranhaMessage = require('../../../PiranhaMessage')

/**
 * TeamLeftMessage (24125)
 *
 * Reason: 0 you left the room, 1 you were kicked, 2 room discarded (day changed).
 */
class TeamLeftMessage extends PiranhaMessage {
  constructor (session, reason) {
    super(session)
    this.id = 24125
    this.version = 0
    this.reason = reason
  }

  async encode () {
    this.stream.writeInt(this.reason)
  }
}

module.exports = TeamLeftMessage
