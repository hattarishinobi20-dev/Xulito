const PiranhaMessage = require('../../../PiranhaMessage')
const AllianceEncoder = require('../../../../Logic/Alliance/AllianceEncoder')

/**
 * TeamStreamMessage (24131)
 *
 * Team chat / event stream (whole stream on login / create / join, single entry on new messages).
 * Layout from Obiad Brawl v4 TeamStreamMessage.py; entries use the alliance stream entry layout.
 */
class TeamStreamMessage extends PiranhaMessage {
  /**
   * @param { Session } session Session
   * @param { Object } team Team
   * @param { Array<Object> } entries Entries to send (default: whole stream)
   */
  constructor (session, team, entries) {
    super(session)
    this.id = 24131
    this.version = 0
    this.team = team
    this.entries = entries
  }

  async encode () {
    const entries = this.entries || (this.team ? this.team.stream : [])

    this.stream.writeVInt(0) // LogicLong (0, team id)
    this.stream.writeVInt(this.team ? this.team.id : 0)
    this.stream.writeVInt(entries.length)

    for (const entry of entries) AllianceEncoder.encodeStreamEntry(this.stream, entry)
  }
}

module.exports = TeamStreamMessage
