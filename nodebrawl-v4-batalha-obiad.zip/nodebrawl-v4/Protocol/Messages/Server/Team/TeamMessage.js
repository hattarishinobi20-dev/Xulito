const PiranhaMessage = require('../../../PiranhaMessage')

/**
 * TeamMessage (24124)
 *
 * Full game room state. Layout from Obiad Brawl v4 TeamMessage.py.
 */
class TeamMessage extends PiranhaMessage {
  /**
   * @param { Session } session Session
   * @param { Object } team Team
   */
  constructor (session, team) {
    super(session)
    this.id = 24124
    this.version = 0
    this.team = team
  }

  static getPowerLevel (player, brawlerId) {
    const brawler = player.brawlers[brawlerId]
    let powerLevel = 0

    if (brawler) for (const card in brawler.cards) powerLevel += brawler.cards[card]

    return powerLevel
  }

  async encode () {
    const team = this.team

    this.stream.writeVInt(team.roomType) // Game room type
    this.stream.writeBoolean(team.practice) // Practice with bots
    this.stream.writeVInt(3) // Game room maximum players
    this.stream.writeLong(0, team.id) // Team id (room code)
    this.stream.writeVInt(1)
    this.stream.writeVInt(0) // LogicLong (0, advertised alliance id)
    this.stream.writeVInt(team.advertisedAllianceId)
    this.stream.writeVInt(15) // DataReference (15, location)
    this.stream.writeVInt(team.locationId)

    this.stream.writeVInt(team.members.length)

    for (const member of team.members) {
      const player = member.session.player
      const brawler = player.brawlers[member.brawlerId] || { trophies: 0, highestTrophies: 0 }

      this.stream.writeLong(0, member.lowId) // Player id
      this.stream.writeString(player.name)
      this.stream.writeVInt(69) // Player experience level (unused)
      this.stream.writeVInt(16) // DataReference (16, brawler)
      this.stream.writeVInt(member.brawlerId)
      this.stream.writeVInt(0) // Skin (null data reference)
      this.stream.writeVInt(brawler.trophies) // Brawler trophies
      this.stream.writeVInt(brawler.highestTrophies) // Brawler trophies for rank
      this.stream.writeVInt(Math.max(TeamMessage.getPowerLevel(player, member.brawlerId) - 1, 0)) // Power level
      this.stream.writeVInt(member.status) // Player status
      this.stream.writeVInt(1)
      this.stream.writeBoolean(member.ready) // Ready state
      this.stream.writeVInt(member.side) // Player side
    }
  }
}

module.exports = TeamMessage
