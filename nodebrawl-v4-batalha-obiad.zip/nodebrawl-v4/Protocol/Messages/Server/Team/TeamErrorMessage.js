const PiranhaMessage = require('../../../PiranhaMessage')

/**
 * TeamErrorMessage (24129)
 *
 * Error id = TID_TEAM_ERROR_{id}: 1 server error, 2 room full, 3 room disbanded, 5 invalid code,
 * 6 room not found, 7 kicked before, 10 already in a room, 12 room expired, ...
 */
class TeamErrorMessage extends PiranhaMessage {
  constructor (session, error) {
    super(session)
    this.id = 24129
    this.version = 0
    this.error = error
  }

  async encode () {
    this.stream.writeVInt(this.error)
    this.stream.writeVInt(0)
  }
}

module.exports = TeamErrorMessage
