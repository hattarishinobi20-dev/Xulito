const PiranhaMessage = require('../../../PiranhaMessage')

/**
 * TeamGameStartingMessage (24130)
 */
class TeamGameStartingMessage extends PiranhaMessage {
  constructor (session, team) {
    super(session)
    this.id = 24130
    this.version = 0
    this.team = team
  }

  async encode () {
    this.stream.writeVInt(0)
    this.stream.writeVInt(0)
    this.stream.writeVInt(15) // DataReference (15, location)
    this.stream.writeVInt(this.team ? this.team.locationId : 0)
  }
}

module.exports = TeamGameStartingMessage
