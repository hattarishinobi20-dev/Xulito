const PiranhaMessage = require('../../../PiranhaMessage')
const LOGIN_FAILED_REASON = require('../../../../Titan/Enums/LoginFailedReason')

/**
 * LoginFailedV4Message (20103)
 *
 * LoginFailed with the v4 layout used by Obiad Brawl v4 (LoginFailedMessage.py).
 * The core LoginFailedMessage (shorter layout) is still used by ClientHelloMessage before the crypto is set.
 *
 * Error codes: 1 custom, 7 patch (content update), 8 update, 9 redirect, 10 maintenance, 11 banned.
 */
class LoginFailedV4Message extends PiranhaMessage {
  /**
   * @param { Session } session Session
   * @param { Number } errorCode Error code
   * @param { String } reason Text shown by the client (custom / banned)
   */
  constructor (session, errorCode = LOGIN_FAILED_REASON.CUSTOM, reason = "") {
    super(session)
    this.id = 20103
    this.version = 0
    this.errorCode = errorCode
    this.reason = reason
    this.fingerprint = ""
    this.contentUrl = ""
    this.updateUrl = "https://github.com/tailsjs/nodebrawl-core"
    this.maintenanceTime = 0
  }

  async encode () {
    this.stream.writeInt(this.errorCode)
    this.stream.writeString(this.fingerprint || null) // Fingerprint json (content update)
    this.stream.writeString(null) // Server host
    this.stream.writeString(this.contentUrl || null) // Content url
    this.stream.writeString(this.updateUrl || null) // Update url
    this.stream.writeString(this.reason || null) // Reason / message
    this.stream.writeInt(this.maintenanceTime) // Maintenance time
    this.stream.writeBoolean(false) // Show support page
    this.stream.writeString(null)
    this.stream.writeString(null)
    this.stream.writeInt(0)
    this.stream.writeInt(3)
    this.stream.writeString(null)
    this.stream.writeString(null)
    this.stream.writeInt(0)
    this.stream.writeInt(0)
    this.stream.writeBoolean(false)
    this.stream.writeBoolean(false)
  }
}

module.exports = LoginFailedV4Message
