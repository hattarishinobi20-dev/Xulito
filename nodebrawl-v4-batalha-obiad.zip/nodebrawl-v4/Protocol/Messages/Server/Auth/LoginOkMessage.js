const PiranhaMessage = require('../../../PiranhaMessage')

class LoginOkMessage extends PiranhaMessage {
  constructor (session) {
    super(session)
    this.id = 20104
    this.version = 1
    this.stream = this.DataStream.getByteStream()
  }

  async encode () {
    const player = this.session.player
    const login = this.session.loginData

    this.stream.writeLong(player.highId, player.lowId) // Account id
    this.stream.writeLong(player.highId, player.lowId) // Home id

    this.stream.writeString(player.token)
    this.stream.writeString("467606826913688") // Facebook id
    this.stream.writeString("G:325378671") // Gamecenter id

    this.stream.writeInt(login.major)
    this.stream.writeInt(login.minor)
    this.stream.writeInt(login.build)

    this.stream.writeString("-dev") // Server environment

    this.stream.writeInt(0) // Session count
    this.stream.writeInt(0) // Play time seconds
    this.stream.writeInt(0) // Days since started playing

    this.stream.writeString() // Facebook app id
    this.stream.writeString() // Server time
    this.stream.writeString() // Account created date

    this.stream.writeInt(0) // Startup cooldown seconds

    this.stream.writeString() // Google service id
    this.stream.writeString(player.region) // Region
    this.stream.writeString() // Content url

    this.stream.writeInt(1) // Event asset count

    this.stream.writeString() // Content url
    this.stream.writeString()
    this.stream.writeString()
  }
}

module.exports = LoginOkMessage
