const PiranhaMessage = require('../../../PiranhaMessage')
const BitStream = require('../../../../Logic/Battle/BitStream')

/**
 * VisionUpdateMessage (24109)
 *
 * Battle state sent every tick (and after every ClientInputMessage).
 */
class VisionUpdateMessage extends PiranhaMessage {
  /**
   * @param { Session } session Session
   * @param { LogicBattle } battle Battle
   * @param { Number } ownIndex Hero index (1-based) of the receiving player
   */
  constructor (session, battle, ownIndex = 1) {
    super(session)
    this.id = 24109
    this.version = 0
    this.battle = battle
    this.ownIndex = ownIndex
  }

  async encode () {
    this.stream.writeVInt(this.battle.ticks) // Battle ticks
    this.stream.writeVInt(0)
    this.stream.writeVInt(1) // Commands count

    const bitStream = new BitStream()

    this.battle.encode(bitStream, this.ownIndex)

    const bytes = bitStream.buffer

    this.stream.writeInt(bytes.length)
    this.stream.writeBytesWithoutLength(bytes)
  }
}

module.exports = VisionUpdateMessage
