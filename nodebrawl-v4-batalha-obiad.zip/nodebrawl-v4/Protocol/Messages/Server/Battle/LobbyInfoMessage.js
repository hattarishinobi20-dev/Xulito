const PiranhaMessage = require('../../../PiranhaMessage')

/**
 * LobbyInfoMessage (23457)
 *
 * Players online counter shown in the home screen.
 */
class LobbyInfoMessage extends PiranhaMessage {
  constructor (session) {
    super(session)
    this.id = 23457
    this.version = 0
  }

  async encode () {
    this.stream.writeVInt(global.sessions ? global.sessions.size : 1) // Players online
    this.stream.writeVInt(0) // Lobby info entries count
  }
}

module.exports = LobbyInfoMessage
