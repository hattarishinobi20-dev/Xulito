const PiranhaMessage = require('../../../PiranhaMessage')

/**
 * StartLoadingMessage (20559)
 *
 * Battle loading screen: players list, brawlers and location. Layout from Obiad Brawl v4.
 */
class StartLoadingMessage extends PiranhaMessage {
  /**
   * @param { Session } session Session
   * @param { LogicBattle } battle Battle
   */
  constructor (session, battle) {
    super(session)
    this.id = 20559
    this.version = 0
    this.battle = battle
  }

  async encode () {
    const battle = this.battle

    this.stream.writeInt(6) // Game mode total players
    this.stream.writeInt(0)
    this.stream.writeInt(0)

    // Logic player array
    this.stream.writeInt(6) // Players count

    for (let index = 0; index < 6; index++) {
      const human = battle.humans.find(h => h.heroIndex === index + 1)

      if (human) {
        this.stream.writeLong(human.player.highId, human.player.lowId)
        this.stream.writeString(human.player.name)
      } else {
        this.stream.writeLong(0, StartLoadingMessage.randomBotId()) // bot id
        this.stream.writeString("Bot")
      }

      this.stream.writeVInt(index) // Player index
      this.stream.writeVInt(index >= 3 ? 1 : 0) // Team (0 own team, 1 enemies)
      this.stream.writeVInt(0)
      this.stream.writeVInt(0)
      this.stream.writeInt(0)
      this.stream.writeVInt(16) // DataReference (16, brawler)
      this.stream.writeVInt(battle.brawlers[index])
      this.stream.writeVInt(0) // Skin (null data reference)
      this.stream.writeInt(0) // Array
    }

    this.stream.writeInt(0) // Array
    this.stream.writeVInt(1)
    this.stream.writeVInt(1) // Draw map
    this.stream.writeVInt(2) // Control mode
    this.stream.writeBoolean(false) // Is spectating

    this.stream.writeVInt(15) // DataReference (15, location)
    this.stream.writeVInt(battle.locationId)
    this.stream.writeBoolean(false)
  }

  static randomBotId () {
    return 30 + Math.floor(Math.random() * 271)
  }
}

module.exports = StartLoadingMessage
