const PiranhaMessage = require('../../../PiranhaMessage')
const Milestones = require('../../../../Logic/Home/Milestones')
const GameConfig = require('../../../../Logic/Server/GameConfig')
const PlayerDatabase = require('../../../../Database/PlayerDatabase')
const V4DataTables = require('../../../../Logic/Data/V4DataTables')

/**
 * BattleEndMessage (23456)
 *
 * Battle result screen + rewards (trophies, coins, experience).
 * Layout and reward tables from Obiad Brawl v4 (BattleEndTrio / BattleEndSD).
 *
 * result = {
 *   battleEndType: Number,   // 3v3: 0 victory, 1 defeat, 2 draw. Showdown: 5
 *   battleRank: Number,      // showdown rank (1-10), 0 for 3v3
 *   isShowdown: Boolean,
 *   isInRealGame: Boolean,   // false = forced end, no rewards
 *   players: [{ characterId, skinClassId, skinId, team, isPlayer, name, powerLevel }]  // first entry is the own player
 * }
 */
class BattleEndMessage extends PiranhaMessage {
  static SHOWDOWN_TROPHIES = [
    [0, 29, [8, 7, 6, 5, 5, 4, 3, 2, 1, 0]],
    [30, 59, [8, 7, 6, 4, 3, 2, 0, -1, -2, -4]],
    [60, 99, [8, 7, 5, 4, 3, 1, 0, -2, -3, -4]],
    [100, 139, [7, 6, 5, 3, 2, 1, -1, -2, -3, -4]],
    [140, 219, [7, 6, 4, 3, 2, 0, -1, -3, -4, -5]],
    [220, 299, [7, 6, 4, 3, 1, 0, -2, -3, -5, -6]],
    [300, 419, [7, 6, 4, 2, 1, -1, -2, -4, -6, -7]],
    [420, 499, [5, 4, 3, 1, 0, -2, -3, -4, -6, -7]],
    [500, 599, [5, 3, 2, 1, -1, -2, -3, -4, -6, -7]],
    [600, 699, [4, 3, 1, 0, -1, -1, -3, -5, -6, -7]],
    [700, 799, [4, 2, 1, -1, -2, -3, -4, -5, -6, -8]],
    [800, 899, [3, 2, 0, -1, -2, -3, -4, -5, -7, -8]],
    [900, Infinity, [3, 1, -1, -2, -3, -4, -5, -6, -7, -8]]
  ]

  static SHOWDOWN_COINS = [34, 28, 22, 16, 12, 8, 6, 4, 2, 1, 1] // index = rank
  static SHOWDOWN_EXP = [15, 12, 9, 6, 5, 4, 2, 1, 0, 0, 0] // index = rank

  static TRIO_TROPHIES = [
    [0, 29, [6, 0, 0]],
    [30, 59, [6, -1, 0]],
    [60, 99, [6, -2, 0]],
    [100, 139, [5, -2, 0]],
    [140, 219, [5, -3, 0]],
    [220, 299, [5, -4, 0]],
    [300, 499, [5, -5, 0]],
    [500, 599, [4, -6, 0]],
    [600, 699, [3, -6, 0]],
    [700, 799, [3, -7, 0]],
    [800, 899, [2, -7, 0]],
    [900, Infinity, [2, -8, 0]]
  ]

  static TRIO_COINS = [20, 15, 10] // index = battleEndType (win, lose, draw)
  static TRIO_EXP = [10, 5, 0]

  /**
   * @param { Session } session Session
   * @param { Object } result Battle result (see class doc)
   */
  constructor (session, result) {
    super(session)
    this.id = 23456
    this.version = 0
    this.result = result
  }

  /**
   * Build a "forced end" result from a running battle (no rewards)
   * @param { LogicBattle } battle Battle
   * @param { Session } session Session receiving the message (own player is written first)
   * @returns { Object } Result
   */
  static fromBattle (battle, session) {
    const players = []
    const own = battle.getHuman(session) || battle.humans[0] || { heroIndex: 1, player: session.player, brawlerId: battle.brawlers[0] }

    for (let i = 0; i < battle.brawlers.length; i++) {
      const human = battle.humans.find(h => h.heroIndex === i + 1) || (own.heroIndex === i + 1 ? own : null)

      players.push({
        characterId: battle.brawlers[i],
        skinClassId: 0,
        skinId: 0,
        team: battle.getTeam(i + 1) + 1,
        isPlayer: human !== null,
        name: human ? human.player.name : `Bot ${i + 1}`,
        powerLevel: human ? BattleEndMessage.getPowerLevel(human.player, battle.brawlers[i]) : 0
      })
    }

    // own player first (BattleEndMessage.encode uses players[0] as the own hero)
    if (own.heroIndex > 1) players.unshift(players.splice(own.heroIndex - 1, 1)[0])

    return {
      battleEndType: battle.brawlers.length === 6 ? 1 : 5,
      battleRank: 0,
      isShowdown: false,
      isInRealGame: false,
      players
    }
  }

  /**
   * Power level of a brawler like Obiad Brawl v4: sum of the owned cards, the unlock card is not counted
   * @param { Object } player Player
   * @param { Number } brawlerId Character index
   * @returns { Number } Power level
   */
  static getPowerLevel (player, brawlerId) {
    const brawler = player.brawlers[brawlerId]
    let powerLevel = 0

    if (!brawler) return 0

    for (const card in brawler.cards) {
      const cardData = V4DataTables.getCard(Number(card))

      if (cardData && cardData.type === "unlock") continue

      powerLevel += brawler.cards[card]
    }

    return powerLevel
  }

  static getTrophiesFromTable (table, trophies, index) {
    for (const [low, high, values] of table) {
      if (trophies >= low && trophies <= high) return values[index] || 0
    }

    return 0
  }

  /**
   * Level index of the value in a milestone table
   * @param { Array<Number> } table Progress start table
   * @param { Number } value Value
   * @returns { Number } Level index
   */
  static getLevelIndex (table, value) {
    let level = 0

    for (let i = 0; i < table.length; i++) {
      if (value >= table[i]) level = i
    }

    return level
  }

  /**
   * Trophy thresholds for the brawler ranks (extended like Obiad for ranks >= 35)
   * @returns { Array<Number> } Thresholds
   */
  static getTrophiesTable () {
    const table = [...Milestones.ProgressStartTrophies]

    for (let index = 34; index < GameConfig.maximumRank; index++) table.push(table[33] + 50 * (index - 33))

    return table
  }

  async encode () {
    const player = this.session.player
    const result = this.result
    const own = result.players[0]
    const brawler = player.brawlers[own.characterId] || { trophies: 0, highestTrophies: 0 }
    const rewardsEnabled = result.isInRealGame && player.tutorialState >= 2

    let trophies = 0
    let coins = 0
    let exp = 0
    let starPlayerExp = 0
    let doubledCoins = 0
    let boostedCoins = 0

    if (rewardsEnabled) {
      if (result.isShowdown) {
        const rank = Math.min(Math.max(result.battleRank, 1), 10)

        trophies = BattleEndMessage.getTrophiesFromTable(BattleEndMessage.SHOWDOWN_TROPHIES, brawler.trophies, rank - 1)
        coins = BattleEndMessage.SHOWDOWN_COINS[rank]
        exp = BattleEndMessage.SHOWDOWN_EXP[rank]
      } else {
        const type = Math.min(Math.max(result.battleEndType, 0), 2)

        trophies = BattleEndMessage.getTrophiesFromTable(BattleEndMessage.TRIO_TROPHIES, brawler.trophies, type)
        coins = BattleEndMessage.TRIO_COINS[type]
        exp = BattleEndMessage.TRIO_EXP[type]
      }

      starPlayerExp = GameConfig.starPlayerExp

      // coins doubler
      doubledCoins = Math.min(coins, player.coinsDoubler)

      if (coins > player.coinsDoubler && player.coinsDoubler > 0) {
        if (!player.homeNotifications.some(n => n.id === 97 && n.type === 2)) {
          player.homeNotifications.push({ id: 97, type: 2, seen: false })
        }
      }

      player.coinsDoubler -= doubledCoins

      // coins booster
      if (player.coinsBooster - Math.floor(Date.now() / 1000) > 0) boostedCoins = coins
    }

    // Rank up / level up bonuses
    const trophiesTable = BattleEndMessage.getTrophiesTable()
    const rankBefore = BattleEndMessage.getLevelIndex(trophiesTable, brawler.trophies)
    const rankAfter = BattleEndMessage.getLevelIndex(trophiesTable, brawler.trophies + trophies)
    const rankUps = rewardsEnabled && rankAfter > rankBefore && brawler.trophies + trophies > brawler.highestTrophies ? 1 : 0

    const levelBefore = BattleEndMessage.getLevelIndex(Milestones.ProgressStartExp, player.experience)
    const levelAfter = BattleEndMessage.getLevelIndex(Milestones.ProgressStartExp, player.experience + exp + starPlayerExp)
    const levelUps = rewardsEnabled && levelAfter > levelBefore ? 1 : 0

    const bonusCoins = rankUps * 10 + levelUps * 20 // added to the gold only (like Obiad)

    this.stream.writeVInt(result.isShowdown ? 5 : 1) // Battle end game mode (5 = showdown, else 3v3)
    this.stream.writeVInt(0) // Related to coins gained. 1+ = "All coins collected"
    this.stream.writeVInt(coins) // Coins gained
    this.stream.writeVInt(6969) // Coins left ("All coins collected" if 0)
    this.stream.writeVInt(0) // First win coins gained
    this.stream.writeBoolean(false) // "All event experience collected" if true
    this.stream.writeVInt(result.isShowdown ? result.battleRank : result.battleEndType) // Result (victory/defeat/draw/rank)
    this.stream.writeVInt(trophies) // Trophies result
    this.stream.writeVInt(28) // DataReference (28, profile icon)
    this.stream.writeVInt(player.profileIcon)
    this.stream.writeBoolean(player.tutorialState < 2) // Is tutorial game
    this.stream.writeBoolean(result.isInRealGame) // Is in real game
    this.stream.writeVInt(50) // Coins booster %
    this.stream.writeVInt(boostedCoins) // Coins booster coins gained
    this.stream.writeVInt(doubledCoins) // Coins doubler coins gained

    // Players array
    this.stream.writeVInt(result.players.length)

    for (const entry of result.players) {
      this.stream.writeString(entry.name)
      this.stream.writeBoolean(entry.isPlayer)
      this.stream.writeBoolean(entry.team !== own.team) // Is enemy
      this.stream.writeBoolean(entry.isPlayer) // Is star player
      this.stream.writeVInt(16) // DataReference (16, brawler)
      this.stream.writeVInt(entry.characterId)
      this.stream.writeVInt(entry.skinClassId) // Skin data reference
      if (entry.skinClassId !== 0) this.stream.writeVInt(entry.skinId)
      this.stream.writeVInt(0) // Brawler trophies
      this.stream.writeVInt(entry.powerLevel - 1) // Brawler power level (-1 for bots)
    }

    // Experience array
    this.stream.writeVInt(2)
    this.stream.writeVInt(0) // Normal experience id
    this.stream.writeVInt(exp)
    this.stream.writeVInt(8) // Star player experience id
    this.stream.writeVInt(starPlayerExp)

    // Rank up and level up bonus array
    this.stream.writeVInt(levelUps + rankUps)

    for (let i = 0; i < levelUps; i++) {
      this.stream.writeVInt(5)
      this.stream.writeVInt(0)
      this.stream.writeVInt(0)
      this.stream.writeVInt(0)
      this.stream.writeVInt(0)
      this.stream.writeVInt(1)
      this.stream.writeVInt(12)
      this.stream.writeVInt(20)
      this.stream.writeVInt(5) // DataReference (5, 1) - resource
      this.stream.writeVInt(1)
    }

    for (let i = 0; i < rankUps; i++) {
      this.stream.writeVInt(1)
      this.stream.writeVInt(0)
      this.stream.writeVInt(0) // Progress start
      this.stream.writeVInt(0) // Progress
      this.stream.writeVInt(0)
      this.stream.writeVInt(1)
      this.stream.writeVInt(1)
      this.stream.writeVInt(10)
      this.stream.writeVInt(5)
      this.stream.writeVInt(1)
    }

    // Trophies and experience bars array
    this.stream.writeVInt(2)
    this.stream.writeVInt(1) // Trophies bar milestone id
    this.stream.writeVInt(brawler.trophies) // Brawler trophies
    this.stream.writeVInt(brawler.highestTrophies) // Brawler trophies for rank
    this.stream.writeVInt(5) // Experience bar milestone id
    this.stream.writeVInt(player.experience) // Player experience
    this.stream.writeVInt(player.experience) // Player experience for level

    // Milestones array
    this.stream.writeBoolean(true)
    Milestones.encode(this.stream, GameConfig.maximumRank)

    // Apply rewards
    if (rewardsEnabled) {
      const totalCoins = coins + bonusCoins + boostedCoins + doubledCoins

      player.trophies = Math.max(player.trophies + trophies, 0)
      brawler.trophies = Math.max(brawler.trophies + trophies, 0)
      if (brawler.trophies > brawler.highestTrophies) brawler.highestTrophies = brawler.trophies
      if (player.trophies > player.highestTrophies) player.highestTrophies = player.trophies
      player.experience += exp + starPlayerExp
      player.gold += totalCoins
      player.coinsReward = totalCoins

      if (result.isShowdown) {
        if (result.battleRank === 1) player.soloWins++
      } else if (result.battleEndType === 0) {
        player.threeVsThreeWins++
      }

      PlayerDatabase.save(player)
    }

    this.session.log(`Battle end: ${result.isShowdown ? "rank " + result.battleRank : "type " + result.battleEndType}, ${trophies} trophies, ${coins + bonusCoins + boostedCoins + doubledCoins} coins, ${exp + starPlayerExp} exp.`)
  }
}

module.exports = BattleEndMessage
