const PiranhaMessage = require('../../../PiranhaMessage')
const LogicBattleManager = require('../../../../Logic/Battle/LogicBattleManager')

/**
 * MatchMakingStatusMessage (20405)
 *
 * Matchmaking screen state. Layout from Obiad Brawl v4.
 */
class MatchMakingStatusMessage extends PiranhaMessage {
  /**
   * @param { Session } session Session
   * @param { Boolean } matchmakeState true = searching, false = cancelled
   */
  constructor (session, matchmakeState) {
    super(session)
    this.id = 20405
    this.version = 0
    this.matchmakeState = matchmakeState
  }

  async encode () {
    const data = LogicBattleManager.getMatchmaking(this.session) || { displayTime: 20, players: [this.session.player], maximumPlayers: 2 }

    this.stream.writeInt(data.displayTime) // Matchmake timer
    this.stream.writeInt(data.players.length) // Current players in matchmake

    for (const player of data.players) {
      this.stream.writeString(player.name)
      this.stream.writeBoolean(this.matchmakeState)
      this.stream.writeLong(0, player.lowId)
    }

    this.stream.writeInt(data.maximumPlayers) // Maximum players in matchmake
  }
}

module.exports = MatchMakingStatusMessage
