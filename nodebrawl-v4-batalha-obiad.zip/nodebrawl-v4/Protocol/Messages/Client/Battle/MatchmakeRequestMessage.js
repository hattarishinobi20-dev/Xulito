const PiranhaMessage = require('../../../PiranhaMessage')
const MatchMakingStatusMessage = require('../../Server/Battle/MatchMakingStatusMessage')
const StartLoadingMessage = require('../../Server/Battle/StartLoadingMessage')
const LogicBattleManager = require('../../../../Logic/Battle/LogicBattleManager')
const Events = require('../../../../Logic/Home/Events')

/**
 * MatchmakeRequestMessage (14103)
 *
 * Client asks for a battle. Since battles are vs bots, the battle starts instantly:
 * MatchMakingStatus -> StartLoading -> VisionUpdate loop.
 */
class MatchmakeRequestMessage extends PiranhaMessage {
  constructor (bytes, session) {
    super(session)
    this.id = 14103
    this.version = 0
    this.stream = this.DataStream.getByteStream(bytes)
  }

  async decode () {
    this.stream.readVInt()
    this.cardClassId = this.stream.readVInt() // Selected card / brawler (16, id)
    this.brawlerId = this.cardClassId !== 0 ? this.stream.readVInt() : 0
    this.eventSlot = this.stream.readVInt() // Event slot (1-based)
    this.stream.readVInt() // Event index
    this.stream.readVInt() // Highstakes index
    this.stream.readVInt()
  }

  async execute () {
    if (!this.session.player) return

    const player = this.session.player

    if (!player.brawlers[this.brawlerId]) {
      this.session.warn(`Matchmake: player does not own brawler ${this.brawlerId}, using first owned brawler.`)
      this.brawlerId = Number(Object.keys(player.brawlers)[0])
    }

    const events = Events.getActiveEvents()
    const event = events[this.eventSlot - 1] || events[0]
    const locationId = event ? event.locationId : 0

    LogicBattleManager.createMatchmaking(this.session, 2)

    await new MatchMakingStatusMessage(this.session, true).send()

    const battle = LogicBattleManager.createBattle(this.session, this.brawlerId, locationId, this.eventSlot)

    this.session.log(`Battle ${battle.id}: brawler ${this.brawlerId}, event slot ${this.eventSlot}, location ${battle.locationId} (${battle.gameMode}), ${battle.getBattleTicks()} ticks.`)

    await new StartLoadingMessage(this.session, battle).send()

    battle.start()
  }
}

module.exports = MatchmakeRequestMessage
