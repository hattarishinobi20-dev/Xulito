const PiranhaMessage = require('../../../PiranhaMessage')
const LogicBattleManager = require('../../../../Logic/Battle/LogicBattleManager')

/**
 * ClientInputMessage (10555)
 *
 * Battle input: movement, aiming and skills. Every input is followed by a VisionUpdateMessage.
 */
class ClientInputMessage extends PiranhaMessage {
  constructor (bytes, session) {
    super(session)
    this.id = 10555
    this.version = 0
    this.stream = this.DataStream.getByteStream(bytes)
    this.inputs = []
  }

  async decode () {
    this.stream.readVInt()
    this.stream.readVInt()

    const count = this.stream.readVInt()

    for (let i = 0; i < count && i < 64; i++) {
      this.stream.readVInt() // index
      this.stream.readVInt() // index
      const type = this.stream.readVInt() // 100 move, 107/108 ulti aim on/off, < 100 skill
      const x = this.stream.readVInt()
      const y = this.stream.readVInt()

      this.inputs.push({ type, x, y })
    }
  }

  async execute () {
    const battle = LogicBattleManager.getBattle(this.session)

    if (!battle) return

    for (const input of this.inputs) battle.handleInput(this.session, input.type, input.x, input.y)

    await battle.sendVision(this.session)
  }
}

module.exports = ClientInputMessage
