const PiranhaMessage = require('../../../PiranhaMessage')
const BattleEndMessage = require('../../Server/Battle/BattleEndMessage')
const LogicBattleManager = require('../../../../Logic/Battle/LogicBattleManager')
const V4DataTables = require('../../../../Logic/Data/V4DataTables')
const Events = require('../../../../Logic/Home/Events')

/**
 * AskForBattleEndMessage (14110)
 *
 * Sent by the client when the battle is over; contains the result and all battle players.
 */
class AskForBattleEndMessage extends PiranhaMessage {
  constructor (bytes, session) {
    super(session)
    this.id = 14110
    this.version = 0
    this.stream = this.DataStream.getByteStream(bytes)
  }

  async decode () {
    this.battleEndType = this.stream.readVInt() // battle result
    this.battleTime = this.stream.readVInt()
    this.battleRank = this.stream.readVInt() // 0 for 3v3 (won/lose/draw is battleEndType), rank for showdown
    this.eventIndex = this.stream.readVInt()
    this.eventSlot = this.stream.readVInt() // event slot (1-based)

    const count = this.stream.readVInt()

    this.players = []

    for (let i = 0; i < count && i < 12; i++) {
      // HeroDataEntry::decode
      const characterClassId = this.stream.readVInt()
      const characterId = characterClassId !== 0 ? this.stream.readVInt() : 0
      const skinClassId = this.stream.readVInt()
      const skinId = skinClassId !== 0 ? this.stream.readVInt() : 0
      const team = this.stream.readVInt()
      this.stream.bitOffset = 0
      const isPlayer = this.stream.readBoolean()
      const name = this.stream.readString()

      this.players.push({ characterId, skinClassId, skinId, team, isPlayer, name, powerLevel: 0 })
    }
  }

  async execute () {
    if (!this.session.player || this.players.length === 0) return

    const player = this.session.player
    const battle = LogicBattleManager.getBattle(this.session)

    // power level of the own brawler (unlock card not counted, like Obiad)
    this.players[0].powerLevel = BattleEndMessage.getPowerLevel(player, this.players[0].characterId)

    const events = Events.getActiveEvents()
    const event = events[this.eventSlot - 1]
    const gameMode = V4DataTables.getLocationGameMode(event ? event.locationId : (battle ? battle.locationId : 0))

    const result = {
      battleEndType: this.battleEndType,
      battleRank: this.battleRank,
      isShowdown: gameMode === "BossFight" || this.battleRank !== 0,
      players: this.players,
      isInRealGame: true
    }

    LogicBattleManager.endBattle(this.session, false)

    await new BattleEndMessage(this.session, result).send()
  }
}

module.exports = AskForBattleEndMessage
