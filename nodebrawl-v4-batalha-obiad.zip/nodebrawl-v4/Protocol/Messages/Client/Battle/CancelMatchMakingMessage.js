const PiranhaMessage = require('../../../PiranhaMessage')
const MatchMakingStatusMessage = require('../../Server/Battle/MatchMakingStatusMessage')
const LogicBattleManager = require('../../../../Logic/Battle/LogicBattleManager')

/**
 * CancelMatchMakingMessage (14106)
 */
class CancelMatchMakingMessage extends PiranhaMessage {
  constructor (bytes, session) {
    super(session)
    this.id = 14106
    this.version = 0
    this.stream = this.DataStream.getByteStream(bytes)
  }

  async decode () {

  }

  async execute () {
    if (!this.session.player) return

    if (!LogicBattleManager.getMatchmaking(this.session)) LogicBattleManager.createMatchmaking(this.session, 2)

    await new MatchMakingStatusMessage(this.session, false).send()

    LogicBattleManager.endBattle(this.session, false)
  }
}

module.exports = CancelMatchMakingMessage
