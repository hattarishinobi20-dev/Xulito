const PiranhaMessage = require('../../../PiranhaMessage')
const ProfileMessage = require('../../Server/Home/ProfileMessage')
const PlayerDatabase = require('../../../../Database/PlayerDatabase')

class AskProfileMessage extends PiranhaMessage {
  constructor (bytes, session) {
    super(session)
    this.id = 14113
    this.version = 0
    this.stream = this.DataStream.getByteStream(bytes)
  }

  async decode () {
    this.highId = this.stream.readInt()
    this.lowId = this.stream.readInt()
  }

  async execute () {
    if (!this.session.player) return

    const account = this.lowId === this.session.player.lowId ? this.session.player : PlayerDatabase.loadAccountByLowId(this.lowId)

    if (!account) return this.session.warn(`Profile of player ${this.lowId} not found`)

    const Profile = new ProfileMessage(this.session)
    Profile.account = account

    await Profile.send()
  }
}

module.exports = AskProfileMessage
