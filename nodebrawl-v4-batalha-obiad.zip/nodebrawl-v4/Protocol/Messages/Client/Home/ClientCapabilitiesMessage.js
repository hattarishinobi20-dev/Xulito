const PiranhaMessage = require('../../../PiranhaMessage')

class ClientCapabilitiesMessage extends PiranhaMessage {
  constructor (bytes, session) {
    super(session)
    this.id = 10107
    this.version = 0
    this.stream = this.DataStream.getByteStream(bytes)
  }

  async decode () {
    this.ping = this.stream.readVInt()
  }

  async execute () {
    this.session.log(`Client latency: ${this.ping}ms`)
  }
}

module.exports = ClientCapabilitiesMessage
