const PiranhaMessage = require('../../../PiranhaMessage')
const LogicChangeAvatarNameCommand = require('../../../../Logic/Command/Server/LogicChangeAvatarNameCommand')
const AvailableServerCommandMessage = require('../../Server/Home/AvailableServerCommandMessage')
const PlayerDatabase = require('../../../../Database/PlayerDatabase')

class ChangeAvatarNameMessage extends PiranhaMessage {
  constructor (bytes, session) {
    super(session)
    this.id = 10212
    this.version = 0
    this.stream = this.DataStream.getByteStream(bytes)
  }

  async decode () {
    this.name = this.stream.readString()
  }

  async execute () {
    if (!this.session.player) return

    const name = this.name.trim().slice(0, 15)

    if (name.length === 0) return this.session.warn("Empty name received")

    this.session.player.name = name
    PlayerDatabase.save(this.session.player)

    await new AvailableServerCommandMessage(this.session, new LogicChangeAvatarNameCommand(this.session)).send()
  }
}

module.exports = ChangeAvatarNameMessage
