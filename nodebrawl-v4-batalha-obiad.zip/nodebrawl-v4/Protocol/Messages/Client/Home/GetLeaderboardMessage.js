const PiranhaMessage = require('../../../PiranhaMessage')
const AllianceDatabase = require('../../../../Database/AllianceDatabase')
const LeaderboardMessage = require('../../Server/Home/LeaderboardMessage')
const PlayerDatabase = require('../../../../Database/PlayerDatabase')

class GetLeaderboardMessage extends PiranhaMessage {
  constructor (bytes, session) {
    super(session)
    this.id = 14403
    this.version = 0
    this.stream = this.DataStream.getByteStream(bytes)
  }

  async decode () {
    this.isLocal = this.stream.readVInt()
    this.leaderboardType = this.stream.readVInt() // 0 - brawler, 1 - players, 2 - alliances
    const classId = this.stream.readVInt()
    this.targetBrawler = [ classId, classId === 0 ? 0 : this.stream.readVInt() ]
  }

  async execute () {
    if (!this.session.player) return

    const player = this.session.player
    let accounts = PlayerDatabase.getAllAccounts().map(account => account.lowId === player.lowId ? player : account)
    let entries = []

    if (this.isLocal) accounts = accounts.filter(account => account.region === player.region)

    switch (this.leaderboardType) {
      case 0: {
        const brawlerId = this.targetBrawler[1]

        entries = accounts
          .filter(account => account.brawlers[brawlerId] && account.brawlers[brawlerId].trophies > 0)
          .map(account => ({ account, trophies: account.brawlers[brawlerId].trophies }))
        break
      }
      case 1:
        entries = accounts.map(account => ({ account, trophies: account.trophies }))
        break
      case 2: {
        let alliances = AllianceDatabase.getAll()

        if (this.isLocal) alliances = alliances.filter(alliance => alliance.region === player.region)

        entries = alliances.map(alliance => ({ alliance, trophies: AllianceDatabase.getTrophies(alliance) }))
        break
      }
    }

    entries.sort((a, b) => b.trophies - a.trophies)

    const Leaderboard = new LeaderboardMessage(this.session)
    Leaderboard.isLocal = this.isLocal
    Leaderboard.leaderboardType = this.leaderboardType
    Leaderboard.targetBrawler = this.targetBrawler
    Leaderboard.entries = entries.slice(0, 200)

    await Leaderboard.send()
  }
}

module.exports = GetLeaderboardMessage
