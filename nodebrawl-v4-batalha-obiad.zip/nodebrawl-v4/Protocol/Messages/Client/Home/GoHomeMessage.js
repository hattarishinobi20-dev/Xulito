const PiranhaMessage = require('../../../PiranhaMessage')
const LogicSeason = require('../../../../Logic/Home/LogicSeason')
const PlayerDatabase = require('../../../../Database/PlayerDatabase')
const OwnHomeDataMessage = require('../../Server/Home/OwnHomeDataMessage')
const LobbyInfoMessage = require('../../Server/Battle/LobbyInfoMessage')
const MyAllianceMessage = require('../../Server/Alliance/MyAllianceMessage')
const LogicBattleManager = require('../../../../Logic/Battle/LogicBattleManager')

class GoHomeMessage extends PiranhaMessage {
  constructor (bytes, session) {
    super(session)
    this.id = 14101
    this.version = 0
    this.stream = this.DataStream.getByteStream(bytes)
  }

  async decode () {

  }

  async execute () {
    if (!this.session.player) return

    LogicBattleManager.endBattle(this.session, false) // leaving a battle

    if (LogicSeason.checkCoinsBooster(this.session.player)) PlayerDatabase.save(this.session.player)

    await new OwnHomeDataMessage(this.session).send()
    await new MyAllianceMessage(this.session).send()
    await new LobbyInfoMessage(this.session).send()
  }
}

module.exports = GoHomeMessage
