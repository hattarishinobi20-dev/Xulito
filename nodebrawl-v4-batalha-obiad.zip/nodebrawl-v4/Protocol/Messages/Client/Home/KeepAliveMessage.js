const PiranhaMessage = require('../../../PiranhaMessage')
const KeepAliveOkMessage = require('../../Server/Home/KeepAliveOkMessage')
const MyAllianceMessage = require('../../Server/Alliance/MyAllianceMessage')
const LogicSeason = require('../../../../Logic/Home/LogicSeason')
const PlayerDatabase = require('../../../../Database/PlayerDatabase')

class KeepAliveMessage extends PiranhaMessage {
  constructor (bytes, session) {
    super(session)
    this.id = 10108
    this.version = 0
    this.stream = this.DataStream.getByteStream(bytes)
  }

  async decode () {

  }

  async execute () {
    await new KeepAliveOkMessage(this.session).send()

    if (this.session.player) await new MyAllianceMessage(this.session).send() // like Obiad: alliance header refreshed on every keep alive

    // coins booster expired while online: notification is shown on the next OwnHomeData
    if (this.session.player && LogicSeason.checkCoinsBooster(this.session.player)) PlayerDatabase.save(this.session.player)
  }
}

module.exports = KeepAliveMessage
