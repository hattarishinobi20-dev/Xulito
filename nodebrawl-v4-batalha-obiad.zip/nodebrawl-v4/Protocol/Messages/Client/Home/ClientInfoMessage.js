const PiranhaMessage = require('../../../PiranhaMessage')

class ClientInfoMessage extends PiranhaMessage {
  constructor (bytes, session) {
    super(session)
    this.id = 10177
    this.version = 0
    this.stream = this.DataStream.getByteStream(bytes)
  }

  async decode () {
    this.info = this.stream.readString()
  }

  async execute () {
    this.session.log(`Client info: ${this.info}`)
  }
}

module.exports = ClientInfoMessage
