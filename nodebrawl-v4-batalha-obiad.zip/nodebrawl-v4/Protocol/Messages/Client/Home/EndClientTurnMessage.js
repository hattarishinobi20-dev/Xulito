const PiranhaMessage = require('../../../PiranhaMessage')
const LogicCommandManager = require('../../../../Logic/Command/LogicCommandManager')
const PlayerDatabase = require('../../../../Database/PlayerDatabase')

class EndClientTurnMessage extends PiranhaMessage {
  constructor (bytes, session) {
    super(session)
    this.id = 14102
    this.version = 0
    this.stream = this.DataStream.getByteStream(bytes)
  }

  async decode () {
    this.isCommand = this.stream.readBoolean()
    this.tick = this.stream.readVInt()
    this.checksum = this.stream.readVInt()
    this.commandsCount = this.stream.readVInt()
  }

  async execute () {
    if (!this.session.player) return

    // every command of the turn is handled in order with the Obiad Brawl v4 layout (type + 4 header vints + body);
    // an unknown command type stops the turn because its length is unknown
    for (let i = 0; i < this.commandsCount; i++) {
      const commandType = this.stream.readVInt()
      const Command = LogicCommandManager.createCommand(commandType)

      if (!Command) {
        this.session.log(`Gotcha undefined ${commandType} command!`)
        break
      }

      const CommandInstance = new Command(this.session, this.stream)

      this.session.log(`Gotcha ${commandType} (${CommandInstance.constructor.name}) command!`)

      await CommandInstance.decode()
      await CommandInstance.execute()
    }

    if (this.commandsCount > 0) PlayerDatabase.save(this.session.player)
  }
}

module.exports = EndClientTurnMessage
