const PiranhaMessage = require('../../../PiranhaMessage')
const LogicSeason = require('../../../../Logic/Home/LogicSeason')
const OwnHomeDataMessage = require('../../Server/Home/OwnHomeDataMessage')
const PlayerDatabase = require('../../../../Database/PlayerDatabase')

class GoHomeFromOfflineMessage extends PiranhaMessage {
  constructor (bytes, session) {
    super(session)
    this.id = 14109
    this.version = 0
    this.stream = this.DataStream.getByteStream(bytes)
  }

  async decode () {

  }

  async execute () {
    if (!this.session.player) return

    if (this.session.player.tutorialState < 2) {
      this.session.player.tutorialState++
      PlayerDatabase.save(this.session.player)
    }

    if (LogicSeason.checkCoinsBooster(this.session.player)) PlayerDatabase.save(this.session.player)

    await new OwnHomeDataMessage(this.session).send()
  }
}

module.exports = GoHomeFromOfflineMessage
