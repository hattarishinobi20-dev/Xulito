const PiranhaMessage = require('../../../PiranhaMessage')
const TeamManager = require('../../../../Logic/Team/TeamManager')

/**
 * TeamLeaveMessage (14353)
 */
class TeamLeaveMessage extends PiranhaMessage {
  constructor (bytes, session) {
    super(session)
    this.id = 14353
    this.version = 0
    this.stream = this.DataStream.getByteStream(bytes)
  }

  async decode () {

  }

  async execute () {
    if (!this.session.player) return

    await TeamManager.leave(this.session, TeamManager.LEFT_REASON_LEFT)
  }
}

module.exports = TeamLeaveMessage
