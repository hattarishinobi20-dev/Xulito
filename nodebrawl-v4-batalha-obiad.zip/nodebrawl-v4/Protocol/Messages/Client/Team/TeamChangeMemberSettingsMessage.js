const PiranhaMessage = require('../../../PiranhaMessage')
const TeamManager = require('../../../../Logic/Team/TeamManager')

/**
 * TeamChangeMemberSettingsMessage (14354)
 *
 * Member selected another brawler.
 */
class TeamChangeMemberSettingsMessage extends PiranhaMessage {
  constructor (bytes, session) {
    super(session)
    this.id = 14354
    this.version = 0
    this.stream = this.DataStream.getByteStream(bytes)
  }

  async decode () {
    this.stream.readVInt()
    this.brawlerClassId = this.stream.readVInt() // DataReference (16, brawler)
    this.brawlerId = this.brawlerClassId !== 0 ? this.stream.readVInt() : 0
  }

  async execute () {
    const player = this.session.player

    if (!player) return

    const team = TeamManager.getTeamOfPlayer(player)
    const member = team ? TeamManager.getMember(team, player.lowId) : null

    if (!member) return
    if (!player.brawlers[this.brawlerId]) return this.session.warn(`TeamChangeMemberSettings: brawler ${this.brawlerId} not owned.`)

    member.brawlerId = this.brawlerId

    await TeamManager.refresh(team)
  }
}

module.exports = TeamChangeMemberSettingsMessage
