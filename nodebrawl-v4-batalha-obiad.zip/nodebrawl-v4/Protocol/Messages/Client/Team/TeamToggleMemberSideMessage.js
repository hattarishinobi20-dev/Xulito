const PiranhaMessage = require('../../../PiranhaMessage')
const TeamManager = require('../../../../Logic/Team/TeamManager')
const TeamMessage = require('../../Server/Team/TeamMessage')

/**
 * TeamToggleMemberSideMessage (14357)
 *
 * Sides are not used by the v4 rooms (everyone plays in the same team): only resends the room state.
 */
class TeamToggleMemberSideMessage extends PiranhaMessage {
  constructor (bytes, session) {
    super(session)
    this.id = 14357
    this.version = 0
    this.stream = this.DataStream.getByteStream(bytes)
  }

  async decode () {
    this.stream.readVInt() // Old position
    this.stream.readVInt() // New position
  }

  async execute () {
    const player = this.session.player

    if (!player) return

    const team = TeamManager.getTeamOfPlayer(player)

    if (!team) return

    await new TeamMessage(this.session, team).send()
  }
}

module.exports = TeamToggleMemberSideMessage
