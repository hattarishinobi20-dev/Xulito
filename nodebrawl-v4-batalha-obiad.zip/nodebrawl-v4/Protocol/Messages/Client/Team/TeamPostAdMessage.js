const PiranhaMessage = require('../../../PiranhaMessage')
const TeamManager = require('../../../../Logic/Team/TeamManager')
const AllianceDatabase = require('../../../../Database/AllianceDatabase')
const AllianceManager = require('../../../../Logic/Alliance/AllianceManager')

/**
 * TeamPostAdMessage (14360)
 *
 * Advertise the room to the alliance: a TeamCreated entry (type 77) is added to the alliance stream once.
 */
class TeamPostAdMessage extends PiranhaMessage {
  constructor (bytes, session) {
    super(session)
    this.id = 14360
    this.version = 0
    this.stream = this.DataStream.getByteStream(bytes)
  }

  async decode () {

  }

  async execute () {
    const player = this.session.player

    if (!player || player.allianceId === 0) return

    const team = TeamManager.getTeamOfPlayer(player)
    const alliance = AllianceDatabase.get(player.allianceId)

    if (!team || !alliance) return

    team.advertisedAllianceId = team.advertisedAllianceId ? 0 : alliance.id

    if (team.advertisedAllianceId && !team.advertised) {
      team.advertised = true

      await AllianceManager.addStreamEntry(alliance, { type: 77, playerId: player.lowId, playerName: player.name, playerRole: player.allianceRole, targetId: team.id })
    }

    await TeamManager.refresh(team)
  }
}

module.exports = TeamPostAdMessage
