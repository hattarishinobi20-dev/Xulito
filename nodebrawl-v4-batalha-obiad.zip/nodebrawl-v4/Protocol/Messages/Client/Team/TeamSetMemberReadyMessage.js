const PiranhaMessage = require('../../../PiranhaMessage')
const TeamManager = require('../../../../Logic/Team/TeamManager')

/**
 * TeamSetMemberReadyMessage (14355)
 *
 * When every member is ready the team battle starts.
 */
class TeamSetMemberReadyMessage extends PiranhaMessage {
  constructor (bytes, session) {
    super(session)
    this.id = 14355
    this.version = 0
    this.stream = this.DataStream.getByteStream(bytes)
  }

  async decode () {
    this.isReady = this.stream.readBoolean()
    this.stream.bitOffset = 0
    this.stream.readVInt()
  }

  async execute () {
    const player = this.session.player

    if (!player) return

    const team = TeamManager.getTeamOfPlayer(player)
    const member = team ? TeamManager.getMember(team, player.lowId) : null

    if (!member) return

    member.ready = this.isReady

    await TeamManager.refresh(team)

    if (TeamManager.isEveryoneReady(team)) await TeamManager.startBattle(team)
  }
}

module.exports = TeamSetMemberReadyMessage
