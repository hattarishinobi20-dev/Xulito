const PiranhaMessage = require('../../../PiranhaMessage')
const TeamManager = require('../../../../Logic/Team/TeamManager')
const TeamMessage = require('../../Server/Team/TeamMessage')
const TeamStreamMessage = require('../../Server/Team/TeamStreamMessage')
const TeamErrorMessage = require('../../Server/Team/TeamErrorMessage')

/**
 * TeamCreateMessage (14350)
 */
class TeamCreateMessage extends PiranhaMessage {
  constructor (bytes, session) {
    super(session)
    this.id = 14350
    this.version = 0
    this.stream = this.DataStream.getByteStream(bytes)
  }

  async decode () {
    this.eventSlot = this.stream.readVInt() // Event slot (1-based)
    this.locationId = this.stream.readVInt() // Location index
    this.roomType = this.stream.readVInt()
  }

  async execute () {
    const player = this.session.player

    if (!player) return
    if (TeamManager.getTeamOfPlayer(player)) return new TeamErrorMessage(this.session, TeamManager.ERROR_ALREADY_IN_ROOM).send()

    const team = TeamManager.create(this.session, this.roomType, this.eventSlot, this.locationId)

    TeamManager.addEvent(team, player, TeamManager.EVENT_CREATED, player)

    this.session.log(`Team ${team.id} created (location ${team.locationId}).`)

    await new TeamMessage(this.session, team).send()
    await new TeamStreamMessage(this.session, team).send()
  }
}

module.exports = TeamCreateMessage
