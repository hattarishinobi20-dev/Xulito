const PiranhaMessage = require('../../../PiranhaMessage')
const TeamManager = require('../../../../Logic/Team/TeamManager')

/**
 * TeamChatMessage (14359)
 */
class TeamChatMessage extends PiranhaMessage {
  constructor (bytes, session) {
    super(session)
    this.id = 14359
    this.version = 0
    this.stream = this.DataStream.getByteStream(bytes)
  }

  async decode () {
    this.message = this.stream.readString()
  }

  async execute () {
    const player = this.session.player

    if (!player) return

    const team = TeamManager.getTeamOfPlayer(player)
    const message = (this.message || "").trim().slice(0, 256)

    if (!team || message.length === 0) return

    const entry = TeamManager.addStreamEntry(team, { type: 2, playerId: player.lowId, playerName: player.name, message })

    await TeamManager.pushEntry(team, entry)
  }
}

module.exports = TeamChatMessage
