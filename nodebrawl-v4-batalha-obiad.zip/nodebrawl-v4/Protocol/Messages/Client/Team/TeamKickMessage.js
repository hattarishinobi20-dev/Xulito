const PiranhaMessage = require('../../../PiranhaMessage')
const TeamManager = require('../../../../Logic/Team/TeamManager')

/**
 * TeamKickMessage (14352)
 */
class TeamKickMessage extends PiranhaMessage {
  constructor (bytes, session) {
    super(session)
    this.id = 14352
    this.version = 0
    this.stream = this.DataStream.getByteStream(bytes)
  }

  async decode () {
    this.stream.readVInt() // Target id high
    this.targetId = this.stream.readVInt() // Target id low
  }

  async execute () {
    const player = this.session.player

    if (!player) return

    const team = TeamManager.getTeamOfPlayer(player)

    if (!team) return

    const actor = TeamManager.getMember(team, player.lowId)
    const target = TeamManager.getMember(team, this.targetId)

    if (!target || target.lowId === player.lowId) return
    if (!actor.host) return this.session.warn("TeamKick: only the room creator can kick.")

    await TeamManager.leave(target.session, TeamManager.LEFT_REASON_KICKED, player)
  }
}

module.exports = TeamKickMessage
