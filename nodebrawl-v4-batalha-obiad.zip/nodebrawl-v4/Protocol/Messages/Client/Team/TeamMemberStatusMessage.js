const PiranhaMessage = require('../../../PiranhaMessage')
const TeamManager = require('../../../../Logic/Team/TeamManager')

/**
 * TeamMemberStatusMessage (14361)
 */
class TeamMemberStatusMessage extends PiranhaMessage {
  constructor (bytes, session) {
    super(session)
    this.id = 14361
    this.version = 0
    this.stream = this.DataStream.getByteStream(bytes)
  }

  async decode () {
    this.status = this.stream.readVInt()
  }

  async execute () {
    const player = this.session.player

    if (!player) return

    const team = TeamManager.getTeamOfPlayer(player)
    const member = team ? TeamManager.getMember(team, player.lowId) : null

    if (!member) return

    member.status = this.status

    await TeamManager.refresh(team)
  }
}

module.exports = TeamMemberStatusMessage
