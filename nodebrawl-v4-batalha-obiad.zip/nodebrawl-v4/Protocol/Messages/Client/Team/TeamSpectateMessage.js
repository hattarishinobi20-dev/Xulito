const PiranhaMessage = require('../../../PiranhaMessage')
const TeamManager = require('../../../../Logic/Team/TeamManager')
const TeamMessage = require('../../Server/Team/TeamMessage')
const TeamStreamMessage = require('../../Server/Team/TeamStreamMessage')
const TeamErrorMessage = require('../../Server/Team/TeamErrorMessage')

/**
 * TeamSpectateMessage (14358)
 *
 * Spectating is not supported: joins the room like TeamJoinMessage (Obiad does the same).
 */
class TeamSpectateMessage extends PiranhaMessage {
  constructor (bytes, session) {
    super(session)
    this.id = 14358
    this.version = 0
    this.stream = this.DataStream.getByteStream(bytes)
  }

  async decode () {
    this.stream.readVInt()
    this.teamId = this.stream.readVInt()
    this.stream.readVInt()
  }

  async execute () {
    const player = this.session.player

    if (!player) return

    const team = TeamManager.get(this.teamId)

    if (!team) return new TeamErrorMessage(this.session, TeamManager.ERROR_NOT_FOUND).send()

    const error = TeamManager.join(team, this.session)

    if (error) return new TeamErrorMessage(this.session, error).send()

    await new TeamMessage(this.session, team).send()
    await new TeamStreamMessage(this.session, team).send()

    const entry = TeamManager.addEvent(team, player, TeamManager.EVENT_JOINED, player)

    await TeamManager.pushEntry(team, entry)
    await TeamManager.refresh(team)
  }
}

module.exports = TeamSpectateMessage
