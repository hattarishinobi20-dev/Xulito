const PiranhaMessage = require('../../../PiranhaMessage')
const TeamManager = require('../../../../Logic/Team/TeamManager')

/**
 * TeamTogglePracticeMessage (14356)
 */
class TeamTogglePracticeMessage extends PiranhaMessage {
  constructor (bytes, session) {
    super(session)
    this.id = 14356
    this.version = 0
    this.stream = this.DataStream.getByteStream(bytes)
  }

  async decode () {

  }

  async execute () {
    const player = this.session.player

    if (!player) return

    const team = TeamManager.getTeamOfPlayer(player)

    if (!team) return

    team.practice = !team.practice

    await TeamManager.refresh(team)
  }
}

module.exports = TeamTogglePracticeMessage
