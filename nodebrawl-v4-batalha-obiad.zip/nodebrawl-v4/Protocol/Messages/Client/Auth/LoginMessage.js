const PiranhaMessage = require('../../../PiranhaMessage')
const LogicSeason = require('../../../../Logic/Home/LogicSeason')
const LoginOkMessage = require('../../Server/Auth/LoginOkMessage')
const LoginFailedMessage = require('../../Server/Auth/LoginFailedMessage')
const LoginFailedV4Message = require('../../Server/Auth/LoginFailedV4Message')
const StartLoadingMessage = require('../../Server/Battle/StartLoadingMessage')
const LogicBattleManager = require('../../../../Logic/Battle/LogicBattleManager')
const BanDatabase = require('../../../../Database/BanDatabase')
const Fingerprint = require('../../../../Logic/Server/Fingerprint')
const OwnHomeDataMessage = require('../../Server/Home/OwnHomeDataMessage')
const FriendListMessage = require('../../Server/Home/FriendListMessage')
const LobbyInfoMessage = require('../../Server/Battle/LobbyInfoMessage')
const MyAllianceMessage = require('../../Server/Alliance/MyAllianceMessage')
const AllianceStreamMessage = require('../../Server/Alliance/AllianceStreamMessage')
const TeamManager = require('../../../../Logic/Team/TeamManager')
const TeamMessage = require('../../Server/Team/TeamMessage')
const TeamStreamMessage = require('../../Server/Team/TeamStreamMessage')
const PlayerDatabase = require('../../../../Database/PlayerDatabase')
const LOGIN_FAILED_REASON = require("../../../../Titan/Enums/LoginFailedReason")
const GameConfig = require("../../../../Logic/Server/GameConfig")

class LoginMessage extends PiranhaMessage {
  constructor (bytes, session) {
    super(session)
    this.id = 10101
    this.version = 0
    this.stream = this.DataStream.getByteStream(bytes)
  }

  async decode () {
    this.highId = this.stream.readInt()
    this.lowId = this.stream.readInt()
    this.token = this.stream.readString()
    this.major = this.stream.readInt()
    this.minor = this.stream.readInt()
    this.build = this.stream.readInt()
    this.fingerprintSha = this.stream.readString()
    this.unknownString1 = this.stream.readString()
    this.deviceId = this.stream.readString()
    this.unknownString2 = this.stream.readString()
    this.device = this.stream.readString()
    this.systemLanguage = this.stream.readVInt()
    this.locale = this.stream.readString()
  }

  async execute () {
    if (this.major != GameConfig.clientMajorVersion) {
      const LoginFailed = new LoginFailedMessage(this.session)
      LoginFailed.errorCode = LOGIN_FAILED_REASON.UPDATE
      LoginFailed.reason = "Update required to continue playing."
      return LoginFailed.send()
    }

    let player = PlayerDatabase.loadAccountByToken(this.token)

    if (!player) {
      player = PlayerDatabase.createAccount(this.token)
      this.session.log(`New account created! (ID: ${player.lowId})`)
    }

    // ban lists (Database/banned_acc.json, Database/banned_ip.json)
    const banReason = BanDatabase.check(player.lowId, this.session.ip.split(":")[0])

    if (banReason !== null) {
      this.session.warn(`Login refused: account ${player.lowId} is banned (${banReason}).`)
      return new LoginFailedV4Message(this.session, LOGIN_FAILED_REASON.BANNED, banReason).send()
    }

    // content update (Obiad AssetsServer): client fingerprint sha must match AssetsServer/lastversion.txt
    if (GameConfig.fingerprintCheck && !Fingerprint.isUpToDate(this.fingerprintSha)) {
      this.session.log(`Client content is outdated (${this.fingerprintSha} != ${Fingerprint.sha}), sending update.`)
      const LoginFailed = new LoginFailedV4Message(this.session, LOGIN_FAILED_REASON.PATCH, "")
      LoginFailed.fingerprint = Fingerprint.data
      LoginFailed.contentUrl = this.getContentUrl()
      return LoginFailed.send()
    }

    // same account already online: the previous session is closed and its in-memory state is kept
    for (const other of Array.from(global.sessions.values())) {
      if (other !== this.session && other.player && other.player.lowId === player.lowId && !other.destroyed) {
        other.warn(`Account ${player.lowId} logged in from another connection, closing this one.`)
        player = other.player
        global.destroySession(other, "log", "Client disconnected (logged in elsewhere).")
      }
    }

    const region = this.locale.split("-")[1]
    player.region = region ? region : "EN"

    PlayerDatabase.save(player)

    this.session.player = player
    this.session.loginData = { major: this.major, minor: this.minor, build: this.build }

    if (LogicSeason.checkCoinsBooster(this.session.player)) PlayerDatabase.save(this.session.player)

    await new LoginOkMessage(this.session).send()

    // player disconnected during a battle that is still running: put him back (like Obiad with battleID != 0)
    const battle = LogicBattleManager.rebind(this.session)

    if (battle) {
      this.session.log(`Battle ${battle.id}: player rejoined.`)
      await new StartLoadingMessage(this.session, battle).send()
      return
    }

    await new OwnHomeDataMessage(this.session).send()
    await new AllianceStreamMessage(this.session).send()
    await new MyAllianceMessage(this.session).send()
    await new FriendListMessage(this.session).send()

    // player was in a game room before reconnecting: bind the new session and resend the room
    const team = TeamManager.rebind(this.session)

    if (team) {
      await new TeamMessage(this.session, team).send()
      await new TeamStreamMessage(this.session, team).send()
      await TeamManager.refresh(team)
    }

    await new LobbyInfoMessage(this.session).send()
  }

  /**
   * @returns { String } Assets server url used by the client to download the content update
   */
  getContentUrl () {
    const cfg = GameConfig.assetsServer
    let host = cfg.publicHost || this.session.localAddress || "127.0.0.1"
    const port = cfg.port

    if (host.startsWith("::ffff:")) host = host.substring(7) // ipv4 mapped ipv6
    else if (host.includes(":")) host = `[${host}]` // plain ipv6

    return `http://${host}${port != 80 ? ":" + port : ""}/`
  }

}

module.exports = LoginMessage
