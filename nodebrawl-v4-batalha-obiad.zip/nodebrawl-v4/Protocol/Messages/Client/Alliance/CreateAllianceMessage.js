const PiranhaMessage = require('../../../PiranhaMessage')
const AllianceDatabase = require('../../../../Database/AllianceDatabase')
const AllianceManager = require('../../../../Logic/Alliance/AllianceManager')
const MyAllianceMessage = require('../../Server/Alliance/MyAllianceMessage')
const AllianceEventMessage = require('../../Server/Alliance/AllianceEventMessage')
const AllianceStreamMessage = require('../../Server/Alliance/AllianceStreamMessage')
const PlayerDatabase = require('../../../../Database/PlayerDatabase')

/**
 * CreateAllianceMessage (14301)
 */
class CreateAllianceMessage extends PiranhaMessage {
  constructor (bytes, session) {
    super(session)
    this.id = 14301
    this.version = 0
    this.stream = this.DataStream.getByteStream(bytes)
  }

  async decode () {
    this.name = this.stream.readString()
    this.description = this.stream.readString()
    this.badgeClassId = this.stream.readVInt() // DataReference (8, badge)
    this.badge = this.badgeClassId !== 0 ? this.stream.readVInt() : 0
    this.type = this.stream.readVInt() // 1 open, 2 invite only, 3 closed
    this.requiredTrophies = this.stream.readVInt()
  }

  async execute () {
    const player = this.session.player

    if (!player) return
    if (player.allianceId !== 0 && AllianceDatabase.get(player.allianceId)) return this.session.warn("CreateAlliance: player is already in an alliance.")

    const name = (this.name || "").trim().slice(0, 15)

    if (name.length === 0) return

    const alliance = AllianceDatabase.create(player, {
      name,
      description: (this.description || "").slice(0, 100),
      badge: this.badge,
      type: [1, 2, 3].includes(this.type) ? this.type : 1,
      requiredTrophies: Math.max(this.requiredTrophies, 0)
    })

    player.allianceId = alliance.id
    player.allianceRole = AllianceManager.ROLE_LEADER
    PlayerDatabase.save(player)

    AllianceDatabase.addStreamEntry(alliance, { type: 4, playerId: player.lowId, playerName: player.name, playerRole: player.allianceRole, event: AllianceManager.EVENT_JOINED, targetId: player.lowId, targetName: player.name })

    this.session.log(`Alliance ${alliance.id} "${alliance.name}" created.`)

    await new AllianceEventMessage(this.session, 20).send()
    await new MyAllianceMessage(this.session).send()
    await new AllianceStreamMessage(this.session).send()
  }
}

module.exports = CreateAllianceMessage
