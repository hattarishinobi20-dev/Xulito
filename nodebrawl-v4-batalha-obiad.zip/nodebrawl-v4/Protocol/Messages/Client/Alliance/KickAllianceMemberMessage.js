const PiranhaMessage = require('../../../PiranhaMessage')
const AllianceDatabase = require('../../../../Database/AllianceDatabase')
const AllianceManager = require('../../../../Logic/Alliance/AllianceManager')
const MyAllianceMessage = require('../../Server/Alliance/MyAllianceMessage')
const AllianceEventMessage = require('../../Server/Alliance/AllianceEventMessage')
const AllianceStreamMessage = require('../../Server/Alliance/AllianceStreamMessage')

/**
 * KickAllianceMemberMessage (14307)
 */
class KickAllianceMemberMessage extends PiranhaMessage {
  constructor (bytes, session) {
    super(session)
    this.id = 14307
    this.version = 0
    this.stream = this.DataStream.getByteStream(bytes)
  }

  async decode () {
    this.targetId = this.stream.readLong()
    this.reason = this.stream.readString()
  }

  async execute () {
    const player = this.session.player

    if (!player || player.allianceId === 0) return

    const alliance = AllianceDatabase.get(player.allianceId)
    const member = alliance ? AllianceDatabase.getMember(alliance, this.targetId[1]) : null

    if (!member || member.lowId === player.lowId) return
    if (!AllianceManager.canKick(player.allianceRole, member.role)) return this.session.warn("KickAllianceMember: not allowed.")

    const target = AllianceDatabase.getMemberPlayer(member.lowId)

    AllianceDatabase.removeMember(alliance, target)

    const targetSession = AllianceManager.getSession(member.lowId)

    if (targetSession) {
      await new AllianceEventMessage(targetSession, 100).send()
      await new MyAllianceMessage(targetSession).send()
    }

    await AllianceManager.addEvent(alliance, player, AllianceManager.EVENT_KICKED, target)
    await new AllianceEventMessage(this.session, 70).send()
    await AllianceManager.refreshMembers(alliance)
  }
}

module.exports = KickAllianceMemberMessage
