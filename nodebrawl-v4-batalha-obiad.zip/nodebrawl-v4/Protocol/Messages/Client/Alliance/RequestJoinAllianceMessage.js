const PiranhaMessage = require('../../../PiranhaMessage')
const AllianceDatabase = require('../../../../Database/AllianceDatabase')
const AllianceManager = require('../../../../Logic/Alliance/AllianceManager')
const MyAllianceMessage = require('../../Server/Alliance/MyAllianceMessage')
const AllianceEventMessage = require('../../Server/Alliance/AllianceEventMessage')
const AllianceStreamMessage = require('../../Server/Alliance/AllianceStreamMessage')

/**
 * RequestJoinAllianceMessage (14317)
 *
 * Join request for invite only alliances: adds a join request entry (type 3) to the alliance stream.
 */
class RequestJoinAllianceMessage extends PiranhaMessage {
  constructor (bytes, session) {
    super(session)
    this.id = 14317
    this.version = 0
    this.stream = this.DataStream.getByteStream(bytes)
  }

  async decode () {
    this.allianceId = this.stream.readLong()
    this.message = this.stream.readString()
  }

  async execute () {
    const player = this.session.player

    if (!player) return

    const alliance = AllianceDatabase.get(this.allianceId[1])

    if (!alliance) return this.session.warn(`RequestJoinAlliance: alliance ${this.allianceId[1]} not found.`)
    if (alliance.type === 3) return this.session.warn("RequestJoinAlliance: alliance is closed.")
    if (alliance.stream.some(e => e.type === 3 && e.playerId === player.lowId && e.event === 1)) return this.session.warn("RequestJoinAlliance: request already pending.")

    await AllianceManager.addStreamEntry(alliance, { type: 3, playerId: player.lowId, playerName: player.name, playerRole: 0, message: (this.message || "").slice(0, 100), event: 1 })
    await new AllianceEventMessage(this.session, 50).send()
  }
}

module.exports = RequestJoinAllianceMessage
