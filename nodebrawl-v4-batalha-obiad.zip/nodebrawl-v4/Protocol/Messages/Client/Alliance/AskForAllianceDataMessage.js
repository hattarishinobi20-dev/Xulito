const PiranhaMessage = require('../../../PiranhaMessage')
const AllianceDatabase = require('../../../../Database/AllianceDatabase')
const AllianceDataMessage = require('../../Server/Alliance/AllianceDataMessage')

/**
 * AskForAllianceDataMessage (14302)
 */
class AskForAllianceDataMessage extends PiranhaMessage {
  constructor (bytes, session) {
    super(session)
    this.id = 14302
    this.version = 0
    this.stream = this.DataStream.getByteStream(bytes)
  }

  async decode () {
    this.allianceId = this.stream.readLong()
  }

  async execute () {
    if (!this.session.player) return

    const alliance = AllianceDatabase.get(this.allianceId[1])

    if (!alliance) return this.session.warn(`Alliance ${this.allianceId[1]} not found.`)

    await new AllianceDataMessage(this.session, alliance).send()
  }
}

module.exports = AskForAllianceDataMessage
