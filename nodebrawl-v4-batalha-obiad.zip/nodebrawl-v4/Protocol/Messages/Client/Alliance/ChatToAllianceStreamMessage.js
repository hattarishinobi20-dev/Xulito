const PiranhaMessage = require('../../../PiranhaMessage')
const AllianceDatabase = require('../../../../Database/AllianceDatabase')
const AllianceManager = require('../../../../Logic/Alliance/AllianceManager')

/**
 * ChatToAllianceStreamMessage (14315)
 */
class ChatToAllianceStreamMessage extends PiranhaMessage {
  constructor (bytes, session) {
    super(session)
    this.id = 14315
    this.version = 0
    this.stream = this.DataStream.getByteStream(bytes)
  }

  async decode () {
    this.message = this.stream.readString()
  }

  async execute () {
    const player = this.session.player

    if (!player || player.allianceId === 0) return

    const alliance = AllianceDatabase.get(player.allianceId)
    const message = (this.message || "").trim().slice(0, 256)

    if (!alliance || message.length === 0) return

    await AllianceManager.addStreamEntry(alliance, { type: 2, playerId: player.lowId, playerName: player.name, playerRole: player.allianceRole, message })
  }
}

module.exports = ChatToAllianceStreamMessage
