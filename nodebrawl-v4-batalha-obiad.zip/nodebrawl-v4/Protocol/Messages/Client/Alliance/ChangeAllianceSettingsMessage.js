const PiranhaMessage = require('../../../PiranhaMessage')
const AllianceDatabase = require('../../../../Database/AllianceDatabase')
const AllianceManager = require('../../../../Logic/Alliance/AllianceManager')
const MyAllianceMessage = require('../../Server/Alliance/MyAllianceMessage')
const AllianceEventMessage = require('../../Server/Alliance/AllianceEventMessage')
const AllianceStreamMessage = require('../../Server/Alliance/AllianceStreamMessage')

/**
 * ChangeAllianceSettingsMessage (14316)
 */
class ChangeAllianceSettingsMessage extends PiranhaMessage {
  constructor (bytes, session) {
    super(session)
    this.id = 14316
    this.version = 0
    this.stream = this.DataStream.getByteStream(bytes)
  }

  async decode () {
    this.description = this.stream.readString()
    this.badgeClassId = this.stream.readVInt()
    this.badge = this.badgeClassId !== 0 ? this.stream.readVInt() : 0
    this.type = this.stream.readVInt()
    this.requiredTrophies = this.stream.readVInt()
  }

  async execute () {
    const player = this.session.player

    if (!player || player.allianceId === 0) return
    if (![AllianceManager.ROLE_LEADER, AllianceManager.ROLE_CO_LEADER].includes(player.allianceRole)) return this.session.warn("ChangeAllianceSettings: not allowed.")

    const alliance = AllianceDatabase.get(player.allianceId)

    if (!alliance) return

    alliance.description = (this.description || "").slice(0, 100)
    alliance.badge = this.badge
    alliance.type = [1, 2, 3].includes(this.type) ? this.type : alliance.type
    alliance.requiredTrophies = Math.max(this.requiredTrophies, 0)
    AllianceDatabase.save(alliance)

    await new AllianceEventMessage(this.session, 10).send()
    await AllianceManager.refreshMembers(alliance)
  }
}

module.exports = ChangeAllianceSettingsMessage
