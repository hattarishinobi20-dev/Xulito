const PiranhaMessage = require('../../../PiranhaMessage')
const AllianceDatabase = require('../../../../Database/AllianceDatabase')
const AllianceManager = require('../../../../Logic/Alliance/AllianceManager')
const MyAllianceMessage = require('../../Server/Alliance/MyAllianceMessage')
const AllianceEventMessage = require('../../Server/Alliance/AllianceEventMessage')
const AllianceStreamMessage = require('../../Server/Alliance/AllianceStreamMessage')
const AllianceStreamEntryMessage = require('../../Server/Alliance/AllianceStreamEntryMessage')
const GameConfig = require('../../../../Logic/Server/GameConfig')

/**
 * RespondToAllianceJoinRequestMessage (14321)
 */
class RespondToAllianceJoinRequestMessage extends PiranhaMessage {
  constructor (bytes, session) {
    super(session)
    this.id = 14321
    this.version = 0
    this.stream = this.DataStream.getByteStream(bytes)
  }

  async decode () {
    this.entryId = this.stream.readLong()
    this.stream.bitOffset = 0
    this.isAccepted = this.stream.readBoolean()
  }

  async execute () {
    const player = this.session.player

    if (!player || player.allianceId === 0) return
    if (player.allianceRole === AllianceManager.ROLE_MEMBER) return this.session.warn("RespondToAllianceJoinRequest: not allowed.")

    const alliance = AllianceDatabase.get(player.allianceId)
    const entry = alliance ? AllianceDatabase.getStreamEntry(alliance, this.entryId[1]) : null

    if (!entry || entry.type !== 3 || entry.event !== 1) return

    const target = AllianceDatabase.getMemberPlayer(entry.playerId)

    if (!target) return

    if (this.isAccepted) {
      if (target.allianceId !== 0 && AllianceDatabase.get(target.allianceId)) {
        entry.event = 0
        entry.responderName = player.name
        AllianceDatabase.save(alliance)
        await AllianceManager.broadcast(alliance, session => new AllianceStreamEntryMessage(session, entry))
        return new AllianceEventMessage(this.session, 92).send() // already in an alliance
      }

      if (alliance.members.length >= GameConfig.allianceMaxMembers) return this.session.warn("RespondToAllianceJoinRequest: alliance is full.")
    }

    entry.event = this.isAccepted ? 2 : 0
    entry.responderName = player.name
    AllianceDatabase.save(alliance)

    await AllianceManager.broadcast(alliance, session => new AllianceStreamEntryMessage(session, entry))

    if (!this.isAccepted) return new AllianceEventMessage(this.session, 91).send()

    AllianceDatabase.addMember(alliance, target, AllianceManager.ROLE_MEMBER)

    await new AllianceEventMessage(this.session, 90).send()
    await AllianceManager.addEvent(alliance, target, AllianceManager.EVENT_JOINED, target)

    const targetSession = AllianceManager.getSession(target.lowId)

    if (targetSession) {
      await new MyAllianceMessage(targetSession).send()
      await new AllianceStreamMessage(targetSession).send()
    }

    await AllianceManager.refreshMembers(alliance)
  }
}

module.exports = RespondToAllianceJoinRequestMessage
