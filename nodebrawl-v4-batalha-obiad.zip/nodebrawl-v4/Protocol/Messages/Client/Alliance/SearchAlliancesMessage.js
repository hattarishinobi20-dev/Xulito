const PiranhaMessage = require('../../../PiranhaMessage')
const AllianceDatabase = require('../../../../Database/AllianceDatabase')
const AllianceSearchResultMessage = require('../../Server/Alliance/AllianceSearchResultMessage')

/**
 * SearchAlliancesMessage (14324)
 */
class SearchAlliancesMessage extends PiranhaMessage {
  constructor (bytes, session) {
    super(session)
    this.id = 14324
    this.version = 0
    this.stream = this.DataStream.getByteStream(bytes)
  }

  async decode () {
    this.query = this.stream.readString()
    this.stream.readInt()
    this.stream.readInt()
    this.stream.readInt()
    this.stream.readInt()
    this.stream.readBoolean()
    this.stream.readInt()
    this.stream.readInt()
  }

  async execute () {
    if (!this.session.player) return

    await new AllianceSearchResultMessage(this.session, this.query || "", AllianceDatabase.search(this.query, 30)).send()
  }
}

module.exports = SearchAlliancesMessage
