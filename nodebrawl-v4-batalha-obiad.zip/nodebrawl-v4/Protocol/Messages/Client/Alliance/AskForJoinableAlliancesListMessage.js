const PiranhaMessage = require('../../../PiranhaMessage')
const JoinableAlliancesListMessage = require('../../Server/Alliance/JoinableAlliancesListMessage')

/**
 * AskForJoinableAlliancesListMessage (14303)
 */
class AskForJoinableAlliancesListMessage extends PiranhaMessage {
  constructor (bytes, session) {
    super(session)
    this.id = 14303
    this.version = 0
    this.stream = this.DataStream.getByteStream(bytes)
  }

  async decode () {

  }

  async execute () {
    if (!this.session.player) return

    await new JoinableAlliancesListMessage(this.session).send()
  }
}

module.exports = AskForJoinableAlliancesListMessage
