const PiranhaMessage = require('../../../PiranhaMessage')
const AllianceDatabase = require('../../../../Database/AllianceDatabase')
const AllianceManager = require('../../../../Logic/Alliance/AllianceManager')
const MyAllianceMessage = require('../../Server/Alliance/MyAllianceMessage')
const AllianceEventMessage = require('../../Server/Alliance/AllianceEventMessage')
const AllianceStreamMessage = require('../../Server/Alliance/AllianceStreamMessage')
const GameConfig = require('../../../../Logic/Server/GameConfig')

/**
 * JoinAllianceMessage (14305)
 */
class JoinAllianceMessage extends PiranhaMessage {
  constructor (bytes, session) {
    super(session)
    this.id = 14305
    this.version = 0
    this.stream = this.DataStream.getByteStream(bytes)
  }

  async decode () {
    this.allianceId = this.stream.readLong()
  }

  async execute () {
    const player = this.session.player

    if (!player) return

    const alliance = AllianceDatabase.get(this.allianceId[1])

    if (!alliance) return this.session.warn(`JoinAlliance: alliance ${this.allianceId[1]} not found.`)
    if (player.allianceId !== 0 && AllianceDatabase.get(player.allianceId)) return this.session.warn("JoinAlliance: player is already in an alliance.")
    if (alliance.type !== 1) return this.session.warn("JoinAlliance: alliance is not open.")
    if (alliance.members.length >= GameConfig.allianceMaxMembers) return this.session.warn("JoinAlliance: alliance is full.")
    if (player.trophies < alliance.requiredTrophies) return this.session.warn("JoinAlliance: not enough trophies.")

    AllianceDatabase.addMember(alliance, player, AllianceManager.ROLE_MEMBER)

    await AllianceManager.addEvent(alliance, player, AllianceManager.EVENT_JOINED, player)
    await new AllianceEventMessage(this.session, 40).send()
    await new MyAllianceMessage(this.session).send()
    await new AllianceStreamMessage(this.session).send()
    await AllianceManager.refreshMembers(alliance)
  }
}

module.exports = JoinAllianceMessage
