const PiranhaMessage = require('../../../PiranhaMessage')
const AllianceDatabase = require('../../../../Database/AllianceDatabase')
const AllianceManager = require('../../../../Logic/Alliance/AllianceManager')
const MyAllianceMessage = require('../../Server/Alliance/MyAllianceMessage')
const AllianceEventMessage = require('../../Server/Alliance/AllianceEventMessage')
const AllianceStreamMessage = require('../../Server/Alliance/AllianceStreamMessage')

/**
 * LeaveAllianceMessage (14308)
 */
class LeaveAllianceMessage extends PiranhaMessage {
  constructor (bytes, session) {
    super(session)
    this.id = 14308
    this.version = 0
    this.stream = this.DataStream.getByteStream(bytes)
  }

  async decode () {

  }

  async execute () {
    const player = this.session.player

    if (!player || player.allianceId === 0) return

    const alliance = AllianceDatabase.get(player.allianceId)

    if (alliance) {
      AllianceDatabase.removeMember(alliance, player)

      if (alliance.members.length > 0) {
        await AllianceManager.addEvent(alliance, player, AllianceManager.EVENT_LEFT, player)
        await AllianceManager.refreshMembers(alliance)
      }
    }

    player.allianceId = 0
    player.allianceRole = 0

    await new AllianceEventMessage(this.session, 80).send()
    await new MyAllianceMessage(this.session).send()
  }
}

module.exports = LeaveAllianceMessage
