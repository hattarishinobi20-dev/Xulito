const PiranhaMessage = require('../../../PiranhaMessage')
const AllianceDatabase = require('../../../../Database/AllianceDatabase')
const AllianceManager = require('../../../../Logic/Alliance/AllianceManager')
const MyAllianceMessage = require('../../Server/Alliance/MyAllianceMessage')
const AllianceEventMessage = require('../../Server/Alliance/AllianceEventMessage')
const AllianceStreamMessage = require('../../Server/Alliance/AllianceStreamMessage')

/**
 * ChangeAllianceMemberRoleMessage (14306)
 *
 * Promote / demote a member. Roles: 1 member, 2 leader, 3 elder, 4 co-leader.
 */
class ChangeAllianceMemberRoleMessage extends PiranhaMessage {
  constructor (bytes, session) {
    super(session)
    this.id = 14306
    this.version = 0
    this.stream = this.DataStream.getByteStream(bytes)
  }

  async decode () {
    this.targetId = this.stream.readLong()
    this.role = this.stream.readVInt()
  }

  async execute () {
    const player = this.session.player

    if (!player || player.allianceId === 0) return

    const alliance = AllianceDatabase.get(player.allianceId)
    const member = alliance ? AllianceDatabase.getMember(alliance, this.targetId[1]) : null

    if (!member || member.lowId === player.lowId) return
    if (!AllianceManager.canChangeRole(player.allianceRole, member.role, this.role)) return this.session.warn("ChangeAllianceMemberRole: not allowed.")

    const target = AllianceDatabase.getMemberPlayer(member.lowId)
    const promoted = this.role === AllianceManager.ROLE_LEADER || this.role === AllianceManager.ROLE_CO_LEADER || (this.role === AllianceManager.ROLE_ELDER && member.role === AllianceManager.ROLE_MEMBER)

    AllianceDatabase.setRole(alliance, member.lowId, this.role)

    await AllianceManager.addEvent(alliance, player, promoted ? AllianceManager.EVENT_PROMOTED : AllianceManager.EVENT_DEMOTED, target)

    if (this.role === AllianceManager.ROLE_LEADER) {
      // leadership given away: the old leader becomes co-leader
      AllianceDatabase.setRole(alliance, player.lowId, AllianceManager.ROLE_CO_LEADER)
      await AllianceManager.addEvent(alliance, player, AllianceManager.EVENT_DEMOTED, player)
    }

    await new AllianceEventMessage(this.session, 81).send()

    const targetSession = AllianceManager.getSession(member.lowId)

    if (targetSession) await new AllianceEventMessage(targetSession, 101).send()

    await AllianceManager.refreshMembers(alliance)
  }
}

module.exports = ChangeAllianceMemberRoleMessage
