const net = require('net') // Modules
const StreamEncrypter = require("./Titan/Crypto")
const LogicLaserMessageFactory = require('./Protocol/LogicLaserMessageFactory')
const MessagesHandler = require("./Networking/MessagesHandler")
const PacketFramer = require("./Networking/PacketFramer")
const PatcherServer = require("./Patcher/Server")
const ResourceManager = require("./Titan/ResourceManager")
const LogicConfig = require("./Logic/Server/LogicConfig")
const Storage = require("./Database/Storage")
const PlayerDatabase = require("./Database/PlayerDatabase")
const AllianceDatabase = require("./Database/AllianceDatabase")
const LogicSeason = require("./Logic/Home/LogicSeason")
const TeamManager = require("./Logic/Team/TeamManager")
const Fingerprint = require("./Logic/Server/Fingerprint")
const GameConfig = require("./Logic/Server/GameConfig")
const AssetsServer = require("./AssetsServer/Server")
const Events = require("./Logic/Home/Events")
const V4DataTables = require("./Logic/Data/V4DataTables")
const LogicCommandManager = require("./Logic/Command/LogicCommandManager")

LogicConfig.loadConfig()
require("./Utils/Logger");

const server = new net.Server() // Class inits
const Patcher = new PatcherServer()

const PORT = LogicConfig.port

global.sessions = new Map(); // Sessions

const clearSession = (sessionId) => global.sessions.delete(sessionId) // Clear session

const getLastSessionId = () => { // Get last session ID
  const sessionsIds = Array.from(global.sessions.keys())

  return sessionsIds.length == 0 ? 0 : sessionsIds[sessionsIds.length - 1]
}

const destroySession = (session, logType = "log", reason = "Client disconnected.") => {
  if (!session) return;

  switch (logType) {
    case "log":
      session.log(reason)
      break
    case "warn":
      session.warn(reason)
      break
    case "err":
      session.errLog(reason)
      break
    default:
      session.log(reason)
  }

  session.destroy()
  clearSession(session.id)
}

const getAmountOfIPConnections = (ip) => {
  let amount = 0

  global.sessions.forEach(session => {
    if (session.ip.split(":")[0] == ip) amount++
  })

  return amount
}

global.destroySession = destroySession

ResourceManager.init()
LogicLaserMessageFactory.loadMessages()
Events.init()
TeamManager.init()
Fingerprint.load()
V4DataTables.init()
LogicCommandManager.loadCommands()

server.on('connection', async (session) => {
  const sessionIp = session.remoteAddress.split(':').slice(-1)
  if (LogicConfig.session.maxConnections != 0 && global.sessions.size >= LogicConfig.session.maxConnections || 
    LogicConfig.session.maxConnectionsPerIP != 0 && getAmountOfIPConnections(sessionIp) >= LogicConfig.session.maxConnectionsPerIP) {
    return session.destroy()
  }

  session.setNoDelay(true)
  session.setTimeout(LogicConfig.session.timeoutSeconds * 1000)

  session.ip = sessionIp + `:${session.remotePort}`;

  session.log = (text) => Client(session.ip, text)
  session.warn = (text) => ClientWarn(session.ip, text)
  session.errLog = (text) => ClientError(session.ip, text)

  session.crypto = LogicConfig.crypto.activate ? new StreamEncrypter(LogicConfig.crypto.type) : null

  session.id = getLastSessionId() + 1

  global.sessions.set(session.id, session)

  session.log(`A wild connection appeard! (SESSIONID: ${session.id})`)
  
  const MessageHandler = new MessagesHandler(session)

  const framer = new PacketFramer(session, MessageHandler)
  session.framer = framer
  session.queue = framer

  session.on('data', (bytes) => framer.push(bytes))

  session.on('close', () => framer.close())

  session.on('end', async () => {
    return destroySession(session, "log", "Client disconnected.")
  })

  session.on('error', async error => {
    if (error.message.includes("ECONNRESET")) {
      return destroySession(session, "log", "Client disconnected.")
    }

    try {
      destroySession(session, "err", "A wild error!")
      
      return console.error(error)
    } catch (e) { }
  })

  session.on('timeout', async () => {
    return destroySession(session, "warn", "Session timeout was reached.")
  })
})

server.once('listening', () => {
  ServerLog(`${LogicConfig.serverName} started on ${PORT} port!`)
  if (LogicConfig.patcher.enabled) {
    Patcher.start();
  }

  if (GameConfig.assetsServer.enabled) {
    new AssetsServer().start()
  }

  if (LogicConfig.logger.enableAdminConsole) {
    rl.setPrompt("> ")
    rl.prompt();

    global.rl.on('close', () => {
      Warn('Server stopped!');
      server.close();
      process.exit(0)
    });
  }
})

Storage.init().then(() => {
  PlayerDatabase.init()
  AllianceDatabase.init()
  LogicSeason.init()
  server.listen(PORT)
}).catch(e => {
  Err(`Storage: unable to start (${e.message})`)
  process.exit(1)
})

process.on("uncaughtException", e => Warn(e.stack));

process.on("unhandledRejection", e => Warn(e.stack));
